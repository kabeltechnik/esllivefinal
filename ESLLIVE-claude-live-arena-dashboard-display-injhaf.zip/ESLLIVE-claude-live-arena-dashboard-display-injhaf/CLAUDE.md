# ESL Live-Arena — Projektanweisungen

## Überblick

**regiocom ESL Live-Arena Dashboard** — 100% clientseitiges IIFE-Script, per Browserkonsole (F12) in das Vodafone/regiocom ESL-Portal (PrimeFaces/JSF) injiziert. Kombiniert ESL-Verkaufsdaten mit Ligalisten-Qualitäts-KPIs über Cross-Origin.

**Master ist [`esl_live_arena_v22.js`](esl_live_arena_v22.js)** (~12200 Zeilen, CRLF/Windows). **Aktives Design = DUNKEL** (die Originaldatei des Users: dunkle Karten `#1D1D1D` auf `#121212`, Vodafone-Rot, „Burgeroberung"-Kriegsradar). Ein helles **Vodafone Classic** Theme wurde gebaut, liegt aber nur in der Branch-Historie (Commit `627dee1`) — der User hat sich **bewusst für Dunkel entschieden**. Nicht ungefragt aufhellen; das helle Theme per 3-Wege-Merge reaktivierbar. `esl_live_arena_v21.js` = alter Fallback, NICHT mehr bearbeiten. Satellite: [`kpi_crawler.js`](kpi_crawler.js) (v5, für den Ligalisten-Tab). Mapping: [`Mitarbeiter_IDS_Final_komplett.xlsx`](Mitarbeiter_IDS_Final_komplett.xlsx) (EIN Import; Details unter „Kritische Fallstricke").

**Design-System: [`VODAFONE_DESIGN.md`](VODAFONE_DESIGN.md)** ist verbindlich** — Kern-Token (`--vf-*`), echte Zustands-Semantik (ok=Grün `#008A00`, warn=Amber `#EB9700`/Text `#8F5C00`, breach=Rot `#E60000`), validierte Standort-gebundene Daten-Palette (Dataviz-Checks bestanden: Lightness/Chroma/CVD/Kontrast ≥3:1). Vor UI-Arbeit lesen. Emojis bleiben verboten.

**Projekt-Agent [`.claude/agents/war-engine-dev.md`](.claude/agents/war-engine-dev.md)** — Spezialist für das RC_WAR-Spielmodul (Persona: Ex-Nvidia-Engine-Dev/Gamer). Arbeitet Phase-1-first: erst kritischer Fehler-Audit (Datei:Zeile), dann Ideen, dann Umsetzung. Für alles rund um Radar/Canvas/Sprites/FX diesen Agenten nutzen.

## ⚡ Token-Spar-Regeln (ZUERST lesen)

1. **Immer graphify vor dem Lesen von Source** (Graph in `graphify-out/graph.json`). `graphify explain "<Konzept>"`, `graphify path "<A>" "<B>"`. Nach Code-Änderungen `graphify update .` (nur AST, keine API-Kosten). Rohdatei nur lesen, um konkrete Zeilen zu ändern/debuggen. **In dieser Linux-Cloud-Umgebung ist `graphify` nicht als Befehl installiert** → über `uvx --from graphifyy graphify <cmd>` aufrufen (uv liegt in `/root/.local/bin`). Auf dem Windows-Rechner des Users heißt der Befehl direkt `graphify`.
2. **Projekt-Memory lesen:** `~/.claude/projects/.../memory/MEMORY.md` + `esl-historie-harvester-fix.md` — dort steht die komplette Fix-Historie mit Zeilen-genauen Details. Das spart das Wiederaufrollen.
3. **v22.js NIE komplett lesen** (~12200 Zeilen). Mit `grep -n "funktionsName"` die Stelle finden, dann gezielt `Read` mit offset/limit.
4. **Offline-Testen statt raten:** `test_dashboard_offline.html` speist Fake-Daten ein (kein Portal nötig). Server: `python -m http.server 8412 --bind 127.0.0.1`, dann Browser-Tools auf `http://127.0.0.1:8412/test_dashboard_offline.html`. Nach 6s ist alles bereit; Funktionen sind als `window.rc*` exponiert.
5. **Nach jeder Änderung `node --check esl_live_arena_v22.js`** (syntaxfrei, sekundenschnell).
6. **Echte Testdaten liegen in `Test Excels/`** (ESL-Export, Ligaliste, Dashboard-Report) + Vorlage `../../PIX Excel/PIX_Dashaaaboard_VKD_TEC2.xlsm`. Für Excel-Analyse: SheetJS/`xlsx-js-style` im Scratchpad installieren, nicht neu raten.
7. **Emojis verboten** im Dashboard/Export (Corporate Design). RAF feuert nicht in verborgenen Tabs → im Test `window.rcWarStep(dt)`.

## Datenformate (aus echten Exporten verifiziert)

**ESL-Export (`Export Projektergebnisse`, Blatt `dataTable`, Datum ISO-String):**
`datum | standort | team | vo_nummer | kunde | produktgrupe | produktmerkmal | produkt | ergebnis | anzahl | sis_angesprochen | sis_nicht_moeglich_grund | id`
- `standort` = Kürzel (AL/B/SER/…); `team` = Team-NAME ("Vodafone AL 02"), NICHT die Nummer (Nummer kommt aus dem Mapping).
- `ergebnis`: "angenommen" = Verkauf; "nicht möglich" = kein Verkauf. `produktmerkmal` "nicht BCR" → nicht BCR-relevant.

**Ligaliste `get_data.rb` (der zuverlässige Weg):** Die Tabelle lädt per POST an `.../dist/scripts/get_data.rb` (Body u.a. `script_id_secure`=Token, `user_id`, `loc_inlist`, `figure_list`, `daterange`, `interval`, `show_ccsid=1`, `table_type=2`). Der Crawler hookt fetch+XHR (`window.__rcLastGetData`) und stellt die Anfrage nach.
- **`daterange`-Werte** (aus dem echten Markup): `user_defined` · `intraday` · `yesterday` · `current_week` · `current_month` · `current_quarter` · `last_week` · `last_month` · `last_quarter`. **`interval`:** `cumulate` · `day` · `week` · `month`.
- **Start-Harvest = `current_month` + `interval=day`** — EIN Request, ganzer Monat auf Tagesbasis, Antwort hat die Datum-Spalte. Das ersetzt das frühere Durchprobieren von `last_week`/`current_week`/3× `user_defined` (samt Montag-Falle: `current_week` hat am Wochenanfang nur heute).
- **`startdate`/`enddate` nur bei `user_defined`**, Format **`YYYYMMDD`** (`20260725`) — ISO/DE sind nur Fallback und liefern beim Oracle-Backend meist 500er.
- **`intraday` immer mit `interval=cumulate`** (ein Tag hat keine Tages-Aufschlüsselung).

**Ligaliste-Excel-Struktur:** Zeile0 "Ligalisten", Zeile1 Gruppenzeile mit Zeitraum, Zeile2 Leaf-Header (`Zeile|Dienstleister|Standort|Team|Agentenname|CCS-ID|Zähler|Nenner|Kennzahl…`), Daten ab Zeile3. IST-Kennzahlen kommen bereits in Prozent (88,5 = 88,5 %).

## Kernkonzepte

- **VO-Nummer** = ESL-Agent-Key. **CCS-ID** = Ligalisten-Key (`user_id=`/CCS-Spalte). Join via CCS-ID, Fallback `rcNormName` (lowercase, Umlaute ersetzt, Tokens sortiert).
- **Ansprache** = Angebot gemacht (angenommen/offen/abgelehnt); "nicht möglich" zählt nicht. `_anspIds`-Set gegen Doppelzählung. **Ansprache-Quote = ESL-Ansprachen / Liga-Calls × 100.**
- **CR immer auf LIGA-Call-Basis** (ESL-Kontakte sind unvollständig getrackt, ~12 %). CR-BCR = BCR / Liga-Calls.
- **Liga-Scope IMMER zentral (Z. ~167ff.):** `rcLigaMeta(k)` → `{std, team, stack}` einer Liga-Zeile (Standort/Team **immer über `ccsMap`**, Roh-Werte nur als Fallback) · `rcActiveScope()` → aktive Filter · `rcLigaInScope(k, scope)` → Scope-Test. **Nie selbst auf `k.standort`/`k.team` filtern** (siehe Fallstrick „Liga-Team ist eine NUMMER").
- **`rcLigaAgg()`** = zentrale Liga-Call-Aggregation auf Basis von `rcLigaInScope`, **respektiert Standort+Team+Stack-Filter**. Immer diese nutzen, nicht selbst filtern.
- **Stacks** trennen Geschäftsbereiche (VKD_Tech/MF_CARE/…). Zuordnung Team→Stack via `stackMap`. **Nur VKD-Teams tracken in "Export Projektergebnisse"** — andere Alanya-Stacks (MF_CARE/VUM…) liefern KEINE ESL-Zeilen (Datenlage, kein Bug).
- KPI-Ziele: CS ≥90, TNPS ≥70, AHT ≤13min, DDS ≤5, FQ ≥30, AQ ≥85, Calls ≥40, FF7 ≥80 (7-Tage-Verzug).

## Aktueller Stand (v22, Juli 2026)

**4 Seiten** (Auto-Rotation 30s): Arena · Qualität · Radar · Cockpit. Filter: Standort + Team + Stack (`rcStandortFilter`/`rcTeamFilter`/`rcStackFilter`).

**Auto-Wechsel (Wandmonitore):** Header-Button `rcBtnAutoRot` schaltet eine Seiten-Rotation ein/aus (Default alle 60 s, `window.rcAutoRotSec` justierbar). Rotation läuft über die konfigurierbare Liste `window.rcAutoRotPages` (Default `['arena','radar']`); zweiter Button `rcBtnAutoRotQuali` („+ Qualität") schiebt `'quali'` zwischen Arena und Radar bzw. entfernt es — auch während laufender Rotation sicher. Konsolen-Handles: `rcSetAutoRot(true/false)`, `rcAutoRotToggleQuali()`. Timer `rcAutoRotInterval` hängt in der Clean-State-Aufräumliste (Re-Inject-sicher). Aktiv-Zustand via CSS `.rc-btn-on`.

**Detail-Modals** (Klick-Delegation über `data-rc-vo/-ccs/-team/-std`): `rcOpenAgentDetail/rcOpenTeamDetail/rcOpenStandortDetail` — zeigen KIP-BNT + MOBILFUNK-BNT prominent (Kacheln + KIP|MOB-Tabellenspalten), alle Liga-KPIs, Wochentrend-Charts. `rcOpenCompare` = Tagesvergleich.

**Trend-Historie (unabhängig, wächst selbst):**
- ESL: `rcEslHistory[tag]` = Tages-Aggregat (bcr/kontakte/byStd/byAgent). **Selbst-Archivierung** speichert Heute-Stand bei jedem Parse. Bereichs-Harvest `rcFetchRangeViaUI(von,bis)` treibt ECHTE DOM-Felder + „Liste aktualisieren"-Klick (Server-Commit), stellt danach auf HEUTE zurück. Debug: `rcEslDebugRange('01.07.2026','13.07.2026')`.
- Liga: `rcLigaHistory[tag].byAgent[ccsId]`. Crawler v5 holt beim Start EINMAL `current_month`+`interval=day` via get_data.rb, danach nur noch Intraday alle 10 Min. Debug: `rcCrawlerHarvestMonth()`, `rcCrawlerWeekRaw('current_month')`.

**Action-Radar (Gamification) — „Burgeroberung / Schlacht um Europa":** Canvas-2D-Engine `RC_WAR` (kein CDN), bewusst DUNKLE Kampfbühne (vom User als „TV-Bild"-Kontrast gewollt — hell ist NUR der Standard-Rahmen drumherum). `rcRadarPing`→`rcWarSpawn`: mob=Ritter (−70 HP), kip=Katapult (−100 HP), fibDsl/ptv/VVL je eigene Einheit; Burgen haben HP-Balken, Ziel = Feindburg auf 0 HP (`FREIKAUF` bei 1 KIP+1 MOB). Qualität=Verteidigung (CS≥90), Lagebericht-Banner, „Held des Tages", Kriegsrat, Tageswertung (KIP|MOB|HP). `rcWar.unitScale`/`baseScale`. Tages-Replay aus `rcAllSales`. Kern-Funktionen: `rcWarKrieger`, `rcWarCinema`, `rcWarDrawHud`, `rcWarDrawGoldAura`, `rcHeroCallList`, `RC_WAR_REGIONS`/`RC_WAR_POS` (Reichsgebiete-Karte).
- **KEIN Skin-System im Master.** Ein experimenteller Vodafone/Classic-Skin (`RC_WAR_SKINS`, `rcWarSkin`) existiert nur in der Branch-Historie (Commit `612f9f8`, gegen eine ältere/kleinere RC_WAR-Version) — NICHT in dieser Datei. Falls gewünscht, muss er gegen die aktuelle „Burgeroberung"-Struktur neu portiert werden (`war-engine-dev`-Agent).
- **League-Modus (RC_LG, ~Z. 4050+):** eigener Vollbild-Stadion-Renderer (darf als „TV-Bild" dunkel bleiben).

**Excel-Export (`rcExportReport`, 9 Blätter):** Blätter 1-2 = **1:1-Nachbau der Vorlage `PIX_Dashaaaboard_VKD_TEC2.xlsm`** ("Aktueller Stand" + "Bewertungslogik", Farben/Skalen/Merges direkt aus der .xlsm extrahiert). Danach Struktur/Liga Standorte/Liga Teams/Standorte/Stacks/Teams/Agenten. Styling via `xlsx-js-style` (CDN), Fallback ohne Farben.

## Kritische Fallstricke (hart erarbeitet — NICHT erneut hineinlaufen)

- **xlsx-js-style numFmt-Leak:** Der Writer MUTIERT `cell.s`. NIE geteilte Style-Objekte an Zellen hängen — pro Zelle klonen (`Object.assign({}`) + `numFmt` explizit setzen. Sonst leakt %-Format auf Stückzahlen ("101"→"10100,0%").
- **Excel-Format `0.0" %"` multipliziert NICHT** (anders als `0.0%`). Kennzahlen ROH schreiben (88,5 → "88,5 %"), nicht /100.
- **JSF/PrimeFaces Export ignoriert geposteten Datums-Override** — er exportiert den serverseitig zuletzt BESTÄTIGTEN Zustand. Erst echten „Liste aktualisieren"-Klick (`j_idt639`), dann Export (`j_idt640`). Danach MUSS auf heute zurückgestellt werden (echter Klick), sonst zählt der Live-Poll Wochensummen als „heute" (der "5000-TX"-Bug).
- **Mehrtages-Schutz:** `processDataStream` zählt strikt nur Zeilen mit heutigem Datum; Fremdtage → `rcEslHistory` + Warn-Banner (`rcMultiDayWarn`).
- **Ligaliste-Select+OK schaltet Intervall serverseitig NICHT** — nur der direkte get_data.rb-Request wirkt.
- **`#interval-list` ist DYNAMISCH — „Tag" existiert bei Intraday gar nicht (Befund 27.07.):** Solange `daterange` auf `intraday`/`yesterday` steht, enthält das Intervall-Dropdown NUR `<option value="cumulate">`. Erst wenn ein mehrtägiger Zeitraum gewählt ist, hängt die Ligaliste `day`/`week`/`month` nach — und zwar **asynchron**. Der Crawler setzte früher erst das Intervall, dann den Zeitraum → `setSelect(iSel,'day')` lief ins Leere, es blieb bei `cumulate`, die Antwort hatte keine Datum-Spalte und der ganze Tages-Harvest fiel durch alle Fallbacks. **Regel: Zeitraum ZUERST, dann per `waitForIntervalDay()` auf „Tag" warten.** Beim Zurückstellen umgekehrt (erst Intervall, dann Zeitraum), sonst wirft die Seite die `day`-Option raus, bevor der Reset greift.
- **Kumulierte Zeilen ohne Datum NIE als „heute" ablegen:** Greift `interval=day` nicht, liefert das Portal je Agent EINE Zeile mit Monatssumme. Der alte DOM-Fallback schrieb die per `datumKey(...) || dayKey(new Date())` auf heute — Monatssummen als Tageswert. Jetzt werden sie verworfen und gezählt gemeldet.
- **Re-Inject:** Clean-State-Block zerstört alle Chart-Instanzen + `cancelAnimationFrame(rcWarRaf)` + entfernt `rcDetailModal`.
- **Mapping-Update:** `rcResetMapping()` in der Konsole + xlsx neu importieren (ganz altes Mapping hat kein `ccsId`/`stackMap`).
- **ZWEI Mapping-Formate** (beide werden von `verarbeiteMappingExcel` unterstützt): ALT = 4 Blätter (`Mitarbeiter_ID_Und_Namen` | `Stacks_Und_Die_Teams` | `Standorte`), eine VO je Zeile, Team = Nummer (`21105083`). NEU (`Mitarbeiter_IDS_Final.xlsx`, vorher `..._DIE RICHTIGEN.xlsx`) = EIN Blatt `Daten`: `Standort|Team|CCS_User|Namen|Stack|VO_ID1..VO_ID4` — Stack als SPALTE, mehrere VOs je Zeile, Team = Name (`VKD-TECH-83`). Der Parser darf `wb.SheetNames[1]` NICHT blind als Standorte-Blatt nehmen (Ein-Blatt-Datei!) und muss VO-Spalten per Regex `/^vo[_-]?(nummer|id)?\d*$/` sammeln.
- **Kopfzeile NICHT als Zeile 0 annehmen:** In der Praxis kamen Mapping-Dateien schon mit 1070 leeren Zeilen über der Tabelle an (falsch eingefügter Bereich) → alle Spalten-Indizes -1 → Mapping still leer. `verarbeiteMappingExcel` sucht die Kopfzeile per `findIndex` (`ccs_user`/`namen`/`standort`) und warnt bei Vorlauf.
- **Mapping-Importe MERGEN sich:** Nur die `voMap` wird über Importe hinweg gesammelt (per CCS-ID an die aktuellen Stammdaten gehängt); `ccsMap`/`stackMap` kommen IMMER vom LETZTEN Import. Grund: Würde man die Stammdaten mergen, erschiene ein umbenanntes Team doppelt (`21105083` neben `VKD-TECH-83`) und die Zahlen splitten sich. Reihenfolge daher: erst ALT (VOs), dann NEU (Teams/Stacks).
- **Mapping-Master ist [`Mitarbeiter_IDS_Final_komplett.xlsx`](Mitarbeiter_IDS_Final_komplett.xlsx)** (EIN Import genügt, 16.07.2026 erzeugt): Stammdaten aus `Mitarbeiter_IDS_Final.xlsx` + VO_ID1..8 und fehlende Stacks per CCS-ID aus `../../Alle_Mitarbeiter_ID_Und_Namen_FINAL.xlsx` ergänzt, Stack-Werte auf die 6 sauberen normalisiert. Ergebnis: 875/1160 mit VO, 999/1160 mit Stack. Neu bauen: Skript-Logik siehe unten.
- **Warum die Quelldateien nicht reichen:** `Mitarbeiter_IDS_Final.xlsx` = aktuelle CCS-IDs/Teams/Stacks, aber nur 137/1160 VO-IDs. `Alle_Mitarbeiter_ID_Und_Namen_FINAL.xlsx` = 1026 Agenten ALLE mit VO+Stack, aber ALTE CCS-IDs (nur 845 überlappen), alte Team-Nummern und **verschmutzte Stack-Spalte** (`MF_CARE` neben `MF_Care`, `OneCoax_Tech` = `OneC_Tech`, Sammelwerte wie `OneCoax_Tech/VKD_Care/VKD_Tech/VUM_Tech` → nicht auflösbar, bleiben leer). Join-Brücke ist die CCS-ID; ein Name-Join scheitert (alte Datei hat abgekürzte Namen "Ahmet A.").
- **Restlücken der Komplett-Datei (Datenlage, kein Bug):** 285 Agenten ohne VO (keine Quelle kennt eine) → deren BNT/VVL/Ansprache bleibt leer. 161 Agenten in 22 Teams ohne Stack — ausschließlich Teams mit noch numerischem Namen (`21101003`) in Essen/Neubrandenburg/Sakarya/Berlin/Potsdam; bei aktivem Stack-Filter unsichtbar. **Muster: Stack fehlt genau dort, wo die Team-Umbenennung (`21105083` → `VKD-TECH-83`) noch nicht durchgezogen ist** — bisher nur Alanya/Serres/ADP/Zeitwert migriert.
- **`rcFinalizeAgg` speichert `ccs`/`nm` nur, wenn `voMap[vo]` existiert.** Mit kaputtem Mapping archivierte Vortage sind ccs-los → Vortags-Stand-Export findet keinen Agenten und schreibt überall "Keine". `rcRepairEslHistory()` rüstet bestehende `rcEslHistory` nach (läuft automatisch nach jedem Mapping-Import).
- **Das Team-Dropdown bot fast nur Karteileichen an (Befund 27.07.):** Es wird bewusst aus dem MAPPING befüllt (damit Liga-only-Stacks wählbar bleiben), das Mapping kennt aber weit mehr Teams als je Tag Daten liefern — an echten Daten (12.07.): Alanya **19 Teams, davon 11 mit Daten**, Berlin **11 zu 3**, Potsdam **4 zu 2**. Alphabetisch standen die LEEREN vorn (`MF-CARE-01`, `21102001`, `21103099`), also lief fast jede Team-Auswahl ins Nichts — der Filter selbst war korrekt. `updateTeamFilter` bekommt jetzt eine `Map(team -> {esl, liga})`, sortiert **ESL-Teams → Liga-only → leer** und beschriftet: „(4 Agenten · Liga)" / „(nur Qualitaet, 3 Liga-Agenten)" / „— keine Daten heute". Die Signatur nutzt nur die Datenlage-KLASSE, nicht die Zahlen — sonst würde der Select bei jedem Poll neu gebaut und ein offenes Dropdown zuklappen; reine Zahlenänderungen ziehen die Labels in-place nach.
- **ESL-`vo_nummer` enthält in der Praxis die CCS-ID:** Im echten Export (`ESL_12.07.xlsx`) traf **0 von 507** Zeilen auf die `VO_ID*`-Spalten des Mappings, aber **507 von 507** auf `CCS_User`. Der Join lebt vom Fallback `voMap[voRaw] || ccsMap[voRaw]` in `processDataStream` — den nicht entfernen. Ein ESL-Teamname ist dabei **nicht** 1:1 ein Mapping-Team (`Vodafone AL 06` → `VKD-TECH-82/83/84/86`); deshalb ist das Mapping-Team der Aggregat-Schlüssel, nicht der ESL-Name.
- **Liga-Team ist eine NUMMER, das Dashboard filtert auf den NAMEN (Befund 27.07.):** Ligaliste liefert `Team = "21105083"` und `Standort = "Alanya"`, das Team-Dropdown wird aber aus dem Mapping/ESL mit dem Team-**Namen** (`VKD-TECH-83`) befüllt. Ein roher Vergleich (`k.team === filterTeam`) trifft daher NIE → Qualitäts-Seite blieb bei jeder Team-Auswahl leer, während `rcLigaAgg` (mapping-basiert) korrekt zählte. **Deshalb ausschließlich `rcLigaInScope`/`rcLigaMeta` verwenden.** Betraf: `renderQualitaet` (std+team roh), `rcStandRows` (std roh, team schon gemappt), Tagesvergleich-Live-Fallback (`ligaOf`/`ligaOfDay`, std roh) — alle umgestellt.
- **Leermeldungen müssen ehrlich UND lesbar sein:** `renderAnspFokus` meldete „Stark — alle Agenten machen Ansprachen" in `#0D0D0D` (helles Theme-Ink) auf der dunklen Karte `#1D1D1D` → Kontrast 1,14:1, das Panel wirkte **komplett leer**. Zusätzlich war die Meldung falsch, wenn der Liga-Join gar nicht griff. Jetzt 4 unterscheidbare Zustände (keine Quelle / keine ESL-Agenten im Filter / kein Join → Mapping prüfen / echt stark), Kontrast ≥4,1:1. Gleiche Ursache bei `qKpiDet`/`qKpiKurz`/`qKpiNonTrack` + Detraktoren-Zelle der Qualitäts-Tabelle (Gut-Zustand `#0D0D0D` → `#F5F5F5`).
- **Theme-Migration unvollständig an Detail-Modal-Kacheln „BCR-VVL (Liga)":** regiocom-Pink `#FF679B` hängt noch an Z. ~7359/7488/7597/7833 (`kpiTile`-Aufrufe). Beim nächsten Modal-Touch auf Zustands-/Standort-Token umstellen.
- **Master ist die ECHTE User-Datei (CRLF, ~9500 Z., Commit `b4dda03`ff.), NICHT der frühere Repo-Stand.** Sie enthält die ausgebaute „Burgeroberung" (HP-Mechanik, Kriegsrat, Held des Tages, Reichsgebiete-Karte). Ein früheres Redesign lief versehentlich gegen eine kleinere Repo-Version — das helle Theme wurde per 3-Wege-Merge (`git merge-file`) sauber auf die echte Datei übertragen (Commit `627dee1`). Bei Merges/Ports Zeilenenden beachten (Datei ist CRLF).
- **Radar bewusst dunkel:** Arena/Qualität/Cockpit sind hell (Vodafone Classic); das Radar-Canvas + die Kriegs-Karten (Frontlage/Kriegsrat) bleiben DUNKEL als gewollte Kampfbühne. Nicht „versehentlich" aufhellen.
- **Zwei nicht synchrone Canvas-Renderer:** Burg-Modus (`rcWarDraw`) und League-Modus (`rcLeagueTick`, ~Z. 4050+) haben EIGENE Zeichenroutinen. Sprite-Änderungen im einen wirken NICHT im anderen; nur `rcWarResize`/`RC_WAR.view`/`classify` sind geteilt.

## Funktions-Landkarte (grep-Anker in v22.js)

`processDataStream` (Live-Parse+KPIs) · `rcLigaMeta`/`rcActiveScope`/`rcLigaInScope` (Liga-Scope, zentral) · `rcLigaAgg` (gefilterte Liga-Calls) · `rcKpiForAgent` (CCS/Name-Join) · `zielColor` (KPI-Ampel grün/amber/rot — zentraler Farb-Hebel) · `renderQualitaet`/`renderCockpit`/`renderRadar`/`renderMarquee` · `rcBuildInsights` (Vertriebs-Blocker WQ/AHT/ACW/AQ) · `rcExportReport` (Excel) · `rcHarvestEslHistory`/`rcFetchRangeViaUI`/`rcAggregateMultiDayBuffer`/`rcRowDayKey` (ESL-Historie) · `rcOpenAgentDetail`/`rcOpenTeamDetail`/`rcOpenStandortDetail`/`rcOpenCompare` (Modals) · `RC_WAR`/`rcWarSpawn`/`rcWarStep`/`rcWarKrieger`/`rcWarCinema`/`rcWarDrawHud`/`rcWarDrawGoldAura`/`rcHeroCallList` (Action-Radar „Burgeroberung").

## Start (voll automatisiert)

**[`ESL_Start.cmd`](ESL_Start.cmd) doppelklicken** — selbstenthaltend (der PowerShell-Teil steckt hinter dem Marker `#PSSTART` in derselben Datei). Startet Edge mit dem DevTools-Protokoll auf Port 9222 und einem **eigenen Profil** (Ordner `EdgeProfil` daneben — überlebt Citrix), klinkt [`esl_autopilot.user.js`](esl_autopilot.user.js) per `Page.addScriptToEvaluateOnNewDocument` ein und reicht Dashboard, Crawler **und die Mapping-Excel** als `window.__rcFiles` mit. Im Ordner müssen liegen: `esl_autopilot.user.js` · `esl_live_arena_v22.js` · `kpi_crawler.js` · `Mitarbeiter_IDS_Final_komplett.xlsx` (+ optional `croco_crawler.js`).

- **[`ESL_Start.ps1`](ESL_Start.ps1) wird AUS der `.cmd` erzeugt** (Kopfzeile sagt es). Änderungen immer in der `.cmd` machen — die `.ps1` war schon einmal die ältere Fassung und schleppte einen längst behobenen Fehler mit.
- **Mapping ohne Datei-Dialog:** die `.cmd` liest die Mitarbeiter-Excel binär und schickt sie als Base64 in `__rcFiles.mapping`; `rcAutoMapping()` importiert sie beim Start, wenn noch kein Mapping da ist. Zusätzlich sichert jeder manuelle Import die Datei unter `rcWcaMappingXlsx`. Grund: Citrix leert den Browser-Speicher, danach musste die Excel **jedes Mal** von Hand gewählt werden.
- **KPI-Quelle startet das Dashboard selbst:** `rcAutoKpiQuelle()` öffnet 12 s nach dem Start die Ligaliste, falls bis dahin keine Liga-Daten da sind (`rcAutoKpiOff = true` schaltet es ab). Vorher hing das allein am `KPI`-Knopf bzw. am PowerShell-Schritt 9 — blieb der aus, lief das Dashboard dauerhaft ohne Liga-Zahlen, ohne jede Fehlermeldung.
- **`rcOpenKpiQuelle()` darf NIE `alert()` benutzen:** ein offener Dialog lässt jedes `Runtime.evaluate` der Fernsteuerung hängen und blockiert den ganzen Starter. Stattdessen Rückgabewert `true/false` + `rcKpiRetryBeiGeste()`, das den Popup-Blocker aussitzt und beim nächsten echten Klick/Tastendruck erneut öffnet (Chromium verlangt „sticky user activation" für `window.open`).
- **Die Ligaliste MUSS aus dem Dashboard heraus geöffnet werden** (`window.open`), sonst ist `window.opener` null — und das ist der einzige Rückkanal, den der Crawler cross-origin hat (BroadcastChannel wirkt nur innerhalb eines Origins, `esl.regiocom.net` ≠ `ccs.vodafone.de`). Ein per DevTools angelegter Tab hat keinen opener.
- Der Autopilot kennt zwei Betriebsarten: als Userscript (Tampermonkey) oder per Einspielung durch den Starter; `window.__rcAutoPilotV2` verhindert Doppelstarts. Konsole: `rcAutoStatus()` · `rcAutoReset()` · `rcAutoMail("...")` · `rcAutoOff()`.

## Architektur / Cross-Origin

```
ESL-Portal (esl.regiocom.net / ccs.vodafone.de)
  └── esl_live_arena_v22.js (MASTER, F12-Inject)
        ├── liest Excel-Mapping · pollt ESL-Export alle 20s
        └── empfängt Liga-KPIs via window.opener.postMessage + BroadcastChannel
Ligaliste (ccs.vodafone.de/.../liga_listen.rb)
  └── kpi_crawler.js (SATELLITE, F12-Inject)
        └── get_data.rb-Request · sendet an opener + BroadcastChannel
```
Primärkanal `window.opener.postMessage` (Dashboard öffnet Ligaliste → opener gesetzt). Chart.js + SheetJS via CDN. IIFE, kein Build-Step.

**Farben (Vodafone Classic, Details + Palette in `VODAFONE_DESIGN.md`):** Marke Rot `#E60000` / Dunkelrot `#BD0000`; Flächen Weiß `#FFFFFF` auf Leinwand `#F4F4F4`; Text Ink `#0D0D0D` / Sekundär `#333333` / Grau `#666666`; Linien `#EBEBEB`/`#CCCCCC`. Zustände: ok `#008A00`, warn `#EB9700` (Text `#8F5C00`), breach `#E60000`. Standort-Daten-Palette (validiert, entity-gebunden): `#0068A0 #647500 #7D3572 #0090B0 #997A00 #A32EA8`. **Alte regiocom-Farben (`#2C57D2`/`#FF4C02`/`#009864`/`#1F2D3D`/`#FF679B`) sind Legacy** — nicht neu einsetzen (Restvorkommen siehe Fallstricke).
Bewusst dunkel geblieben (Marken-Kontrastmomente): Laufband-Footer, Abschluss-Feier-Bühne, Warn-Balken, League-„TV-Bild".
