(function() {
  // ============================================================
  //  regiocom KPI-Crawler v5 — Ligaliste -> ESL Live-Arena
  //  - parst ALLE Kennzahlen der Ligaliste (ACD, ACW, AHT, ACHT,
  //    Auflegerquote, CS, CS-DDS, TNPS, FQ, TNPS-DDS, First-Time-Fix,
  //    Total-Fix, Promotoren/Detraktoren/Neutrale je CS+TNPS,
  //    Weiterleitungsquote Skill<>) — Header wird dynamisch erkannt
  //  - START: EINMAL "Aktueller Monat" + Intervall "Tag" -> ein einziger
  //    get_data.rb-Request liefert die ganze Monatshistorie auf Tagesbasis
  //  - DANACH: nur noch LIVE (Intraday) alle 10 Minuten
  //  - mit mitgeschnittenem Token laeuft der Live-Takt komplett an der Seite
  //    vorbei: kein Ok-Klick, keine Select-Aenderung, keine Nebenwirkung auf
  //    die Ansicht des Nutzers. Ohne Token: Ok-Klick + DOM-Tabelle lesen.
  //  - speichert je Tag einen Snapshot in localStorage (rcLigaHistory,
  //    max. HISTORY_DAYS Tage) und sendet die Historie mit
  //  - sendet via BroadcastChannel + window.opener.postMessage
  // ============================================================
  const CHANNEL_NAME = 'regiocom_live_arena';
  const POLL_INTERVAL = 600000;   // 10 Minuten — Live-Takt (Ligaliste aktualisiert nicht schneller)
  const REFRESH_WAIT  = 12000;    // Wartezeit nach "Ok"-Klick bis die Tabelle neu gebaut ist
  const HISTORY_DAYS  = 35;       // so viele Tages-Snapshots behalten (Bereichs-Vergleiche!)
  // Start-Harvest: EIN Lauf ueber den aktuellen Monat auf Tagesbasis.
  // Frueher wurden last_week + current_week + drei user_defined-Datumsformate
  // durchprobiert — viel Last, ueberlappende Tage und im DOM-Weg das falsche
  // Intervall (siehe waitForIntervalDay). "Aktueller Monat" deckt alles ab.
  const HARVEST_RANGE = 'current_month';

  const channel = new BroadcastChannel(CHANNEL_NAME);

  // ---------- Original-Datenanfrage der Seite mitschneiden ----------
  // Die Ligaliste laedt ihre Tabelle ueber POST an get_data.rb (siehe DevTools).
  // Wir merken uns die letzte solche Anfrage (mit gueltigem Sicherheits-Token,
  // user_id, figure_list, Standorten) und koennen sie mit anderem Zeitraum/
  // Intervall nachstellen — ohne die Live-Ansicht der Seite zu veraendern.
  window.__rcLastGetData = window.__rcLastGetData || null;
  // Body eines Requests in einen url-encoded STRING normalisieren — egal ob die Seite
  // ihn als String, URLSearchParams oder FormData sendet. (Frueher wurden NUR Strings
  // erfasst -> bei URLSearchParams/FormData blieb der Token unsichtbar = Hauptursache
  // fuer "Keine get_data.rb-Anfrage mitgeschnitten".)
  function rcBodyToString(b){
    try {
      if (b == null) return null;
      if (typeof b === 'string') return b;
      if (typeof URLSearchParams !== 'undefined' && b instanceof URLSearchParams) return b.toString();
      if (typeof FormData !== 'undefined' && b instanceof FormData) {
        const p = new URLSearchParams();
        for (const pair of b.entries()) p.append(pair[0], pair[1]);
        return p.toString();
      }
    } catch(e){}
    return null;
  }
  (function hookRequests(){
    if (window.__rcReqHooked) return;
    window.__rcReqHooked = true;
    const isGetData = u => typeof u === 'string' && u.indexOf('get_data.rb') !== -1;
    // fetch
    const origFetch = window.fetch;
    if (origFetch) window.fetch = function(input, init){
      try {
        const url = (typeof input === 'string') ? input : (input && input.url) || '';
        const s = rcBodyToString(init && init.body);
        if (isGetData(url) && s) window.__rcLastGetData = { url, body: s };
      } catch(e){}
      return origFetch.apply(this, arguments);
    };
    // XMLHttpRequest (falls die Seite XHR statt fetch nutzt)
    const oOpen = XMLHttpRequest.prototype.open, oSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(m, u){ this.__rcUrl = u; return oOpen.apply(this, arguments); };
    XMLHttpRequest.prototype.send = function(b){
      try { const s = rcBodyToString(b); if (isGetData(this.__rcUrl) && s) window.__rcLastGetData = { url: this.__rcUrl, body: s }; } catch(e){}
      return oSend.apply(this, arguments);
    };
  })();

  function cleanText(s){ return (s || '').replace(/\s+/g, ' ').trim(); }
  function pad2(n){ return String(n).padStart(2, '0'); }
  function dayKey(d){ return d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate()); }
  // Datum-Zelle -> 'YYYY-MM-DD' (Portal liefert z.B. "2026/07/13" oder "13.07.2026")
  function datumKey(s){
    const t = cleanText(s); if (!t) return '';
    let m = t.match(/(\d{4})[\/.\-](\d{1,2})[\/.\-](\d{1,2})/);      // YYYY/MM/DD
    if (m) return m[1] + '-' + pad2(m[2]) + '-' + pad2(m[3]);
    m = t.match(/(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{4})/);          // DD.MM.YYYY
    if (m) return m[3] + '-' + pad2(m[2]) + '-' + pad2(m[1]);
    return '';
  }

  // "hh:mm:ss" -> Sekunden
  function timeToSec(s){
    const m = cleanText(s).match(/^(\d{1,2}):(\d{2}):(\d{2})$/);
    if (!m) return null;
    return (+m[1])*3600 + (+m[2])*60 + (+m[3]);
  }

  // ---------- Dynamischer Header-Parser ----------
  function buildColumnMap(table) {
    const headRows = table.querySelectorAll('thead tr');
    if (headRows.length < 2) return null;
    const leafCells = headRows[headRows.length - 1].querySelectorAll('th');
    const leafLabels = Array.from(leafCells).map(th => cleanText(th.textContent));
    const groupCells = headRows[0].querySelectorAll('th');
    const groupPerLeaf = [];
    groupCells.forEach(th => {
      const span = parseInt(th.getAttribute('colspan')) || 1;
      const name = cleanText(th.textContent);
      for (let i = 0; i < span; i++) groupPerLeaf.push(name);
    });
    return { leafLabels, groupPerLeaf };
  }
  function findLeaf(map, label) {
    return map.leafLabels.findIndex(l => l.toLowerCase() === label.toLowerCase());
  }
  // nth = das wievielte passende Vorkommen (Promotoren/Detraktoren/Neutrale
  // gibt es zweimal: erst CS-basiert, dann TNPS-basiert)
  function findKpi(map, group, sub, nth) {
    let seen = 0;
    for (let i = 0; i < map.leafLabels.length; i++) {
      if ((map.groupPerLeaf[i] || '').toLowerCase() === group.toLowerCase() &&
          map.leafLabels[i].toLowerCase() === sub.toLowerCase()) {
        seen++;
        if (seen === (nth || 1)) return i;
      }
    }
    return -1;
  }
  function cellNum(cells, idx) {
    if (idx < 0 || !cells[idx]) return null;
    const t = cleanText(cells[idx].textContent);
    if (t === '') return null;
    const v = parseFloat(t.replace(',', '.'));
    return isNaN(v) ? null : v;
  }
  function cellText(cells, idx) {
    if (idx < 0 || !cells[idx]) return '';
    return cleanText(cells[idx].textContent);
  }

  // ---------- Tabelle parsen (ALLE Kennzahlen) ----------
  // tableEl optional: erlaubt das Parsen einer Tabelle aus einer nachgestellten
  // get_data.rb-Antwort (Wochen-Historie) statt der Live-Tabelle im DOM.
  function parseKpiTable(tableEl) {
    const table = tableEl || document.querySelector('table#result-table');
    if (!table) { console.warn('[KPI Crawler] Tabelle nicht gefunden'); return []; }
    const map = buildColumnMap(table);
    if (!map) { console.warn('[KPI Crawler] Header nicht lesbar'); return []; }

    // Identitaet
    const iName = findLeaf(map, 'Agentenname');
    const iCcs  = findLeaf(map, 'CCS-ID');
    const iStd  = findLeaf(map, 'Standort');
    const iTeam = findLeaf(map, 'Team');
    const iDatum = findLeaf(map, 'Datum'); // nur bei Intervall "Tag" vorhanden

    // Agentenzeiten
    const iAcdKz  = findKpi(map, 'ACD', 'Kennzahl');
    const iAcwKz  = findKpi(map, 'ACW', 'Kennzahl');
    const iAhtKz  = findKpi(map, 'AHT', 'Kennzahl');
    const iAchtKz = findKpi(map, 'ACHT', 'Kennzahl');
    const iCalls    = findKpi(map, 'AHT', 'Nenner');
    const iCallsAcd = findKpi(map, 'ACD', 'Nenner');

    // CAB-Block
    const iAq     = findKpi(map, 'Auflegerquote', 'Kennzahl');
    const iCs     = findKpi(map, 'CS', 'Kennzahl');
    const iCsDds  = findKpi(map, 'CS Deep Detractor %', 'Kennzahl');
    const iTnps   = findKpi(map, 'TNPS', 'Kennzahl');
    const iFq     = findKpi(map, 'TNPS Antwortquote %', 'Kennzahl');
    const iDds    = findKpi(map, 'TNPS Deep Detractor %', 'Kennzahl');
    const iFtf    = findKpi(map, 'First-Time-Fix', 'Kennzahl');
    const iTotFix = findKpi(map, 'Total-Fix', 'Kennzahl');
    // ZAEHLER der Kern-KPIs (fuer den "Aktueller Stand"-Export; Header-Text "Zähler")
    const Z = String.fromCharCode(90, 228) + 'hler'; // "Zähler" — encoding-sicher beim Konsolen-Inject
    const iAqZ  = findKpi(map, 'Auflegerquote', Z);
    const iCsZ  = findKpi(map, 'CS', Z);
    const iTnZ  = findKpi(map, 'TNPS', Z);
    const iFqZ  = findKpi(map, 'TNPS Antwortquote %', Z);
    const iDdsZ = findKpi(map, 'TNPS Deep Detractor %', Z);
    const iFtfZ = findKpi(map, 'First-Time-Fix', Z);

    // NPS-Kategorien: 1. Vorkommen = CS-Basis, 2. Vorkommen = TNPS-Basis
    const iPromCs   = findKpi(map, 'Promotoren', 'Kennzahl', 1);
    const iDetrCs   = findKpi(map, 'Detraktoren', 'Kennzahl', 1);
    const iNeutCs   = findKpi(map, 'Neutrale', 'Kennzahl', 1);
    const iPromTnps = findKpi(map, 'Promotoren', 'Kennzahl', 2);
    const iDetrTnps = findKpi(map, 'Detraktoren', 'Kennzahl', 2);
    const iNeutTnps = findKpi(map, 'Neutrale', 'Kennzahl', 2);

    // Weiterleitungen + Final Fix (falls eingeblendet)
    const iWq  = findKpi(map, 'Weiterl.-Quote Skill<>', 'Kennzahl');
    const iFf7 = findKpi(map, 'Final Fix 7', 'Kennzahl');

    const rows = table.querySelectorAll('tbody tr');
    const kpis = [];

    rows.forEach(row => {
      try {
        const cells = row.querySelectorAll('td');
        if (!cells.length) return;

        let ccsId = iCcs >= 0 ? cellText(cells, iCcs) : '';
        const nameCell = iName >= 0 ? cells[iName] : null;
        const nameLink = nameCell ? nameCell.querySelector('a') : null;
        if (!ccsId && nameLink) {
          const m = nameLink.href.match(/user_id=(\d+)/);
          if (m) ccsId = m[1];
        }
        const agentName = nameLink ? cleanText(nameLink.textContent)
                                   : (nameCell ? cleanText(nameCell.textContent) : '');
        if (!ccsId || !agentName) return;

        const callCount = (iCalls >= 0 ? cellNum(cells, iCalls) : cellNum(cells, iCallsAcd)) || 0;

        kpis.push({
          ccsId, agentName,
          standort: cellText(cells, iStd),
          team:     cellText(cells, iTeam),
          datum:    iDatum >= 0 ? cellText(cells, iDatum) : '',
          callCount,
          // Zeiten (Sekunden)
          acdSec:  iAcdKz  >= 0 ? timeToSec(cellText(cells, iAcdKz))  : null,
          acwSec:  iAcwKz  >= 0 ? timeToSec(cellText(cells, iAcwKz))  : null,
          ahtSec:  iAhtKz  >= 0 ? timeToSec(cellText(cells, iAhtKz))  : null,
          achtSec: iAchtKz >= 0 ? timeToSec(cellText(cells, iAchtKz)) : null,
          // Quoten
          auflegerquote: cellNum(cells, iAq),
          cs:    cellNum(cells, iCs),
          csDds: cellNum(cells, iCsDds),   // CS Deep Detractor %
          tnps:  cellNum(cells, iTnps),
          fq:    cellNum(cells, iFq),      // TNPS Antwortquote %
          dds:   cellNum(cells, iDds),     // TNPS Deep Detractor %
          ftf:      cellNum(cells, iFtf),    // First-Time-Fix
          totalFix: cellNum(cells, iTotFix), // Total-Fix
          ff7:   cellNum(cells, iFf7),
          wq:    cellNum(cells, iWq),      // Weiterl.-Quote Skill<>
          // Zaehler (fuer die "Zaehler"-Spalten im Stand-Export)
          aqZ:   cellNum(cells, iAqZ),
          csZ:   cellNum(cells, iCsZ),
          tnpsZ: cellNum(cells, iTnZ),
          fqZ:   cellNum(cells, iFqZ),
          ddsZ:  cellNum(cells, iDdsZ),
          ftfZ:  cellNum(cells, iFtfZ),
          // NPS-Kategorien (Anzahlen)
          promCs:   cellNum(cells, iPromCs),
          detCs:    cellNum(cells, iDetrCs),
          neutCs:   cellNum(cells, iNeutCs),
          promTnps: cellNum(cells, iPromTnps),
          detTnps:  cellNum(cells, iDetrTnps),
          neutTnps: cellNum(cells, iNeutTnps),
          // Kompatibilitaet: "det" = CS-Detraktoren (wie Crawler v2, 1. Gruppe)
          det: cellNum(cells, iDetrCs),
          timestamp: new Date().toISOString()
        });
      } catch (err) {
        console.error('[KPI Crawler] Fehler beim Parsen einer Zeile:', err);
      }
    });
    return kpis;
  }

  // ---------- Tages-Historie (localStorage am Liga-Origin) ----------
  function loadHistory(){
    try { return JSON.parse(localStorage.getItem('rcLigaHistory') || '{}'); } catch(e){ return {}; }
  }
  function saveHistory(h){
    try {
      Object.keys(h).sort().slice(0, -HISTORY_DAYS).forEach(k => delete h[k]);
      localStorage.setItem('rcLigaHistory', JSON.stringify(h));
    } catch(e){
      // localStorage voll (Quota): aelteste Tage abwerfen und erneut versuchen
      try {
        const keys = Object.keys(h).sort();
        keys.slice(0, Math.max(1, keys.length - 10)).forEach(k => delete h[k]);
        localStorage.setItem('rcLigaHistory', JSON.stringify(h));
        console.warn('[KPI Crawler] localStorage-Quota: Historie auf die letzten 10 Tage gekuerzt.');
      } catch(e2){ console.warn('[KPI Crawler] Historie konnte nicht gespeichert werden:', e2); }
    }
  }
  // Kompakter Tages-Snapshot: Summen je Standort + gesamt (Mittel spaeter daraus)
  // + byAgent: kompakte Tageswerte je CCS-ID — Datenbasis fuer die
  //   Agenten-Wochentrends im Dashboard (Detail-Modal)
  function snapshotOf(kpis){
    const byStd = {}, byAgent = {}, tot = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 };
    kpis.forEach(k => {
      const s = byStd[k.standort] || (byStd[k.standort] = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 });
      [s, tot].forEach(o => {
        o.calls += k.callCount || 0; o.agents++;
        if (k.cs   != null) { o.csSum   += k.cs;     o.csN++; }
        if (k.tnps != null) { o.tnpsSum += k.tnps;   o.tnpsN++; }
        if (k.ahtSec != null && k.ahtSec > 0) { o.ahtSum += k.ahtSec; o.ahtN++; }
        o.det += k.det || 0;
      });
      // kompakt (kurze Schluessel, null-Werte weggelassen) — localStorage-schonend
      const a = { c: k.callCount || 0 };
      if (k.cs   != null) a.cs  = k.cs;
      if (k.tnps != null) a.tn  = k.tnps;
      if (k.ahtSec != null) a.aht = k.ahtSec;
      if (k.fq   != null) a.fq  = k.fq;
      if (k.dds  != null) a.dds = k.dds;
      if (k.auflegerquote != null) a.aq = k.auflegerquote;
      if (k.det) a.det = k.det;
      // fuer den Vortags-"Stand"-Export: FTF + Zaehler der Kern-KPIs
      if (k.ftf  != null) a.ftf = k.ftf;
      if (k.aqZ  != null) a.za = k.aqZ;
      if (k.csZ  != null) a.zc = k.csZ;
      if (k.tnpsZ != null) a.zt = k.tnpsZ;
      if (k.fqZ  != null) a.zf = k.fqZ;
      if (k.ddsZ != null) a.zd = k.ddsZ;
      if (k.ftfZ != null) a.zx = k.ftfZ;
      byAgent[k.ccsId] = a;
    });
    return { byStd, tot, byAgent };
  }
  function storeSnapshot(dateStr, kpis){
    if (!kpis.length) return;
    const h = loadHistory();
    h[dateStr] = snapshotOf(kpis);
    saveHistory(h);
    console.log('[KPI Crawler] Tages-Snapshot gespeichert fuer ' + dateStr + ' (' + kpis.length + ' Agenten)');
  }

  // ---------- Senden (3 Kanaele) ----------
  // liveDaterange sagt dem Dashboard, WAS die payload ist (intraday = echte Live-
  // Daten; yesterday/last_week/... = die Seite steht auf einem anderen Zeitraum).
  function currentDaterange(){
    const dSel = document.getElementById('daterange-list');
    return dSel ? (dSel.value || '') : '';
  }
  function sendKpis(kpis, liveDr) {
    const msg = { type: 'KPI_BATCH', payload: kpis, history: loadHistory(),
                  liveDaterange: (liveDr !== undefined) ? liveDr : currentDaterange() };
    let ziele = [];
    try { channel.postMessage(msg); ziele.push('BroadcastChannel'); } catch(e){}
    try {
      if (window.opener && !window.opener.closed) { window.opener.postMessage(msg, '*'); ziele.push('opener'); }
    } catch(e){}
    try {
      if (window.rcDashWin && !window.rcDashWin.closed) { window.rcDashWin.postMessage(msg, '*'); ziele.push('dashWin'); }
    } catch(e){}
    console.log(`[KPI Crawler] ${kpis.length} Datensaetze gesendet via: ${ziele.join(', ') || 'KEIN ZIEL'}`);
    if (!ziele.includes('opener') && !ziele.includes('dashWin')) {
      console.warn('[KPI Crawler] Kein Dashboard-Fenster erreichbar. Ligaliste bitte ueber den "KPI-Quelle"-Button IM DASHBOARD oeffnen.');
    }
  }

  // ---------- Seite selbst aktualisieren ----------
  function findOkButton(){
    const direct = document.getElementById('ok-button');
    if (direct) return direct;
    const btns = document.querySelectorAll('button, input[type="submit"]');
    for (const b of btns) {
      const t = cleanText(b.innerText || b.value || '');
      if (/^ok$/i.test(t) || (/\bok\b/i.test(t) && t.length <= 6)) return b;
    }
    return null;
  }
  function triggerPageRefresh() {
    const b = findOkButton();
    if (b) { try { b.click(); console.log('[KPI Crawler] Seiten-Refresh ausgeloest'); return true; } catch(e){} }
    console.warn('[KPI Crawler] Kein Ok-Button gefunden — Daten koennten veraltet sein');
    return false;
  }

  // Sorgt dafuer, dass die Original-get_data.rb-Anfrage (mit Sicherheits-Token)
  // MITGESCHNITTEN ist. Ohne diesen Token lehnt der Server jede Anfrage ab, und der
  // Token laesst sich nicht nachbauen — nur abfangen, wenn die SEITE selbst laedt.
  // Deshalb loesen wir bis zu `tries` mal einen echten "Ok"-Klick aus und pollen je
  // Versuch, bis window.__rcLastGetData.body vorliegt. Der Klick laedt nur die
  // aktuelle (Intraday-)Ansicht neu -> keine Stoerung der Live-Sicht.
  async function ensureCapture(tries){
    if (window.__rcLastGetData && window.__rcLastGetData.body) return true;
    tries = tries || 3;
    for (let i = 0; i < tries; i++) {
      triggerPageRefresh();
      for (let w = 0; w < 20; w++) { // bis ~12 s je Versuch, in 600ms-Schritten
        await new Promise(r => setTimeout(r, 600));
        if (window.__rcLastGetData && window.__rcLastGetData.body) {
          console.log('[KPI Crawler] Original-Anfrage (Token) nach ' + (i+1) + '. Ok-Klick gesichert.');
          return true;
        }
      }
    }
    return !!(window.__rcLastGetData && window.__rcLastGetData.body);
  }

  // Geparste Zeilen dem RICHTIGEN Tag zuordnen und speichern.
  // NIE blind als "heute" ablegen: die Seite kann auf "Gestern"/Woche stehen
  // (daterange-Select) — dann landeten Gestern-Werte als Heute im Dashboard.
  function storeByDate(kpis){
    const withDate = kpis.filter(k => datumKey(k.datum));
    if (withDate.length) {
      const byDay = {};
      withDate.forEach(k => { const key = datumKey(k.datum); (byDay[key] || (byDay[key] = [])).push(k); });
      Object.keys(byDay).forEach(key => storeSnapshot(key, byDay[key]));
      return Object.keys(byDay).sort();
    }
    const dr = currentDaterange();
    if (dr === '' || dr === 'intraday' || dr === 'today') { storeSnapshot(dayKey(new Date()), kpis); return [dayKey(new Date())]; }
    if (dr === 'yesterday') { const g = dayKey(new Date(Date.now() - 86400000)); storeSnapshot(g, kpis); return [g]; }
    console.warn('[KPI Crawler] Tabelle zeigt "' + dr + '" ohne Datum-Spalte — Snapshot uebersprungen (kein Tag zuordenbar).');
    return [];
  }

  let busy = false;
  // Live-Takt. Mit mitgeschnittenem Token laeuft das KOMPLETT an der Seite vorbei:
  // ein direkter intraday-Request, kein Ok-Klick, keine Select-Aenderung. Damit
  // kann der Crawler die Ansicht des Nutzers gar nicht mehr verstellen — genau die
  // Nebenwirkung, die frueher "wie von selbst" den Zeitraum umgeschaltet hat.
  // Ohne Token bleibt der bisherige Weg (Ok-Klick + DOM-Tabelle lesen).
  function pollKpis(withRefresh) {
    if (busy) return;
    busy = true;
    const hatToken = !!(window.__rcLastGetData && window.__rcLastGetData.body);

    const viaReplay = async () => {
      const res = await fetchDaterangeKpis('intraday');   // interval=cumulate (ein Tag)
      if (!res.kpis || !res.kpis.length) return false;
      storeByDate(res.kpis);
      sendKpis(res.kpis, 'intraday');
      return true;
    };

    const doParse = async () => {
      try {
        // Bevorzugt: Live-Zahlen direkt anfordern, ohne die Seite anzufassen.
        if (hatToken) {
          try { if (await viaReplay()) return; }
          catch(e){ console.warn('[KPI Crawler] Intraday-Replay fehlgeschlagen, lese DOM-Tabelle:', e); }
        }
        let kpis = parseKpiTable();
        if (!kpis.length) { console.warn('[KPI Crawler] Keine Daten gefunden'); return; }
        storeByDate(kpis);
        const liveDr = currentDaterange();
        sendKpis(kpis, liveDr);
      } finally { busy = false; }
    };

    // Der Ok-Klick ist nur noetig, wenn wir wirklich die DOM-Tabelle brauchen.
    if (withRefresh && !hatToken && triggerPageRefresh()) setTimeout(doParse, REFRESH_WAIT);
    else doParse();
  }

  // Ein Select robust setzen (nativ ODER via Wert; feuert change-Event)
  // Ein Select robust setzen: erst per value, sonst per Label-Regex (falls die
  // Ligaliste-Version andere Werte/Beschriftungen nutzt, z.B. "Tag" vs "taeglich").
  function setSelect(sel, val, labelRe){
    if (!sel) return false;
    let opt = [...sel.options].find(o => o.value === val);
    if (!opt && labelRe) opt = [...sel.options].find(o => labelRe.test((o.textContent || '').trim()));
    if (!opt) { console.warn('[KPI Crawler] Select-Option nicht gefunden: ' + val + (labelRe ? ' / ' + labelRe : '')); return false; }
    sel.value = opt.value;
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    // manche Widgets hoeren zusaetzlich auf input/click der Option
    try { sel.dispatchEvent(new Event('input', { bubbles: true })); } catch(e){}
    return true;
  }

  // Intervall "Tag" setzen — DER kritische Punkt im UI-Weg.
  // Solange der Zeitraum auf "Intraday" steht, hat #interval-list NUR die Option
  // "kumuliert"; "Tag"/"Kalenderwoche"/"Monat" haengt die Ligaliste erst nach,
  // NACHDEM ein mehrtaegiger Zeitraum gewaehlt wurde. Wer (wie bisher) erst das
  // Intervall und dann den Zeitraum setzt, waehlt ins Leere: es bleibt bei
  // "kumuliert", die Antwort hat keine Datum-Spalte und der ganze Tages-Harvest
  // laeuft ins Nichts. Also: Zeitraum zuerst, dann hier auf "Tag" WARTEN.
  async function waitForIntervalDay(iSel, maxMs){
    if (!iSel) return false;
    const bis = maxMs || 6000;
    for (let t = 0; t < bis; t += 250) {
      if ([...iSel.options].some(o => o.value === 'day')) {
        const ok = setSelect(iSel, 'day', /^tag$/i);
        if (ok) return true;
      }
      await new Promise(r => setTimeout(r, 250));
    }
    console.warn('[KPI Crawler] Intervall "Tag" erschien nicht in der Auswahl — Zeitraum zuerst setzen. Tages-Aufschluesselung nicht moeglich.');
    return false;
  }

  // ---------- Tabelle aus einer Text-/JSON-Antwort ziehen ----------
  // get_data.rb liefert je nach Modus HTML (Tabelle) oder JSON mit HTML-Feld.
  function extractTableHtml(text){
    const t = (text || '').trim();
    if (!t) return null;
    if (t[0] === '{' || t[0] === '[') {
      try {
        const j = JSON.parse(t);
        const findHtml = (o, d) => {
          if (d > 5 || o == null) return null;
          if (typeof o === 'string') return /<t(able|body|r)\b/i.test(o) ? o : null;
          if (Array.isArray(o)) { for (const v of o){ const r = findHtml(v, d+1); if (r) return r; } return null; }
          if (typeof o === 'object') { for (const k in o){ const r = findHtml(o[k], d+1); if (r) return r; } return null; }
          return null;
        };
        return findHtml(j, 0);
      } catch(e){ return null; }
    }
    return /<t(able|body|r)\b/i.test(t) ? t : null;
  }

  // Einen Zeitraum direkt anfordern (get_data.rb nachstellen) -> geparste KPI-Zeilen
  // daterangeVal: 'current_month' | 'intraday' | 'user_defined' | ...
  // opts.startdate/enddate: nur fuer user_defined (Format YYYYMMDD, siehe harvestRangeApi)
  // opts.interval: 'day' (Default, liefert die Datum-Spalte) oder 'cumulate'.
  //   WICHTIG: intraday ist ein TAG — dort waere interval=day sinnlos, das Portal
  //   soll die laufende Summe liefern. Deshalb dort immer 'cumulate'.
  async function fetchDaterangeKpis(daterangeVal, opts){
    const cap = window.__rcLastGetData;
    if (!cap || !cap.body) return { kpis:null, reason:'kein-request' };
    const params = new URLSearchParams(cap.body);
    const iv = (opts && opts.interval) ? opts.interval
             : ((daterangeVal === 'intraday' || daterangeVal === 'today') ? 'cumulate' : 'day');
    params.set('daterange', daterangeVal);
    params.set('interval', iv);
    params.set('startdate', (opts && opts.startdate) ? opts.startdate : 'undefined');
    params.set('enddate',   (opts && opts.enddate)   ? opts.enddate   : 'undefined');
    let resp;
    try {
      resp = await fetch(cap.url, { method:'POST', credentials:'include',
        headers:{ 'content-type':'application/x-www-form-urlencoded;charset=UTF-8', 'accept':'*/*', 'x-requested-with':'XMLHttpRequest' },
        body: params.toString() });
    } catch(e){ return { kpis:null, reason:'fetch-fehler:'+e }; }
    if (!resp.ok) return { kpis:null, reason:'HTTP '+resp.status };
    const text = await resp.text();
    const html = extractTableHtml(text);
    if (!html) return { kpis:null, reason:'keine-tabelle', sample:text.slice(0,300) };
    const doc = new DOMParser().parseFromString(html, 'text/html');
    const table = doc.querySelector('table#result-table') || doc.querySelector('table');
    if (!table) return { kpis:null, reason:'kein-table-element' };
    return { kpis: parseKpiTable(table) };
  }

  // ---------- START-HISTORIE: EINMAL der aktuelle Monat auf Tagesbasis ----------
  // Ein einziger get_data.rb-Request mit daterange=current_month & interval=day.
  // Die Antwort hat eine Datum-Spalte und je Agent eine Zeile PRO TAG — damit ist
  // der ganze Monat in einem Rutsch abgedeckt. Vorher wurden fuenf Zeitraeume
  // durchprobiert (last_week, current_week, 3x user_defined), die sich ueberlappten
  // und teils nur Oracle-500er lieferten. Die Live-Ansicht der Seite bleibt dabei
  // voellig unberuehrt — es wird nichts umgestellt und nichts geklickt.
  async function harvestMonthDaily(){
    try {
      if (!window.__rcLastGetData) {
        console.log('[KPI Crawler] Warte auf Original-Datenanfrage der Seite (loese Refresh aus)...');
        triggerPageRefresh();
        await new Promise(r => setTimeout(r, REFRESH_WAIT));
      }
      if (!window.__rcLastGetData || !window.__rcLastGetData.body) {
        console.warn('[KPI Crawler] Keine get_data.rb-Anfrage mitgeschnitten — DOM-Fallback.');
        return harvestMonthDailyDom();
      }

      const res = await fetchDaterangeKpis(HARVEST_RANGE, { interval:'day' });
      if (!res.kpis) {
        console.warn('[KPI Crawler] Aktueller Monat: ' + res.reason + (res.sample ? '\n' + res.sample : '') + ' — DOM-Fallback.');
        return harvestMonthDailyDom();
      }
      const byDay = {};
      res.kpis.forEach(k => { const key = datumKey(k.datum); if (key) (byDay[key] || (byDay[key] = [])).push(k); });
      if (!Object.keys(byDay).length) {
        console.warn('[KPI Crawler] Aktueller Monat: ' + res.kpis.length + ' Zeilen OHNE Datum-Spalte (interval=day hat nicht gegriffen) — DOM-Fallback.');
        return harvestMonthDailyDom();
      }

      const days = Object.keys(byDay).sort();
      days.forEach(key => storeSnapshot(key, byDay[key]));
      console.log('[KPI Crawler] Monats-Historie gespeichert: ' + days.length + ' Tag(e) aus EINEM Request (' +
        res.kpis.length + ' Zeilen) — ' + days.map(d => d + ' (' + byDay[d].length + ')').join(', '));
      // Live-Ansicht (intraday) unveraendert weitersenden — inkl. neuer Historie
      const live = parseKpiTable();
      sendKpis(live.length ? live : (byDay[days[days.length-1]] || []));
    } catch(e){
      console.error('[KPI Crawler] Monats-Nachladung fehlgeschlagen — DOM-Fallback:', e);
      try { return harvestMonthDailyDom(); } catch(e2){}
    }
  }
  // ---------- BEREICHS-HARVEST auf Kommando (Dashboard: "Zeitraum"-Button) ----------
  // Zwei Wege: (A) direkter get_data.rb-Replay (schnell, nur mit Token), (B) sich in
  // der echten UI "durchklicken" und die DOM-Tabelle ablesen (immer moeglich, ohne
  // Token). Der Wrapper waehlt automatisch — B greift, wenn A nicht kann/leer ist.
  async function harvestRange(fromIso, toIso){
    if (window.__rcLastGetData && window.__rcLastGetData.body) {
      const api = await harvestRangeApi(fromIso, toIso);
      if (api.days.length) return api;
      console.warn('[KPI Crawler] get_data.rb lieferte keine Tage — wechsle auf UI-Durchklick.');
    } else {
      console.log('[KPI Crawler] Kein mitgeschnittener Token — hole den Bereich per UI-Durchklick (ohne get_data.rb).');
    }
    return await harvestRangeDom(fromIso, toIso);
  }

  // ---------- Weg B: BEREICH ueber die UI "durchklicken" (ohne get_data.rb) ----------
  // Stellt Zeitraum (user_defined + flatpickr) und Intervall (Tag) in der echten
  // Ligaliste-UI ein, klickt "Ok", wartet auf den Neuaufbau und PARST DIE DOM-TABELLE.
  // Unabhaengig davon, WIE die Seite die Daten holt (kein Token noetig). Danach wird
  // der urspruengliche Zustand (Live/Intraday) wiederhergestellt.
  function harvestRangeDom(fromIso, toIso){
    return new Promise(resolve => {
      const out = { days: [], error: null };
      (async () => {
      try {
        const dSel = document.getElementById('daterange-list');
        const iSel = document.getElementById('interval-list');
        const dateInput = document.getElementById('userdef-date');
        const ok = findOkButton();
        if (!dSel || !ok) { out.error = 'Ligaliste-Bedienelemente (Zeitraum/Ok) nicht gefunden — bist du auf dem Ligalisten-Tab?'; return resolve(out); }
        const origD = dSel.value || 'intraday';
        const origI = iSel ? (iSel.value || 'cumulate') : null;
        const hasUserDef = [...dSel.options].some(o => o.value === 'user_defined');
        busy = true;
        // 1) ZUERST der Zeitraum — erst dadurch haengt die Ligaliste "Tag" in die
        //    Intervall-Auswahl. Umgekehrt (wie frueher) griff setSelect(iSel,'day')
        //    ins Leere und es blieb bei "kumuliert" -> keine Datum-Spalte.
        if (hasUserDef) setSelect(dSel, 'user_defined');
        // 2) Datum auf den Bereich setzen — bevorzugt ueber die flatpickr-Instanz
        //    (der zuverlaessige Weg; .value zu setzen reicht flatpickr NICHT).
        const from = new Date(fromIso + 'T00:00:00'), to = new Date(toIso + 'T00:00:00');
        let dateSet = false;
        try {
          const fp = dateInput && dateInput._flatpickr;
          if (fp && typeof fp.setDate === 'function') { fp.setDate([from, to], true); dateSet = true; }
        } catch(e){}
        if (!dateSet && dateInput) { // Fallback: Textwert + Events
          const ger = d => pad2(d.getDate())+'.'+pad2(d.getMonth()+1)+'.'+d.getFullYear();
          dateInput.value = ger(from) + ' bis ' + ger(to);
          dateInput.dispatchEvent(new Event('input', { bubbles:true }));
          dateInput.dispatchEvent(new Event('change', { bubbles:true }));
        }
        // 3) JETZT das Intervall auf "Tag" — mit Warten, bis die Option da ist
        const ivOk = await waitForIntervalDay(iSel);
        console.log('[KPI Crawler] Durchklicken: Zeitraum ' + fromIso + ' bis ' + toIso + ', Intervall=' + (ivOk ? 'Tag' : 'NICHT umstellbar') + (dateSet ? '' : ' [flatpickr nicht gefunden, Text-Fallback]') + ' — klicke Ok...');
        // 4) Ok klicken -> die Seite baut die Tabelle neu (egal ueber welchen Kanal)
        ok.click();
        // 5) auf Neuaufbau warten, dann die sichtbare Tabelle parsen
        setTimeout(() => {
          try {
            const kpis = parseKpiTable();
            const byDay = {};
            let ohneDatum = 0;
            kpis.forEach(k => {
              const key = datumKey(k.datum);
              if (!key) { ohneDatum++; return; }
              if (key >= fromIso && key <= toIso) (byDay[key] || (byDay[key] = [])).push(k);
            });
            Object.keys(byDay).sort().forEach(key => { storeSnapshot(key, byDay[key]); out.days.push(key); });
            if (!out.days.length) {
              out.error = 'Die Ligaliste zeigte fuer ' + fromIso + '..' + toIso + ' keine Tageszeilen (' +
                kpis.length + ' Zeilen' + (ohneDatum ? ', ' + ohneDatum + ' ohne Datum' : '') +
                '). Bitte auf der Ligaliste Intervall = "Tag" und den Zeitraum pruefen.';
            } else {
              console.log('[KPI Crawler] Durchklicken erfolgreich: ' + out.days.length + ' Tag(e) [' + out.days.join(', ') + '] aus der DOM-Tabelle gelesen.');
            }
          } catch(e){ out.error = 'DOM-Parse fehlgeschlagen: ' + e; }
          finally {
            // 6) Original-Zustand wiederherstellen (zurueck auf Live/Intraday).
            //    Zuerst das Intervall, DANN den Zeitraum: sonst wirft die Ligaliste
            //    beim Wechsel auf Intraday die "Tag"-Option raus und der
            //    Intervall-Reset laeuft ins Leere.
            try { setSelect(iSel, origI || 'cumulate'); setSelect(dSel, origD); ok.click(); } catch(e){}
            setTimeout(() => { busy = false; pollKpis(false); resolve(out); }, REFRESH_WAIT);
          }
        }, REFRESH_WAIT + 3000); // Bereich laedt etwas laenger
      } catch(e){ busy = false; out.error = String(e); resolve(out); }
      })();
    });
  }

  // ---------- Weg A: BEREICH via direktem get_data.rb-Replay (nur mit Token) ----------
  // Holt einen frei waehlbaren Bereich via user_defined (ISO + DE-Format probiert,
  // dazu last_week/current_week als Fallback), speichert jeden Tag als Snapshot.
  async function harvestRangeApi(fromIso, toIso){
    const out = { days: [], error: null };
    try {
      const toYmd = iso => iso.replace(/-/g, '');            // 2026-07-01 -> 20260701 (ECHTES Portal-Format!)
      const toGer = iso => iso.split('-').reverse().join('.');
      const attempts = [
        { dr:'user_defined', startdate:toYmd(fromIso), enddate:toYmd(toIso), label:'user_defined YYYYMMDD' },
        { dr:'user_defined', startdate:fromIso,        enddate:toIso,        label:'user_defined ISO' },
        { dr:'user_defined', startdate:toGer(fromIso), enddate:toGer(toIso), label:'user_defined DE'  },
        { dr:'last_week',    label:'last_week (Fallback)' },
        { dr:'current_week', label:'current_week (Fallback)' }
      ];
      const byDay = {};
      for (const a of attempts) {
        const res = await fetchDaterangeKpis(a.dr, a);
        if (!res.kpis || !res.kpis.length) { console.warn('[KPI Crawler] Bereich ' + a.label + ': ' + (res.reason || 'leer')); continue; }
        const perDay = {};
        res.kpis.forEach(k => { const key = datumKey(k.datum); if (key) (perDay[key] || (perDay[key] = [])).push(k); });
        Object.keys(perDay).forEach(key => {
          if (key >= fromIso && key <= toIso && (!byDay[key] || perDay[key].length > byDay[key].length)) byDay[key] = perDay[key];
        });
        console.log('[KPI Crawler] Bereich ' + a.label + ': ' + Object.keys(perDay).length + ' Tag(e) [' + Object.keys(perDay).sort().join(', ') + ']');
        // user_defined hat den Bereich geliefert -> restliche Formate/Fallbacks
        // ueberspringen (ISO/DE wuerden nur Oracle-500-Fehler erzeugen).
        if (a.dr === 'user_defined' && Object.keys(perDay).length >= 1) break;
        await new Promise(r => setTimeout(r, 300));
      }
      Object.keys(byDay).sort().forEach(key => { storeSnapshot(key, byDay[key]); out.days.push(key); });
      if (!out.days.length) out.error = 'Portal lieferte keine Tage fuer ' + fromIso + ' bis ' + toIso + ' (rcCrawlerWeekRaw("user_defined") pruefen).';
    } catch(e){ out.error = String(e); }
    return out;
  }
  window.rcCrawlerHarvestRange = harvestRange; // manuell: rcCrawlerHarvestRange('2026-07-01','2026-07-13')

  function handleCommand(d, replySource){
    if (!d || d.type !== 'RC_HARVEST_RANGE' || !d.from || !d.to) return;
    console.log('[KPI Crawler] Bereichs-Anforderung vom Dashboard: ' + d.from + ' bis ' + d.to);
    harvestRange(d.from, d.to).then(res => {
      const done = { type:'RC_HARVEST_RANGE_DONE', from:d.from, to:d.to, days:res.days, error:res.error, history: loadHistory() };
      try { channel.postMessage(done); } catch(e){}
      try { if (window.opener && !window.opener.closed) window.opener.postMessage(done, '*'); } catch(e){}
      try { if (replySource && replySource.postMessage && replySource !== window) replySource.postMessage(done, '*'); } catch(e){}
      console.log('[KPI Crawler] Bereich fertig: ' + (res.days.join(', ') || 'KEINE Tage') + (res.error ? ' — ' + res.error : ''));
    });
  }
  window.addEventListener('message', ev => { try { handleCommand(ev.data, ev.source); } catch(e){} });
  channel.addEventListener('message', ev => { try { handleCommand(ev.data, null); } catch(e){} });

  // Debug: Rohantwort eines Zeitraums ansehen — rcCrawlerWeekRaw('last_week')
  window.rcCrawlerWeekRaw = async function(daterange){
    const cap = window.__rcLastGetData; if (!cap) { console.warn('Noch keine Anfrage mitgeschnitten'); return; }
    const p = new URLSearchParams(cap.body); p.set('daterange', daterange || 'last_week'); p.set('interval','day');
    const r = await fetch(cap.url, { method:'POST', credentials:'include', headers:{'content-type':'application/x-www-form-urlencoded;charset=UTF-8'}, body:p.toString() });
    const t = await r.text(); console.log('HTTP', r.status, 'Laenge', t.length, '\n', t.slice(0, 1500)); return t;
  };

  // ---------- Fallback: AKTUELLER MONAT ueber die UI (Select + Ok) ----------
  // Nur noetig, wenn kein get_data.rb-Token mitgeschnitten werden konnte.
  async function harvestMonthDailyDom(){
    try {
      const dSel = document.getElementById('daterange-list');
      const iSel = document.getElementById('interval-list');
      const ok = findOkButton();
      if (!dSel || !ok) { console.warn('[KPI Crawler] Zeitraum-Auswahl nicht gefunden — Historie uebersprungen'); return; }
      const origD = dSel.value || 'intraday';
      const origI = iSel ? (iSel.value || 'cumulate') : null;
      if (![...dSel.options].some(o => o.value === HARVEST_RANGE)) { console.warn('[KPI Crawler] "' + HARVEST_RANGE + '" nicht verfuegbar'); return; }
      console.log('[KPI Crawler] Lade AKTUELLEN MONAT auf Tagesbasis nach (UI-Weg)...');
      busy = true;
      // Zeitraum ZUERST — erst danach bietet die Ligaliste ueberhaupt "Tag" an.
      setSelect(dSel, HARVEST_RANGE);
      const ivOk = await waitForIntervalDay(iSel);
      if (!ivOk) console.warn('[KPI Crawler] Ohne Intervall "Tag" liefert der Monat nur EINE kumulierte Zeile je Agent.');
      ok.click();
      setTimeout(() => {
        try {
          const kpis = parseKpiTable();
          if (!kpis.length) { console.warn('[KPI Crawler] Monat: keine Daten erhalten'); return; }
          // nach Datum gruppieren — Zeilen OHNE Datum sind kumulierte Monatswerte
          // und duerfen NIEMALS als "heute" abgelegt werden (sonst stehen
          // Monatssummen als Tageswert im Dashboard).
          const byDay = {};
          let ohneDatum = 0;
          kpis.forEach(k => {
            const key = datumKey(k.datum);
            if (!key) { ohneDatum++; return; }
            (byDay[key] || (byDay[key] = [])).push(k);
          });
          const days = Object.keys(byDay).sort();
          if (!days.length) {
            console.warn('[KPI Crawler] Monat: ' + kpis.length + ' Zeilen ohne Datum-Spalte — als kumulierte Monatswerte VERWORFEN (kein Tag zuordenbar).');
            return;
          }
          days.forEach(key => storeSnapshot(key, byDay[key]));
          console.log('[KPI Crawler] Monats-Historie gespeichert: ' + days.length + ' Tag(e) — ' + days.join(', ') +
            (ohneDatum ? ' (' + ohneDatum + ' Zeilen ohne Datum verworfen)' : ''));
          // aktualisierte Historie sofort ans Dashboard funken
          sendKpis(byDay[days[days.length-1]] || []);
        } catch(e){ console.error('[KPI Crawler] Monats-Parse fehlgeschlagen:', e); }
        finally {
          // Zustand zuruecksetzen und wieder live gehen (Intraday, urspruengliches Intervall)
          setSelect(iSel, origI || 'cumulate');
          setSelect(dSel, origD);
          ok.click();
          setTimeout(() => { busy = false; pollKpis(false); }, REFRESH_WAIT);
        }
      }, REFRESH_WAIT + 3000); // Monat laedt etwas laenger
    } catch(e){ busy = false; console.error('[KPI Crawler] Monats-Nachladung fehlgeschlagen:', e); }
  }
  window.rcCrawlerHarvestMonth = harvestMonthDaily; // manueller Aufruf in der Konsole
  window.rcCrawlerHarvestWeek  = harvestMonthDaily; // Altname bleibt gueltig

  // Sofort einmal parsen (ohne Refresh), danach im POLL_INTERVAL-Takt live
  pollKpis(false);
  // Token proaktiv sichern: falls der Crawler NACH dem Tabellen-Load injiziert wurde,
  // hat er die Original-Anfrage noch nicht gesehen. Ein/mehrere Ok-Klicke holen sie
  // nach -> Zeitraum-Abrufe funktionieren danach OHNE manuelles Nachklicken.
  ensureCapture(1).then(ok => {
    console.log(ok
      ? '[KPI Crawler] Bereit: Original-Anfrage gesichert (schneller get_data.rb-Weg verfuegbar).'
      : '[KPI Crawler] Kein get_data.rb-Token — Zeitraum-Abrufe laufen automatisch ueber den UI-Durchklick (funktioniert trotzdem).');
  });
  // EINMALIGER Start-Harvest: aktueller Monat auf Tagesbasis. Danach nur noch live.
  setTimeout(harvestMonthDaily, 6000);
  if (window.kpiCrawlerInterval) clearInterval(window.kpiCrawlerInterval);
  window.kpiCrawlerInterval = setInterval(() => pollKpis(true), POLL_INTERVAL);

  console.log('[KPI Crawler] v5.0 gestartet — Start: EINMAL "Aktueller Monat" + Intervall "Tag" (ein get_data.rb-Request, ganze Monatshistorie auf Tagesbasis). Danach LIVE im ' + (POLL_INTERVAL/60000) + '-Minuten-Takt auf Intraday — mit mitgeschnittenem Token ohne jeden Eingriff in die Seite (kein Ok-Klick, keine Select-Aenderung), sonst per Ok-Klick. Snapshots werden nach ECHTEM Datum abgelegt (nie blind als heute); kumulierte Zeilen ohne Datum werden verworfen statt als "heute" gezaehlt. Konsole: rcCrawlerHarvestMonth() · Bereich: rcCrawlerHarvestRange("2026-07-01","2026-07-13") · Rohantwort: rcCrawlerWeekRaw("current_month")');

  window.addEventListener('beforeunload', () => {
    if (window.kpiCrawlerInterval) clearInterval(window.kpiCrawlerInterval);
  });
})();
