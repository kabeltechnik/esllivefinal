(function() {
    // ============================================================
    //  esl live-arena v22.0 — Vodafone Edition (Vision 2026)
    //  Live-Motivations-Cockpit fuer Sales-Agents (WCA/ESL-Portal)
    //  - laeuft 100% clientseitig in der Browser-Konsole
    //  - pollt alle 20s den Excel-Export des PrimeFaces-Portals
    //  - Design nach Vodafone-Systematik: weisse Flat-Cards auf
    //    getoenter Leinwand, Electric Red #E60000 exklusiv fuer
    //    Marke/Navigation/Erfolg, Datenviz aus der 10er-Palette,
    //    operative Zustands-Tokens (ok/warn/breach) statt Ampel-Neon
    // ============================================================

    // 1. ORIGINAL-CONSOLE WIEDERHERSTELLEN (Portal ueberschreibt console evtl.)
    let realConsole = window.console;
    try {
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        document.body.appendChild(iframe);
        if (iframe.contentWindow && iframe.contentWindow.console) realConsole = iframe.contentWindow.console;
    } catch (e) {}
    const rcLog = {
        log: (...a) => { try { realConsole.log(...a); } catch(e){} },
        error: (...a) => { try { realConsole.error(...a); } catch(e){} },
        warn: (...a) => { try { realConsole.warn(...a); } catch(e){} }
    };
    rcLog.log("esl live-arena v22.0 (Vodafone Edition) gestartet");

    // 2. CLEAN-STATE: alte Intervalle stoppen, alte DOM-Reste entfernen
    ['rcLiveInterval','rcFlashbackInterval','rcSprucheInterval','rcClockInterval','rcRotateInterval','rcHistInterval','rcHeroInterval','rcLowPerfInterval','rcWarHudInterval','rcAutoRotInterval','rcRadarCarouselInterval','rcCfgInterval','rcReportInterval','rcKeepAliveInterval','rcSessionWatchInterval','rcCrocoInterval','rcCrocoReconcileInterval'].forEach(k=>{
        if (window[k]) { clearInterval(window[k]); window[k]=null; }
    });
    window.rcHarvestBusy = false;
    ['rcLiveDashboard','rcToastContainer','rcLiveBadge','rcMappingModal','rcDetailModal'].forEach(id => {
        const el = document.getElementById(id); if (el) el.remove();
    });
    // Chart-Instanzen zerstoeren, sonst zeichnen sie nach Re-Inject auf tote Canvases
    ['rcChartInstance','rcTnpsChartInstance','rcQualiStdChartInstance','rcRadarChartA_i','rcRadarChartB_i','rcHistChart_i'].forEach(k => {
        if (window[k]) { try { window[k].destroy(); } catch(e){} window[k] = null; }
    });
    (window._rcDetCharts || []).forEach(c => { try { c.destroy(); } catch(e){} });
    window._rcDetCharts = [];
    if (window.rcWarRaf) { try { cancelAnimationFrame(window.rcWarRaf); } catch(e){} window.rcWarRaf = null; }
    if (window.rcAutoScrollRaf) { try { cancelAnimationFrame(window.rcAutoScrollRaf); } catch(e){} window.rcAutoScrollRaf = null; }
    window.rcRadarBuilt = false;
    if (window._rcHeroHideTO) { clearTimeout(window._rcHeroHideTO); window._rcHeroHideTO = null; }

    // ---- RC_WAR HUD-Sichtbarkeit: Text-Overlays einzeln schaltbar ----
    // Konsole:  rcWarHud.chronik = true;  rcWarHudApply();
    // Zuruecksetzen:  localStorage.removeItem('rcWarHud'); location.reload();
    window.rcWarHudDefaults = {
        chronik: false,          // CHRONIK DES TAGES (Canvas, oben links)
        heroRuf: true,           // Helden-Ruf-Banner (DOM #rcHeroCall, Mitte)
        heroKompakt: true,       // Helden-Ruf kleiner + kuerzere Standzeit
        tageswertung: true,      // TAGESWERTUNG-Rangtabelle (Canvas, oben rechts)
        lagebericht: false,      // LAGEBERICHT-Banner (Canvas, unten mittig)
        aufstiegsLegende: false, // SO STEIGST DU AUF-Legende (Canvas, unten links)
        tagesziel: false,        // DEIN TAGESZIEL-Leiste (Canvas, unter der Legende)
        fortschritt: true,       // KIP/MOBILFUNK-BNT-Fortschrittsbalken (Canvas, oben)
        burgLabels: true,        // Burg-Name/Platz/Punkte (Canvas, an den Burgen)
        burgKompakt: true,       // Burg-Labels ohne lange Untertitel (BCR/Stufe/Quali)
        einheitenLabels: false,  // BOT/Name/Standort-Tags ueber den Truppen (Canvas)
        stundenDuell: true,      // Stunden-Koenigsjagd-HUD + Countdown (Canvas, oben)
        aufholjagd: true         // Aufholjagd-Vignette des gefilterten Standorts (Canvas)
    };
    (function(){
        let saved = {};
        try { saved = JSON.parse(localStorage.getItem('rcWarHud') || '{}') || {}; } catch(e){}
        window.rcWarHud = Object.assign({}, window.rcWarHudDefaults, saved);
    })();

    // ============================================================
    //  STAMMDATEN
    // ============================================================
    const STANDORT_METADATA = {
        // Monochrome Vodafone-Rampe fuer DUNKLEN Grund (Rot-Familie + helle Graus).
        // Alle Toene >=3:1 Kontrast gegen die dunklen Flaechen (#121212/#1D1D1D);
        // Strichmuster (dash) unterscheiden die Standorte zusaetzlich in Charts.
        'ADP': { name: 'Alexandroupolis', short: 'Alexandr.',   nation: 'GR', color: '#B4B4B4', dash: [6,3], call: 'DELTA',    lat: 40.85, lon: 25.87 },
        'AL':  { name: 'Alanya',          short: 'Alanya',      nation: 'TR', color: '#E60000', dash: [],    call: 'ALPHA',    lat: 36.54, lon: 32.00 },
        'B':   { name: 'Berlin',          short: 'Berlin',      nation: 'DE', color: '#FF6666', dash: [2,2], call: 'BRAVO',    lat: 52.52, lon: 13.40 },
        'E':   { name: 'Essen',           short: 'Essen',       nation: 'DE', color: '#FFA9A9', dash: [6,3], call: 'ECHO',     lat: 51.45, lon: 7.01 },
        'P':   { name: 'Potsdam',         short: 'Potsdam',     nation: 'DE', color: '#DCDCDC', dash: [],    call: 'PAPA',     lat: 52.40, lon: 13.06 },
        'SER': { name: 'Serres',          short: 'Serres',      nation: 'GR', color: '#FFFFFF', dash: [],    call: 'SIERRA',   lat: 41.08, lon: 23.55 },
        'ZWT': { name: 'Zeitwert',        short: 'Zeitwert',    nation: 'AT', color: '#8C8C8C', dash: [1,3], call: 'ZULU',     lat: 48.20, lon: 16.37 },
        'NBB': { name: 'Neubrandenburg',  short: 'Neubrdbg.',   nation: 'DE', color: '#CFCFCF', dash: [6,3], call: 'NOVEMBER', lat: 53.55, lon: 13.26 },
        'SKA': { name: 'Sakarya',         short: 'Sakarya',     nation: 'TR', color: '#BD0000', dash: [4,2], call: 'KILO',     lat: 40.77, lon: 30.40 }
    };
    const shortName = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].short) || (STANDORT_METADATA[code] && STANDORT_METADATA[code].name) || code;

    // Qualitaets-Ziele (Mandanten-Vorgaben)
    const RC_ZIELE = {
        ff7:   { min: 80,  label: 'FF7 ≥ 80 %' },
        cs:    { min: 90,  label: 'CS ≥ 90 %' },
        ahtMin:{ max: 13,  opt: 10, label: 'AHT ≤ 13 Min' },
        tnps:  { min: 70,  label: 'TNPS ≥ 70 %' },
        dds:   { max: 5,   label: 'DDS ≤ 5,0 %' },
        fq:    { min: 30,  label: 'FQ ≥ 30 %' },
        aq:    { min: 85,  label: 'AQ ≥ 85 %' },
        calls: { min: 40,  label: '≥ 40 Calls/Tag' }
    };
    // Operative Zustands-Tokens auf dunklem Grund: gut = helles Weiss (souveraen),
    // warn = helles Rot (lesbar auf dunkel), kritisch = Electric Red.
    function zielColor(val, ziel){
        if (val == null || !ziel) return '#9C9C9C';
        if (ziel.min != null) { if (val >= ziel.min) return '#F5F5F5'; if (val >= ziel.min*0.9) return '#FF6666'; return '#E60000'; }
        if (ziel.max != null) { if (val <= ziel.max) return '#F5F5F5'; if (val <= ziel.max*1.15) return '#FF6666'; return '#E60000'; }
        return '#9C9C9C';
    }
    const NATION_METADATA = {
        'TR': { name: 'Tuerkei',       color: '#E60000' },
        'GR': { name: 'Griechenland',  color: '#FFFFFF' },
        'DE': { name: 'Deutschland',   color: '#DCDCDC' },
        'AT': { name: 'Oesterreich',   color: '#8C8C8C' }
    };
    const ORDER = ['AL','SER','ADP','B','P','E','ZWT','NBB','SKA'];

    function normalizeStandort(std) {
        if (!std) return 'ALL';
        let s = std.toString().toUpperCase().trim();
        const map = {ALANYA:'AL',SERRES:'SER',ALEXANDROUPOLIS:'ADP',BERLIN:'B',ESSEN:'E',POTSDAM:'P',ZEITWERT:'ZWT',NEUBRANDENBURG:'NBB',SAKARYA:'SKA'};
        if (map[s]) return map[s];
        return s;
    }

    function getFlagSvg(code, size = 'small', wave = false) {
        let nation = STANDORT_METADATA[code] ? STANDORT_METADATA[code].nation : code;
        const w = size === 'xl' ? 54 : (size === 'large' ? 34 : 20);
        const h = size === 'xl' ? 36 : (size === 'large' ? 22.6 : 13.3);
        const cls = wave ? 'rc-flag-wave' : '';
        const base = `border-radius:2px; display:inline-block; vertical-align:middle; box-shadow:0 0 0 1px rgba(255,255,255,0.30);`;
        if (nation === 'TR') return `<svg class="${cls}" viewBox="0 0 120 80" width="${w}" height="${h}" style="${base}"><rect width="120" height="80" fill="#E30A17"/><circle cx="45" cy="40" r="20" fill="#fff"/><circle cx="50" cy="40" r="16" fill="#E30A17"/><polygon points="70,40 76,42 74,48 79,44 85,46 81,41 85,36 79,38 74,34 76,40" fill="#fff"/></svg>`;
        if (nation === 'GR') return `<svg class="${cls}" viewBox="0 0 27 18" width="${w}" height="${h}" style="${base}"><rect width="27" height="18" fill="#005BA6"/><rect y="2" width="27" height="2" fill="#fff"/><rect y="6" width="27" height="2" fill="#fff"/><rect y="10" width="27" height="2" fill="#fff"/><rect y="14" width="27" height="2" fill="#fff"/><rect width="10" height="10" fill="#005BA6"/><rect x="4" width="2" height="10" fill="#fff"/><rect y="4" width="10" height="2" fill="#fff"/></svg>`;
        if (nation === 'DE') return `<svg class="${cls}" viewBox="0 0 5 3" width="${w}" height="${h}" style="${base}"><rect y="0" width="5" height="1" fill="#000"/><rect y="1" width="5" height="1" fill="#D00"/><rect y="2" width="5" height="1" fill="#FFCE00"/></svg>`;
        if (nation === 'AT') return `<svg class="${cls}" viewBox="0 0 3 2" width="${w}" height="${h}" style="${base}"><rect y="0" width="3" height="0.67" fill="#C60C30"/><rect y="0.67" width="3" height="0.67" fill="#FFF"/><rect y="1.34" width="3" height="0.67" fill="#C60C30"/></svg>`;
        return `<svg class="${cls}" viewBox="0 0 24 24" width="${w}" height="${h}" fill="none" stroke="#7E7E7E" stroke-width="2" style="${base}"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10zM2 12h20"/></svg>`;
    }

    function ladeBibliothek(url, checkVar) {
        return new Promise((resolve) => {
            if (window[checkVar]) return resolve();
            const s = document.createElement('script');
            s.src = url; s.type = 'text/javascript';
            s.onload = () => { rcLog.log(`Bibliothek ${checkVar} geladen.`); resolve(); };
            s.onerror = () => { rcLog.error(`Fehler beim Laden von ${checkVar}.`); resolve(); };
            document.head.appendChild(s);
        });
    }

    // Mapping (Mitarbeiter-IDs) aus localStorage
    window.rcWcaMapping = null;
    const savedMapping = localStorage.getItem('rcWcaMapping');
    if (savedMapping) { try { window.rcWcaMapping = JSON.parse(savedMapping); } catch(e){} }

    // Standort-Auswahl fuer den Battle — IMMER genau 2 (Duell-Format)
    (function(){
        let sel = [];
        try { sel = JSON.parse(localStorage.getItem('rcSelectedStandorte') || '[]'); } catch(e){}
        sel = (Array.isArray(sel) ? sel : []).filter(c => STANDORT_METADATA[c]).slice(0, 2);
        if (sel.length < 2) sel = ['AL','SER'];
        window.rcSelectedStandorte = new Set(sel);
    })();

    // ============================================================
    //  KPI-EMPFAENGER (externe Website via Satellite-Crawler)
    // ============================================================
    window.rcKpiData = {};    // { ccsId => kpiObjekt }
    window.rcKpiByName = {};  // { normalisierterName => kpiObjekt }  (Join-Fallback)
    window.rcKpiLastUpdate = null;

    // Name normalisieren, damit "Baltaci Derya" == "Derya Baltaci" == "baltaci derya"
    window.rcNormName = function(s){
        if (!s) return '';
        return s.toString().toLowerCase()
            .replace(/[.,]/g,' ')
            .replace(/[äàáâ]/g,'a').replace(/[öòóô]/g,'o').replace(/[üùúû]/g,'u').replace(/ß/g,'ss')
            .split(/\s+/).filter(Boolean).sort().join(' ');
    };

    function ingestKpi(kpi){
        if (!kpi || !kpi.ccsId) return;
        window.rcKpiData[kpi.ccsId] = kpi;
        if (kpi.agentName) window.rcKpiByName[window.rcNormName(kpi.agentName)] = kpi;
    }

    // KPI-Objekt zu einem ESL-Agenten finden (per CCS-ID, sonst per Name)
    window.rcKpiForAgent = function(ag){
        if (!ag) return null;
        if (ag.ccsId && window.rcKpiData[ag.ccsId]) return window.rcKpiData[ag.ccsId];
        const byName = window.rcKpiByName[window.rcNormName(ag.name)];
        return byName || null;
    };

    // Eine Liga-Zeile auf die Dashboard-Stammdaten abbilden. ZWINGEND ueber das
    // Mapping: die Ligaliste liefert das Team als NUMMER ("21105083"), waehrend
    // Dropdown, ESL-Aggregate und stackMap mit dem Team-NAMEN ("VKD-TECH-83")
    // arbeiten. Wer k.team roh vergleicht, bekommt bei aktivem Team-Filter IMMER
    // eine leere Liste (Befund 27.07.: Qualitaets-Seite blieb gefiltert leer).
    window.rcLigaMeta = function(k){
        const map = window.rcWcaMapping || {};
        const m = (map.ccsMap || {})[k.ccsId];
        const team = ((m && m.team) || k.team || '').toString().trim();
        return { std: normalizeStandort((m && m.standort) || k.standort), team,
                 stack: team ? ((map.stackMap || {})[team] || '') : '' };
    };

    // Aktiver Dashboard-Scope (Standort + Team + Stack) — an EINER Stelle gelesen.
    window.rcActiveScope = function(){
        const std = (document.getElementById('rcStandortFilter') || {}).value || 'ALL';
        const tSel = document.getElementById('rcTeamFilter');
        const sSel = document.getElementById('rcStackFilter');
        return { std,
                 team: (std !== 'ALL' && tSel) ? (tSel.value || 'ALL') : 'ALL',
                 stack: sSel ? (sSel.value || 'ALL') : 'ALL' };
    };

    // Gehoert eine Liga-Zeile in den Scope? Der einzig gueltige Liga-Filter —
    // nicht selbst auf k.standort/k.team filtern.
    window.rcLigaInScope = function(k, scope){
        const sc = scope || window.rcActiveScope();
        const meta = window.rcLigaMeta(k);
        if (sc.std   !== 'ALL' && meta.std  !== sc.std)  return false;
        if (sc.team  !== 'ALL' && meta.team !== sc.team) return false;
        // ohne Team-Zuordnung nicht dem Stack zurechenbar
        if (sc.stack !== 'ALL' && (!meta.team || meta.stack !== sc.stack)) return false;
        return true;
    };

    // Liga-Calls-Aggregation: echte Telefonate aus der Ligaliste je Standort/Team.
    // WICHTIG: Das ist der einzig gueltige Nenner fuer die BCR — die ESL-Kontakte
    // sind unvollstaendig, weil viele Agenten nur erfolgreiche Calls eintragen
    // (Befund 12.07.: nur 12 % der Liga-Calls im ESL getrackt, CRs bis 118 %).
    // WICHTIG: respektiert den aktiven Dashboard-Scope (Standort + Team + Stack),
    // damit Liga-Calls und ESL-Zahlen IMMER dieselbe Basis haben. Ungefiltert
    // standen z.B. 3766 Alanya-Liga-Calls neben 171 gefilterten VKD-ESL-Kontakten
    // -> CR-BCR 1,5 % statt 6,5 % (Nutzer-Befund 13.07.).
    window.rcLigaAgg = function(){
        const byStd = {}, byTeam = {};
        let total = 0;
        const sc = window.rcActiveScope();
        Object.values(window.rcKpiData || {}).forEach(k => {
            const calls = k.callCount || 0; if (!calls) return;
            if (!window.rcLigaInScope(k, sc)) return;
            const meta = window.rcLigaMeta(k);
            total += calls;
            byStd[meta.std] = (byStd[meta.std] || 0) + calls;
            if (meta.team) byTeam[meta.team] = (byTeam[meta.team] || 0) + calls;
        });
        return { byStd, byTeam, total };
    };

    // Liga-Tageshistorie MERGEN (nie ersetzen) + im Dashboard-Origin persistieren —
    // so ueberleben Bereichs-Harvests und Vortage jeden Dashboard-Reload.
    function rcMergeLigaHistory(h){
        if (!h || typeof h !== 'object') return;
        const cur = window.rcLigaHistory || (window.rcLigaHistory = {});
        const size = x => (x && x.byAgent) ? Object.keys(x.byAgent).length : 0;
        Object.keys(h).forEach(k => { if (!cur[k] || size(h[k]) >= size(cur[k])) cur[k] = h[k]; });
        try {
            const keys = Object.keys(cur).sort();
            keys.slice(0, Math.max(0, keys.length - 40)).forEach(k => delete cur[k]);
            localStorage.setItem('rcLigaHistDash', JSON.stringify(cur));
        } catch(e){}
    }
    try { window.rcLigaHistory = Object.assign(JSON.parse(localStorage.getItem('rcLigaHistDash') || '{}'), window.rcLigaHistory || {}); } catch(e){}

    // Gemeinsamer Handler fuer alle Kanaele (BroadcastChannel same-origin + postMessage cross-origin)
    function handleKpiMessage(d){
        if (!d || typeof d !== 'object') return false;
        if (d.type === 'RC_HARVEST_RANGE_DONE') {
            if (d.history) rcMergeLigaHistory(d.history);
            rcLog.log('Ligaliste-Bereich geliefert: ' + ((d.days||[]).join(', ') || 'keine Tage') + (d.error ? ' — ' + d.error : ''));
            if (window.rcRangeDone) window.rcRangeDone(d);
            return true;
        }
        if (d.type === 'KPI_BATCH' && Array.isArray(d.payload)) {
            // Steht die Ligaliste auf einem anderen Zeitraum (z.B. "Gestern"), sind die
            // payload-Zeilen KEINE Live-Werte -> nicht ingesten, nur Historie mergen.
            const drL = (d.liveDaterange || '').toString();
            const liveOk = !drL || drL === 'intraday' || drL === 'today';
            if (liveOk) d.payload.forEach(ingestKpi);
            else if (!window._rcWarnedLiveDr) {
                window._rcWarnedLiveDr = true;
                rcLog.warn('Ligaliste steht auf "' + drL + '" — Zeilen nicht als LIVE uebernommen (Historie schon). Auf der Ligaliste "Intraday" + Ok waehlen.');
            }
            // Crawler v3 liefert zusaetzlich die Liga-Tageshistorie (Snapshots je Tag)
            if (d.history && typeof d.history === 'object') rcMergeLigaHistory(d.history);
            if (!liveOk) return true;
        } else if (d.type === 'KPI_UPDATE' && d.payload) {
            ingestKpi(d.payload);
        } else { return false; }

        window.rcKpiLastUpdate = new Date();
        rcLog.log(`KPI-Daten empfangen: ${Object.keys(window.rcKpiData).length} Agenten (CCS-ID)`);
        if (window.rcCaptureTnpsSnapshot) window.rcCaptureTnpsSnapshot();
        if (window.renderTnpsChart) window.renderTnpsChart();
        if (window.rcLetzteStats) {
            const agentsArr = Object.values(window.rcLetzteStats.agentStats);
            if (window.renderAgents) window.renderAgents(agentsArr);
            if (window.renderAnspFokus) window.renderAnspFokus(agentsArr);
            if (window.renderQualitaet) window.renderQualitaet();
            if (window.renderMarquee) window.renderMarquee();
            if (window.rcActivePage === 'cockpit' && window.renderCockpit) window.renderCockpit();
            if (window.rcActivePage === 'radar' && window.renderRadar) window.renderRadar();
        }
        return true;
    }

    // Kanal 1: BroadcastChannel (funktioniert nur wenn Crawler auf DERSELBEN Domain laeuft)
    const rcKpiChannel = new BroadcastChannel('regiocom_live_arena');
    rcKpiChannel.onmessage = (event) => handleKpiMessage(event.data);

    // Kanal 2: window.postMessage (CROSS-ORIGIN — Ligaliste ist ccs.vodafone.de, Dashboard esl.regiocom.net!)
    // Der Crawler funkt via window.opener.postMessage zurueck. Nur KPI-Zahlen, daher Origin-agnostisch.
    window.addEventListener('message', (event) => {
        const d = event.data;
        if (d && (d.type === 'KPI_BATCH' || d.type === 'KPI_UPDATE' || d.type === 'RC_HARVEST_RANGE_DONE')) handleKpiMessage(d);
    });

    // KPI-Quelle (Ligaliste) aus dem Dashboard oeffnen -> setzt window.opener beim Crawler,
    // damit dieser cross-origin zurueckfunken kann.
    // KEIN alert() mehr: ein offener Dialog laesst jedes Runtime.evaluate der
    // Edge-Fernsteuerung haengen (ESL_Start.cmd Schritt 9) — der Auto-Start blieb
    // dadurch stehen. Stattdessen ein Rueckgabewert und ein sichtbarer Hinweis.
    window.RC_LIGA_URL = 'https://ccs.vodafone.de/cgi-bin/AGENTEN_KENNZAHLEN_2/LIGA_LISTEN_NEW/dist/liga_listen.rb?script_id=11035';
    window.rcOpenKpiQuelle = function(){
        try { if (window.rcKpiWin && !window.rcKpiWin.closed) { window.rcKpiWin.focus(); return true; } } catch(e){}
        window.rcKpiWin = window.open(window.RC_LIGA_URL, 'rcKpiQuelle');
        if (!window.rcKpiWin) {
            rcLog.warn('KPI-Quelle: Popup wurde blockiert — oeffnet beim naechsten Klick ins Fenster automatisch.');
            rcKpiRetryBeiGeste();
            return false;
        }
        rcLog.log('KPI-Quelle geoeffnet (opener gesetzt) — der Autopilot startet dort den kpi_crawler.js.');
        return true;
    };

    // Popup-Blocker: Chromium laesst window.open nur bei "sticky user activation"
    // zu. Beim automatischen Start gibt es die noch nicht. Deshalb EINMALIG auf
    // die naechste echte Geste warten (Maus/Taste) und dann erneut oeffnen —
    // die Fernsteuerung des Starters schickt ohnehin echte Klicks.
    function rcKpiRetryBeiGeste(){
        if (window.__rcKpiGesteArmed) return;
        window.__rcKpiGesteArmed = true;
        const versuch = () => {
            if (window.rcOpenKpiQuelle()) {
                ['pointerdown','keydown'].forEach(t => window.removeEventListener(t, versuch, true));
                window.__rcKpiGesteArmed = false;
            }
        };
        ['pointerdown','keydown'].forEach(t => window.addEventListener(t, versuch, true));
    }

    // Automatischer Start der KPI-Quelle. Frueher musste dafuer jemand den
    // KPI-Knopf druecken bzw. der PowerShell-Starter es von aussen anstossen —
    // blieb das aus, lief das Dashboard dauerhaft ohne Liga-Zahlen (Ansprache-
    // Quote und CR leer, ohne Fehlermeldung). Jetzt macht es das Dashboard selbst,
    // aber nur, wenn nach der Wartezeit wirklich keine KPI-Daten da sind.
    window.rcAutoKpiOff = false;   // Konsole: rcAutoKpiOff = true  schaltet es ab
    function rcAutoKpiQuelle(){
        setTimeout(() => {
            if (window.rcAutoKpiOff) return;
            if (Object.keys(window.rcKpiData || {}).length) return;     // Crawler funkt schon
            try { if (window.rcKpiWin && !window.rcKpiWin.closed) return; } catch(e){}
            rcLog.log('Keine Liga-Daten nach 12 s — KPI-Quelle wird selbst geoeffnet.');
            window.rcOpenKpiQuelle();
        }, 12000);
    }

    // Mitarbeiter-Mapping ohne Datei-Dialog. ESL_Start.cmd reicht die Excel als
    // Base64 in window.__rcFiles.mapping mit; ausserdem wird ein einmal geladenes
    // Mapping unter rcWcaMappingXlsx gesichert. Grund: unter Citrix wird der
    // Browser-Speicher regelmaessig geleert, danach stand das Dashboard ohne
    // Mapping da und die Excel musste JEDES MAL von Hand gewaehlt werden.
    function rcB64ZuBuffer(b64){
        const bin = atob((b64 || '').replace(/^data:[^,]*,/, ''));
        const buf = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) buf[i] = bin.charCodeAt(i);
        return buf.buffer;
    }
    function rcAutoMapping(){
        const hatMapping = !!(window.rcWcaMapping && window.rcWcaMapping.ccsMap
                              && Object.keys(window.rcWcaMapping.ccsMap).length);
        let b64 = null;
        try { b64 = (window.__rcFiles && window.__rcFiles.mapping) || null; } catch(e){}
        if (!b64) { try { b64 = localStorage.getItem('rcWcaMappingXlsx'); } catch(e){} }
        if (!b64) {
            if (!hatMapping) rcLog.warn('Kein Mitarbeiter-Mapping vorhanden — bitte die Excel einmal auf die Mapping-Flaeche ziehen (danach merkt sich das Dashboard sie).');
            return;
        }
        if (hatMapping) return;                 // schon geladen, nicht neu einlesen
        try {
            verarbeiteMappingExcel(rcB64ZuBuffer(b64));
            rcLog.log('Mitarbeiter-Mapping automatisch uebernommen (kein Datei-Dialog noetig).');
        } catch(e){ rcLog.error('Mapping-Autoimport fehlgeschlagen:', e); }
    }
    rcLog.log("KPI-Empfaenger aktiv (BroadcastChannel + postMessage). Warte auf Crawler-Daten...");

    // ============================================================
    //  STYLES
    // ============================================================
    const styleEl = document.createElement('style');
    styleEl.innerHTML = `
        /* ============================================================
           VODAFONE VISION 2026 — Design-Tokens & Basis
           Systematik: weisse Flat-Cards auf getoenter Leinwand,
           Electric Red exklusiv fuer Marke/Navigation/Erfolg,
           operative Zustands-Tokens statt Ampel-Neonfarben,
           Radius 6px + asymmetrisches Speechmark-Echo (oben rechts).
           Keine Schlagschatten, keine Farbverlaeufe, keine Italics.
           ============================================================ */
        @font-face{ font-family:'VodafoneVF'; font-style:normal; font-weight:400; font-display:swap;
            src:local('Vodafone'), url(data:font/woff2;base64,d09GMgABAAAAAE5wABEAAAAA8BwAAE4TAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGiIb6EAcIAZgAHQIGgmCcxEMCoLWWIK4ZwE2AiQDilwLhTAABCAFhxYHIAxyG1PdeSAq1+77yZI4Aeg2BMrYVDXSc+Jkus1ToDtwU4qXBGdlsHEAkGiPGf3//////6cmGzEmHHg84Ks2q7bWpiikRAQJQoZKiZSha4Dodagx5yaponY1BuRxrim3XfaxnCIMouMLXjIR1VE65I4oBI+nXCASUk7c20YVfSVa3VZCJiRfh2HbfHZYhCSkreC3pByq1Kl3HOadcNKwgdXS4ND0asefh0TokCcRhdQUkraDbk/8Nrx+A1LFXV/wQ0jzH241AKURCXY9vN//sAxjw41iARecuNIh3T/mMWAKcXrPNtcCecqDi06choa0ND4hzbWqlaZaHjEtDdvQ7puZEnZ6l7qRqg1paFT+s2FZEhcuM+05hVQDlyfdpl9bwv36N8byFoGNyxjJSrde+If/P+3XPjdiASQplAHTTjuS7iP4Z/gM0Nw6UiRH1KLZxoqxwdjGxraLBUs2NpBoiZYnDAwMxCpUEIzGfitRjAKMfNHGKIzmHU//P0a78z7mIe1ipbomL10saUxLgtDgdC+BuuP3v1+7u4g10UFmEF9PmCazNxHVTii/FA5JdGjDkjPs0U3S08bSBAP7PVpg1ovk+0M1gRf2JxElDi2hQ5zu0XJj+qahZern8XTqrzKluvDDlJNST1a9EKDLhmtksOfBCZMyKUwh1iasAJjfT629M9k4s63FgTg2BnHyr9Y87e+LRVmr02fF6jxkbpthffHmMocnCv5dE41yhamaszUVi1jFmcjVtuIgFGoehE8hY0O5WTO7PnP7A1+rIF63FTslyal8vvQL3xpQvSWIVhBLg+0WaX2S3Lvyl+0mu53dNqWdNt0/f6fpT49wzXBctwbheAiFkAiJkAj3EQ4st5Bs2jLJ3n2Qzs/QAnALZNnJ7QWpThu38vRPQF2+BLp5/E2LQwR+hIsJNaRC9BNSxY46Jie26SSO2Hu3xQzT5aNxIGolYviw0vlQhescbxe0HGNaaRwVdTCikAlhgvzZ2NUr75dWCiAg/gmlE0imWj2NDLxAken0Qb5RLkZ2E9Xu5vArQF+SIIV48rmwDxjxwvRADpR3KzTPI5jOxQXYnbq5QfD//NWmbT8yC7XsdPm2Pu2DTWABBhhggJHmInX3UcEgwdZW++awb+3/X7PXvpv8Wfi/APSJVIUko8hVqJk7L/DmbRaSxZklzl9IZgmT7J7ZAqADdEALwK6ACpiOr2zdbxWgrlVEiowuDx9LU6p3mn85pSsdelkOCjC7czO02tsr3+t1a5fWZPe0rksttDRch1el3xgFwAoDeBAICkKGmQAWHr5Xs8+UB494vUaORW4p3SnKJtl6lwXN15eASBCNT4prx8lYQ7QZNM3OyBiXpDZI81E2tZFMWkt7yew+UgoS0JnIU7KQe06Zndi6ylpXtVQ1CLeO6BDeq5j6MVOyRZ1hkuv4zfG6NdoQjBBCGBO6yJaJKOcVoBZqqcG2l8VmWdg8k+svbltjZwxILlhyF4Yrtvkvctq9gn2EECQNQUTs/O4uiYAIj7etwUGSc5JWZpxkVTJOCAhRhc1pwtDiJjzwAECjna3r767gAajt6cGAPtRzAMkSa5at2HGud2ELjgmY+JRwSXPd4ubrjnIfP6KYfWDEXxhq3D1PeQt9vvrrKG9Us//XAHvQlODe0CvhWehXOC5+DX4nvh//lwvANcxi4jriKVIpm8vmMkLIenIluZF7n3eFso5aTH0TsZu2id5C76L3M/JuV2EfiKQyUZuxs3ahD/LG7xR9KNLXyXC9K8EFgjQu0NbwQ9hctnQXRjLvSkh0ZRQjrwNfcG07tafxYs2WyBYmigvEBKe/njaLWdxYzb72dGYXc5hVzyI3SE4aYnNbUhZb2va9hn2AC6Qh3JwtX3FPwBVyPy3KNwqLC7vEG8+70nj1R/H70froQ9GV2E3cWX92j7xuBeOWOYT/AyA3ROXl1RamovA9CBmhvip60pOaIketOXovawtDepKJYCcdrjLKiDGBCcSazBxZi51rgBUuMYk1bjKD3W63hEPus5qTnldEv34NXPfMWF54YbYvvDTHr76a63c/zPOXXvf/BftOtE7IDsu3zS4rts8eK3fK8SaGhvIOD+ebP56/B3VzoAtJRwUa0IEBTGDDtM4ODnCCC9wAgRd84IcABGETtmEX9uEQjiEKp3AOl3ANMUhACjIIeku9FdTQ5hGP+UpfS9y50tBmv4tkZnIzhZnSTGWmNovMVmZrM05oryMbRUNFQ8fwru/LxCobp9yXv6JffCQrH+WnHs0TYoo1ttg5OLm4QTz18vELCJrb+V3YxV064bMy69m0bdehY1Gnzl26FpOQktHzFtrb9r59aoMqVcVUM73yd17XGlqotdwDNmITNmMLtmSZsWV7ljN14eus2wB6EBUSMNrrcmK1T+veNCxVU7iaYsEfBX8S/Fnwr519vDXbiIzY+FYrZNWshudZu1Kz2wRD8OEikA7SLeohoISoIgmeiHhEgIREjLRkgAySITJMRsgYGScTZJJMkWnBEgqjDdmSHdmTG4lLUtKSDbczFalMVWqLHYrELsVij/o0pDFNaU4JfasprYQMDbX2Opv/OS/mH6f6ugEkJIGr8IhYkSjTwpISVnXVUKFqqTY6FKFLMXq0Eplai63aq1zp6zZggAAdQBVobnTMGWEwJmEzrWZAM6gZ0gxrRjRjGjtxECdxETeBiJf4iJ8ESJBsNJuy1WzLTrMre82+HNqxReVUzuVSruWmiVm8SViySVm6yfhZC6iolaisVaiq1cidEK4BrqEJnnQjUNdLSKo+JAiVMFQSnYzIiYIoiYqoicbOtCoiK7ImWWpjhDGmoVapa3WDW32He/2AuX517e9gFgiPAR5r7XZo0W2GYXifIbAORjahAhqgAwZ4B94DJmABNuAALuEzCZP6mUwkFylESpFKpBZpvEHLBtggG2LDbISNMYOJ0cRkYjaxmFhNbCZ24ABO4AJuAAEP8AIf8IMACIJZMMfm2QJbZJFoebISrU7WovXJhm3Clm3Dju3Cnu3DIRxDFE7hHC7hGm4sBnFLQNJSkLYMZH1WgFu4hyd45gCKXIIyV6DKNXiFd/iEOjUopBYNeMQTnvGCl7zlPed8DrUl1FbCvgqjjVGWo8nqrD0MHT+XhIiIqkEEAFTRIyIiIiLqSyRXolmLYAql7Np36FjUqXOXrsUkpDqZXkCidLQBn4eYnQiDoOP6HgZJKFQCb5CvEQDhSKz63iMtGoBBQ4aNGCvG2YRJU88acMzlPCxYLJZU4es3CKJgMEgbIyQkJKRgMDjFihgVLWpSzBE4W5QWiSVSmVyBKH8OhUz1c6U+dBtgNIivMQLo+OxuQQ9y0psnbqEy2sNdL/MQFasLnBNaiD2kBQM0aMiwEWPFOJowaWpw2pvszMHJxQ3i5eMXEFwRAaMlD4WRGyw2bSu3bceuPftPYgMzMwcCgSmsIlvjzhBwESQyhUo7ZgsdgJfgwrz0VUU8wxCJJVKZXIEoa8ZbvOmhNyN0w5lgCAawZtEJ6tJ4xNh9OJus42oba0/KemHQGdNEZhZWtopVuWwrVq1ZzyxGL61OPwy/IJM1xrWmOqP2IdPCYX6ovQvhewCzdX92tA28AAyIWF298Lu065tBfnruMUlQc8Kak+LNxsbGxqbUoMZ7DMTIxMzCyvasuYvZY5GNZaqXtmrN+nPlNR8uK7jN5Hd1ozWvoZ0Mk1bfa648MLTeBXwvRmImcAgKSirq+Vb3ftjmCq29ZbYX/XwISbd1GCA0HXsuoWeBVk8LH8m/0howmEM0bMRYjsNETsJUJbDPGi7M5hzNW7Boo0ZF9Oib2qNHj952jdRZZ53bjommCXaBtb4gQ4vEEqlMrkCUC7Q/W21dOrCSiAHxeKiVICIuJLqlDHd65Y/8MgtH6zbeIHWA4RQ2/I9Z6WWllqv6L5gCIUI6Afj7Glgja5OvAAQAH0mSJImiJEqiOCkSmAjtiDQSOydZzu/5Of4lk/qQer7s25wZwlc+ciQ78pGPJEmSJEmUJEmSJFEUz4yWnAurVtA4iiMfgQQSSCBJkiRJkgQSSCCBNCn42N0J4i3snWpGRYoUqXReK3nn6CnXgwGyBBlBIlMoJ1O7zPlW2muQOz46OZ1aRRwG7eyF8sY5uUt4RCmuv30JcikNSKOYmFlY2Z4lOFfapi9wLBx+LQ3o9XOkc0Mgayxyy0wHd9HiLnsbOnxV0mB2EM4h/Qfw4dawZIlZZLZTFEWxWBSLYjGdCRIH37cPlTohk8iRClJSUb8TjXfdzs7ObG+2s1MURVEUi6IoiqIAAEh2klmKXZQoURRFURRFiRIlShRFtFgssUSJEkWxWNhkMpkAAAAcSuHF6L9TiX/ic98F8wsEAlBrHbUZ0Cq8X5HRi068Y++TFqzKkZLj67lo8JqqqqqqqoczQ6RRTINmf7EgK9vTcqW39rAv5Ww8haWrqKJa+1OxLbvPyJkyBgmpJpOXnPlrgW9l71RdpQQKrbjye90ZRHy5tG5N+yvtir4JaY3dJd15pz26EyF+dJBynEbjugmZNPUcLgDC4fCmOhwOh90Jh8NcQQ9belD06NGjR+/2pD1/LIOj9WTVH8xXEG5D+gLgtnJbDRbvTxs9bS0xEWTZK3KTVXgERtTlpAn9oZ8+YQTvmO+RzIyVbONUgvJzeQv/G4KD8BfRItlu1j4TBEEQBK/IsizLsiyKqoiiKAiCIAiSIAiCIPimpAWL10dC7ARVODPayJs5t2zbjl179ovD4FjUqXOXrvOmIpZxSEhKScs8NDsQUteFCM0SxkywexskHUVPS4MksrVLRlJixIhVWn546QavCHwzksgUykHql63tHi9GX5wev7rts1qrVNdFba2j/LQSJ2bil0XtXDHCz2LStHJDBAICgmfUAoFAIBAIBJhfbceXj9GM8kckTIexZbUanOjyhBF7LKkT7mVrZutlt9LFdlXDHbe2Vco0logOy5b+AvPyPrL5/7RVVD/+/c72i93zjpGVEmsN7EmPetqDyKTIx/BFATGebibz7KYTVX5TrJL1c+ZMUw8GyCrmwv3l4s5nf7CO7sRIG/b7iLL94g2uNr/Cf+bI/qgSTegYmNidNJHxl1JKKaWUcg6zNm3bte/QsahT5y5di0lI7WXeHpAoe9qfBpH3KPb94vKJdQmz6KL127zeitViElJ9hskkypjDC/EBAJSe/NYAl2lE2lj85ER6/N2zfrmUX6h/vhvHfQ8ax8sQ9qbS3T+DsZ7U8UIlqC6hiIjPoTGv6mN1/9a6cddLgqzCCTWXV9Dqxp4k9f29dlaOFWSjpkHHLLhuSNMwnUYyMbOwsj1ri5xFsTysWh+vap66olm5kjmj7qZBkFV5ZNt6Fg5lFHQ3mAXXIE0H0gkubhAvH7+AoFlRp85ddq57AYlCW7Ga/vxWB+2RvRiulEZh8IKRiZmFle1ZhqUXJayfK22iJ8EIQoZsEvBDyVZUA43oGJjY13M9Hw6r1Wq1Wq2GYRiGYRiGYRhWq9UwjBIOHYs6de7StZiEVCfTC0gUWqF73gBZxaidjq0yotk2T2aFEBGxIRwafiWJiIiIiPhiRGfFb0RERERERERERAXuZMg3wmaLwl8Mr1tG0t7029sQrNqrLxUXfnILtC85d25rO2xnlLpCijwTGhnZZZoHWMq2MtEvKVlXIFWdWKLwgID//V0Cg9ANkWepcK1SBLq5q0HeN75p1ixrvdJPZmreVl05pzLpVj9+ZbcK9bJVypeDmFTZhSY+Hl6qlndBmvdSkfMhZQ5kMcOxW/Ur1A0PtWrUbnzk8TOQc1eadmvv7SGvvhnyBn1ZoHOtwj28ePqgh4r+Dz8qOpSo+GE/KmMPaduHpOykg78gg7dLvLnN9Xl0oMLq6velAnsuWypbWKx9nt+7tm8PgkOiBcFLLy+aC5KKuC3K3PsLIfRq2UO6fk5vWvXmzrN8kZvVqvXBqlatWrU01KpVq1br3RtxZwr1a/x9EVL4G+Oi2Fm+6JRTWcfS8TP1U1yN4uMw2IDZSI1xHCMqWCC/5U8/gs+PenHliesEj+8GfImJZSUWjwSSizqpVNpYkfZ87NFuCfsOED1UPXQib666NhocZcUB/7y3/0AVfzUmdngw6o4vbv/f2FiG1KUHW8WSy048l/a/LLjjVD4z5yCvbqW8V4LeQoI8JsT/PY/y7Lr7XhEFSX5hyFG3PKpmeRevDtIQWkjQF0J+9txqKyiHljBhYvf3yy87X155u33KMb+1okrqdh/oP71WJMemHbfdjwRn1S7VGFAS2p6MnIKSilrEirUGiFnDObrZl35xwUPIbdi7ujdPp3Dp0uXypUrVTbCrIZL0xG0CRQJOHky7Pd0/NymeSPD1b5wQc9uhvf3/oa031iyeWWQi4OhlFvKC/sgPALs+etFs+H4DTNjd3cNZ73MZ1ynws2k/N9uE3NI0FBCPV8cvKkSwjvYugLMAem/aQQ1neAWHFRy4Trd2ZdUHA8UFD4dqck0tN3Erd3APvx+vLjigxpqNGm7klq3vzf7rqX9ny7VMS7SB72kB4cTTPawAgpwWEwBRC/HSEx6mXfROZG644KxF33Ga/9DjmLGFCZU/gjgrVyScMhs8fzpnyWlzJrNFqc00LyezsWAr4vJ66FSONqJrB9HGAp/sHtiOiFNpppXD6GGKzdxFp9fy8xaJnVX6WuVQdSThPP2Yd4hlMWL4rAfzmbRlfx/dXt7MDbZFuxvWgr2bIzs7pyTC8/bNHOwbTKKacD5JJSfdnzbKDP4oX2obFujF/mBf8iyZxSd+XkvtFHuXsyk6oeun5x48P9AAgsLletSviEueKXd32adAodNP8J3SKUqicwkXzNzYCPNzJKIJABgCGOuwALQQAMyt4A9A4j0KfgIIfAvwno119wIwGAwOXgx6PrhrPplzp/frdq1lfb9q94/3rSchpu3E8XbMNSNZanO3p6+2z84+NZ9r19YTfEZwSn/jvV/fYrc2HW/t8dZE6+VpZR6NtobgbbLFlgLp9uPLi3ta52ettRppRzZs339J12sgADDsZQU3fdPvJNxsjwoQjClfPjTZ8jTyzU1PpgQo8fl9K7JeiGXosH5F6J6FrM2tqfj5FB/EvZRY1QJECTDiTW1mcNV96jQgIl9ftdGkTKci6VLivZ5gDIBc8httAb6RiHcTuC6KAu6mLUG3gOMIH7WAUN51UTB2mdHIiFh983lTxQ4BH01jFennoIEBS25JPYbqRVfd2JUlaNRo7gAAvTLQZKYHAL+kRaMwxXCOAGH6NpvKsmHLJiIhvy5iWAQUQog7vkQQnBTt3yWE4dui2LNdv+hgZHjTKkTkU8nzEfDhTF4QAFJuDgF8dwPT9VsaX58CW5ECtTC+v+FuHx/C5EhJ+N04m9jyAtZ4c4CNxfyK5e1oEKkxvCl3qb2ZfwnBswW8lAyW9Ui5xZoIr0r1C4NBcazxrSLam2jY0+IS8veH50jLQMJEMce9UPhJvmU7JV5J9/4lgKB1vHwUn1vAJGVMTpfJZhG9m6iFH4wkdUuieG2eFajEfcKAk0yVf4J+S6S3CmSI6z21KQCTUVO1LWvupbTBKEwpnBMSM2amEdS6N1+OHO/SEQnjxvmbK4rzjRDaM8szH2GikYj0VIwRn+HSH4lcMCaHn7cw/I02BRPSDVtY+yiYjiS2toDd/cqYM1ze2AAHREUzUxBwluC1Wvsz0nQvrH8X4w1fQAe3y8ZwxbiOm28Ktq3HrrnK6/wjrOEAGwaCbraiI9migokI+E2H/6hZFtnbuv0IanAuhLMAaBxp4Yl0E1Nd/4kz1sHNaa7LuyVzkUtCs6XUR83O4XFW5m4aNzYB4eAMNxlJYiRI+HvXud50HTVZHCrO8hL+LlQPVHdlzG36nArn82naY4kdwWt2XzToDlXy+2qXKfLpp635Gn+ymJ34PeNqV6LQvoLxrOI30o30LNxEbpBwU7p5OKc5UAkR17XSsfh34C374XnvTgr73uUd/utP7JHOrogOutFBDD3dsQsiol+YJAtfh+ka6aX1yyNJfT2Zqqg2QK7ppTTdzYezrgNQwvtEAK+OztPSQfNRd5rYfFWgPNIoFUj3Ngjt6VhgG6koHcMObqNAvuI6l4Pc2JIggC8tD6X19K3UDUyI8NPmN1HvOp9umH//1BzlJHbglOsmqZV8s8EnarwwVlnlItbwaZOgS1+jnVleerosTkRFRFzatBwDgYNuS9N7aqvFqQ81RPR/ruzc7Tp3nhgcPcHcJrfKxlkuyNZMvokL0baCWW3hzEPLZoI8Ci8Va1lEhko2nEOhmJbB/nK5l+We/EBR1UFXe4M6uE17MUljSh+/ExguIsNEdlis90imgaS5ynOFLeZKQ2Ts7x3NXYzGHl6b4xN+uLxerGfUn7ljCbb1TEYw7XDr/VnjeVmm+sS7p6ZQ+D/g+xGUv3yWLfq2HV2lLiWLbb3owjdLFqbnRKSXQKLQ0rUEbk/tIktpXBI6oKJLvzwXgUFa/IKBlB5o4HYD8MaH3BmY2htY1bm14pZWqrew7aYbxpHo6bvXgUxloIKha/jkkOAAE+ApVai41dehg5FwViRt6r66eJU7wQ6sfT3w6MyrtCLcHHA/9EqnKYKcc9HfxXDvBDc/nHXtPXbNxU+b6QGPBJt2XxGNUxvGW+xnNGRnvVifLOE8zkYiXvn75Dl6O1UmT1wC18K5Y+kPE4CoDAZL4ScdxMVw6u21YCR3MZUnQH/i7A83kW6a6z8AG5S+Lf0rQ4HGjziZo22Zm2CLqZVuSvyJzjP8fLVrH/ioXvTlZz3Dwsgx5G1xWFUYviVMlZeaP47oyF6VtSVauGTQX7HmcBFjpjO2h3sJauBezL/jvMbftnP8GFdyXLRBoXAxqfBlEWFtv7DkYiKCs6F/JY0tLx/GbhswIZIn8oBEPJ+xvNE7uGG5QGbRBp2MKKS/F8598q1nMibBZE+eXxaEo6m71O4Wd6DeQ+RWm0tuPYhvLurS04+fdtbrbhpvrWb+gLcb4OQvpi46J5eRd+j7FobbQdNYiFBFSciFNyt3riE9vfL8XIwqBiPCXxkLkXoNk6BOU1+aIeUKVEsAt3LaqKVcQ5v1FANB6mR/oDlO3RyuwIIOEIZ9mH5gpw2qt2AMLJHLsSjPkCXHul+5nNeUGPz3WUcVJ5cE44DPtzJ5DTHVRmCu7tndvOq6HdjYAFEZylRBbLGsnLrPU1Z351K8aeqj2RrElBzp+XQFojoMXldAXP7nLurXooog0rgK+curWtCtsvIIzqlneNcab1IuocH/YvPBR9ubcen6jpG5l1P2B5q9INjXBKjWSRSgTvrf+6LRoN59CXA1PR6IUc90W+hZiUHYDjPtq8ActS8UCreZ8UyWrNuRiCanykTtsiWEHtmWLyVA5fYMtImjLJ0kLO/aYKQ1PYqYVKpfTPElw7HGty2HemaashTJt3/1YZUzRfaAy7FC1WZeP+XqMNG1GEk0dvKGXWv6XeZIkiSdh7YmzLnblZEYydoihTFpod1BP1/KyT2Cbcx3XIzQe3q1jMfJT+5sMQmv1juSbnlhhyl7rFP8CmSWrOSplpTwYLXA0I2ZXQay36vH1tCZmqn5BHHRt3NBlcshCgUCxOuSiDrQQZUKax7xHXyvxR2oGkjvOkw1pJWW1MniFqBh+zZohWnHMssr/TBFkeaNMnvbN74Pg8WxmMJRwLk0T4p5vdBfN/Smw+1T1UElyW8z8RspI0C70PqDgXiXU3YFkBb1SNtmIBY2ubFN5Sk8VcbKAhgXvVT22IaITaUTweT2NjP4ju4EU/qRuaxxssDyqR3F8mGyFuK7bYQnMxPpg+Ic0k+KqOf1MRtLKf0QGSaIkQCJznPj+EBc/FhwpA5w1rAF4TbtIpiucSFvHmG8fkCaIeORGI5KPOzlUJAT8WW5LSFMMx/8k7JNvZyW7jri0785+r+H5yVXh0sGzo+bAaZ36ecs/phb8bW37Z37aqp0okNJFZSEkwdxgeCRyo23snbRRj4doCx9WsMJznsuW6rQLOrao7mKINW+Ua41tRuIPuvJMfhiMprNjj+K3VhjfCen87zx1czWCUewre9hWzrHuLWyUh5rxxcwN3NZ1Jw7fUumfjyNgzCpyV/Gr/iuG2fe+C/CZSbSCea6tGj+PkL/dDfNK3t5vuEd5uULaijc2VM6YU1p+Oi9r/Js8/mAyrQDJ3iHS/LY7JWzDmtc0vrPrI2yqeevExHLrjB+pADQj+az9RvizFNb728FMBkQj225I3mzB961zT8WPh1B7C+o5KGsy8mN1XtGII+K1aeFExgwuBO7uVwjmwpkYPinINLthAfiW+/hMORE5nayYrAYAjZQqfyX1SseF5c8Jrodc+L9W9grzG6PU9DxipJa7I2wLM6lZ3hzP5920Dftb4FidFu5nIqFcC4ktmReYzj91JOCKYk0DiQo9zlMjlhJOZyvAMSpYuhaSf82ce2myEnHEcSejW9eIs3qi0jDv83EedEe3yA6KDsbVHfN0f/j1asM93o5+U/mbyHsscqMxZrI92nOtqVy9e0T58z4tIOE8Yr1gbFLRXpWcLZQ7MJCrYRlW8e/Ouu0zUEpdqkYKo0xyf2QI/s2WnCqVp8plJxaXR4X238LfZq+q1E1DJihZiAM22rtljXwmnFroDVbFVtrtiq3roZWj1sNr96i3FKz5V3NuJqBR4tn7s7jH3bLRdjdvilUUyYr1DtsQ/h02fTkmfNXp/02F28YtJr/6LAaGhMNPhqGZl5cskrIiRwpLbiel8UMXVhKc5Sq3G+MGtM3uw6vLrETmcUNIA7fb8BXPzF485bNGP5A/JR+0ifgVPEHf1w+dACDffmDmySsrlRI5NY1K8kYs1ex4Of6Tk+3UtyRnOGPgaPwkWdcIuFGoIIYioNuIqVze0vajpJJd0YnMdYxllU3Tx5/SkJhziSh28r3vipexKxuL19pRXIy8rmZCwN3OncsPuMBkuPMgjhE7pgcVcMAGeSPilVqY0wBfnyiFjdekIdoitgLJTDVjMpXQOHlLLsY+mklKpy66DANDpkIOM2HljGTOn6ykUhOYh02EYW4KjAlRDvR1lGevsMyd4x5w1jrWPu1StMM4Yxq46Nx9rH29TVJc3Mf6h+cVJ38D/pv+K/3gVxYm+X7Y+r0Dh2yHoPejKH19qYzHqt71LhMz9ABNPphaFgvGn11S+uSBa+qvYDxaHJ8XA56vKIUbyJYizRSiy7N3xSQiBQSkgmWIq1YFcPFeEEnBfpAKFAJxUfQJ5F1qBw+H5VLMVQ5chzi+dmq49OgpWwRWxKwMLQ5xWShrh3Nqa2kaSgDqRnZleq15v2DoC/+7N7n3tnWTS7DL7wl8Pln3mAW9X+iwqTGRUMqg9yHjk0J8AhYFFck7hv2DoOrjNKfx9rOMFD+MOD37/+3iQJn6OkV1RaSOm49bwsCIVvwb+6Skl968/5/2J6ChzYn0QRTyr3/ddPYLamU7y4iNQxsvzbGs2J8dZEVEqA+3vbxFhrY0dqQLH6hsDO7rEmgc3072m1hIbZ2yhKSEnj35mZJsR8HbcKoySzw8cfensCR25v7npCW5aIo/kQv5J6rI6xwL4mopdYVHeQrDXAnXD6/JsJnJQ04d6tDq8kaXgzbdlfLMnHkrEgDlgmM1O9SKo9pjD/HShVoZXFXTxV4w8wX3+LCvPf07+vKG8H66SEOijlxItNPSbl5S+Xq11VSupDx4qZfIE7qM/9Po0cw0UPpluN2zYC/wDDOnbKExIEp/4eZOG4U60wY46Qb/oVSoJTcQv6q1OJxsQrBZD+6OBPv3G72laMoJZb44/crR92ZWQs3Sqa1o8GIf/iNwYQlqm7VqcdINxKqnxWu5jfS/sGA09olwRv1/G/u08woFrTKRc0UxPJYX2cED2bKpDZ7mk5AR1xO3T9HoDpy9q2yNETY5MIkgs3LRrFxlqdWT1emFBctH3IlLtHieMoQKl2Bf4U28txJJuj7Hsa+zGCNzZqeWCyBcgiTkThM7eLF07gGwFKFzUYh7okUr6yRgUP0veaXlbIYkQ4k3tlW/AtwW8JQmzXx6ivkalbQgfRAhaF9X25WulEBw6PUHtZUFaBKkG47umYBPI/XJZ28ZDSSJ34Uk1dZdlHoLcqmqSyMpowmtpVlvfiLi+SKjROXkEjLsLaMeTOV2AIeDJHpEjXFD6P+cJhU4vA0tK+nGb1Ra2Uaqs3PhlfhKrZm4Y5rfDh22CiucOYSgvM8U6JLjv+rRVEs6w3tNQjt9nXkxncZMsrQXoRgnlxDrvNMUm9RLk1jYTZlTGcmsSxbL/JYnwi615OuKPkCJfCkz0dxLFSJHy1AYAqd9Ua4s0S1n3asPMxBNbTrSTKSrl0nkAlmGdr17VENnrye12HQrFo8+2PCV/2fVKtlxt7k3hWdu+TBmUJ9m56S5FdnYm/KumspePI5LO682/WKwApDu95OQ2JVnjtQ4W4goW3UDuI+YiqmTRvivNen3tBuSBj6pGsXWVH+c8TeqoJ4RQ6+UVlMsVKsE7Tq/Ldvg8xBJqUS36jIKYhHVHB//0MfkGebF6ZMlUWr+nc3/UbFhORxDCquI8fQfq6iePT/Z+F9q7TB29Io0cQjCCyTT9hmJ9ID/nxLZ0s/4P0jLqi4vDcGMXNo20s+Hn4drGyEsKc++yZxPomU/xG7XFqQb3Fdufz3FEzoMdv3RnShEV0UAJe8b2grC2qklkyY3ihWxMmanr/zURbYm4kqo5kigEAwGl20YNy7TGJSGpjAik/HMOTF3EgtoisQn+HhWjpUlzbBnKi14Tp1Bvu+o+WqvQe5iZy1K3nehtwxrDLpMf0OmyVLp7Omp+7QH7PXt+Rtjlw3+KIteX/Evgjz0zbF0iVthjKPVg9Rs2u5q2Flm2Su63LXeqDHthfOmOk22y1lb8K59OzluHZc+l3FnTT7Vp/dPtZHo5TJ1MQCLxvSbk93lCJicH7VXLlmSKOImuE549GNqffDRs5XtP9lyOdWCRopYHhrVlybWYGtA8gPVF9VPiGE7RNcOmd7nfDE5+1bHoEwGL+otiB3qQsHutawREcW65OTcuIgxtj7J0jl+UvznQsEYmJwRKqj4ZlnTFLIsanaq1fL0BoAy/n12zM5k8eI+H7MaB+d6qS4ctt76K9XqPcU9YiVDvVfz0gdroOSIc/V6q9dY8TaJJuCFlEikhjsT9TAQCuKE4JUiXDcy/XG1iS0w/Nrw0uk8SF0hlA7PJzLj6N4uvdo2yH77OYKXGoGK69hU+0IUU52qJkp5RmGHNUjPQsbpkyw/Pc2g8PT3HwxEi1MTNcX6DggbhPX4fPnwybJUOTkydbHHKXokb0TkkMUp3Bls08OY2LVeyrztJBcLi/r3PXkLNMLw0KBu5AQjkahkkXNbqbwEql8JTpNyMWkimBbZDwt2TfrqpNalhCFcgc4NYNTyZ/Ih14il/51nAHbtc/3QVhOhj43KzKRCXLFVJA8ta4PHEgcoPKCLoSFXgwKOhwadoiP77nMbvnPHPwh8Z1KaPG/+9ijQwq2a6uisceMrAJTdMVnXNxB1HXTxaTY6a1OZWuzQ2TvCtd5xLOUCE4bSZIGo957nCv9BxyAkBw1kUUFw/MumCnRGiAZmiRkBBATmVIWKKEok4AFMUQtE8RySApyU+0bir8H92swzCxdVm6kliXlQ5IIiDit/vRfz1gjU6BCp0Uhvb35MbE6z3A0na8mKD9kR8u4UZewyRyhUf6dLPD/EGJkCfnyr44c5bE20HJBERxBbd54pux0bIpeFksJEDtOJ35c9Kk1EHbyzjReW0uYU8jbXO4ILjl2Jb2SyNaRRQpChsSSmTTKHhJE07kVrtw4hPb3tJ7j8ye0k2y8yFBoYakDAQfAqi3ryB78bg/Vs2BiT+HozvOe1M4xYwI6LCCZw31G59dxoLBGvsSsgYSJxPrB+sMRTHUYp4IxCCoknkLeBEf5RU9BoVhslBunaqc2yMdGU1qDCJFiL6d1rzzTjelZXC1fXiykwHhbnW4Ahvf/2rtxwwNT0+y5sxN3PqDNnfPAlFdTU8OpHpM3xjjnAVQ6qmyUCVj+ZeGrpMLthdtN81+s+J5UeaD8gNLl1AhIasZtVC8u3/PeMr+TlgLfwNYYw7Ki29j1lKSlEQzV/lEkNk3nY3GVm0y+xhA5Y0DWfxNeFt1NZVG7o5fBN65ZFCuemcKahaKdO0TCmYSFftMfs0AtG2YH/5+0dhZzpjBsx84wYTNz1lrLtRude+6JYcXsuXlvRjO+4ZTe93kFUUGMN3LZCFCpkxJzObW4rTle9B3RCRHTa0cLRMf6NH1k0SbNQzfsR8i1Ly6LEj0tJSbp7FWaiKA5MXPMc31vWtiuvMZXJV65CxcIbgCeqxALt++p+KOEla0FaUWpCrN48Y795YtfgTFczeI+uO9gCLzNkDEAwxlhMJ0eBmfA8AACn4FDaDQ4pAdBFtLeGI1vJreAkR4TfYQzfQQT2vF6SuzBw4lEUvX6xWGaMEFX/pQnNNy51wK3YJ6XwGDTk5SVPmt8rC1PFHDJM+x0ePq9SSJtIBwIhQbBQRHHF/BAfPLB2DQC4xaJpkig+ItUsT6To6c753761IuJ08ulvO+xJjoTTc4k4MVeD+B61adwXsI3yUVucCxZ5smTrSNy7fpCPDPYaTvTMaPRYIrG5cPPfPc0vX2y3FbMnKGujE5fnKhMopl8H9dbFFYlJhmbClXz0qLTjHQjPVmcA8XCsSHa0MT4rEh9pGGSElGVxCKplOr4eMoYVWpxrDqFDoW7Y5OlyXfeLl3f/FgE8Unv356iCcHUVJsqJYb0lPVoNMxxZC4tC5nnLcZ6/PsO8qhmOhOiWyfyVjHF7zSDotD7Z4Whef8VgSomGT/++J3Yi2cOXXaftbp11WxW75njl7+2rF3WEdi6KLJRdaqKQuK/LZewUUXyDi/QqcA48ZEL9d1I7THx8S9mux6xJDuWIFkJYQno7eOx7ioIj4VVI7BDbLazC3O09fJRyjoSaR2FvJsS9LiuyxGMg85Dzm0ByPeAnWbCoV/9c0exc01wcGuwf3XhbFQWIzqJTtzzK/Je0JKY1tk64vS/hmwu2gtNvkcMDGC8eGyoExwUVYY9EzYwBKB4/jxCTOdsFy/dsbZEHjhTyFl6uElASywinwz1n7b5SDDx0Nre/3iU5pDHT+8v3EgH8RSsKjL+0Ucbgw6z5WydOrMlLtZ5ENuadkQ1GaEmryaz+6IFmXFRevbxqpgF8pn3NP5e4Uhfy7UpdbXbEbN33MQqNXX0qZz0Ri8y1I/fE5letiKA9HkdsRuMPbKso2Xt1+OXQ85cbl01a7X7ocuBu07TYX3xvrJ7eKqKMG+L6CTnVtWWJBipzpEKFLStJ4tzvP5dirT03qi4uiRoh2aqQWpMMJI2RJi8gcck+8J/Gs4VD+x8rfAgp6xn9yYE5o5M4RNNj9YHKxJWXJy4YHBy8+QZ35pmvuwvLOaub0+dFVgUahIlPsaNU5CszsV2urPEIIPTFoSUiqlcaVW0Afe704fPDUL1VK0JqXpkL8c0VH5mka0nYrZjjqFdX19z92JuVUFpdeuDOolaCiNQgrx2V5onCSs3CzqsFcyIM2Ry0wHrXKHTw/c6MyQGeVFxCsNAYicoB53y0wptSRm5Nq2WbsYQv/a/FKpi3J88DvK67jh0zpO0d38rlWQtDDt7iUb1E1NYbKU/AUQNz9cxhcj+/ffexIIcwL5j+2lLNJKF0lRG1z+Ks/d9FcImZgE2PUkYw3zz9M8rX/zDymCOUuQ4BVBCT1pNzJTaPf1ehbxE8RnbnM13V10YyS+4++Ws9H7H/clxKcRs7wxnLalYBOkIHf7RLJTRi+YF518XyfXZ6emmPMcURwF0Lv/HGVW36vGaezoYNwYmc20uxDzh9toR38I2RXEtVkqh2MduiBE2Z9H8bMdUfzh8E+eJTrmR0UHwt6nkj459+1VSNY+XwmEhPYKr4DNV7kN0Z8SwqHtPYoaDho/mCkou6kFnQudFDvZ8U82WzIa1sEwiw3GxvlsNrwoSCur0dbI6XV1+Qv6rZchrN15WKesDKdoErUQr6UnoKedI5NfpaAfItKhV0/kdDQu49QvmFVSR55Vzd/vEjjPFT12s3pfEqRrnHauBrIvZVagW6p1rTH0L8vxpiGkXTxpiy4W1KZJo7QiLuL/aMECZZrH8QI+q6zWDAv3117UbElzddF0qoWWJrcc+GSHlQ0bt97dBCgvNp5uSGrn2VPYk8+odGzbo47O7H+b4R0+cPnlay8wZ3RzqGsqtkuwaS5yEm17zMDBHlDfZHP+eW3l/Gx5irZ5PblyrORZepa9IWPEpsNB9Wp2wml7GamBqxFhmIz5FhY9nN6e5YgeIbrl9MY6mCoJK4/2OEL7H78ivSvZ5bZify37HeiMJLmTfkVKmrNwyInz7BLH485yDVdc09vDh8SB4YUzlYiwm4vxvH3Rq7pRQHyz6xOvwpSGhS8PDl4aGLC3ZfpbpwSAoTLvuOEL3oX0HgwM9vx9HHkoX3X4QQQqejtsf7Hu4/857CimA4DU30H88KYYQ1Dn7i/OEoFWzAwOfar5pfL7Iq7dv4snyBZO/hOI2ojHrQ9DvnEKC3xYLT2b9YaenfshIpMLil900EBeIRSKlDx9a6Yw1gzd9frP4cb81wuuEX3xmU0eYJ7Q8at0t7j06mw6tqsyfpld5plfWedXp4UR4x4hktUnKOVtEVHTlbcpA/JW1iN6rpnhSlswU8/+XMY1ceXyye/JO5BmBoepW+fwnUjfJ+E0+g0NdOszWsABKzET4gfZLxIlD4jh8ILGIE6GccnfGZjO8/w553AFZFAwIj+iffezR9O2lLsL1P3mtmfCfvNMgAxK7yRFjk1AucF4KJB01wo8jvSiO7sYjpROVdSGwiXq4UNt/udP0wYk0qCMtlZ72NxG3YAqds6uUa3fmpLDb19lkt3rUlIsaOG84iiMP1ZHnJbC+WECAb6q5UAX6KERNWWgwRpFLGgERONvFM6Bsu3VKikhbHRc2xXpCvEvYXG4iVbbrrAyC2y5StPbY1IJPkjtX271CpLiwzqalaR7OwvwrV4K226OkaK6rW02HOxd2SK4YbTcnUnQV7Ui7ctMwTipj1geRmym/wPyKhkgQKIkNlXiAE1FnhVMdQhLgO7eVclKQpqRo0jC5AqegleTXlI0xIuNlRxYIfdvlDiTEVmJRAyrujrRUwgK1QcPECpzCjor/AKI6FH+ViHtqyrQzVkVZ0CSjSEMUCTQeP2Gqw+MsnrShOKnZoh45BJWuFQgGs6+2a+lTtuvuLBUN2k4Bz6Qhu7kOXWBL053XSCyTmzs6sN3oR8Qe0h4CkPg0lYu2OWs60JbshWjwGvqSy53zooSDbhBYvuS00ahrGJgesO25or44jvWR/X2bbZUF25cbRMY4eUmzkKIimGjsNaKUaa9tD9i/w7zu1rIhmGhUUXb1P1jOCx7Kg5n7Ii+tqAiUhdawvKaZ64IpEROs/H8Q8LRg5dOiwHkdJ+A/PUYL4pB8FqjkpCCqL8V/pkzVRYfs/4dWwrQX4WUsuCTY+PsYCzJsb3Yv5cXe1bbA/qYegYoGKRCwExqiWqDh0AhZKdKjNSwVzWJsqNgME7jtImuwKqTydpcw4kJaqez4DQv8GA8e0l/dfCAnmCglOKiV8C+VoY8h3alsnY3DKIRpJn0m/LgRoUojE/W/5/YlgLzYf530Sq2+LjjOdLhH3z5874tROba5H47WfrMkA0id4zKvH96hWTudHSbTQ/VCz2EDTMXaV3CFpcL83o7SUUsczltMB9BrdR8Qaj3tuAOvT5OwSL5EiP24nCIutfYb0/KNGwBMw1pKVL8MsvEFodaKLe1oAe8DgitiTwCM58pR+y1Tph/m3qTm2Q9hd+UB7FqyPq8h4vROTD+EXs/dAF6EidILnXd6HVj6G7M6CODnTv+temT2ty9dx0ocvQvo7zbOiRUQvafv7nDleRDzaHfb3w7M3XbImNXpmmUlUz0XHZXkuLy2bXccrMZdv376OWqjN3IcGa/P+bO9kW4f0VzkawvZ0XZQmKMrcjpHZqykN+0dyf68rkdt08uNB10tym1hjq7IcaRjuch5S3N0PrWV7UsPuWf7ipK11HavCTnv7/NZ/Lsge7f4cTr6edm6mLfv+mm6hDhj80z/3qJ9luicwc0rBwOWfvFaso3Pqj0djs3uVYu+ZVyX+t3Locm1AD2w6nGyP3xwGsLJE6Nr8cGuWm7tR1Ci6vi3+8am6dcP6vVn8roee5Z7oe7bY3mofXC9lmGOrm79the6dS7mdNrhY7hKYtf1fi3xuQgjWj/nfL1g9GtKaxm1ejuW3mzuWN5cr9nIYmDa5Q2yZyUjQe+VOPEtcXN/XtulMW/3UwxER8yKrjiqO3A5be3bfzv9hWSq5qJjkjyWgVy0T718pcvtwHp1jhblsh3qXI+thwbQsdOPyIkjUXv3XrQ8GJnvQxP9RHO/5b3CewTx4Ggwfa4B7gQp0iRryAIb7OtY57r2zw0vz5UAtwnymJGY5XeL4BBMHht2kY4v4ji/bgUTW5I/cQiDi1xZj0PG2n99hLnGGLeKSnGlVllCds0zb7330SeffZl7CnkcvpU47fvXMGRnhtMzP24995axouyyk7p1AwLVB9ZyTBXPLwTj9rgNFVdro+l1xarD1vCYOfEe8s6mMepOzHJSEXJknUO90X6uINPLKZiGcZNdd/u/hUufZMjVemqrTxPOlIWKWDhg9dy3rYp+evuV5UKk10yxiwbtYyrW/UZKSqXUhPSP6RLgbu0uaYLz8lwDRtIuXCKJaY1SYpxZVtr6SK/ld+viTYPrJNzb/cMVZQkJCQkJCQllZaezsoR3v1PDETfayvKmmUqunZwqmCpYwQ/O82rdp3VDKvoBlAVJZW126T1pJFGib8ysjLhYBt5zqT7k3d4YQ4nTURRFURRFURTF5Vd57lda21r9DZnkrC3NpDg770pTFnOm9BgTQgghhBAih0gh9ww4quZuE7DK9zmk2w0VArtniwcfewPbs8eJRlw+IYPYRwghhBBCKBOqiXYXuOhcdMyNDAAAAID/IcZK+2LsbaOcdSaWNiszMzMzczZzY84ql6/0t/XHP5WPOVBX5ZezvxZanfXjrApH9lB7efv4+pVo+86dLMufvYKeiIiIiCiLqCQRLVnRbE1SLQTQWQAHAAAAZIDT/q/UVXhaw2KaIQMAAAAAIOFXrsdPi/Jd8bZUcYxnS5/3iG362+vrryly8T6MOzPONBvqRRngvWfGZhXS5Ea6j6SNWup/bjBG1TETERERETHRUK0UdfkLg9EPT/YvxVkdyrjTVwsn0BtewzbgR/HppvKr/kqXMl28Ahe47DiO4ziO4zguOU4XeHC0AIvFYrFYLBaLJS8Wy9fqykhrjqp+SN0mZcMwDMMwDMMw2TDM76xGkCYSIQdBEARBEARBEIo/wA/U0EyNpI0gMRZS56V9lrOZmZmZmZOdvTbJ4lVVFYV6GUUlR0REREREAil/6KadGl5ZlEVERERElOQ1e6vrypPHZ83BJc3VETVERERExEzEaEetuhXOzUQm6symP8F8p/X5jU1cw/Srfl1xkRiTHBERERGRlLeuo7eX3bw/HAdNz1t+Uor370ET0lI/m2YAAAAAAAAgAwBFKxcvU7wiiUg5SZIkSZIkSVJK0i/ulKed6LoC8dhznbI3fA/R7pF0HAlLCCGEEEJIFkJ+5DldZ3jeNaVbO5twFD/UGpxoz41pWMMRKzDGGGOMMc6ME69dREMQHqJzgLIp/C4rXsLDnmkOprXWWmutdW6tI665WJdR5VJKKaWUUipVX4Hd+S7lIhB0G/7qrcb7H08/afAcZ6u7iYF+HxXVTTRttiwiIiIioixKsuwvmImIiIiImNiRkHbEsAg+QKuyba63Uy8ytre3Gm4operefzeONGKWHm0U/Mnk+cznFVdVRz30Nl1HZE/dPM1KKaWUUkrpHNpTIvRWmX3lFstwkwLNE8e2z2UN2BFDmsfZ2m8QJlZiyWBGCCGEEEIIOwwg08nbaw9a8ZvJaZmyCH4mBC5CDoIgCIIgCIIgFOMeq1LtGY4owIOn/iDZcb3I2O77d1E/pZRSSimlWSmd0MpEbHH+pomuL5fs+Xjg1Mjd1EndY0twvNC5e7zzWLq9iGpjvanK/RL0jrcPs9zOsWOtOrcsV+UleNYwtd1MixdYM2k+e57neZ7neZ7nI8f0p5z2q7eMp6hPcDHo50kqFEX+AoEwEiGEEEIIoUwINZOqmvfflBlZqSxPrQqdNU3TNE3TNE3TcSFL1iOMMcYYY4wzY1x+NnqaEDYGE2fCuXn1JqhJDdOhm9DYbreChaJZqfpoAG4J2D+9DRhU6ng7ZQxvFLxx3PSEqC4ful2UyEIIIYQQQigTQr/82Y+kPvsOFm2OtZgabHqNUJehURRFURRFEMwQFMsJO8ubdn1OPeHa1omYSyc4VT/H9lvk1je1YtWyvxjrtR62XexyuJMtshzutluIyOXA5NFWEYLbXVP1m7Hu6vLgi1oqt+8enVhzqRcPZqcXqaAG/3csTXsnFmF7ijauXqwI/OdpNtcoTmUz2Gqared2bwusBwJM1fgBj+breVKGZLjeTMVH5U38mCDKTdM0TdM0TdNy02btG+qnb8W4dmxH+4QzY4wxxhhjnBinCV1sCDktab2EK93gB7cRiEVU/15pD4ra4ox/TdVA79KUYXngweFwOBwOh8PhyIcjHVL6f//XOHMM/GnpR0Bw+hiryRBdSrwCEyQLIYQQQgghSWZyFWqKyL8LZd+NTArqHhFTP33QbVxADAh5disjHdw8B5hq9a1M/e63yH1Zf6qqqqqqqqpqrqpa5qUHF3UxY5ABAAAAAJAA6ePXSk33pY8/Iazg1/09To8I2cMcSwcvjuM4juM4jsuO44oI8W4RzHuesM5VymFextHR+iH8zYFhShbo5tSTB2cPJtPgspHpTh4Z3M23r/gh7KYzAAAAAAAyoAO/eLF+cbwNrn39NHRg7P0NMzMzyayrJo+p4fYcKKgaG9re25vaxePcC/649t1julvOaZSxBxuq1Es9Nfd2I785f0x2nlhDW7Vax2SPFyPqlo9Jw9eekdfMvNeMVl12rAY7Smo1Ty+EDR16b19qmA/fUAL8OJo0vvykHyGFclWCAAdejnu9u51JT5W+PVmrm9va9ZCWIeck5CAIgiAIgiAIQmy0V7rSHyYagdWH04bF81Ig9yp7NRi8LxZYOHo5Z1mWZVmWZVlOuc9ypGL9xwP+/id5W1C3enz/OqtWMiEvLJI8X8ls5iRJkiRJkiRJOUnSorw4ajBQFEVRFEVRlFyUu0tm6BOwTp/QjOFIWEIIIYQQQrKQJO+p3pyHN/2NzSpxf5ZxXd9l3D9E8HShOEoppZRSSrPSQUuLQwdWdX7Pc7XlrWWsm5ivbfJml+8+2Ty7ThYbhRt7SnTdbLDhefzL7W1V6xEUJcrZ+SiyoiiKoiiKopij2MVpuXKPc0m4U9WpuaqqqqqqqqqqWtRznwgZh/vy8TaxaFymkQkRjG2xst/CODPGGGOMMcZ4ZYtjcX0/Yfdn7diXySoAxbTHk90X6J40CbSzJw8H6Kt8T17zYRkqwCqOaBqXY1qKPWT0chPS7Iiel/o+lFJKKaWUZqW9FqUOmIZ/Wfb11HPXdV3XdV3X9d2eK6jR5ITqS8y9LdilbfN4P8j4ev1bgVzTn/8MyiLa0xlbh95KtKJs+c8SDVfxthkLA5eYez9ztYh8EKmGas7KVRmDTRDWloBN2cqU0B1ydfNwNmzLiUsT8Sqt8KIMqQ9UUO3qyO4aNebIGAYuUh/2zPt6KFT+wR4b1b6731FJkuCvDVgIeGbLsizLsizr6Vk/G8b7p3OL//YK4Q1jaE3g/zrkQ6oQlf9xKtUrPzw8PDw8PDw8vLzSK73q7AjJzGaz2Ww2myEoI2g2v8/wA6k+/BN9ORpdjHk0Go1Go9FoNBrrUcS7ER7v+yYtlI4zY4wxxhhjnBiTEf5cz62geNkCaJZxNaNNBpjnWNJ8IoQQQgghlAn1xHOeDghuFonFeaGqr1J8SfcJv1XlIAiCIAiCIAg5CCnQ1hF73WwOxsL314B4HqYgUrFHzoXLjuM4juM4juN6x/BmnS5wtHqVtw8NFUcohRkhhBBCCCEc0J7UKMIhRi1lKXC6kjzP8zzP8zyfPc+X+eeB4icVovYYOY1Mo9L02qSSgp7WNwYgXw8YaFMmUw6tTkXL+xricli6nNT3pq93F8EuyY2eXh9FURRFURRFZUVRTw0hTeMba5TJFKN+q10Mbl2XRr76R8mQ7dePrhSRqVSdr/baRBQtk46f9edfJrPaX6r1E+RPY7EbhY2sWiTH47m1WAMKuUuAQFnc672fGs8Ls/+tLKL/mouuxj+k3Rg4AdDgO4bspy5f+ysR6RNKNVx3b2lKGRqF7OOOipJaSJIkSZIkSTJLMslHSVKSo97DkB9sRTmWZd7jCKQgAwAAAAAAAKBpEaoTsEBiiepxx6Kmd0F92YvBxBvmtgmCSIKm+q++zTawf1kXu5tlGqRN6LRUM0hlRVEURVEURVFUQI2R9jRnvQ223GyLDcSWN5vNZrPZbDabzRb06skX2w6h7xLchhyQnyetowzrPpqhkr3aqlkYRLwVuZmKQhioKOyHhUrVX8U7TQdprb98q26O10eWioXVKQeREWOenO4LFImIiIiI5IgUnDoYmbDf4qvs7rzUC0clnM3MzMzMzI8/8hCPHuOYJ08pkzdfTK9aUQO+79tuGz7UJSSyGZABAAAAAABNzbLWw1Um66vK80RtyJOLNpI5t/8Mq7iBJajoepyJ8viRTj0/oSR1oQJRFEUAUcxRZEIgh6h2+B8GFe5jfZ8nv6e3vvLjKctsoGHKM5lMJjMzk6merGqrXD5x5r889HkyUB0x6VD3RXT0tCxL415jQb697fn50g1JqoVCeZAk3JYozwq5dMLayCXRyqEc75zcoptxjDRfp7fObwTfY65A6zP9PNWfz+HrP8dvasUCjx/4L1/zDTAn1zfp/bei1/OvfXM1f+znbUbYs2CQsffqkuIViSWUQwghSUIoEZpdcyVijDHGGGOMM+PEJu9rE/NZz8M8ljR7KBNCCCGEEEIoSk8jTmxosteU5cImnVXJDabRJVpSw3iuxg2Xw6C4DtOOWWK7L0xXwNec8bC+1gr3cdZDo8kyAjHowWLNQQYAAAAAAAAS3O6/dDXfn9fVPDkwinCS5/t5lW6VVMKR1hHD3F6LWLV8SWUHLf+jpY1u7hmFWSuaHWau6uu+1F1/dxt15Zx9le/nY7f93v8q/6smYg5Xq5qnOhYNzfjZLCDTmxThSAiVMF4wqnatF0S9Jt3kN+nESYziRhUT01pRsWiblONC334WO6vuayK3+GqyLMuyLMuynLMsN0BYIBdnxhhjjDHGOHHPWBy4N+MvyFrqsX9kUwOV8/Rox4oTHkBSvms4iHbRhZk9hBBCCCGEGSHs/Vql+1NMPLk8JLptl49bjgpxZowxxhhjjHGz/ySjyDu9qIJb1ew3j5SU3GDfS928Wy+9WWVJz9F5RBND7DmUVSdjhl5Hkrltyv3NW0j7vCk2/JRFerH5+x4gWydP+7TPevbpyYpCNX2/9cEAjhe5QTTENJdnlOR0Op1Op9PpdObTOZz9fsvPIvq6HUlpXwc5dtHiXYnxh4nx6uWBckc+HA6Hw+FwOBwOR7EDo7vP7PqZ/Fid/eJm8PcSbtJ9UhU03xAZxgPwJvaIpt4LmrT947DQlx9LnpKXTtxJaweeaeynQ8PSp8O3aqjW91wr2iUrWfm/mZfXGj78exfrxMQ1aHf/Sur97ev8d1lfUNEwx6NL4CszMzMzczbznu+L3mFG1I/LjzUHHzz1Hv1gMXpQ/Ylipit+MJfWK630Z//QoJuvfwjworbphEnJKIlYzlNNvzYdeYllWZZlWZZlOWdZfv47/d6zC9dXm0B2003T7lmzguvkjusRGclCCCGEEEJIEuI9neIYDFPAIH/mMxRFURRFfeaz/JnP0LiGJ19tdgxvJQMJnVyeS+bMxIkgCIIgiNPpLMoc4ilZ3ti4UKIoigCimKPIa3MMU59J6FR/0JZIz5Nb6kjY7GupR7n87/et7GgSicTbYMyTMdVybCSvZcau6VoWcsXLhjeZlbzE3pdebttrqzWta9jLJz+4rojxriSRMQo/fhRdxEwURRFAFOvIeq+81zq5+940opt0v//gB/d6fcm7QE89jtDHhc9zx6F0lmVZlmVZls2WTfY/Es32f9bjiE5Pib8TzNpEVu2H/JjRbKk3L6Gd793eaPge2knUw5l1b58hyJe7Ltvtdrvdbrfb7Xm3p/02dZBVfd2vNaeWF69XAZVa9XLVCWterVar1Wq1Wq3WYW0IT2uvKlypbc41+nBewjPjphiTxAhbozMWzoqGSE1qYx9jP3w9gjlr/ECLnKp6cBV3VlfXFlvlmKHaYwbbIrt0V5YAw3OeDwV03eXULurJ6mGwtTvNiagbXkDVPrjlWAGm9mbt6YgN1BukoEwIIYQQQgihOF4IrW5LWD29Ji1wUTzjfbXqDQS6fQqPF9aYey4/tzpFcusONyUXexE3bQPaugLPyrMvJxcBFa+jNI2IgSLeJpJK9W6dbY1DLdeYxbjSsaHfqcr9UgHmqW6KSB5geLCMwvNL2f1SlsePJYT8ALb3Lpcx39j3VVhhaNJSIJrIgiAIgiAIgiCSeN4ZGqowvcubxaDPLeibDeHIApZlWZZlWZbNlmW3F2+Qs1Y9TxJdKVhhCes6XJHfvfO7XN6/U3WJkv5dMNOvo+kP72093OV31Z8i623a2JVV0/7ke7fRPhnT5PTSMzVWTakXwp/mb0OURUREREREP1oOx61GvROh9xjHBrUdz7GYwpLfvfmikN6stFL98JzdRPmXKSd7ry+GPQLLjUSMMNp+LaLR/v+AAvV8VBD5kdo26iAfW1irOaS2R2AhAwAAAAAA2nZB9OUpfzeiDeuxW23h8dQmD4kyIYQQQgghhOIiX8dCUYgSTZPWfbsnq/N0vEJvK2Hobx/E54HneZ7neZ7ns+f5dTLc5QKL8LaZMcYYY4wxzowHbmDNzsh3lAyORGJzxN7iCcjI/lFzuspXNVvcwsltAAAAAAAZAGGmbaVx1dZSxuEnPxWcvx2Hat1f2yOzN9ptv/Hxuhseq/uB2DvW8/7+0JxN2SRvXMN51cukJ06UY2e3+dOK3lS2z3S/dLLuMQkAO2YnoEPlZcLmj0nBpOfTP5ul/z0I60sAPPDs8S4A+Pz5WJXFlbq+XNNAAAOAwDm6VOj1ZXHlri85caHTQk7g+u67VzodeNMNMAIa5wGlswG0dTqTxEweQGerHQE1DqpNoUjHtObJdlYFmApdUA+NkIIcDIcRyki4nNZgPYCa2fRklf02T/CnAqD/GQxO1Axi0CuyAy3EkR2hDOZl2OHBef3rDOYS2ezep5ao/BMyzSPSG7R8ZqQpQmv8AMxTgCkJ4GntX1T3QOoGeDaeGiDJrwBdbYtOasjPQJ3Gzs+CT9QigWWlgX6uEoI5L/cP8pN05QONM9Cv/7H74Btr9i0/U0uGC4gFzuR6GBdAhwHosQ5nhyYfBLgI4gNPbe7fhFvfzghYYJyAzEyxZW5xbjcip+vM1aY5HkBbBiHmFb7GCSiHvLX81YY0ClpeZSoRpJBXadWQ6PUEKXmSW/2RwYnKIf081NeEBzrs/N6swtV2v9chThd6IftgIxnMHSQstB8Lv43ZOuAbmoCZ9+hFI0KgZ5q/QNv9cch8KPPhfIIdXQEQr9AOFA7mL7YPPoERw3v0ojEj1C9AxlVxnE/C1XF8YLTXIAaDclpHRGR7juIzwjhje0CEUce4iRFiX7difxlsnyvtNjyHu/CZPF+OJ8/1bwLIlbq3hEGtshmRppX7OcGoytee15H85GQwmKUL3oeKrn+rg3FzfPLx9J2BfqQ4A4kS84bW+uKQNT1kjZQzmEQHQvDn8bnEbARCmFnMjU/CuKBnzUP8qcxtAxiPNfeYPd9cuohNGwxcwxBMhUvgUJgD7e78/Ap4uU24XRP2rM1KaCJ7ewFv4kCzG8WNgL2ARlbTA+9qLzm9wJZOxY2puL70kpDOoB+5SDXGrUUtz0gAPQooF4tEHl1siOnmYodlemr0tCz20jtjjb7txQGaZs/iIFVz/uIw3XO7MULGRK8xOZbn8cYW+iOG+GYlZAVGfkfk83ixRBjZGjwYEBKgr3QmKq0FHV4EYwbGrj1tZMmLZsUL9XCgTUpFgPUfYs+CnRxKvOd5X6DG7EyiSAEY8pmz7wCtAjFU8qoDjC6F8+EezgFey/WtjoaeLRsUk+RnL69eks7K8wfgbHSM2BxFbhdtwG3b6liw2htDy5xNezZko+fbDHbILU6r4scqbult3ISWog2y4XSIFs31XyPGRyEvjmitGGIwmr2HhqtJKzWlivHyrHGPepkb2IwGPQ63x2eHMhwgFy4OzVKpGPhOpB0hDCaduzkP4AH3NBLwP7F91QCB9FcehjbsdtuLWQCIOKhhERqXI99czfz7MP4HJw==) format('woff2'); }
        @font-face{ font-family:'VodafoneVF'; font-style:normal; font-weight:700; font-display:swap;
            src:local('Vodafone Bold'), local('Vodafone-Bold'), url(data:font/woff2;base64,d09GMgABAAAAAErQABEAAAAA1GwAAEpwAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGiIb6FwcIAZgAHQIGAmCcxEQCoKeeIKBUAE2AiQDiloLhTAABCAFhz4HIAxgG+7BB3DnSxhuB0P735f9JtwYeo+DBGrTswOt2xFSx/vvGf3/n3M0DrHkSA6otvvtSYbMNlJOVsKUSmoOGtIQTO4amA3ZMSEyemtYCq0KW+FQJFwySXSMtUgzvNAjFd8Kb4VSKNzFs6jXzSrG2I3GQWdXG/EqebZo85qQMTMeoasLD788+HzQA9OofuLEoT9+vnNnkF9dgfEmp1ISKV6q9gY/+qc7kHEFdtDRSn5hFq8CY9dD1Fh16oX/5//Pau1zU2in5Zeq7pSSJgI2URmx4ZF/YWf+MsKv6DMA2yx0pSiiAgbdSqiAEi0gtDYGs2rBsGqti3YV5ap/56JcRPnz59t9f271NGZjuobw6oPYwRqoTY2TkcHFvC2hSjWG1IlRx2SqPxPEJq+YY/I5NIofYqVmhFz4bk4nxnQw9lCz8v/4t/sMWkB/AQdtCdqZd1q9si2ru8m2JPdxGbdp22f3ylzf2fvpKAAGwAAYAANgAKyPhwYFwPivpjpMS8ahlqnSrXJxqycgJ5dD6EoX4uSvE74UvJRvEF+SL2Hvx+t3J1K3XzPVZMLgDUG5MxIEovPm1Jf2WXq7Bet2GDcpAA0xtodwOf9rewVMOeA4jEUHypL9YTDP1PEuVebUigr9NwcA/09/MTHbLwtPDliw0JQ1ya39fvj4Lt1yKQ01Yq14xEb/PE+6BeyygFmwXIjfv069k+z0vX9W4e04de6wIUz//jlWyEmB16zSKq1BMEGAsYWKbitR9voQaBq+YEA2N0tUndSAG+GDAYvwS4AgLzTlK5j/W7Oy9QeTA+BF1Edqz50iecZU/66eTnUlQ9RLncWeWU4GuDuZ5IBQndt3CmiAMou9THbAnWMQ5tQp1uclAAmnlofvp59SnVm/3TU0YH7QKCPA0lEg0D7L5UaurHT40rrS/7fcKmsoMBOYsKplf4IctowHg0Dz8L2pX6Y87/0GhrtyrD/y0ZfJNwhnhpzZyjdLwIcLtJrN7h7nKWsiZ9gAGgsarLW5cuUuMi5JFCS5SpEUZPLLaS/VavVmzne/Oc0pyGkN4AQwTdAh6C9LHjvSpnWntEKNfgC7CYCBAawVlAm8Px35EjiXc8oQpJTy0TqL0hn2t+y97rGPMea1IiJaKaWV2HNmo6YJCP1wztmx6UoRUvp/+/tZ/+33lc893rulzSgKCFIDiSFb1lVt2+51es0isoikEoJNU5t5+vextJrpr7vfFqe0NVVUsAFJMAL689q9RkDK4qelsoC0Xg4QAvoyASZ+pcqKDbCJAUCjie1H7tsFG1CcHMMgsO/MCD/Vr5Z/xZ4L4TPfNDpDF8HPxc40qWLzyPCRDaPWsuYFSICxQF2Qf3BDCB0MCBWh18KTwudAT0Zgo/DRuxFAlAU9C70YvZJmRJ9m92O6GSp8A3YGru6mt0EDYNaub999znFuC7ef6E98R1pEnkaZRR1LXUQ9Tmv7GYw1jy6hPzyAJTqOOsDtOk/MLTp5MHY/vY5BHYoGOPyJFXUcLYnbb8R00Yw5tI1OxvseySd749t/t/mQQY3zMUQMVTrzE8+QYWNMYFxhBjDHR+F25ptTyhAsIEvEihp7LGseu5/9gyM7P2cl5/gRV7gtF87t4vb3/yImLeZWTNcJsbNi789HWvBnHKN8MPTbtmIAcfxJQGUkPbAIYRqJhKHAGXk0eKCIkShUKbsONqV+W5nRTAfmzGIYF0aZwpNZNvBnlz1Es48rFHDtGrGOGzylnqcHT+f5wd18ae8CvvVHF/Jz/lys4ddRXKuRR3GdAlw+O+J6BSnDMnQQ+GXi/DUiP4fKX6KGho6FLZachEuMTMwsrMCww8HJxS0qLikt46bb7rrvoceycuAmvztAooDZcZwn2FvLa2dVhXHlE5aoIYaElIycXxAUL49XfYDzFtmkQV8MYbhNMeeqY9eCugat6BjBPM2z7eC5wVcRvKvIB+KQkJKRtxUeqUxS09BWnQ16GKrRFyaYWViB1eaYHY5wwsWd1+xYt2Eze1R8Y78PAjYEm0MmQcIR/RJxSUrLuOm2u+576LGsHFi+XfA2wXFLa38Z+JJEAfPeccf22V3IXDqTnWM7pXIljNZGVa8YaeYdqQ9XT3gDBDUSQamyS3VFo82vqUUVT/jI2SrLgeW/+rSuMXX1ZLNm5VqVM1W5gsUO4Lju2sfq9zzeLAKPxDi9w6ochAs+ZR7Dxk2YNGXGrDnzFuoiw/Ml+5CImISUJ7ZsNzsn+w+RTK0OmyseXyCMCIlMoUIq4+O0a6YG1bbvJnto9Wxez621PgIPSAKmGoviNwSKxR3PYR+7Q3Qme+yQXJpnvkDYroUada0+Rpq55WJY6oDjuusgMYRhFFT0Nhvw/aKMMYybMGnKTDYSJmYWViA7BycXd14D6zZsZo9ffBF5R/QsFnFLSEpJ1wx10/k2cdd9Dz2OJ5PIOrYsZxtsp8lv9r9PgCSSyJSs0mDE5BTKowRGd9L4ZW8YDOdUL9WH4AnirpJ4J9cQ7OsnQKQQE5KQkpFXhSOL0/BLEDQuOO1C08RgZQflCXLN10b3jv5kiLGmZl7pyxBKyGpDOQf4y7s7GIad60WcT7OdP1NbZBcGBUMy3KaoXMWuBXUdaEzoihFMytxDkPkXakzologlDgkpGXlbYZKSGjNuwqQpM1nlgpqmakW6hh6GbBSYmFlYgYONP4IgCB1Wl67P2M8KuBCsEEi4HaGigpi4hKSUdGTkptvuuu+hx/FkIhtbkrMNtiM/LviUgJMNCcEPC23mncyXQCgixZES2jKFSqOdtH7BYfUYzdt9nCsPT5HAVUCypaYdORqGGDz0+U26piF6QmwSUjLybKRMzCysQHYOTi7u8EsQFFGJS0r/KJeUUtohKwcuOQwQEqWBLS+EFRxwXPez9RNZCRZtNsERcOf5vHedExJKxxjGTZg0ZSbPEnPmLVwz4bFm3YbN6uH5OBtBMhSxiktISl2VGMWTiWxsSc422M6QXySEEUZYGJg64dPTZo8UR1KpTK5QqmAEfZvzoIztp6vSY8C2fX7oN4RnLdbHSdad9uoGAIBOmYWw/+scOa4SXwcFddbQXMxbeJZFY2v4mrgSO3R0KKWUUkrh9ljRPusJCQlHkeukSZN+Gjnmc8HdlS8Qno0MWyRIZXKFUgUj6MCmM1dWG6vRqaWoQdGCo30McpkECWtN5LNMAuz4hIkscn26SSVqGlo6eobCqQhUUAgkPC647EJCodEZTBZ7CcM0UzMhYQzUUPYAbI+xDucxQkBE+dlSPYmR1WtJkl1SILBZ22a7Z6tNiIisE4uElIy8rTBKhalpaOnoGa6ZusQq2VNtvnf91gWI3lUINIQrEiGEkNuLtnQQQt4VBY81JUskpajJahaw0+411a7DDTF9+2NPV9UdWY23VvNTTjtZj80ObomElIz8QPRrsLVG0KBnKNQ828s1baCZWgnCEgcc1537qP6j+JlOwkhlU0pizMZNmDRlJmZlzryF8SJiBCaYWViB7BycXNxWY83WbdgUyVEQi3glJKWkf4QMAABIkiRJEgIECCQpot5FIIp4H0mlMrlCqYIRdKirw1nSoKMDi4fkrOJVhUFaePpkH1HMwa0HXYTBiab6opZFK33XdlBOoLU71TYw0ZD5PLZjrZ5iCoIx4Wio4ABmGNYJu83xS/NOrxmezHO821+33qvZpZxuSZK0UNn9X34AwOCoADPrXD2eY+nVM33TcYQQAnwAhBBiTudpsW0hEDwE2SM/ggpFpDjgwP0kjnaGqs5nqtoaxW9p5FLC6Dx3VCOvt9QYc75qd3v/4wSHS/xBYL8aNspgnrDwgj9/dgHiVKgIdWho6egZrhm0P/RQPq4lJNxPAPvVfJ+5jCAt9DKYLPZCBjV7OjwQ2GOUqZlXEoVwBKUFLQLa2W4DSwA+AtjhOI5TKjklp3Tx8UCg8u46/pwn1CAixCEhJSN/doURB1BVdqihoaWjZ8hGjomZhRVYbUr2hgNOLm6reU2wbsPm2G9JwKkgOWQHJNx7g+SSS47jOI7juOSSSy65jnHBxwRlS1v7611Ccsl1ooKxn8TRzhm5SGeycyyUypUwmntVozlfxW6rPlpeC6ELRQEpBf+be9QwPBxw0WJV2gIAA4Ze1EOgKuSJQkxCSkbeViioEDUNLR09w6Tq9HQb1CerVyjsPOIRf9/ILs8oCAnQMtb+lhrn2O/iKOeMUDqTPbGAE0LmFSu0ASxyAMd1X2U9QugXBkIoq9dQa65UhwQBAQIEd0tqkyhRokSJEiVCBW4ITRxq8NNOGqGrQTcDoyGsQbmCdgPouFqmzZ32rN5dY3v8hGFgFQ6k4rxwXNFN0d5KZg2eY0iG64hrlF29ask1gkrQio5RBOR5WEps2zgqXF085SXzPRUMwzAM461CoVAoFAqWZVmWZRmGYRjGEsMwDMPYtt1hM/yuAVYQIZBwjShEiRjiEpJS0jnDuOm2u+576HE8mcjGFnK2wXbkxwUvEiy1jLW/w//aDJxMFIlMoYKxJ4527qtjsskmW2z66TJfwhzbLpUrYbTNdetljeZ8ddPtZz+uUHcGU00SAL5j7A2upS1azOPibqFviRO/UU6cOHHixIkTJwa4UzQ4S0r2NvVpXRU/n85VdtpOvRj43UC52GXv3XrPk7oHcxlyFQ16MIRhFFT0rKoiNQ0tHT1DNnpgYmZhBbJzcHJx50AVhYQj+heXlJaJm7jtrvseeiwrB27yuwMkCrj37qLnv3QuZG9U1d52h+90xzrTG7V5moEo+5mzL/QG0Kf6lGtrGIp7ySEqfL3UdKmWLt8Zje8d2iPkvjav54rUHv+cdowsGRQNxTDKcMUpi0Os64PQn0iiKIqiKIqi2NlqrNl6bDBsdiiKoiiKoiiKoiiKHflv6t/4374qEJOggDmmpXIl3NBHO2fL++7ojeqZtfTuWWjLTcMBKl83c76809v82PRFLyyONHLlgP0v0dsuQHbaOg6Yg8V0FyvQJ1xjTwMq5obv13jgFza49wcA5Zb8sdyF2lJStDjwl46EjGIYzGRWiDi4ePh9sgghhKzJNZtKrCp7AvLlABF6gcL7jJMh6Ex2dkPscucTsGdB75GA67hT8hanMiXCThzGmyr/1yFIXZjsUjyP4jpVqUqHpxOqC0RDyESAlq4kSZIkSZIkSaK0fLwkSdLpFDCJAi6F4u/3UTkV2X/s9/A7LVSTUIeGlo7eIgzXFPmLUNw/G31hMmAaEN8/H7bMpgRdUFDRf1umswoWEgAAeDUAAAAAgHdotLmXth2mPGot7VnBuhK/mEIIIfRp4jBcggeAW/GgdAYAQAghwy4wcJOw/08GZSalQK4h7vuZU4Ul2ie8RpneE0S9Hm7Zf0mmJZfLZDJ5kcN3ORSXDESZXk3bL8XV3CiEGG+1kZco9F4DlG7kEhLcrYvLR1wqMBhj2zfbSj9YSlKHKmeHWqQuCkvftyX1QqMCsDcKeD57Fzxf75RD8Bp2DwD9t6L+psl3WlDukvDVQYF2hvtAgPy5qRLCFMHLvbUK7kqSAMGwJDxWyj6FsgAghjeqRAbRlPYOtr17dyFEB4oONIzpm6m353ML9lmJ3oYGz/sBzifgafAxbVz8S81XY5VWejEdQJ56UC75c4qGvrXZPmdoNcu89Zxt8Rz3VkDOGmIqHdb/eagyLZBbof+5RfPhJd0UIFEuffGzzxvVb3ciyPdI6m3uH6CBVKhQ4eWiQoUKFSpUqFChJhF27S3gWwIiXOuyUIL2mFqW+KLUSVrIcl9zj3GenKcAACADDCsvH8PzxyM41uK1Q556jjnMnP7fad4UhrSwnSfgkh2kgiP27m+3OGTY6jm8C0uEVvHngJi1Wdz/f7zXzmEEV8FQknCh+8Gy28dV9RqLQtsE9T/3daA3PEZ9twaQxx4jsl/p5qfPhEd4yzKWFHcNgfrpq41iWPF0IL2ERUQD+ehfLq65sopo6UAHoid7fjdYSfqUvXtVpP8/WUXI+rThRUQDJDcWBXifHO08QdR1tO25Z8NowZkhshAHElIycn5BUBR8c0DX/MLQw0zjDzXZ/EpQS+u81+vonJFWOrOxa1mW2iDc4/gplGkIEnnicyW5oLJYK7J/WULOPUAwgSH5F8xB5Zv7btG5t3u9oIGVgWAD7FEYoB/0EwD2KJk60FoM+RPWrzW02tJf7Eyghf0L7LBSfmUeEmzbEJtwJ8ahjzsAuAQAfWwLABH+8AyBD8tCdOhwDnl/hDKMGKerORoWjY7GR21RMrq3TciHgIjlkXA0KhqXfG/6R37so37YCDaAdWDN7ZUcGRDXbjUMH+lUAAxyJxx9zQi7BoEGkFq+H86a3gfld35tn4aa9uE8/iE4hIMPSjdAqSgql5Tqyk03wFINUHeCNghPRZXtgVSx9bbXsGdH7UuTz45csVvyjqjHSCQdaODIKTW9qE5Q79azssG9iXouYux9pZRabUG6AcETH6NuqjnYbQzx26TI/xvKZ6SW6x4I5DVpa3vrZ5ak6znn2thEIipvf5IaXn9yUDpRS083YHYq2YTGraN6BlYGszt62Sye9cmTi1OJOPvsaHJ7on4mTx/b3h5xuq0Gx1bjFCBRltWAMTCQyvvVsuaRp0W0sUTPae5lNUSipko34KSW23vLpbGJRI0FgEArRhw//08A0GYA7H6AHyN+IACG3QX0aYamW4GlBwGA3XTRdA4Jl7QJzAiYL2oCyReiMJBoZ1dg6qsaMIyoWtBJiE2iXXaMS+W8PL/eKCyFw9ty10abKxfqIdS3XVhQNxGXXp7gUmoWpsCFIkigpJG3B0XvGs5mqlop3do0/GHZ/QWEsIRPCgoVLhzKVIoQCpgqPJ240/chH/2klxhCLNr3nDhpEI6JL9gqoMyQx1IV+1VekgtR2BOUEUgwhFsv5q0KN7RoIw0FE0bOSqs0lKF80gn2RMY2sMqmekgCCN8LIYxuS4EQgsb4FCYCiqKBrQ8FxKlAKHSMFJXHUv9LC2gnBRQl42loZB0msIEMF34el6m3UzRsE4yhFIlIFYQQhmECuaM0hPAkMgfbUDvYRaDA22S5NllkkyWokJ73Jdg3yqUWPvh0Y9xRWsVLsY+hcoMzypEC1VZV+xDD9nmLzpURVUAU7dp5SinQXCLdUEE5F4LvcL7C7o7kvbYFIJCRv5hWrgv9UD6EB/D+KBo4HJiv617QzORD59JSis/RVqN2blI5U6BU4ZHl067jA4NO6EKfuJy2sMCalSllEhF+6rjNmFYLQHE4gxcUZW57Cqo6xIQAlGPzX4VSeJmnLWVK1wErIW9RGzHCSGApW3RPACQKFE3w3OhnMjmoPHTBREAC5ppkS2c4/hcng55oy3h+yl2P0SWfT+frbXvJV0IpVJpLV7qWjR4NZnHWRihCOKAOSToMdYRIJFwaIx1XpjPvlw7L8kjnEpocOGGUUUlS7PNBomzIlgb9TKekL0p6BR1oS1iWMpr/I3mv19ZnOxdjDL+RRaDSPEH1986kdOeiT1parTk7sf7iQCyd2BQYL9za+hw8ieZyqTer502nKl6o4J7cXDJk47gebXytR04IH+5AnSEimi6grjuKu/+FGDpw5a3JuJiXB/P6BasytqpiPxazo9H7096tYoFsOyuA1yZG305J0pLOd7sdCEtq+d5627lJh05mZrBVIbWLULYVqK5JFXePjzu61w2O0asNEjf3QoU6zi1rveLXZmxhnRR0oBkLl2WLkSSgXCJ9rLiDpErVYeMfWlQxWAfZbJpqw1cgDwofN02YeGOHV8dBNeZkxAgq9ebTcewS6zeN4GcHrweLhxRb7eMIeRPGm7CMAIrwRPXKKC2UoCj9f7zf0m/wSH8gG7mX2kVLCuP6LOWr13fE0BgpNF9NDmYdjqxQB9QOKj3MavWs251CyIV3LA7mvImnEzLBPQrpwP7E+tVum2GYkBPTleXMoUU8zxzMKGjswNBi6POcmJeszpfJtEP7FPQbXrrStWb0OrqzyWiucKBHhGSlslwOzIiylcXlIhwo9TJjX6gnKA8zWd5pJULpsmDd5TKlvcZaZAZ86PWndiC5jatGqnWpXpG00b5Yu/TXCeRyNDc6CSt5PzMK1TmhIKquZhcPZ/ky5in4SSGhmSJoDDZ4UnwofzrORpcI6vDVal4+1TZPjWXKvWIvsYPdYljIfXe5tqF2UfQaGZmeRd2bIfeAOYhhqFJO6WRGTO4VugYaC7wyWvCtrOiPEby1K2WNejaVimmCDNDQXuq5Hlmu67YZvfHMrd0V5mO22vmE3sLQ4S90NhMfYRF137LhQCXi6CaIheK1ymiyE7eL4hbht9SK/XkGPCBQmyB5lh+M9g2qcc10gTbgmPVrKcy1M3DnuGLuPOgj+fYiJiM9dB6ws7RIay10zyXzYVqPWxHNlAdIcpPKYBTDLtVJBwuEUCvLhG4rms0N3tx5eIhNs16tXrxORsKgip5dhPN7S13V48oBG/YgjgzQMoMxRNWzrPXWvUk7Wep5/i5wdfgKBA8Yjep5y9TWnYq8wT2+LF6girNCYhKtL82qaPVsDJEApKUhcL8+E9OJvenkxKmIu2/u5FPWSjHehE69PetA9Kdc8/NjjNUjKFZwN7J8tR9U2wUnS7bw26UbinX24k5ULvnxrhXZ/lJ/WsQHr5w4Bm7LvhUmiiOeiG3maVMKZ7orjaKwYVHt7XR1l9YMq7yHaFbvpqSCu2uTRcDRuKcq7/LpvH9T54dyMU1gaZt3Z/K6N8lluEssv1i+QBC9kPmt5GetZrC1UjYFCQPs+eyb9NuRpJkPG1DkzJrRC2ZLONPDOUmKY2v1LKJqAde1k1oRcWB6zxymoRYdsd6Zcm6F8RvQlAbtUJj1bWDTt/do1gZmeKl7iptUYGZF9IhoogTDOym6K/qD1L0EIzN+yzuIH0JisFFT0DNTbeqc0/dXoape/q8yRIj1qrlEcPym8N/YX4HRz/ViPA8bfxM85QFxLxkEgmB7svwH1Tzm434Y/fDQAYyDvl6hFES2B3ZnQPycHFxAuAyqSBQmk2J4N4HWmksyhzNH2xvMgLpTMSOGdInVqX1Oac4mJrEfcjnZBIJI929KTQAr5+wcIgPqa3lZSs8G1CZj/XP2AHuP7V93rwNrBs1wmMP9erGn/au6Xl8qppnpzwWMnldMdqp4R5YWRiYrgdgcKI0iHmJL8OJ2p+oP8sc/VAjBgBTTEe0uHxbINqSTbD5v9f58MSoNpbbeOlehfIMpz2E7pq1mijpJD6vZx1bMdCvZLoIPX54L/6F431l538RxHrp4BU0w5ebO0KLjZLGoWHLEWAf6S7dxgLyNCTW02Ddrxr/diITlWXqasUH6yvBTTj1ubWlSLkBT6Zr5a/4WO4aOJRKNyYy3nliPWbytVioVuhkZBQhSw3KgcSM64DK4oPwAoiCU24a/UN3lCa2lKokuibWBBbXFbvSH5PN5SWjM3NCsdH4KeCwag0u5UexJ7Dmt7LQG5ySzggRzlulDgHx8JsxRmutpphPzYqEmLCmC4D0yoqwDZ545ki6TJzV0A5d0o4Dkl5XmTLLcKcVHGFIVtYagZLbIJF1R0KNeUKWX+MXrgbGltEtYOa+ULQjwL8wSU7UeprSKFOADLa3s+fQAWaYjeKEhl7wWt5d4d6V5YlllnIxTzKqatmdELYlel72Ei4MYmZRvBd7D+bS5x+1wsEdm9Wj9/8dW72pKciqAyumPk2szCGa49MMi8xiXw+Nci8nOJVuQha534pxDsORprYC16pSWYFQ7VaOXFFhFbj8sBo04ylaeHN2RaZqe6ct08Rp0+VFpf7iG1CC73TPoTX4NE2rJSxvGyH2+UrON+zf5ybPG/lHRBlO8hc0a/5K28wJlsgSZ+0pl63aUIhiy6apkDt986c3a13EIflnLJlQU/Vu92qSlNc7/4ZMQfzCXXhpYkYkmcATQemPEXi7lAGiTefjoltouq3/mD5ney18vKDVYe5gUqp/NYh7uz4BugVwUdhbKP7O/E1vNkBNS59FTyqAPjLZUVXyQXHhWvQxBfciqTZEciF3bUvhaUUz3MDLOfltvOq5Vsuv2lLcxx7AklW9sy7kQQwteWZifoeVARq7KlJ00Flbg3S/Ftdmk16bxDF1yZ0ET7qQwRG7yrOskn9azKwPMYOt5K/KRnzyHiCIofZnXCGI28+Moh9NyFKIDhXdAZs327vTzYKZuL+suW31f1R3THoKuzPxW08rz9cpBNxP0r7jklY4+mzeJfdzEGfIDafQ5V1Shy1euYMldIeBGJwZHkW6UyvWsUAskLMdilxPwmy8294NzTefaxbXU8VQ91Ut1tus7OrwdmR3jOzprOl2d1Z2d4zszO72dHdUdro6/rkzX8xtTWl56eC/NuT8MdAbLRST9OtljwjwkqQSJL1+b8cTZqTOEmbyFZivsI4EBwYYFtj/YXW3ByWNo+gTx/Q0p1HmtXuQo6sH6ONSwjefWPJ5Rja09LgGi4+o3/vKTa6ty5aplYNRhOPwwamFkIqgbvWT4iHOuiZt7ZsszA3vtQaoTnN1XHISJjETcRYJKbhqHzO8A+00YWISKLJGWqmjbqP3E4T+wYzMSU5gys7bqNCJyLgS+o2Pv6DkO45h1U47MTHQu/3HzVHgpfumYoukG/nQyfcdZIdYG/1v2x2QWetA+dQnOhnO48/8INapY3YoxYwK1W7FlsveUn2qcTDyxC2sK07ij/QfZcfZtKFxrK8mQcJyF8mKlwOISeXI8GSKhpVgxWsF1ZktK8i4az+yt3Hu++PzuN+wzUo03GHQ7tEaHRorwBCuFxMgQEs55P3sxJUACE4FkEghIJAKZ48a449c8y+YHATxVRlJcfqRPUoC0o6zVKcqsnsUhFrBeJon0xeVnJClqP22JUgdY/CRhztulsONHjsRG0wHHg21L269//jPeIMq91lEwj0kzY6jpaVNK62+S6WgWckA3ySlx+8celIFR2hA2OYMl56ZpCvS7gYUAGGVs41sQpYKeF1fMNpO4iRUsiTFWFnLiui322uL6h7z1qqHCqfoj4s4sb1D6Pan+L0gATSDb5fFpiHZOG6yAvqdorXyMvC3wW9ftvIcg/KWLfy4ZVdKTsazHjz++HnXaEKdjpoS6a2v9qmpgvrbyMZnzJvZIN4wAyWptLK9KiW5k4KBPX46NYCMLRmVtW6oWjGZcRgIodLYSaobQ4CnZVhKvlvwfVxhMidx61srhPf649NloyNQJYblT6LUHKjzTfCGRMzkAFN+Cm4DUknE3n2p/Z+GMxPgQcBY5RhW6HK4fH0IkWBIMT2m9MDJSW2zB86pZL8nknyzGD9KIb2vBoaTIF0mNIyNC5hwARuead4P9T5TcH0JjgMGhluBS2YyRzrzUcEsQKpqtxvyONHHU377nM4TJAKMRtdQbmM5akFbTLuOXRBTDs6MZ9ovnAzAazWIk68IQv95yaIV96wJi2W/HsGwYbFHlrcqbt2PnkewWXOWw7N8OUtmWBXbYEeDvVuB/w78G5Tyg06q8XhkBM4aEuBV4ybSnaJEGgtYCrllufQ8M5tIMJVIFLerEtsV1S51UJUUFGx/TFuvhF5opVnpa0YGz31nEztoobm6U013t0Z74XdCmCSHAAiXKZLMklR/vQlRL4I3ZpfdT4WJDbfi26PKKHpgIgWzyW4Akmj2is3sAHxc1f1rUzuocSnXaf+xMGynT9w7oAHIO8BcfiyLX4BNtUkG8e56WEtVRk4lz7jXgIRG+8pfjI9MrkoQB9Q5oVP95fzjGGsg/oQdJixlGF63FmcFtM7sKacIwE7wwMDM7RUd/tQKJnbI/ypVYkT02JcFKDqNW9v684QBcoO89TEwNqvlQXr/AmAVA44tjU2ZolLgMmZev2d/PKBQlUDy9ObIQbFyTvneXj7fgn+/fAr3Pqe/d5uMs/eL9AjJYQfJylimN3mzLYLWZXB5afFqZbGeqBatmsWVa15ky2Qjj+o+eNhWIGhAzoXjMY3lPDWK3vrclYJDdEgz4IHzy3vL3cjaCBGYknFhaNHX9rmBCW8zTlmeenNzc3rqAlJCdAzm3Jxa/erCMXnZqczViqvXqz9uyBnRFXha80CewD5s8I2xaM2ZR+8o7M+902DzNYZPqpo2XZWwHLFve1Fsdvv/AVBNIXy7R5REaZDJQ7ahcrC/UiDXiKGu0UywjNpa5UqIfjxiWf6z0BVMxodjEpVL6eqA2JlM/BPb0ndf3nuNag20/WTnCUVFqXtVJlBJISP1UoEX0/dxshCO3bWCwjF1jUboIjzCfpfiudzcrLDXyd1V6lVi8kJkAomT/2VL1KKYdefC/mNd6QE83i4HisZyDff6IUdNj9nTGrC3YEFfJisj7U5FRm8nNkWRsAoBYBvCc0V2CyonfV5XjuCUE+tqzaWg9dKW8YxceLH3zrgQfR1OCi5c/VqQd2fD1wHH+AhSh5hylMQ29Z3enUgVQtfakpLw/iT/i++M7gperQc7T/+NWJuxt2SBRGKVSmVGyoWVvAiVdnZSFbfzxfdHk9b/W/Gp6tUg2qXFRs+FE2Ylx1SeST9Q3LWoe96j60XjA5Yxj0pljLtRemHlUejmjp/15+/PM28F3u3smBbQFTL/eHeyIrlTsovr6aqXbNL6EpO6qh5XFs4srOaswq15l89c8C0J3V5bMLql8WCXeDK8lL07LWqavZObcwt/XfNOAWNH9VSLb0WlBR4GYjr3riRFUzem2XNjqUdRWIlGODqG6VG3nabnXVMiTMOVwYa1S0D/qjahT/xJPdqzwvoiMYv78AuSmwk42NuwHYu0iQwQxRkPJVyZlIIXFEp3JoNVq+NEiSPERAJBpQT0gZssyEo18PpMljz61NjMz8fUlIlWkMejEhgTelaF+9KoszIL3wG4DjaeGZ8aaXvsdLs2QEd4fqu+tUfk3BJdE/prxoQJJCT/WjECfWT9pSEAgx4H6R8qWJ+Kzr1pwbAuAJXn3F4uIlygFQq4WdQnrcQv3vPLMqRPsQzlO7xuFXTbX3CTzyOCacwfSEpCs5QpQoY2OgrMJkcWeoqYp3/vItXv3wsdEl0+3RrKFkVgkFSdOI4sV6HSeWWQYz1Xys4GrbxRVlyZyw4s6gCfygsSoEPR0OFCqMA7hSb0Nd/Jes9SAuZ0tS0noBpjkGRoNLEjdmDRQPyAJIRsQcAOZZIAjDBNjLwhzewMpVxuu2lVFo/aSHu1DIn5/SU3qbchCh+8eYJR2JXRJhBlX5qfemihsZZ5CUG4WHgG20PZO9yM3hMAVEIgOls371e+bNFCrtMsQOLwCen7YVTjLCtjd172EjKtHcEUxUSWD9ihCA0I4lohEAThnkwZqnGd10STR5MlYTzyqARJ3kY4ChblmjwKKXIx4LTKDo/8/qEwgstaX0hMZ+hAIMiMdVvp5Z88sNG1CePZx+pGHH5sQQMytdV1rEw8vq7EDuinq37+DQGwjCl3Fk6JRx+NRMta9HcOCIkYmhsHvL38NCtoPH/op/7KgilXoTJ6RlTiBpyS5Akb2bkXC6yNO5AW1uEGnwjHDI8jnkwZqaqes+QQPo7wIKzuFIowlqLzvga2avdmHtMwcApY9FceiRQBn9Bwd9fqy4HLguRxznjQMy6Wls/UYLvMtNCqadjFNThAdhQY57P1vnl8FnkvU8kJUHlVjfWOVp+p7pBVMWo1Jy1XBfC8DWamjizAN4bGJTCLyXVrDQK0gSAPpvnD+SUej1CdtOvWEvHTJk1Yb18T1pHBt3NYlTzy2BEuCedim91u/TiueUzKnee2bLT+mls4vni8nHgVWCh3R5fxMQd/Tzs6aYJR9A0QXXZBeR5xle09zUAy/f/iYTHz6COJfz5QcPyywgPov0QEw6YwtJPW45HFqUqvRpHX4BbhmptHKM/4CXrArwyR90yxihZ5Zw4QlBjpz59Er2S8A3pSDrvEDXQ4/k9bY+uWviZa5AuaP2Lr6yPDxkuIArVobh14+bHkIeJWyiG6ztfPeA8dvP0z+MLIyWnlyycBUy5TZtsuEdGxQJNHpXAgPW1XhD2NNp6R94dbOfJr7Q1mhLDYMDzp5fQ1Ympt4KU+dujMafUmUf6TiSONwX1eZ0u2Wy+/8IrG/7jjI3W6lYnEjBt29WJneF/N771ahXNyExTQtrk6/du/2OQZoSfb07ZbAfv+aaPjHlesOvJ9WPnqlZGLbiLoRHcskheVT3zvUer6XP/6HwCsgPehJsBN/C9xzl6NQ9WEY2q8iFlioFQtjlfPeHqAqUtU6rhnDkzr82EjIWAj8zQ8eRMj8RzguXZE2L5LlL4Au4n9HJrMGwmBDM+UjIYiyfTUcAjU6ikrAR0VFR20Nu4S33ehqlrqK6Z3aypjMlXq5hWwO+VRik9nlCAcyTVnNzYjJSKGkUJzmjOsnI5QwmSSNqKa0P7pokeVyZVZsSXwC0uVWeZpopOpwCK5QaI+gHr9OkVp4nXbWBwUGYFkYIoMrJMmMSK/ayv1lpZ/pJvMUCXxB/ZIzt1cAoQegsNbcSroCipZqpfonLkZblBH6YKM875SlLxVM7n7O/O/S6ZtW5cTJc7qmGRZgaW5uF6R+5vDiils1BAqtLruR6Dx6VrLceg6PxxPHMMefwFQwec0sGf8pRA5RCY6frub8eQusJpmU189wLCkwzmLPfsUnf0VFXSXFvyHJ09PT4Weq2F4vVk4cFQ2p4tK7xuFVxAAaxA1Jg6IxWDQUisZi0L2RlbcqUUvWGXuPBQyLjEHTCs+Eh4lD4PPX4RQbly/DCb9xMednO6Xd5jELlcQ+LloFaouMoUDbsQHXcgVLDqPHptw33VniwdATjHGrG6JHHJ0msgWJDi8bT6KnMtCDUyrE/uPS4adAFY7g1NUbwpShMssjEnL4o//OHpkxveDbCwkNRfz0eTaDZWSymMVM50rqoqZ7cZt3iyZVWiaBFlruyggkbaNeo+OfIn+SkX1gWWRsbqOJTD8+d+6GQ5H8xooUKi2VEEClB+AJUXRqgC+faTDM6Zo42ao8dfNysmHuxQ9ALMrTNyEA8aJ+H37+uwnvFsX79m8/OXrbctzEjxP0BH2JHiwYn2r+7JLZqyc26Ize5i3dTZ/Q5GsyKXUCqUJadArzFnhpgoxQL5E2UehAw8U6q1brWhxdwiukO/JkiWqCMgjuVgtXJwmzZjnHP6sEhde3fCLa4+VSvnCIOCpqKdJzLeqsfLYwIcsYGA9Sxf6ckwfViD1kOjn2+Zqtm7IQyLWj53HcnHpEDD0aQH/YMGM9EmTlP6uOWvLvNLMnRsG92NCk8Cj9NElV4KFMbsfOQ2mHu5ywtjDU54mrORsJo0Z9jywbUjwLxJy6vYEs7fsRcfo5BIVAWrHEtbepqf+FYqm5Fw+lMfrmvNi/gMpz4geOG4gcD+z/ozcE8zEtf5nwoK/X2nyXexnyDMeB/kfKTrLce5vN5UddZEpaa3Th2S4F9KpQr0vga9p4WcjMQFN4EsqToE0li0us3jsjUaggee16JjdJoyOSnuX9BmhxW7GYrbhdpxjs1qALlbcqX63DbcNgtuE2zTha+DJ2ORGfz2+Z+XxhXD1L/xWdyWub2ysirs3tfLxl8eoRxLaJt6Ep0u6HfgdRO7ZuCVYOZw3pqA6nNdwBv0tiz3GHsI6NjAiOuaof0iWckHo+8Mfax/Lr+WK7GCqoGujQP1XkKVJbUgchkfZ0TfHazh60DF61jRCnitkN7GWpyxwKJ+7WpfGiJmb62cHC1qzqlkG3G5U00HDidGrcpC716p1h3DuVUjDnoKB8C5iyx67/W8VxFiYyW15kioT2WZlnhT7zLaXzsibNoKUUiAQN3xwChqnFvFP2NF+4/wLfDZ67LmfU2gPN65MlTIKi9DdlXZnnBdkLQURlcxkNimcNtfrM9bUGH9vlYtcZU2Lq0lwTWNrvK7LNCZug36B/rCMHRxohHJQpXoVe7AeMtzPitQhl9KgTLIy5e0wMHjmfF3139pOFWdSuHhMnXjXFHrywF+FYsz8Qu+zZSeisvFlb1gtrcnhLT14PtOwqcM/XG+/gGarRqmTFssbJVaOrtJG5IOJpTPryZ6tSBjX9zyhIf5B+LYMm/M6qxvh7keBVmNpGJSczx50jp9Z2gEv12lyHy87Ot0fnZ16Dwz9luv12napNvk9DN2IwjWv8Wk/u/VDy6jmXocD0QeP1a5Nnz4lGv71P6obooVA9JLzMouuoDvTxQsnAhnDYGG3QqY9RoKvg2lcRyfQSTxpCSQp/T4e/qw8NjPipIt5QJjGQD6aEBL2AxCKTe+dJtMN8GYvmJWkhl3K+54AiefXubFuYzsggUawEvAiJ1tWE3gYNpM//++krTAnYSTdgvdhkelJouJvBSPLDMd10OjbZa8AGbQ2WairyFGrSEu0s/YJ9zkMUDUW7cprWVacFJrmY8Rpkqj7erDd3kJeO6yIw18Zyijrt6AKvWZT1NyCPJ+Eqo64tNxWyPXs3DiJ3924+uX71wkihXTdzedf9OPOuwl1jTukyW9dbnjUgvB0w6PC4wSCItwGCeEitRRWA0aKPcnCsuTqJ73kI7VCg9gDxfMpaQQHAe4NQq+P/Ox46+XUdRsx7Sca0AKSaoS2/GQSRJvXsyYraJHjKG5DHn+XIOpa0aZQjfrZKeKG9hbDVZYKJeK8ZTjwCFjI/u4DMBSBLEHlG9o50sPO+wzrWz0+hnB/eBFt8v3C65ErhNucycHkc3JX1aFWpmoctImThVAh5EUIpA1/HxSIq5FxSPGmG/EjCxWNnWCg3ebE6oYAtbatQeVJSiatHkEY1r+iGxWNLBcr1rIIt0/nzYv6u1XDsTb5c32c+69uSuR+dY8uV/Fxw8djyapSb7fGAqXFLOrlq9QLj0vsbl1TAkV6QMkpkSeiIZgabScGQXpQrhQ4yBxeLYpItFaUCdTRhUYgKXaFYEfbUsV3kdaXGABbKJe0ShSgRwM5TMs5PAUnZqXhUR7c3Kh+HuJHY12j0DJCvhLJIRTHNjhJerCyUut2wHAgNtTen2TxBjcb5qUJFzjI6KoSMXYQuimvD+6WaSSnrDUpHhWO+qQ2hNeFa0UcsynSpupg+q+az94eMXfAjReE+7KIfnhQfrMNx5TmTTI+EildKvgPW4qddoIdXADj54nLuSSWM7jg4MQfS5WQM9VhhzUu8T0wnXptYZXphMhE94dN7oI3bEGjbZGjjMt/bBg793xNTpMKaWW0THEtOMttUZxKHmY4J6YUTpzqtL9ayeKqBVocwX3HdOOFaj6uNRc8G90oNq1QU5zC7hJGa8ZL1wuuSjY1d/294eoWx6wvAE5djDfpP4XOxrnEcnZzZD+UwY91qlOvwzDTMH1fDiX+EJmxtHHpSEhTp/skZyvtUV7AhO/ONh3aJcBpOENXg60o1y4ldgC4KeewiVUWxil0mrygvwl7C4MKSmnvSERf+jR9w/MUc67ckLfImAKLocUYZqlkyj5pa7AUx+3Lm5WOnE1OohJOFSuPtPN7v5nsIbZcXZ91Z3Ru8acXDDsC8F5keVs2Hec2P4p0cMOg/r7589n0o64N+sGbmhYz+4///NJ8JTPLvPKDXwH3S7++ZrnFW3+Pnn+22LSBQukPa9OEBv1tq7i9JH8MOCe2BcXAj/Xez0HLDKLaBB2BD5gMBuuIeE8S+U5GamPnbNn0e+bNMGXe8vTy40fIvNo6hA+OayNNxIe1AYJz/vK5Tnybn37XVHjS+2m+zA4Fd774D54YO6QMVH/rPsoGM+x+Tc/Cnjvtf0R/q3jFNYCe/DkA9I2xv6Dtbu95+ZOhApomdHVj5D70aCmQqSsId+ulDdmWRX+R9S2+MFLV+5JaZ9SrRV/QRhn82Smhs1x7SgKBxFZk4DSpe0SethEpOW6+u4iBHQ/CGCVkKGrkoswklqkrIg4rXdY3sfnKRrvsYvrAikyBlmLe1aIOL5TBO9vYry/xyuTS4/VSZtUP+uFwUHPxmmbIJf1Omg68/udBmqzzH+F/b+eAfOGMLuAO8Ft7Hw7+YRUoDF2hrVxH/or7wYW6YpLW1rDdfFgYgxxvA/IuwuKw01NkoYZc1xIf6pmyq9/aXdtvELD8M/Xv9mEftxet+YZIVP3gd6KOPYYEJnTHHI7Pb4Igo8H8lvUfv8jmFRrtdngHtX/TCX8r4V+3yMT6iq8qQmVkZTusD4IP+CiNkIL7SZm4Ynfer8Oirxtppv4rb5rKGkGMeKTBhFr7nzvyTPVKizHo/J9IL7QAE+05KALvLzwtC+6ihPgJJ/TpF65+wB4hMnAb1qyvgNC6vLUFHo2pXN9/+1UpofgQOgcCrenjOfb9Hoclg8eLnb7mPwv7L6LU+RCbgfNAhWgA/fnjZ42H3/0ECPwIA/CcGsb6DMUSrydn1U9znxZCAz5E5Bf/9ldPrGDzIq3Ao45YOFS9GH8k6tIZM7pV7o1i1IfJm9Ve9rFvy88Fb2G5YReSAbAIP1YjAKJSEStC3I5rpRDPd6JW/o5DFAg8h3HAXLz8CrggUs6pUBiq5/1jdabhbjrjT5jFk4NTzgOI4juPhA6Z5tNfyDv4WsqVg9OS1bJ2uzjP9B7JIAOCcfl3zzjl/0beuIeqrEXC5XC53+UClUqlUy4k4Ozs79+etq6ura3sdo8hvAvJkDk0M0s3DN8Rc3UjqRJUo/Sxj2zQfyBhI+TBnY1gul8vl73Ez8uT7bxHfGZg9e1tIAc0td+mKW7du3Xa3ifbjrlvF2q0UvTBK3WfqwOKTAsJqOgzDMK3p61kNgCjcmy0Wi8XSLi8bLGUeHKBMbEsqljf49Uz5fD6fv/r0dZa3hT0kCwiCIPg+YTq+uRSKFvxJBASVYdE7tC/9HX8LAORaH83hHM/Z3KvC0sOLOYgnlN2S0tmOxIRZmfJ67BQMw3DGvBTN2dzh/JK7Da11qzyeVqqjLPP2W4VXMWG/x45ey2NlEqXgtOlTLpfLc/47+UxYOhuXjMvAG41Go/GX6IvrhHTYTzOxx7D2MUulUqlU+hdhMw2L6hqNRtM1uQcBQ/hjNERQBSzvKnriZQRBkEwU5lEB2aXENGrT8/HhOI63fAs0w0jp3TpjGIZhmVnnN6l4TAHdDMMwDGeskP1hewAU7g8MhYmtWiZRrodg4ATPhz9SscoNokJIxL/x0fVt7s04b1wjkvH5fH72xdnw28oYhqmk5CLJH+RsUSl/nrJQFEUzlTRq5PKent4b77lPA6PRaMyjUf2eQWrrgvKB4hqRGrOjo6OjYz7a26vnD8l/jO+YLC/8Xw7Y35BPFxnQ987q9Xr90Gf9SDptxzC3cyDx5sUb700vla/B1ni+/puLvvnmm2++lap75vm29KMXL1685BcvuW3KRts6MvyEI8mLSA/2ZZizvYdiJYzYz0aj0WiMGJL9hTddXFxcuota9Wj2SF5LUpjNZnOe5/NTRpZ7C5yOvc6A/Z3P3Llz585d0GH+lPSjtZ5JzhNHz4v/3yFml4MIjn4R6OcPLAcHBweHmi/+vBNdADjFY8lX2V4QF6zfBdlgAdJB7MB53Ul2JgeijJ68rnSjWCwWD3F5yONwhCo1n/NmUXI5uywDKyJQFEV1ilUcoAX5lgvS9hfZDk6T/qmY2pIf+zK3UwcHBweHeP0ruTR3ygvk1VUSDA8QE+1seJ+NzpfS65nxfiG/u/VFF6GNim06jjq6ZCmzlmaA9CtXWa1Wq/U9uXUkD8M4IfJFqVQqlaXSlRi+mg6eG9r49tU+7pTLSujM1pUhbzrbjJd+gJVm0WLltTyVy+Vy+VRVErJjlkqlUmkoE6CvcKZSqVSqP+wGACwddHIdcBQQXVkAkmDao3tvlQ/WXqk2KBAS8quHBf0ZYsFhixPb/zXUauwGs7w09tv4MQzDDIaLdcX4ztnpzPqPP69tHrA+2luRSCSaR7NGo9FoNGVHCe6hoDUyf9NuXu0QbA5MokPV+wR6Y9eQTfgJBitaOVPNX14vIALpODomeaLJ4k0BWLGXK7c4NRe0E3k02XCKZtGZTZWW7kyB+9z62tt2A7hh3p3VSXayx6jQhi5jQXN0yDMixsGACoS/XNkv1j7zSO4nCV4YJnSNFsXJFsJad4DnlFuidrl9hcr/Vp3frNVqtdquDUGtXDs9qc5Jll2M0B3dJVa9sYTJS1OUcH7kDBML1ChzAc4Ntz/N44hTX6lpEJHyfAuTSaFwy55PK0pGYbHWtEpwEQ1Ng3sGHWs0Gk1uqqZ4/lmDjLDYrtT2OdvpMeBZxZKViz/NVKyu24fu0nq6yGTh3pd86ev3era3t7e3L8f2LLPftU/le76FdXief0r1+XXEBXWNGcC0ybm6qvulPrVYLJZqgYG7AXTbrx2J5cxiFXO0qFGvFBVGWh8Pfo4GvbGEXohS8HAw3+4rLMrvN7qNU9nkj09P6ZtjOGduza1s3U0R2F/uXuW6OpeyF1SxYs+KxMvI3q+3ungsd6JJ4wxmsIFdhSt3/WRkqeuuD14Qm3ObWiwfnGOYfQtjhb8Kul3kpg2HJdjj9nP5f2cjqwt113g4vPPk/hTqTk5OTvn0LOE6Ba2hCcz2ta64ztRs1gz3ByHlP54jafOYDVUvF+1SbZZbyTyfbW1tbW3zVtdti7iaOqw7bGXRwjKFURRFZUVl/5EN2bdy2IdJcPeximKxWBzdOtJnW5bJZLIui1903afRNE3TVRL/zBzB++RaEolEIpl2wlPuVBU3Cozr0iEQlska1Yx/Za1bqSQHooyevK5BkWmXxJnEtxZI1tu+ZWJWKpVKpfKP6xNKl5opiqKorMRZBb2RXdLmS21SzZ1HmoYRCfsdpezarszIYFHl9eNWjEaj0Rgt/cbTGnmT2pdK4yXnsWgdstUFOx2eM5MkSZJk8D6VYiLSVL70ZabFBHHLzzXfcEQdWRL4cQBQClNYLjtKGjOGYRiGRaXXt/darVY7tNVxP5vDbDabzWX7laYBoFPFIVbIizLK+w4xtV4Aiu3+tKEjTfAotF9l1jNETmfofkcA8CJHgoRg7faDEc0gCIIguM6HGYI5hh+jwXy53uozMQzDYiffRhs9gdiJo23iZcO16mORU5RVOOoh7a0R7pYacDvgu7B904lYVLfNRCy5YSphcSyaghXie5cq9JEkcW5ecYpTPK7RV7F0IpPeOJLN0IPmygMA6Xr5UVEQsct78fUkKjGpaojbw4hoz+V+u/nZbDabzfP5JY/nk17vP03TNF2UtJUfbjX3gn4yHjo6VYx/jxsN/BDKqhGhoGm5qoknDlMMtwLIFfm72KoGuZICfvpKryqVSpUrkX6U5LYrvhmtr1MgTJuc87U43xSPHo1XhBlE96fum7jnsdbeuxqPx+N1np9edla3ngTDU3v+8UyGMplMJlNr4u6nllwgEAhyIBhuqjMPHtwMZx2n8pyyLqTK4mMr0xIEQWShnA0Gg8FQDXzOCauxEX49urIZmsBglIWOycCIA5AEYNrkXF1/PgYAkRCHSTcAjcRvnRhB66L69So1UAcT2giaPgxDHN0F+y3KiDK9Si4qF57Sxddv+vrjtOedjcl/FprwlY3uCz+hQY/91Iq3VmSLLbl37fPY4hAvzvE2j2KFyz9z5L+RfzcdseCBENkfLBGRAiyE7hlUhMtgbXFqfYUdNzXLeBMDgEv9C0af3oaTgZ9pFn8yASaoQQzgA+BjG69A8mlnbklcRLxsUXrWL5/fpzLNH+FP/uwv/upv/u4/f4/3nOt/j/+jtUNVkQEAKqiRulOailB8FovFYnGOwUFLPdeUaJCWni2Hz+TF7N69e/fu3a8I5CiYFovFkpdhOehlWopzsVZ5UqVq7oNeT/cvgLQtpXtl8GFRng0sm3VkAyJi8q+iaoTMri0XfNf1UtY7og4+tgAno+VRLq/ynVyQo8vSML777rvvvhdW/Kn0vTN3J1wFVzlxirlcXFxc2sttc2vt8dV/83F4k1+tEzUQwqq+ywQ6nU6nK3ZlBMx0+cOUEpfTX8gkONRbeiOgVup0WJlUr+3DhFQvZ1Cr1Wr1UiWr1Wrt12e8evXq1WsgBMMfNJXEE1GZBfmZT951X4KlRrkQxuzZW2jPrJnPgcM1lDMNuVg8KZcf6fBTzMly03KREl49OP0TJq5AQV1WErk6pcERQRrnu98C79Do1HHPYWcpH/ONx8/VV5vZ2dnZtTtn/tkXLunj9YUK9NVXX30dvlrx5bz97IXlo7tX4EfM/WVfStX/zgBgxz4b+p5N50LTNJ01XQXTamzBQ20jX1OBCGP2nN9COrFmyTMEO/K1gIGVhkQvQpHsAq1VXBG8+EvrHVUJq0C2gGolaT21JEMCkmPalGHcyIztFKLwGUVRFD2kpKvk8h/QT0vojk5OCP2jKIoGuOuy160p5mGjTkqfpHMsfV6wCIIgiPKaoJLLp5+lxCZkX4trgSvw9+04gPMju76u80k3nI+LdRu8bcXvdlaNvEOXlXTS465hPVB2YTtKbWvH3SKjds2krIPkz+W3ej2mLcfxyq2Y5pg2nj4uHplilW4i+vwgBwKicHRk7k1cwFg4HdbIZnxYGYZhsmHm4axWq9XqXAtPuiI+q+yGkWLpEOBdFn/RQ2/0aEXc7QsJS/wJfxaxeDuMPFX88iU4XdV3168d7RalL4drMwwgZ7257ZpPdmNGb1qlCTCh1XaYlORkZL0zV18VwqIjfm2IbbCdwWAw5MFQxVNGE+JMvy2lDGeueEHVGtSdx5Vbb07FY9p7P6MLnT9LB8L8aDbEoFfO+5LoA7megpZhkYC7dEjeMFUqQpExrFW16rZ/snmgHDnFaBN61CkVL58RiUSiIXI3m8IvhM0b2sjvh6/3aT1/3TBcO4fpU/9pZU9tt2cDe+oAclHN2hcZSqFQKKrC1iWGOHidRxn6Mfzge1L24xmSqkdXBGu6u75bg1fDB7wC6CgLR2W062LEXT9v02w2m9vZSe1k7/O8B8sa7BLXof3e/lUP5DmTyWQy5cmkKsK3zh174e7OPK3F69HAM0xfHUlqIsKHzfb29vb29mVJT5k9sOqKYNrkXF2nf8mpcyjellZAt4tYHKkcPvPYRNGmW+1L3Gq1Wm1uD9v91rZSs3pyQfMhj3vR9qWmO+BxnnaTla2xH5/A+lQXpk3O+VpUfB4Ar55UY9hqtlqtVutxKwX/1dql34OAI7YT8duj4v6x+VfM+h+wLC+kOyICd4/CggjTIViE5DA4ARN0rchgtlgsFktemPkpxReNa9/bvjkyB0cJ3DvkBnnoZJkUdBrp6ut9VKvV6lz/fAGAmkFeZMpDDUkaVCGZZ3+hQrEEkeIPZbac2MCN4fYGaxeI+s2W6HuhYMdt3XkPrbK5hnqoWU9VB9+JdYrkCVRb+h2yWUHyH+0XvJTmdLevs5YeZEpTXNQ58+WbUentA+bwrTONVt4uO68Nwxx9fnbdWVbfA2OdzZV4mPRl3slyOZhbPCo6f2F2uagQH0X1XSWe2IIqMWVcqriJGF8nBTHyHEnG2F3W8HaJXrc7c33YNw9C1ovMFEeLEkpwKCuvSPoRXG+GkTDkrKtmH8caZNRCbmO3t6eeNh4aXjkggiBIJlfh598+h60Ul0uRofg0emj6N0YE85BYEEBGgln/iATdGkzHh1rU5oMPPvhQfdgODMLNdw7mtH2y9XXQqvWP2vPo0aPH4bFGy4+2s0KhUCgUN9YO/NFse77U7X5Mor1u8f7guAmwkadNy5owN47Y/SyNxldJxkexJs8iQ3TBw0dx6S83zoYOCC5il9OrfIGRqAQqFj0SmEjFL0sUA0fmSy2REpDIYX1gN4FAIBDcJsKKi9d/gsCOuOqGuLc9JZzMumMGAAAAAkncM8r0USuL7UrMdtV51OXk3QTv6fJLEDOHIAiC2HaWfoWMW9HasDBtcn7BFez47ZOgAp1NMo3lxvHHXn+rIUf3n+RTe/0NCWBTxFouGVuUrcL07ZkZZQcpkEFHk2jLcmYpCNlecUuXjbmHdsHIwNYfBbiIfTc9+i6JYcChSmcFoS0IlkdZe1pCklQtqOrD1b7DEb7CT1waZ59fUvNFa28PLRrjqHn5LMUPEKz+vJw8GCz5jWDCCwDwxEHzVwDw+UnW/f4LOjG8CGMgWjEABOEiVwYeXrigh4YX+KHPNUCbOAI8r+tnkLSNtSkBMBG3o+C2B16+RyIryFhRoOpIGWIEl4DLEiI3IRpRzocIZGEcDIIxMBi6oQs6ZMjmKoeCyztAF/lvuw7X4gGbh97EMIyyk1no9X+eW5MetyDmBkTMpyXxAPaBBBvky/tcRflGA+9tEcgEI2iy83AxF2B/0NeSAKwTgI0hWtpIlSPdAWz9WaAvoFsJ0SvQxktGV8GZIDh9JiFbwDaQhCmTxM+mC/kffSMjYxKDC7amDi6ghA/LXEre4boMUrHwWRKxfoHdBegzAPqDmD4BL3HA/FlREIC61/9Jv71/KmWIVebHePOGR1/4e5VT0U1idADtwCKldCRNkRATwxZGYJPumarqRE3MkbICB05qdRxtNMT6wSBViNFBakPDPLUibQpEBiZSiBentAy/7OHAFc6RtQAdKxwtCCMJye3v5z6zDwAdQkIgTtbmkCcbIPCOmUIX/LKHJSNgRAF1sOPR/PQP/sK9udetAxKEArQYTqiFjRCkGaGe9EMA7UMBjo7t64doUZEAGthFlubKfkW08xXkA7Q62k1SYI04TEP9Mj+dhKdwE96RhyhFRoMEdJUz1oeHHhHjEb+QP/EJWhWfK5gwEBnjb6CPT0xkQAX7VyPis44oZUiapO4XQtQVJQ1F/YVR1II1ehB9oGAiv6bhS/RGvRA9i74JiWgX1Cw6iH5PuIvpzHyP3gs51ZAtKTqIwTOogj6MAAXBIKrxzRHyfNsT3wTHA1iaQUGL6BjGDOtEmRsuKCuCTESGM0oHWOU0fqDN+MNgHQQCoC8YuhEcAQO5P6gR6wN6FsCmj4jrVB+jVa/2CWzS/T4xxphhnyZmmfclm9N9WklaLc6KvmXo048ZduqS/emS8banH/zpPAS4faNIHvmUUUgGaaRDQUKlAA2wxMKFiwAsKhLIhiKPXEhMJJBAGiRGKJLRBYucbLIheURRxFMMUnhxYoXc0Y3PEIV82FCNJSeQI5aSRDY0RVgpyBCngnzKFFwTkklggBTEO5ZNWQO9ggSCSkHxQAobCvvDNfYhcpMit9TnrTnYSwZPnxT0RlQPyXoVBQ2wN9aGVlcyVS5WgGl1dAz42MIT+iKl27ugkCy+0GKA4+Vlp3USW5WSRxlxdFlkxqzHwNacihDrb8aBxe65RL4ZQrOm6fBFe82sFtGAkWTRbDSb+VjC2cZ7ua5aanw5a6Gr12XnjJBMZuFcL8qV0eCkAfRwEIRhPToAju7g6DuahgqGCEKA1h6OgZjyEY1HYswGmuUgBDFaehrAP3EBAAAA) format('woff2'); }
        :root{
            /* Marke */
            --vf-red:#E60000; --vf-red-dark:#BD0000;
            --vf-white:#FFFFFF; --vf-surface:#1D1D1D; --vf-canvas:#121212;
            --vf-ink:#F5F5F5; --vf-abbey:#C9C9C9; --vf-grey:#9C9C9C;
            --vf-line:#2C2C2C; --vf-line-strong:#3E3E3E;
            /* Monochrome Datenwelt: nur Rot, Dunkelrot, Schwarz, Grau, Weiss */
            --vf-maroon:#820000; --vf-red-soft:#FF6666;
            --vf-grey-dark:#262626; --vf-grey-mid:#7E7E7E; --vf-grey-light:#BEBEBE;
            /* Operative Zustands-Tokens: gut=Schwarz (souveraen), warn=Dunkelrot, kritisch=Electric */
            --vf-ok:#F5F5F5; --vf-warn:#FF6666; --vf-breach:#E60000;
            --vf-font:'VodafoneVF','Vodafone',Arial,'Helvetica Neue',sans-serif;
            /* Legacy-Bruecke (alte Variablennamen -> monochrome Palette) */
            --rc-blue:#F5F5F5; --rc-orange:#FF6666; --rc-green:#F5F5F5; --rc-cyan:#FF6666;
            --rc-yellow:#E60000; --rc-pink:#B4B4B4; --rc-dark-bg:#F4F4F4; --rc-card-bg:#FFFFFF;
            --rc-matrix-green:#E60000;
            --vf-seance:#B4B4B4; --vf-finn:#DCDCDC; --vf-cerulean:#FF6666; --vf-lagoon:#F5F5F5;
            --vf-gold:#FF6666; --vf-nova:#E60000; --vf-tangerine:#FF6666;
        }
        #rcLiveDashboard{position:fixed; inset:0; width:100vw; height:100vh; z-index:999999;
            color:var(--vf-abbey); font-family:var(--vf-font); display:flex; flex-direction:column;
            overflow:hidden; box-sizing:border-box; background:var(--vf-canvas);}
        #rcLiveDashboard *{box-sizing:border-box; font-style:normal;}
        /* FERNSICHT-ZOOM — Wallboard haengt hoch/weit weg: alles proportional groesser.
           zoom skaliert den kompletten Inhalt; width/height-Kompensation (logische Groesse / zoom)
           haelt den Container physisch exakt auf Bildschirmgroesse (kein Overflow). Steuerung:
           Kopfleiste + Strg +/-/0. */
        #rcLiveDashboard, #rcDetailModal, #rcMappingModal, .rc-goal-stage{
            zoom: var(--rc-zoom, 1);
            width: calc(100vw / var(--rc-zoom, 1)) !important;
            height: calc(100vh / var(--rc-zoom, 1)) !important;}
        .rc-zoomctl{display:inline-flex; align-items:center; gap:2px; background:var(--vf-surface);
            border:1px solid var(--vf-line); border-radius:8px; padding:2px; margin:0 2px;}
        .rc-zoom-btn{width:24px; height:24px; border:none; background:transparent; color:var(--vf-ink);
            font-size:16px; font-weight:700; line-height:1; cursor:pointer; border-radius:6px; padding:0;
            display:flex; align-items:center; justify-content:center;}
        .rc-zoom-btn:hover{background:var(--vf-canvas);}
        .rc-zoom-lbl{min-width:44px; height:24px; border:none; background:transparent; color:var(--vf-ink);
            font-size:11px; font-weight:700; cursor:pointer; border-radius:6px; padding:0 4px; letter-spacing:0.3px;}
        .rc-zoom-lbl:hover{background:var(--vf-canvas); color:var(--vf-red);}
        .rc-zoom-lbl.rc-zoom-on{color:var(--vf-red);}
        #rcLiveBadge, #rcToastContainer, .rc-toast-goal, .rc-goal-flash, #rcMappingModal{font-family:var(--vf-font);}
        .vf-dot{width:7px; height:7px; border-radius:50%; display:inline-block; flex-shrink:0;}

        /* HEADER — weisse Leiste, rote Markenlinie */
        .rc-header{height:58px; background:var(--vf-surface); border-bottom:1px solid var(--vf-line);
            display:flex; justify-content:space-between; align-items:center; padding:0 20px; flex-shrink:0; position:relative;}
        .rc-header::after{content:''; position:absolute; left:0; right:0; top:0; height:3px; background:var(--vf-red);}
        .rc-header-brand{display:flex; align-items:center; gap:12px;}
        .rc-arena-tag{font-weight:700; font-size:16px; color:var(--vf-ink); letter-spacing:0.2px;
            border-left:1px solid var(--vf-line); padding-left:14px;}
        .rc-arena-tag small{display:block; font-size:9px; font-weight:400; color:var(--vf-grey); letter-spacing:1.2px; text-transform:uppercase; margin-top:1px;}
        .rc-live-pill{display:inline-flex; align-items:center; gap:6px; background:var(--vf-red);
            border-radius:9999px; padding:4px 12px 4px 9px; font-weight:700; font-size:10px;
            letter-spacing:1.5px; color:#fff;}
        .rc-live-dot{width:7px; height:7px; border-radius:50%; background:#fff; animation:rc-pulse 1.5s infinite;}
        @keyframes rc-pulse{0%,100%{opacity:1;}50%{opacity:0.35;}}
        .rc-clock{font-weight:700; font-size:16px; color:var(--vf-ink); text-align:right; line-height:1; font-variant-numeric:tabular-nums;}
        .rc-clock small{display:block; font-size:9px; font-weight:400; color:var(--vf-grey); letter-spacing:0.5px; margin-top:2px;}
        .rc-pageswitch{display:flex; background:#2A2A2A; border-radius:9999px; padding:3px; gap:2px;}
        .rc-page-btn{background:transparent; border:none; color:var(--vf-abbey); font-family:var(--vf-font);
            font-weight:700; font-size:12px; padding:5px 15px; cursor:pointer; border-radius:9999px; transition:background 0.2s, color 0.2s;}
        .rc-page-btn:hover{color:var(--vf-ink);}
        .rc-page-btn.active{background:var(--vf-red); color:#fff;}
        .rc-btn-on{background:var(--vf-red) !important; color:#fff !important; border-color:var(--vf-red) !important;}
        .rc-select{background:var(--vf-surface); border:1px solid var(--vf-line-strong); color:var(--vf-abbey);
            padding:6px 12px; border-radius:6px; font-family:var(--vf-font); font-size:12.5px; outline:none; cursor:pointer;}
        .rc-select:hover{border-color:var(--vf-abbey);}
        /* Filter-Gruppe: beschriftet, aktiver Filter rot hervorgehoben */
        .rc-filtergroup{display:flex; align-items:center; gap:5px; padding:3px 5px 3px 8px; border-radius:8px;
            background:rgba(230,0,0,0.05); border:1px solid var(--vf-line);}
        .rc-flt-lbl{font-size:9px; font-weight:800; letter-spacing:1.2px; color:#9C9C9C;}
        .rc-flt.rc-flt-on{border-color:var(--vf-red,#E60000); border-width:2px; background:rgba(230,0,0,0.09);
            color:var(--vf-red,#E60000); font-weight:700;}
        .rc-flt:disabled{opacity:0.5; cursor:not-allowed;}
        .rc-flt-reset{border:none; background:var(--vf-red,#E60000); color:#fff; width:22px; height:22px;
            border-radius:9999px; cursor:pointer; font-size:12px; line-height:1; font-weight:700;}
        .rc-flt-reset:hover{filter:brightness(1.15);}
        .rc-btn{padding:6px 16px; border:none; border-radius:9999px; font-family:var(--vf-font); font-weight:700;
            font-size:12px; cursor:pointer; color:#fff; transition:background 0.2s, color 0.2s, border-color 0.2s;}
        .rc-btn-blue{background:var(--vf-red);}
        .rc-btn-blue:hover{background:var(--vf-red-dark);}
        .rc-btn-orange{background:var(--vf-surface); color:var(--vf-red); border:1px solid var(--vf-red);}
        .rc-btn-orange:hover{background:var(--vf-red); color:#fff;}
        .rc-btn-gray{background:var(--vf-surface); color:var(--vf-abbey); border:1px solid var(--vf-line-strong);}
        .rc-btn-gray:hover{border-color:var(--vf-abbey);}
        .rc-btn-ghost{background:transparent; border:1px solid var(--vf-line-strong); color:var(--vf-grey);
            font-size:10px; padding:4px 11px; font-weight:700;}
        .rc-btn-ghost:hover{color:var(--vf-ink); border-color:var(--vf-abbey);}
        .rc-btn-tab{background:var(--vf-surface); border:1px solid var(--vf-line-strong); color:var(--vf-abbey);
            cursor:pointer; transition:all 0.2s; outline:none; padding:2px 10px; font-size:10px; border-radius:9999px;
            font-family:var(--vf-font); font-weight:700;}
        .rc-btn-tab:hover{border-color:var(--vf-abbey);}
        .rc-btn-tab.active{background:var(--vf-red); border-color:var(--vf-red); color:#fff;}

        /* KPI-STRIP — weisse Kacheln, Hero-Zahlen in Schwarz */
        .rc-kpi-strip{display:flex; align-items:stretch; gap:10px; padding:10px 14px; flex-shrink:0;}
        .rc-kpi{flex:1; background:var(--vf-surface); border:1px solid var(--vf-line); border-radius:6px;
            padding:8px 12px; position:relative; overflow:hidden;}
        .rc-kpi.hot{border:1.5px solid var(--vf-red); border-radius:6px 18px 6px 6px;}
        .rc-kpi-l{font-weight:700; font-size:9px; letter-spacing:0.8px; text-transform:uppercase;
            color:var(--vf-grey); display:flex; align-items:center; gap:5px; white-space:nowrap;}
        .rc-kpi-v{font-weight:700; font-size:22px; line-height:1.05; color:var(--vf-ink); margin-top:3px; font-variant-numeric:tabular-nums;}
        .rc-kpi-v small{font-size:11px; color:var(--vf-grey); font-weight:400; margin-left:5px;}
        .rc-kpi.blue .rc-kpi-v, .rc-kpi.green .rc-kpi-v, .rc-kpi.orange .rc-kpi-v,
        .rc-kpi.pink .rc-kpi-v, .rc-kpi.gold .rc-kpi-v{color:var(--vf-ink);}
        /* Koenigsprodukte KIP-BNT + Mobilfunk-BNT (zaehlen doppelt) — deutlich hervorgehoben */
        .rc-kpi.king-kip{border:2px solid #FFB300; border-radius:6px 18px 6px 6px;
            background:linear-gradient(180deg, rgba(255,179,0,0.16), var(--vf-surface));
            box-shadow:0 0 0 1px rgba(255,179,0,0.35), 0 0 15px rgba(255,179,0,0.30);}
        .rc-kpi.king-kip .rc-kpi-v{color:#FFC633;}
        .rc-kpi.king-mob{border:2px solid #22C7E6; border-radius:6px 18px 6px 6px;
            background:linear-gradient(180deg, rgba(255,0,153,0.10), rgba(34,199,230,0.12), var(--vf-surface));
            box-shadow:0 0 0 1px rgba(34,199,230,0.35), 0 0 15px rgba(255,0,153,0.24);}
        .rc-kpi.king-mob .rc-kpi-v{color:#3BD6E6;}
        .rc-kpi-crown{position:absolute; top:5px; right:9px; font-size:7.5px; font-weight:800;
            letter-spacing:0.4px; color:#FFB300; opacity:0.92; text-transform:uppercase;}
        .rc-kpi.king-mob .rc-kpi-crown{color:#22C7E6;}
        @keyframes rc-kpi-flash{0%{transform:scale(1.1);}100%{transform:scale(1);}}

        /* GRID + CARDS — Full-White-Karten, Radius 6, keine Schatten */
        .rc-grid{display:grid; grid-template-columns:320px 1fr 320px; gap:10px; padding:0 10px 10px; flex:1; overflow:hidden;}
        .rc-col{display:flex; flex-direction:column; gap:10px; overflow:hidden; height:100%;}
        .rc-card{background:var(--vf-surface); border:1px solid var(--vf-line); border-radius:6px; padding:11px 13px;
            display:flex; flex-direction:column; overflow:hidden; position:relative;}
        .rc-card::before{content:none;}
        .rc-card-header{display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;
            border-bottom:1px solid var(--vf-line); padding-bottom:6px;}
        .rc-card-title{font-size:10.5px; font-weight:700; text-transform:uppercase; color:var(--vf-abbey);
            margin:0; letter-spacing:1px;}
        .rc-scroll{overflow-y:auto;} .rc-scroll::-webkit-scrollbar{width:5px;}
        .rc-scroll::-webkit-scrollbar-thumb{background:var(--vf-line-strong); border-radius:4px;}

        .rc-list-item{background:#262626; border:1px solid transparent; border-radius:6px;
            padding:6px 10px; margin-bottom:5px; display:flex; align-items:center; gap:9px; font-size:12px;
            color:var(--vf-abbey); transition:background 0.2s;}
        .rc-list-item b{color:var(--vf-ink);}
        .rc-list-item:hover{background:#2E2E2E;}
        .rc-rank-badge{width:22px; height:22px; border-radius:50%; background:var(--vf-surface);
            border:1px solid var(--vf-line-strong); color:var(--vf-abbey); display:flex; align-items:center;
            justify-content:center; font-weight:700; font-size:11px; flex-shrink:0; font-variant-numeric:tabular-nums;}
        .r1{background:var(--vf-red); border-color:var(--vf-red); color:#fff;}
        .r2{background:#F5F5F5; border-color:#F5F5F5; color:#111111;}
        .r3{background:var(--vf-grey-mid); border-color:var(--vf-grey-mid); color:#fff;}

        .rc-table{width:100%; border-collapse:collapse; font-size:12px; text-align:left; color:var(--vf-abbey);}
        .rc-table b{color:var(--vf-ink);}
        .rc-table th{padding:8px; font-size:9.5px; font-weight:700; color:var(--vf-grey); letter-spacing:0.6px;
            border-bottom:2px solid var(--vf-line-strong); text-transform:uppercase; position:sticky; top:0;
            background:var(--vf-surface); z-index:1;}
        .rc-table td{padding:7px 8px; border-bottom:1px solid #262626; vertical-align:middle;}
        .rc-table tr:hover{background:#232323;}
        .rc-table-row-1{box-shadow:inset 3px 0 0 var(--vf-red); background:rgba(230,0,0,0.10);}
        .rc-table-row-2{box-shadow:inset 3px 0 0 #F5F5F5; background:rgba(255,255,255,0.06);}
        .rc-table-row-3{box-shadow:inset 3px 0 0 var(--vf-grey-mid); background:rgba(126,126,126,0.14);}
        .rc-mono{font-family:var(--vf-font); font-weight:700; font-variant-numeric:tabular-nums;}

        .rc-bar-track{height:8px; background:#2E2E2E; border-radius:4px; overflow:hidden;}
        .rc-bar-fill{height:100%; border-radius:4px; transition:width 0.9s cubic-bezier(0.4,0,0.2,1); width:0;}

        /* Standort-Battle: Auswahl-Chips + Duell */
        .rc-battle-picker{display:flex; flex-wrap:wrap; gap:5px; margin-bottom:10px;}
        .rc-battle-chip{cursor:pointer; border:1px solid var(--vf-line-strong); border-radius:6px; padding:2px 7px 2px 5px;
            background:var(--vf-surface); opacity:0.45; transition:all 0.2s; display:flex; align-items:center; gap:4px;
            font-weight:700; font-size:9.5px; color:var(--vf-abbey);}
        .rc-battle-chip:hover{opacity:0.8;}
        .rc-battle-chip.on{opacity:1; border-color:var(--vf-red); background:rgba(230,0,0,0.14); color:var(--vf-ink);}
        .rc-duel{display:flex; align-items:stretch; gap:8px; margin-top:4px;}
        .rc-duel-side{flex:1; text-align:center; padding:10px 6px; border-radius:6px; background:#262626; border:1px solid transparent;}
        .rc-duel-vs{display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px; color:var(--vf-red);}
        .rc-tug{height:12px; border-radius:9999px; overflow:hidden; display:flex; margin-top:10px; background:#2E2E2E;}

        /* Flaggen-Wehen */
        @keyframes rc-wave{0%,100%{transform:rotate(-1.6deg) skewX(-2deg);}50%{transform:rotate(1.6deg) skewX(2deg);}}
        .rc-flag-wave{animation:rc-wave 2.4s ease-in-out infinite; transform-origin:left center;}

        /* Motivations-Banner — roter Kampagnen-Streifen (Speechmark-Echo) */
        .rc-moti{flex-shrink:0; background:var(--vf-red); border-radius:6px 20px 6px 6px;
            padding:9px 15px; display:flex; align-items:center; gap:12px; overflow:hidden;}
        .rc-moti .spk{display:flex; align-items:center;}
        .rc-moti-txt{font-weight:400; font-size:13.5px; color:rgba(255,255,255,0.92); transition:opacity 0.5s; line-height:1.3;}
        .rc-moti-txt b{color:#fff; font-weight:700;}

        /* Laufband — dunkler Kontrast-Footer mit roter Markenlinie */
        /* Unteres Laufband auf Nutzerwunsch ausgeblendet — gibt allen Seiten unten mehr Hoehe
           (Module werden hoeher = weniger Scrollen). Zum Reaktivieren: display:none -> display:flex. */
        .rc-marquee{height:34px; background:#000000; border-top:2px solid var(--vf-red); color:#fff;
            display:none; align-items:center; overflow:hidden; white-space:nowrap; position:relative;
            font-size:12.5px; font-weight:700; flex-shrink:0; font-variant-numeric:tabular-nums;}
        .rc-marquee-content{display:inline-block; padding-left:100%; animation:rc-marquee 90s linear infinite;}
        @keyframes rc-marquee{0%{transform:translateX(0);}100%{transform:translateX(-100%);}}
        .rc-mq-alarm{color:var(--vf-red-soft);}
        .rc-mq-alarm b{color:#fff; background:rgba(230,0,0,0.35); padding:1px 6px; border-radius:4px;}
        .rc-mq-sep{color:#6E6E6E;}

        /* ===== Feier-Fenster: Abschluss = Marken-Moment in Electric Red ===== */
        #rcToastContainer{position:fixed; top:66px; right:20px; z-index:10000001; display:flex; flex-direction:column; gap:10px; max-height:80vh;}
        .rc-toast-recap{background:var(--vf-surface); border:1px solid var(--vf-line); border-left:4px solid var(--vf-red);
            border-radius:6px; padding:10px 16px; color:var(--vf-abbey); min-width:240px; font-weight:400; font-size:13px;
            display:flex; align-items:center; gap:8px; animation:rc-recap-in 0.4s cubic-bezier(0.25,1,0.5,1) forwards;}
        .rc-toast-recap b{color:var(--vf-ink);}
        @keyframes rc-recap-in{from{transform:translateX(120%); opacity:0;} to{transform:translateX(0); opacity:1;}}
        @keyframes rc-toast-out{to{transform:translateX(120%); opacity:0;}}
        /* ---- Abschluss-Buehne im Arena-Stil: dunkles Stadion-Dimmen, rotierende
               Lichtkegel, 3D-Flip-in der roten Marken-Karte, Schwebe-Loop + Glanz.
               (Licht-Verlaeufe sind hier bewusste Show-Ausnahme vom Flat-Gebot.) ---- */
        .rc-goal-stage{position:fixed; inset:0; z-index:10000002; pointer-events:auto; cursor:pointer;
            display:flex; align-items:center; justify-content:center;
            background:rgba(0,0,0,0.85); perspective:1400px; overflow:hidden;
            animation:rc-stage-in 0.35s ease-out forwards;}
        .rc-goal-close{position:absolute; top:18px; right:22px; z-index:5; width:44px; height:44px;
            border-radius:9999px; border:2px solid rgba(255,255,255,0.55); background:rgba(0,0,0,0.35);
            color:#fff; font-size:24px; line-height:1; font-weight:700; cursor:pointer; pointer-events:auto;
            display:flex; align-items:center; justify-content:center; transition:background 0.15s, transform 0.15s;}
        .rc-goal-close:hover{background:var(--vf-red,#E60000); transform:scale(1.08);}
        .rc-goal-dismiss-hint{position:absolute; bottom:26px; left:50%; transform:translateX(-50%); z-index:5;
            font-size:12px; letter-spacing:2px; text-transform:uppercase; color:rgba(255,255,255,0.6);
            font-weight:700; pointer-events:none;}
        .rc-goal-stage::before, .rc-goal-stage::after{content:''; position:absolute; left:50%; top:50%;
            width:240vmax; height:240vmax; margin:-120vmax 0 0 -120vmax; border-radius:50%;
            background:conic-gradient(rgba(255,255,255,0.10) 0 14deg, transparent 14deg 68deg,
                rgba(255,255,255,0.07) 68deg 80deg, transparent 80deg 155deg,
                rgba(230,0,0,0.16) 155deg 172deg, transparent 172deg 260deg,
                rgba(255,255,255,0.08) 260deg 274deg, transparent 274deg 360deg);
            animation:rc-stage-spin 11s linear infinite;}
        .rc-goal-stage::after{animation-duration:17s; animation-direction:reverse; opacity:0.7;}
        @keyframes rc-stage-in{from{opacity:0;} to{opacity:1;}}
        @keyframes rc-stage-out{to{opacity:0;}}
        @keyframes rc-stage-spin{to{transform:rotate(360deg);}}
        .rc-goal-ring{position:absolute; left:50%; top:50%; width:340px; height:340px; margin:-170px 0 0 -170px;
            border:2px solid rgba(255,255,255,0.5); border-radius:50%; animation:rc-ring-out 1.6s ease-out 0.25s infinite;}
        .rc-goal-ring.rg2{border-color:rgba(230,0,0,0.55); animation-delay:0.85s;}
        @keyframes rc-ring-out{0%{transform:scale(0.55); opacity:0.9;}100%{transform:scale(2.4); opacity:0;}}
        .rc-toast-goal{position:relative; text-align:center; padding:44px 88px; border-radius:10px 44px 10px 10px;
            min-width:580px; background:var(--vf-red); transform-style:preserve-3d; overflow:hidden;
            animation:rc-goal-in3d 0.85s cubic-bezier(0.16,1.3,0.4,1) forwards,
                      rc-goal-float 3.8s ease-in-out 0.9s infinite;}
        .rc-toast-goal::after{content:''; position:absolute; top:-60%; bottom:-60%; width:120px; left:-200px;
            background:linear-gradient(105deg, transparent, rgba(255,255,255,0.35), transparent);
            transform:rotate(8deg); animation:rc-goal-shine 2.6s ease-in-out 0.7s 2;}
        @keyframes rc-goal-shine{0%{left:-220px;}55%{left:115%;}100%{left:115%;}}
        @keyframes rc-goal-in3d{0%{opacity:0; transform:rotateY(-74deg) translateZ(-460px) scale(0.5);}
            62%{opacity:1; transform:rotateY(7deg) translateZ(26px) scale(1.05);}
            100%{opacity:1; transform:rotateY(0) translateZ(0) scale(1);}}
        @keyframes rc-goal-float{0%,100%{transform:rotateY(-4.5deg) rotateX(1.5deg) translateY(0);}
            50%{transform:rotateY(4.5deg) rotateX(-1.5deg) translateY(-9px);}}
        @keyframes rc-goal-out{to{opacity:0; transform:rotateY(38deg) translateZ(-260px) scale(0.7);}}
        .rc-toast-goal.special{outline:3px solid rgba(255,255,255,0.9); outline-offset:-11px;}
        .rc-toast-goal.streak3{background:var(--vf-maroon); outline:3px solid var(--vf-red); outline-offset:-11px;}
        /* Koenigsprodukt-Abschluesse knalliger: KIP=Gold, Mobilfunk=Cyan/Magenta */
        .rc-toast-goal.king-kip{background:linear-gradient(160deg,#8A6200,#FFB300 58%,#5E4200);
            outline:3px solid #FFE27A; outline-offset:-11px; box-shadow:0 0 60px rgba(255,179,0,0.55);}
        .rc-toast-goal.king-mob{background:linear-gradient(160deg,#0E7C93,#22C7E6 52%,#B0106B);
            outline:3px solid #BEEFF7; outline-offset:-11px; box-shadow:0 0 60px rgba(34,199,230,0.5);}
        .rc-goal-head{font-weight:700; font-size:58px; letter-spacing:6px; color:#fff; margin-top:6px; line-height:1;}
        .rc-goal-sub{font-size:15px; font-weight:700; letter-spacing:3px; text-transform:uppercase;
            color:rgba(255,255,255,0.85); margin-top:9px;}
        .rc-goal-time{display:inline-flex; align-items:center; gap:8px; margin-top:14px; padding:6px 18px; border-radius:9999px;
            background:#FFFFFF; font-weight:700; font-size:20px; color:var(--vf-red); letter-spacing:1px; font-variant-numeric:tabular-nums;}
        .rc-goal-city{font-weight:700; font-size:32px; color:#fff; margin-top:16px; display:flex; align-items:center; gap:14px; justify-content:center;}
        .rc-goal-name{font-weight:700; font-size:28px; color:rgba(255,255,255,0.88); margin-top:14px;}
        .rc-goal-name b{color:#fff;}
        .rc-goal-prod{font-size:21px; color:rgba(255,255,255,0.92); margin-top:6px; font-weight:400;}
        .rc-goal-prod b{font-weight:700; color:#fff; border-bottom:2px solid rgba(255,255,255,0.7);}
        .rc-goal-flash{position:fixed; inset:0; z-index:10000000; pointer-events:none;
            background:rgba(230,0,0,0.12); animation:rc-flash-anim 0.9s ease-out forwards;}
        .rc-goal-flash.special{background:rgba(255,255,255,0.18);}
        @keyframes rc-flash-anim{0%{opacity:0;}18%{opacity:1;}100%{opacity:0;}}
        /* Kompakte Buehne OHNE Standort-Filter: die Karte gehoert allen Nationen,
           also nur ein dezenter Sieges-Gruss statt der fetten Vollbild-Show.
           Die volle Buehne gibt es NUR fuer den eigenen (gefilterten) Standort. */
        .rc-goal-stage.compact{background:rgba(0,0,0,0.45);}
        .rc-goal-stage.compact::before, .rc-goal-stage.compact::after{content:none;}
        .rc-goal-stage.compact .rc-goal-ring{display:none;}
        .rc-toast-goal.compact{min-width:400px; padding:24px 52px;}
        .rc-toast-goal.compact .rc-goal-head{font-size:32px; letter-spacing:3px;}
        .rc-toast-goal.compact .rc-goal-city{font-size:21px; margin-top:9px; gap:9px;}
        .rc-toast-goal.compact .rc-goal-name{font-size:19px; margin-top:8px;}
        .rc-toast-goal.compact .rc-goal-prod{font-size:15px; margin-top:4px;}
        .rc-toast-goal.compact .rc-goal-time{font-size:14px; padding:4px 13px; margin-top:9px;}
        /* Header-Zugzwang: Zeit seit letztem Abschluss */
        .rc-lastsale{font-size:10px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase;
            color:var(--vf-grey-mid); font-variant-numeric:tabular-nums;}
        .rc-lastsale.warn{color:#FF6666;}
        .rc-lastsale.hot{color:var(--vf-red); animation:rc-pulse 1.2s infinite;}

        #rcMappingModal{display:none; position:fixed; inset:0; background:rgba(0,0,0,0.72); z-index:10000000;
            justify-content:center; align-items:center;}

        /* DETAIL-MODALS — Klick auf Agent / Team / Standort + Tagesvergleich */
        #rcDetailModal{display:none; position:fixed; inset:0; background:rgba(0,0,0,0.72); z-index:10000001;
            justify-content:center; align-items:center; font-family:var(--vf-font);}
        .rc-detail-card{width:min(1080px,94vw); max-height:92vh; overflow-y:auto; position:relative; padding:20px 24px;}
        .rc-detail-close{position:absolute; top:10px; right:12px; background:transparent; border:none; color:#9C9C9C;
            font-size:19px; cursor:pointer; font-weight:700; line-height:1; font-family:var(--vf-font);}
        .rc-detail-close:hover{color:#F5F5F5;}
        .rc-detail-head{display:flex; align-items:center; gap:12px; margin-bottom:4px; padding-right:30px;}
        .rc-detail-head h3{margin:0; font-size:19px; font-weight:700; color:#F5F5F5;}
        .rc-detail-sub{font-size:11px; color:#9C9C9C; font-weight:700;}
        .rc-detail-sec{font-size:10.5px; font-weight:700; color:#E60000; letter-spacing:0.7px; text-transform:uppercase;
            margin:16px 0 8px; border-bottom:1px solid #3E3E3E; padding-bottom:4px;}
        .rc-detail-kpis{display:grid; grid-template-columns:repeat(auto-fill,minmax(116px,1fr)); gap:8px;}
        .rc-detail-kpi{background:#232323; border:1px solid #3E3E3E; border-radius:6px; padding:7px 10px;}
        .rc-detail-kpi .l{font-size:8.5px; color:#9C9C9C; font-weight:700; letter-spacing:0.4px; text-transform:uppercase; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
        .rc-detail-kpi .v{font-size:16px; font-weight:700; color:#F5F5F5; font-variant-numeric:tabular-nums; margin-top:2px;}
        .rc-detail-kpi .v small{font-size:9px; color:#9C9C9C; font-weight:400; margin-left:4px;}
        .rc-detail-chartwrap{position:relative; height:190px; background:#232323; border:1px solid #3E3E3E; border-radius:6px; padding:8px;}
        .rc-detail-grid2{display:grid; grid-template-columns:1fr 1fr; gap:12px;}
        @media (max-width:900px){ .rc-detail-grid2{grid-template-columns:1fr;} }
        .rc-detail-table{width:100%; border-collapse:collapse; font-size:11.5px;}
        .rc-detail-table th{font-size:9px; color:#9C9C9C; text-transform:uppercase; letter-spacing:0.4px; text-align:left; padding:5px 7px; border-bottom:1px solid #3E3E3E;}
        .rc-detail-table td{padding:5px 7px; border-bottom:1px solid #2E2E2E; color:#C9C9C9;}
        .rc-detail-table tr:hover td{background:rgba(230,0,0,0.07);}
        .rc-detail-hint{font-size:10px; color:#9C9C9C; margin-top:6px;}
        .rc-cmp-controls{display:flex; gap:10px; align-items:center; flex-wrap:wrap; margin:10px 0 4px;}
        .rc-cmp-controls .rc-select{min-width:150px;}
        .rc-delta-up{color:#F5F5F5; font-weight:700;}
        .rc-delta-down{color:#E60000; font-weight:700;}
        .rc-delta-zero{color:#9C9C9C;}

        /* Alles Klickbare bekommt Zeiger + dezentes Hover */
        [data-rc-vo],[data-rc-ccs],[data-rc-team],[data-rc-std]{cursor:pointer;}
        tr[data-rc-vo]:hover td, tr[data-rc-ccs]:hover td, tr[data-rc-team]:hover td, tr[data-rc-std]:hover td{background:rgba(230,0,0,0.08);}
        div[data-rc-std]:hover, div[data-rc-team]:hover{background:rgba(230,0,0,0.06); border-radius:4px;}
        #rcDropZone{border:2px dashed var(--vf-line-strong); padding:30px 20px; border-radius:6px;
            background:#232323; cursor:pointer; transition:all 0.2s; margin-bottom:20px; text-align:center; color:var(--vf-abbey);}
        #rcDropZone:hover{border-color:var(--vf-red);}

        /* Warn-Balken (Datenprobleme) — schwarzer Systembalken mit roter Kante */
        #rcWarnBar{color:#fff !important; background:#000000 !important; border-bottom:none !important;
            box-shadow:inset 6px 0 0 var(--vf-red);}

        /* ===== Qualitaet-Seite ===== */
        .rc-quali{flex:1; display:flex; flex-direction:column; min-height:0; overflow:hidden;}
        .rc-quali-strip{display:flex; gap:10px; padding:10px 14px; flex-shrink:0;}
        .rc-quali-strip .rc-kpi{flex:1;}
        .rc-quali-grid{display:grid; grid-template-columns:300px 1fr 300px; gap:10px; padding:0 10px 10px; flex:1; overflow:hidden;}
        .rc-ziel-chip{display:flex; justify-content:space-between; align-items:center; font-size:11px; padding:5px 9px;
            border-radius:6px; background:#262626; margin-bottom:4px;}
        .rc-det-item{border-left:3px solid var(--vf-breach); background:rgba(230,0,0,0.12); border-radius:0 6px 6px 0;
            padding:7px 10px; margin-bottom:5px;}
        @keyframes rc-det-pulse{0%,100%{background:rgba(230,0,0,0.10);}50%{background:rgba(230,0,0,0.22);}}
        .rc-det-critical{animation:rc-det-pulse 2.2s ease-in-out infinite;}

        /* Ansprache-Fokus (Warnliste) — operative Tokens */
        .rc-warn-item{display:flex; align-items:center; gap:8px; padding:6px 9px; border-radius:0 6px 6px 0; margin-bottom:5px;
            background:rgba(255,102,102,0.10); border-left:3px solid #FF6666;}
        .rc-warn-item.hart{background:rgba(230,0,0,0.16); border-left-color:var(--vf-breach);}
        .rc-warn-item .nm{flex:1; font-weight:700; font-size:11.5px; color:var(--vf-ink);}
        .rc-warn-item .wv{font-size:10px; color:var(--vf-abbey); font-variant-numeric:tabular-nums;}

        /* ===== Radar-Seite (helle Kartografie + Manager-Einsatzzentrale) ===== */
        .rc-radar{flex:1; display:none; grid-template-columns:330px 1fr 330px; gap:10px; padding:0 10px 10px; min-height:0; overflow:hidden;}
        /* Radar-Seitenpanels (links + rechts) mit groesseren Texten fuer die Wallboard-Lesbarkeit;
           dafuer das Kriegsfeld (Mitte) etwas schmaler (breitere Seitenspalten oben).
           zoom erwischt auch die inline gesetzten Schriftgroessen; verursacht kein horizontales
           Overflow, weil die Grid-Spaltenbreite die Card begrenzt (offline verifiziert). */
        .rc-radar > .rc-col{zoom:1.3;}
        /* ===== SMART CAROUSEL + AUTO-SCROLL (Radar-Seitenspalten) =====
           Je Spalte EINE hohe Karte statt drei kurzer. Die Karte blendet alle
           ~12 s weich zum naechsten Modul (Fade + leichter Slide); der Kartentitel
           folgt dem sichtbaren Modul (rcCarouselSyncTitle). Lange Listen fahren per
           Ping-Pong-Auto-Scroll durchs Bild, native Scrollbars sind fuer die
           TV-Optik komplett ausgeblendet. */
        .rc-radar .rc-col > .rc-carousel{flex:1; min-height:0;}
        .rc-carousel-body{position:relative; flex:1; min-height:0; overflow:hidden;}
        .rc-carousel-pane{position:absolute; inset:0; display:flex; flex-direction:column; min-height:0;
            opacity:0; transform:translateY(10px); pointer-events:none;
            transition:opacity 0.55s ease, transform 0.55s ease;}
        .rc-carousel-pane.rc-pane-on{opacity:1; transform:none; pointer-events:auto;}
        .rc-carousel-dots{display:inline-flex; gap:5px; align-items:center; margin-left:auto; padding-left:10px;}
        .rc-carousel-dots i{width:7px; height:7px; border-radius:50%; background:var(--vf-line-strong);
            display:block; transition:background 0.35s ease, transform 0.35s ease;}
        .rc-carousel-dots i.on{background:var(--vf-red); transform:scale(1.3);}
        /* Auto-Scroll-Listen fuellen die Pane; native Scrollbar unsichtbar (TV-Optik) */
        .rc-autoscroll{flex:1; min-height:0; overflow-y:auto; overflow-x:hidden;
            scrollbar-width:none; -ms-overflow-style:none;}
        .rc-autoscroll::-webkit-scrollbar{width:0; height:0; display:none;}
        [data-rc-std="AL"] { background: rgba(230,0,0,0.18) !important; border-left-color: #E60000 !important; }
        [data-rc-std="AL"] b { color: #FF6666 !important; text-shadow: 0 0 8px rgba(230,0,0,0.5); }
        .rc-alanya-highlight { color: #FF6666 !important; font-weight: bold; border: 1px solid #E60000; padding: 2px 5px; border-radius: 4px; background: rgba(230,0,0,0.18); box-shadow: 0 0 10px rgba(230,0,0,0.3); }
        /* Sales-Funnel: Calls -> Ansprachen -> Abschluesse */
        .rc-fn-row{margin-bottom:8px;}
        .rc-fn-top{display:flex; justify-content:space-between; align-items:baseline; font-size:10.5px; margin-bottom:3px;}
        .rc-fn-top b{color:var(--vf-ink); font-size:13px; font-variant-numeric:tabular-nums;}
        .rc-fn-top .lbl{font-weight:700; letter-spacing:0.6px; text-transform:uppercase; color:var(--vf-grey-mid); font-size:9px;}
        .rc-fn-bar{height:14px; border-radius:4px; background:#2E2E2E; overflow:hidden;}
        .rc-fn-fill{height:100%; border-radius:4px; transition:width 0.9s cubic-bezier(0.4,0,0.2,1);}
        .rc-fn-conv{font-size:9.5px; color:var(--vf-grey-mid); margin:2px 0 0 2px; font-variant-numeric:tabular-nums;}
        .rc-fn-conv b{font-weight:700;}
        .rc-fn-lever{display:inline-block; font-size:8.5px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase;
            color:#fff; background:var(--vf-red); border-radius:9999px; padding:1px 8px; margin-left:6px;}
        .rc-fn-split{display:flex; gap:6px; margin-top:8px; padding-top:8px; border-top:1px solid var(--vf-line);}
        .rc-fn-chip{flex:1; text-align:center; background:#262626; border-radius:6px; padding:5px 4px;}
        .rc-fn-chip b{display:block; font-size:15px; color:var(--vf-ink); font-variant-numeric:tabular-nums;}
        .rc-fn-chip span{font-size:8.5px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase; color:var(--vf-grey-mid);}
        /* Quadranten-Matrix: Qualitaet x Abschluss */
        .rc-quad{display:grid; grid-template-columns:1fr 1fr; grid-template-rows:1fr 1fr; gap:6px; flex:1; min-height:0;}
        .rc-quad-cell{border-radius:6px; padding:7px 9px; background:#262626; overflow:hidden; display:flex; flex-direction:column;}
        .rc-quad-cell.q-champ{background:rgba(230,0,0,0.14); box-shadow:inset 0 0 0 1.5px var(--vf-red);}
        .rc-quad-cell.q-risk{background:rgba(255,102,102,0.10);}
        .rc-quad-cell.q-alarm{background:rgba(230,0,0,0.12);}
        .rc-quad-t{font-size:8.5px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase; color:var(--vf-abbey);}
        .rc-quad-n{font-size:20px; font-weight:700; color:var(--vf-ink); line-height:1.1; font-variant-numeric:tabular-nums;}
        .rc-quad-act{font-size:8px; font-weight:700; letter-spacing:0.4px; text-transform:uppercase; margin:1px 0 3px;}
        .rc-quad-names{font-size:9px; color:var(--vf-abbey); line-height:1.45; overflow:hidden;}
        /* Krisenherd-Ring um Standort-Blips */
        @keyframes rc-blip-warn{0%,100%{opacity:0.85; transform:scale(1);}50%{opacity:0.25; transform:scale(1.25);}}
        .rc-blip-warn{animation:rc-blip-warn 1.6s ease-in-out infinite;}
        .rc-radar-ops{font-size:9px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase; color:#FF6666;}
        .rc-radar-svgwrap{position:relative; flex:1; min-height:0; display:flex; align-items:center; justify-content:center; overflow:hidden;}
        .rc-radar-svgwrap svg{width:100%; height:100%;}
        /* Action-Radar: Canvas-Gefechtsebene ueber der SVG-Karte */
        #rcWarCanvas{position:absolute; inset:0; width:100%; height:100%; pointer-events:none;}
        @keyframes rc-sweep{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
        .rc-sweep{animation:rc-sweep 7s linear infinite;}
        @keyframes rc-blip-pulse{0%{transform:scale(1); opacity:0.5;}70%{transform:scale(2.6); opacity:0;}100%{transform:scale(2.6); opacity:0;}}
        .rc-blip-pulse{animation:rc-blip-pulse 2.8s ease-out infinite;}
        @keyframes rc-ping{0%{transform:scale(0.4); opacity:0.9;}100%{transform:scale(5); opacity:0;}}
        .rc-ping-g{animation:rc-ping 2.6s ease-out forwards;}
        .rc-radar-log-item{font-size:10.5px; color:var(--vf-abbey); padding:4px 8px; border-left:2px solid var(--vf-red);
            background:rgba(230,0,0,0.12); border-radius:0 5px 5px 0; margin-bottom:4px; font-variant-numeric:tabular-nums;}
        .rc-radar-log-item b{color:var(--vf-ink);}
        /* ===== HELDEN-RUF: riesige persoenliche Ansprache ueber der Kriegskarte.
           Jeder Agent wird der Reihe nach mit Namen gerufen — lesbar vom
           anderen Ende des Grossraums. pointer-events:none (Karte bleibt klickbar). ===== */
        /* KOMPAKT (Stufe 2): schmale Leiste, die in der Luecke zwischen der Chronik
           (oben links) und der Tageswertung (oben rechts) sitzt und diese NICHT mehr
           verdeckt. Name + Standort + konkrete Handlungs-Aussage bleiben lesbar. */
        .rc-herocall{position:absolute; top:140px; left:50%; transform:translateX(-50%); z-index:60;
            pointer-events:none; width:min(440px, 40%); text-align:center;}
        /* Der Koenigs-Counter belegt den oberen Streifen (KIP/MOBILFUNK) — der Helden-Ruf
           sitzt darunter. Bei aktivem Stunden-Duell zusaetzlich nach unten ausweichen. */
        .rc-herocall.rc-duel{top:212px;}
        .rc-herocall-card{background:linear-gradient(160deg, rgba(16,12,8,0.95), rgba(34,20,8,0.95));
            border:1.5px solid; border-radius:8px; padding:6px 14px 7px;
            box-shadow:0 6px 22px rgba(0,0,0,0.5), inset 0 0 22px rgba(0,0,0,0.4);
            animation:rc-herocall-in 0.5s cubic-bezier(0.18,1.25,0.4,1) forwards;}
        @keyframes rc-herocall-in{0%{opacity:0; transform:translateY(-18px) scale(0.9);}
            100%{opacity:1; transform:translateY(0) scale(1);}}
        .rc-herocall-card.out{animation:rc-herocall-out 0.35s ease-in forwards;}
        @keyframes rc-herocall-out{to{opacity:0; transform:translateY(-12px) scale(0.94);}}
        .rc-herocall-kicker{font-size:9px; font-weight:700; letter-spacing:1.6px; text-transform:uppercase;
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
        .rc-herocall-name{font-size:22px; font-weight:700; color:#FFFFFF; line-height:1.1; margin:1px 0;
            text-shadow:0 1px 8px rgba(0,0,0,0.8); letter-spacing:0.3px;
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
        .rc-herocall-name .rc-flag-wave{margin-right:7px;}
        .rc-herocall-name svg{width:26px; height:auto; vertical-align:middle;}
        .rc-herocall-msg{font-size:12px; font-weight:700; color:#F5E9D0; line-height:1.25;
            display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;}
        .rc-herocall-msg b{color:#FFD700;}
        .rc-herocall-sub{font-size:9px; color:#C9B08A; margin-top:2px; letter-spacing:0.3px;
            white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
        .rc-herocall-stripes{height:3px; border-radius:2px; margin:4px auto 0; width:56%; display:flex; overflow:hidden;}
        .rc-herocall-stripes i{flex:1;}
        /* Kompaktmodus: kleineres Helden-Ruf-Banner, damit das Kriegsfeld frei bleibt */
        .rc-herocall.rc-hero-kompakt{width:min(320px, 30%);}
        .rc-hero-kompakt .rc-herocall-card{padding:4px 10px 5px;}
        .rc-hero-kompakt .rc-herocall-name{font-size:15px;}
        .rc-hero-kompakt .rc-herocall-name svg{width:18px;}
        .rc-hero-kompakt .rc-herocall-msg{font-size:10px;}
        .rc-hero-kompakt .rc-herocall-kicker{font-size:8px; letter-spacing:1.2px;}
        .rc-hero-kompakt .rc-herocall-sub{font-size:8px;}
        /* XXL-Listenzeilen: Namen muessen vom Agenten-Monitor lesbar sein */
        .rc-xl-item{background:#262626; border:1px solid transparent; border-left:3px solid transparent;
            border-radius:6px; padding:8px 11px; margin-bottom:6px; display:flex; align-items:center; gap:10px;
            color:var(--vf-abbey); transition:background 0.2s;}
        .rc-xl-item:hover{background:#2E2E2E;}
        .rc-xl-item b{color:var(--vf-ink); font-size:15.5px; line-height:1.15;}
        .rc-xl-item .rc-xl-sub{font-size:10.5px; color:#9C9C9C; line-height:1.35;}
        .rc-xl-item .rc-xl-ask{font-weight:700; font-variant-numeric:tabular-nums; color:#FFD700;
            font-size:12px; text-align:right; line-height:1.25; flex-shrink:0;}
        .rc-xl-chip{display:inline-block; font-size:8.5px; font-weight:700; letter-spacing:0.6px;
            text-transform:uppercase; color:#111; border-radius:9999px; padding:1px 7px; vertical-align:2px;}

        /* Live-Scanline fuer Monitor-Charts (dezente rote Linie, kein Verlauf) */
        .rc-chartwrap{position:relative; flex:1; padding:4px; min-height:0;}
        .rc-ekg-scan{position:absolute; top:8%; bottom:12%; width:2px; pointer-events:none;
            background:rgba(230,0,0,0.40); animation:rc-ekg 7s linear infinite;}
        @keyframes rc-ekg{0%{left:4%;}100%{left:97%;}}

        /* Cockpit (Manager) */
        .rc-cockpit{flex:1; display:none; flex-direction:column; min-height:0; overflow:hidden;}
        .rc-cockpit-grid{display:grid; grid-template-columns:1.1fr 1.3fr 0.9fr; gap:10px; padding:0 10px 10px; flex:1; overflow:hidden;}
        /* Cockpit v2 — Management-Statistik-Zentrum (scrollbare Sektionen) */
        .rc-ck-body{flex:1; min-height:0; overflow-y:auto; padding:2px 12px 18px; display:flex; flex-direction:column; gap:11px;}
        .rc-ck-body::-webkit-scrollbar{width:8px;} .rc-ck-body::-webkit-scrollbar-thumb{background:var(--vf-line-strong); border-radius:4px;}
        .rc-ck-classrow{display:grid; grid-template-columns:repeat(7,1fr); gap:8px; flex-shrink:0;}
        .rc-ck-clstile{background:var(--vf-surface); border:1px solid var(--vf-line); border-top-width:3px; border-radius:6px; padding:8px 11px 9px;}
        .rc-ck-clstile .l{font-size:8.5px; font-weight:700; letter-spacing:0.5px; text-transform:uppercase; color:var(--vf-grey); display:flex; align-items:center; gap:5px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
        .rc-ck-clstile .v{font-size:23px; font-weight:700; margin-top:3px; line-height:1; font-variant-numeric:tabular-nums;}
        .rc-ck-clstile .s{font-size:8.5px; color:var(--vf-grey); margin-top:3px; font-weight:700;}
        .rc-ck-dot{width:8px; height:8px; border-radius:2px; flex-shrink:0; display:inline-block;}
        .rc-ck-2col{display:grid; grid-template-columns:1fr 1fr; gap:11px;}
        .rc-ck-3col{display:grid; grid-template-columns:1fr 1fr 1fr; gap:11px;}
        .rc-ck-body .rc-card{min-height:0; flex:none;}
        .rc-ck-chartbox{position:relative; height:264px; padding:4px 2px;}
        .rc-ck-legend{display:flex; flex-wrap:wrap; gap:4px 12px; margin-top:7px;}
        .rc-ck-legend span{font-size:9px; color:var(--vf-abbey); display:flex; align-items:center; gap:5px; font-weight:700;}
        .rc-ck-matrixwrap{max-height:430px; overflow:auto;}
        .rc-ck-tblwrap{max-height:300px; overflow:auto;}
        .rc-ck-listwrap{max-height:340px; overflow:auto;}
        .rc-ck-crosswrap{max-height:380px; overflow:auto;}
        .rc-ck-trendtabs{display:flex; gap:4px;}
        .rc-ck-trendtabs .rc-btn-tab{font-size:9px; padding:3px 7px;}
        /* Produktklassen-Matrix */
        .rc-ck-matrix{width:100%; border-collapse:collapse; font-size:11.5px; white-space:nowrap;}
        .rc-ck-matrix th{padding:7px 8px; font-size:8.5px; font-weight:700; color:var(--vf-grey); letter-spacing:0.4px; text-transform:uppercase; border-bottom:2px solid var(--vf-line-strong); position:sticky; top:0; background:var(--vf-surface); z-index:1; text-align:center; cursor:pointer;}
        .rc-ck-matrix th:first-child{text-align:left;}
        .rc-ck-matrix td{padding:5px 8px; border-bottom:1px solid #242424; text-align:center; font-variant-numeric:tabular-nums; color:var(--vf-abbey);}
        .rc-ck-matrix td:first-child{text-align:left; color:var(--vf-ink);}
        .rc-ckm-std{cursor:pointer; background:rgba(255,255,255,0.02);}
        .rc-ckm-std:hover{background:rgba(230,0,0,0.08);}
        .rc-ckm-std td:first-child{font-weight:700; font-size:12px;}
        .rc-ckm-team{cursor:pointer;}
        .rc-ckm-team:hover{background:rgba(230,0,0,0.06);}
        .rc-ckm-team td:first-child{padding-left:24px; color:var(--vf-abbey); font-weight:700;}
        .rc-ckm-agent td:first-child{padding-left:44px; color:var(--vf-grey); font-size:10.5px; font-weight:400;}
        .rc-ckm-agent:hover{background:rgba(255,255,255,0.03);}
        .rc-ckm-caret{display:inline-block; width:12px; color:var(--vf-red); font-size:9px;}
        .rc-ck-gcell{font-weight:700; color:var(--vf-ink)!important;}
        .rc-ck-zero{color:#4A4A4A!important;}
        /* Cross-Selling */
        .rc-ck-crossrow{display:flex; align-items:center; gap:10px; padding:8px 11px; border-radius:6px; background:#232323; margin-bottom:6px; cursor:pointer; border-left:3px solid var(--vf-line-strong);}
        .rc-ck-crossrow:hover{background:#2A2A2A;}
        .rc-ck-crossrow .nm{font-weight:700; color:var(--vf-ink); font-size:12px;}
        .rc-ck-crosstag{font-size:8.5px; font-weight:700; letter-spacing:0.4px; text-transform:uppercase; padding:2px 8px; border-radius:9999px; white-space:nowrap;}
        .rc-ck-num{font-variant-numeric:tabular-nums; font-weight:700; font-size:12px;}
        .rc-ck-agentrow{display:flex; align-items:center; gap:10px; padding:4px 11px 4px 30px; font-size:11px; color:var(--vf-abbey); border-bottom:1px solid #242424;}
        .rc-ck-mark{font-weight:700; font-size:12px; width:22px; text-align:center; display:inline-block;}
        .rc-chip{display:inline-block; font-weight:700; font-size:8.5px; padding:2px 7px; border-radius:9999px;
            margin:1px 2px 1px 0; letter-spacing:0.4px; text-transform:uppercase;}
        .rc-chip.rot{background:rgba(230,0,0,0.18); color:#FF8A8A; border:1px solid rgba(230,0,0,0.5);}
        .rc-chip.gelb{background:rgba(255,102,102,0.12); color:#FF9E9E; border:1px solid rgba(255,102,102,0.4);}
        .rc-mailbtn{background:var(--vf-surface); border:1px solid var(--vf-red); color:var(--vf-red); border-radius:9999px;
            font-weight:700; font-size:9.5px; padding:3px 10px; cursor:pointer; text-decoration:none; display:inline-block;
            transition:background 0.2s, color 0.2s;}
        .rc-mailbtn:hover{background:var(--vf-red); color:#fff;}
        /* ===== IN-DASHBOARD KONFIGURATOR (Zahnrad) ===== */
        .rc-cfg-hidden{display:none !important;}
        #rcCfgBackdrop{position:fixed; inset:0; background:rgba(0,0,0,0.45); z-index:9999990; display:none;}
        #rcCfgBackdrop.on{display:block;}
        #rcCfgPanel{position:fixed; top:0; right:0; height:100vh; width:410px; max-width:94vw; background:var(--vf-surface);
            border-left:1px solid var(--vf-line-strong); box-shadow:-10px 0 40px rgba(0,0,0,0.5); z-index:9999998;
            transform:translateX(102%); transition:transform 0.28s cubic-bezier(0.4,0,0.2,1); display:flex; flex-direction:column;
            font-size:13px; color:var(--vf-ink);}
        #rcCfgPanel.on{transform:none;}
        #rcCfgPanel .rc-cfg-head{display:flex; align-items:center; gap:8px; padding:13px 16px; border-bottom:1px solid var(--vf-line);
            font-size:15px; background:var(--vf-panel,#171717); position:relative;}
        #rcCfgPanel .rc-cfg-head::after{content:''; position:absolute; left:0; right:0; top:0; height:3px; background:var(--vf-red);}
        .rc-cfg-x{border:none; background:transparent; color:var(--vf-grey); font-size:16px; cursor:pointer; padding:2px 6px; border-radius:5px;}
        .rc-cfg-x:hover{color:var(--vf-red); background:var(--vf-grey-dark);}
        .rc-cfg-tabs{display:flex; gap:3px; padding:8px 10px 0; border-bottom:1px solid var(--vf-line); flex-wrap:wrap;}
        .rc-cfg-tab{border:1px solid var(--vf-line); border-bottom:none; background:var(--vf-grey-dark); color:var(--vf-abbey);
            font-weight:700; font-size:11.5px; padding:6px 11px; border-radius:7px 7px 0 0; cursor:pointer;}
        .rc-cfg-tab.on{background:var(--vf-red); color:#fff; border-color:var(--vf-red);}
        .rc-cfg-body{flex:1; overflow-y:auto; padding:12px 16px 40px;}
        .rc-cfg-sec{font-size:10px; font-weight:800; letter-spacing:1px; text-transform:uppercase; color:var(--vf-red-soft);
            margin:16px 0 7px; border-bottom:1px solid var(--vf-line); padding-bottom:4px;}
        .rc-cfg-sec:first-child{margin-top:2px;}
        .rc-cfg-sub2{font-size:10px; font-weight:700; letter-spacing:.6px; text-transform:uppercase; color:var(--vf-grey); margin:8px 0 4px;}
        .rc-cfg-note{font-size:11.5px; color:var(--vf-abbey); background:var(--vf-grey-dark); border:1px solid var(--vf-line);
            border-radius:8px; padding:9px 11px; margin-bottom:12px; line-height:1.45;}
        .rc-cfg-row{display:flex; align-items:center; gap:10px; padding:6px 0; border-bottom:1px solid #242424;}
        .rc-cfg-row.sub{padding-left:16px;}
        .rc-cfg-rl{flex:1; font-size:12.5px; color:var(--vf-abbey);}
        .rc-cfg-rc{flex:0 0 auto; display:flex; align-items:center; gap:6px;}
        .rc-cfg-hint{font-size:10px; color:var(--vf-grey-mid); font-weight:600; margin-left:6px;}
        .rc-cfg-num{width:60px; background:var(--vf-grey-dark); border:1px solid var(--vf-line-strong); color:var(--vf-ink);
            border-radius:6px; padding:5px 7px; font-size:12px;}
        .rc-cfg-txt{width:100%; background:var(--vf-grey-dark); border:1px solid var(--vf-line-strong); color:var(--vf-ink);
            border-radius:6px; padding:6px 8px; font-size:12.5px; font-family:inherit;}
        textarea.rc-cfg-txt{min-height:52px; resize:vertical; line-height:1.4;}
        .rc-cfg-txt:focus, .rc-cfg-num:focus{outline:none; border-color:var(--vf-red);}
        .rc-cfg-mini{width:24px; height:24px; border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark); color:var(--vf-ink);
            border-radius:6px; font-weight:800; cursor:pointer;}
        .rc-cfg-mini:hover{border-color:var(--vf-red);}
        .rc-cfg-btn{border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark); color:var(--vf-ink); border-radius:7px;
            padding:6px 12px; font-size:12px; font-weight:700; cursor:pointer;}
        .rc-cfg-btn:hover{border-color:var(--vf-red);}
        .rc-cfg-btn.danger{border-color:var(--vf-red); color:var(--vf-red-soft);}
        .rc-cfg-btn.danger:hover{background:var(--vf-red); color:#fff;}
        /* Toggle-Switch */
        .rc-sw{position:relative; display:inline-block; width:38px; height:22px; cursor:pointer;}
        .rc-sw input{opacity:0; width:0; height:0; position:absolute;}
        .rc-sw span{position:absolute; inset:0; background:var(--vf-line-strong); border-radius:22px; transition:.2s;}
        .rc-sw span::before{content:''; position:absolute; width:16px; height:16px; left:3px; top:3px; background:#fff; border-radius:50%; transition:.2s;}
        .rc-sw input:checked + span{background:var(--vf-red);}
        .rc-sw input:checked + span::before{transform:translateX(16px);}
        /* Modul-Zeile */
        .rc-cfg-mod{display:flex; align-items:center; gap:4px; padding:5px 0; border-bottom:1px solid #242424;}
        .rc-cfg-ord, .rc-cfg-sz{width:24px; height:24px; border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark);
            color:var(--vf-abbey); border-radius:5px; font-size:11px; cursor:pointer; padding:0; line-height:1;}
        .rc-cfg-sz{width:auto; padding:0 7px; font-weight:800;}
        .rc-cfg-ord:hover, .rc-cfg-sz:hover{border-color:var(--vf-red); color:#fff;}
        .rc-cfg-mlbl{flex:1; font-size:12px; color:var(--vf-ink); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; padding:0 4px;}
        .rc-cfg-mlbl.off{color:var(--vf-grey-mid); text-decoration:line-through;}
        .rc-cfg-rename{flex:1; min-width:60px; font-size:12px; color:var(--vf-ink); background:#161616; border:1px solid var(--vf-line-strong); border-radius:4px; padding:3px 6px;}
        .rc-cfg-rename:focus{border-color:var(--vf-red); outline:none;}
        .rc-cfg-rename.off{color:var(--vf-grey-mid); text-decoration:line-through;}
        .rc-cfg-rreset{width:24px; height:24px; border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark); color:var(--vf-grey-mid); border-radius:4px; cursor:pointer; font-size:13px; line-height:1;}
        .rc-cfg-rreset:hover{border-color:var(--vf-red); color:#fff;}
        /* Info-Editor */
        .rc-cfg-addbar{display:flex; flex-wrap:wrap; gap:5px; margin-bottom:10px;}
        .rc-cfg-add{border:1px dashed var(--vf-line-strong); background:transparent; color:var(--vf-red-soft); border-radius:7px;
            padding:5px 9px; font-size:11px; font-weight:700; cursor:pointer;}
        .rc-cfg-add:hover{border-color:var(--vf-red); background:rgba(230,0,0,0.08);}
        .rc-cfg-add.sm{padding:3px 8px; font-size:10.5px; margin-top:4px;}
        .rc-cfg-imod{border:1px solid var(--vf-line); border-radius:9px; margin-bottom:10px; overflow:hidden; background:var(--vf-panel,#171717);}
        .rc-cfg-imhead{display:flex; align-items:center; gap:5px; padding:7px 9px; background:var(--vf-grey-dark); border-bottom:1px solid var(--vf-line); font-size:11.5px;}
        .rc-cfg-del{border:none; background:transparent; color:var(--vf-grey-mid); cursor:pointer; font-weight:900; padding:0 4px;}
        .rc-cfg-del:hover{color:var(--vf-red);}
        .rc-cfg-imfields{padding:9px 10px;}
        .rc-cfg-fl{display:block; font-size:9.5px; font-weight:800; letter-spacing:.5px; text-transform:uppercase; color:var(--vf-grey); margin:8px 0 4px;}
        .rc-cfg-imfields > .rc-cfg-fl:first-child{margin-top:0;}
        .rc-cfg-lrow{display:flex; gap:5px; margin-bottom:5px;}
        .rc-cfg-lrm{width:28px; border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark); color:var(--vf-grey); border-radius:5px; cursor:pointer; font-weight:800;}
        .rc-cfg-lrm:hover{color:var(--vf-red); border-color:var(--vf-red);}
        /* Info-Seite (eigene Inhalte) */
        .rc-info-page{flex:1; display:none; grid-template-columns:repeat(3,1fr); gap:10px; padding:10px; overflow:auto;
            align-content:start; grid-auto-rows:minmax(120px,auto); min-height:0;}
        .rc-info-check{list-style:none; margin:0; padding:0;} .rc-info-check li{position:relative; padding:7px 6px 7px 26px; font-size:14px; line-height:1.4; border-bottom:1px solid #232323;}
        .rc-info-check li::before{content:''; position:absolute; left:6px; top:11px; width:12px; height:12px; border:2px solid var(--vf-red); border-radius:4px;}
        .rc-info-offerhead{display:flex; align-items:baseline; gap:9px; margin-bottom:8px; flex-wrap:wrap;}
        .rc-info-prod{font-size:16px; font-weight:800; color:var(--vf-ink);} .rc-info-price{font-size:18px; font-weight:900; color:#FFCE00;}
        .rc-info-args{list-style:none; margin:0 0 8px; padding:0;} .rc-info-args li{position:relative; padding:5px 6px 5px 20px; font-size:13.5px; line-height:1.4; color:var(--vf-abbey);}
        .rc-info-args li::before{content:''; position:absolute; left:3px; top:11px; width:8px; height:8px; border-radius:50%; background:#3DD68C;}
        .rc-info-bridge{background:rgba(230,0,0,0.10); border-left:3px solid var(--vf-red); border-radius:0 8px 8px 0; padding:8px 10px; font-size:13.5px; line-height:1.45; margin-top:8px; color:var(--vf-ink);}
        .rc-info-obj{background:rgba(235,151,0,0.10); border-left:3px solid #EB9700; border-radius:0 8px 8px 0; padding:8px 10px; font-size:13px; line-height:1.45; margin-top:8px; color:var(--vf-abbey);}
        .rc-info-k{display:inline-block; font-size:8.5px; font-weight:800; letter-spacing:.7px; text-transform:uppercase; color:var(--vf-grey-mid); background:#232323; border-radius:5px; padding:2px 7px; margin-right:7px;}
        .rc-info-sit{font-size:11px; font-weight:800; letter-spacing:.6px; text-transform:uppercase; color:#57D0E0; margin-bottom:7px;}
        .rc-info-quote{font-size:16px; line-height:1.5; font-style:italic; color:var(--vf-ink); border-left:3px solid var(--vf-red); padding:3px 0 3px 11px;}
        .rc-info-line{font-size:13px; margin:7px 0; line-height:1.4; color:var(--vf-abbey);}
        .rc-info-reward{font-size:24px; font-weight:900; color:#FFCE00; line-height:1.1; margin-bottom:7px;}
        .rc-info-sub{font-size:12px; color:var(--vf-grey); margin-top:7px; line-height:1.4;}
        .rc-info-goalnum{font-size:30px; font-weight:900; text-align:center; color:var(--vf-ink);} .rc-info-goalnum span{font-size:18px; color:var(--vf-grey); font-weight:700;}
        .rc-info-bar{height:11px; background:#262626; border-radius:6px; overflow:hidden; margin:8px 0 3px;} .rc-info-bar i{display:block; height:100%; border-radius:6px; transition:width .6s;}
        .rc-info-bigcount{font-size:38px; font-weight:900; text-align:center; font-variant-numeric:tabular-nums; color:var(--vf-red-soft); margin:6px 0;} .rc-info-bigcount.over{color:var(--vf-grey-mid); font-size:22px;}
        .rc-info-text{font-size:14px; line-height:1.55; color:var(--vf-abbey);}
        .rc-info-empty{color:var(--vf-grey-mid); font-size:13px; padding:12px 4px; text-align:center;}
        /* Konfigurator v2: Seiten-Auswahl + Zonen + Live-Modul-Bausteine */
        .rc-cfg-pagesel{display:flex; flex-wrap:wrap; gap:4px; margin:0 0 8px;}
        .rc-cfg-pg{border:1px solid var(--vf-line-strong); background:var(--vf-grey-dark); color:var(--vf-abbey);
            border-radius:7px; padding:5px 11px; font-size:11.5px; font-weight:700; cursor:pointer;}
        .rc-cfg-pg.on{background:var(--vf-red); color:#fff; border-color:var(--vf-red);}
        .rc-cfg-zone{background:var(--vf-grey-dark); border:1px solid var(--vf-line-strong); color:var(--vf-ink);
            border-radius:5px; font-size:10.5px; padding:2px 5px; margin-right:5px;}
        .rc-cfg-add.live{color:#57D0E0; border-color:#2C4A50;}
        .rc-cfg-add.live:hover{border-color:#57D0E0; background:rgba(87,208,224,0.08);}
        .rc-cfg-custom{overflow:hidden;}
        /* Live-Modul-Bausteine (b-*) fuer eigene Module auf allen Seiten */
        .b-flag{display:inline-block; min-width:20px; text-align:center; font-size:9px; font-weight:800; letter-spacing:.5px;
            background:#262626; border:1px solid #3E3E3E; border-radius:4px; padding:1px 4px; color:#C9C9C9;}
        .b-rank{list-style:none; margin:0; padding:0;} .b-rank li{display:flex; align-items:center; gap:9px; padding:6px 4px; border-bottom:1px solid #232323; font-size:14px;}
        .b-pos{flex:0 0 auto; width:24px; height:24px; border-radius:6px; background:#262626; color:#C9C9C9; font-weight:800; display:grid; place-items:center; font-size:12px;}
        .b-pos.gold{background:#FFCE00; color:#1a1a1a;}
        .b-nm{flex:1; font-weight:700; color:var(--vf-ink);} .b-val{font-weight:900; font-variant-numeric:tabular-nums; font-size:17px; color:#FF6666;}
        .b-list{list-style:none; margin:0; padding:0;} .b-list li{display:flex; align-items:center; gap:8px; padding:6px 4px; border-bottom:1px solid #232323; font-size:13px; color:var(--vf-abbey);}
        .b-list li.warn .b-tagr{margin-left:auto; font-size:9px; font-weight:800; color:#FF6666; background:rgba(230,0,0,.14); border-radius:5px; padding:2px 6px;}
        .b-meta{font-size:11px; color:var(--vf-grey);}
        .b-table{width:100%; border-collapse:collapse; font-size:13px;} .b-table th{text-align:right; font-size:9px; letter-spacing:.4px; text-transform:uppercase; color:var(--vf-grey-mid); padding:4px 5px; border-bottom:1px solid var(--vf-line);}
        .b-table th:first-child{text-align:left;} .b-table td{padding:5px; text-align:right; border-bottom:1px solid #232323; font-variant-numeric:tabular-nums; color:var(--vf-abbey);}
        .b-table td:first-child{text-align:left; font-weight:700; color:var(--vf-ink);}

    `;
    document.head.appendChild(styleEl);

    // ============================================================
    //  OVERLAY-STRUKTUR
    // ============================================================
    const overlay = document.createElement('div');
    overlay.id = 'rcLiveDashboard';
    document.body.appendChild(overlay);

    // Vodafone-Speechmark-Echo: roter Kreis mit weissem Apostroph-Tropfen (Marken-Signatur)
    const vfLogoSvg = `<svg viewBox="0 0 40 40" width="32" height="32" style="vertical-align:middle; display:block;"><circle cx="20" cy="20" r="19" fill="#E60000"/><text x="21" y="31.5" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-size="46" font-weight="700" fill="#FFFFFF">&#8217;</text></svg>`;
    const vfSpeechmarkWhite = `<svg viewBox="0 0 40 40" width="24" height="24" style="display:block;"><text x="21" y="31.5" text-anchor="middle" font-family="Georgia,'Times New Roman',serif" font-size="46" font-weight="700" fill="#FFFFFF">&#8217;</text></svg>`;

    const standortOptions = ['<option value="ALL">Alle Standorte</option>']
        .concat(ORDER.map(c => `<option value="${c}">${STANDORT_METADATA[c].name}</option>`)).join('');

    overlay.innerHTML = `
        <div class="rc-header">
            <div class="rc-header-brand">
                ${vfLogoSvg}
                <span class="rc-arena-tag">ESL Live-Arena<small>Vodafone Sales-Cockpit &middot; regiocom</small></span>
                <span class="rc-live-pill"><span class="rc-live-dot"></span>LIVE</span>
                <span id="rcFetchStatus" style="font-size:11px; color:#9C9C9C;">— warte auf Abruf</span>
                <span id="rcLastSale" class="rc-lastsale"></span>
            </div>
            <div style="display:flex; align-items:center; gap:14px;">
                <div class="rc-clock"><div id="rcClock">--:--:--</div><small id="rcClockDate">—</small></div>
                <div class="rc-pageswitch">
                    <button class="rc-page-btn active" id="rcPageArena" data-page="arena">Arena</button>
                    <button class="rc-page-btn" id="rcPageQuali" data-page="quali">Qualität</button>
                    <button class="rc-page-btn" id="rcPageRadar" data-page="radar">Radar</button>
                    <button class="rc-page-btn" id="rcPageCockpit" data-page="cockpit">Cockpit</button>
                </div>
                <button class="rc-btn rc-btn-ghost" id="rcBtnAutoRot" title="Automatisch alle 60 s zwischen Arena und Radar wechseln (fuer die Wandmonitore)">Auto-Wechsel</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnAutoRotQuali" title="Qualität zusätzlich in den Auto-Wechsel aufnehmen">+ Qualität</button>
                <div class="rc-filtergroup" title="Ansicht filtern: Standort · Stack (Abteilung, z. B. VKD_Tech) · Team">
                    <span class="rc-flt-lbl">FILTER</span>
                    <select id="rcStandortFilter" class="rc-select rc-flt" title="Standort waehlen">${standortOptions}</select>
                    <select id="rcStackFilter" class="rc-select rc-flt" title="Stack / Abteilung (z. B. VKD_Tech) — grenzt die Liga-Calls auf die Verkaufsteams ein"><option value="ALL">Alle Stacks</option></select>
                    <select id="rcTeamFilter" class="rc-select rc-flt" title="Team (erst Standort waehlen)"><option value="ALL">Alle Teams</option></select>
                    <button class="rc-flt-reset" id="rcFltReset" title="Alle Filter zuruecksetzen" style="display:none;">&#10005;</button>
                </div>
                <button class="rc-btn rc-btn-ghost" id="rcBtnCompare" title="Tagesvergleich Vertrieb und Qualitaet mit Datumswahl">Vergleich</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnRange" title="Datumsbereich laden: stellt ESL und Ligaliste automatisch auf den Zeitraum und zeigt die Tage im Vergleich">Zeitraum</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnTest">Test</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnKpiQuelle" title="Ligaliste als KPI-Quelle oeffnen">KPI</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnMapping">Map</button>
                <button class="rc-btn rc-btn-ghost" id="rcCfgBtn" title="Konfigurator: Seiten, Module, Kriegsfeld-Texte, Info-Seite" style="font-size:15px; line-height:1;">&#9881;</button>
                <div class="rc-zoomctl" title="Fernsicht: Anzeige vergroessern, wenn der Monitor hoch/weit haengt (Strg + / Strg - / Strg 0)">
                    <button class="rc-zoom-btn" id="rcZoomOut" title="Kleiner (Strg -)">&#8722;</button>
                    <button class="rc-zoom-lbl" id="rcZoomLabel" title="Auf 100% zuruecksetzen (Strg 0)">100%</button>
                    <button class="rc-zoom-btn" id="rcZoomIn" title="Groesser (Strg +)">+</button>
                </div>
                <button class="rc-btn rc-btn-ghost" id="rcBtnToggle">&#10005;</button>
            </div>
        </div>

        <div class="rc-kpi-strip">
            <div class="rc-kpi"><div class="rc-kpi-l">Kontakte</div><div class="rc-kpi-v" id="kpiCalls">0</div></div>
            <div class="rc-kpi blue"><div class="rc-kpi-l"><i class="vf-dot" style="background:#FF6666;"></i>Ansprachen</div><div class="rc-kpi-v" id="kpiPitches">0<small id="kpiPitchRate">0%</small></div></div>
            <div class="rc-kpi green hot"><div class="rc-kpi-l"><i class="vf-dot" style="background:#E60000;"></i>BNT gesamt</div><div class="rc-kpi-v" id="kpiBnt">0<small id="kpiBntRate">0%</small></div></div>
            <div class="rc-kpi king-kip"><span class="rc-kpi-crown">Koenig &times;2</span><div class="rc-kpi-l"><i class="vf-dot" style="background:#FFB300;"></i>KIP-BNT</div><div class="rc-kpi-v" id="kpiKip">0</div></div>
            <div class="rc-kpi king-mob"><span class="rc-kpi-crown">Koenig &times;2</span><div class="rc-kpi-l"><i class="vf-dot" style="background:#22C7E6;"></i>Mobilfunk-BNT</div><div class="rc-kpi-v" id="kpiMob">0</div></div>
            <div class="rc-kpi pink"><div class="rc-kpi-l"><i class="vf-dot" style="background:#B4B4B4;"></i>VVL</div><div class="rc-kpi-v" id="kpiVvl">0</div></div>
            <div class="rc-kpi"><div class="rc-kpi-l"><i class="vf-dot" style="background:#8C8C8C;"></i>Angebote offen</div><div class="rc-kpi-v" id="kpiOffers">0</div></div>
            <div class="rc-kpi orange"><div class="rc-kpi-l"><i class="vf-dot" style="background:#E60000;"></i>Ablehnungen</div><div class="rc-kpi-v" id="kpiRej">0<small id="kpiRejRate">0%</small></div></div>
        </div>

        <div id="rcWarnBar" style="display:none; padding:7px 18px; background:#000000; color:#FFFFFF; font-weight:700; font-size:12px; flex-shrink:0;"></div>

        <div class="rc-grid" id="rcPageArenaContent">
            <!-- LINKS -->
            <div class="rc-col">
                <div class="rc-card accent-blue" style="flex:1.1;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcBattleTitle">Standort-Battle</h2>
                        <span id="rcBattleHint" style="font-size:9px; color:#9C9C9C; font-weight:700;">Flaggen antippen</span>
                    </div>
                    <div class="rc-battle-picker" id="rcNationPicker"></div>
                    <div id="rcNationBattleList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
                <div class="rc-card accent-blue" style="flex:1.3;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcStandorteTitle">Standorte</h2>
                        <div style="display:flex; gap:5px;">
                            <button id="rcTabStdSales" class="rc-btn-tab active">Abschluesse</button>
                            <button id="rcTabStdRates" class="rc-btn-tab">Quoten</button>
                        </div>
                    </div>
                    <div id="rcStandortBattleList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
                <div class="rc-card accent-dark" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Meistverkaufte Produkte</h2></div>
                    <div id="rcTopProductsList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
                <div class="rc-card accent-blue" style="flex:0.9;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title">Tages-Momentum</h2>
                        <span style="font-size:9px; color:#9C9C9C; font-weight:700;">BNT je Stunde &middot; Pace</span>
                    </div>
                    <div id="rcMomentumPanel" style="flex:1; padding:2px 2px 4px;">Warte auf Daten</div>
                </div>
            </div>

            <!-- MITTE -->
            <div class="rc-col">
                <div class="rc-moti"><span class="spk">${vfSpeechmarkWhite}</span><div class="rc-moti-txt" id="rcMotiText">Live-Arena bereit — der Tag gehoert euch</div></div>
                <div style="display:flex; gap:10px; flex:2.1; min-height:0;">
                    <div class="rc-card" style="flex:1.5; min-width:0;">
                        <div class="rc-card-header">
                            <h2 class="rc-card-title">Agenten-Arena</h2>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="display:flex; gap:5px;">
                                    <button id="rcTabAgTotal" class="rc-btn-tab active">Gesamt</button>
                                    <button id="rcTabAgBnt" class="rc-btn-tab">BNT</button>
                                    <button id="rcTabAgAnsp" class="rc-btn-tab">Ansprachen</button>
                                    <button id="rcTabAgTeams" class="rc-btn-tab">Teams</button>
                                </div>
                                <span id="rcValidRows" style="font-size:10px; color:#9C9C9C;" class="rc-mono">0 Zeilen</span>
                            </div>
                        </div>
                        <div class="rc-scroll" style="flex:1;">
                            <table class="rc-table">
                                <thead><tr>
                                    <th style="width:34px; text-align:center;">#</th>
                                    <th id="rcAgentHeadName">Verkaeufer</th>
                                    <th style="width:40px; text-align:center; color:#FF6666;">KIP</th>
                                    <th style="width:40px; text-align:center; color:#F5F5F5;">MOB</th>
                                    <th style="width:40px; text-align:center; color:#F5F5F5;">BNT</th>
                                    <th style="width:40px; text-align:center; color:#9C9C9C;">VVL</th>
                                    <th style="width:46px; text-align:center; color:#F5F5F5;">Ges.</th>
                                </tr></thead>
                                <tbody id="rcAgentLeaderboard"><tr><td colspan="7" style="text-align:center; padding:20px; color:#9C9C9C;">Lade Daten aus Portal</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="rc-card accent-orange" style="flex:1; min-width:0;">
                        <div class="rc-card-header">
                            <h2 class="rc-card-title"><svg viewBox="0 0 24 24" width="13" height="13" style="vertical-align:-2px;"><path d="M12 3 L22 20 H2 Z" fill="none" stroke="#FF6666" stroke-width="2" stroke-linejoin="round"/><line x1="12" y1="10" x2="12" y2="14.5" stroke="#FF6666" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17.2" r="1.1" fill="#FF6666"/></svg> Ansprache-Fokus</h2>
                            <span style="font-size:9px; color:#9C9C9C;">Calls ohne ESL-Ansprache</span>
                        </div>
                        <div id="rcAnspFokus" class="rc-scroll" style="flex:1;">Warte auf KPI-Quelle</div>
                    </div>
                </div>
                <div style="display:flex; gap:10px; flex:1.6; min-height:170px;">
                    <div class="rc-card accent-blue" style="flex:1; min-width:0;">
                        <div class="rc-card-header"><h2 class="rc-card-title">Abschluesse je Standort — kumuliert</h2></div>
                        <div class="rc-chartwrap"><canvas id="rcTrendChart"></canvas><div class="rc-ekg-scan"></div></div>
                    </div>
                    <div class="rc-card accent-blue" style="flex:1; min-width:0;">
                        <div class="rc-card-header"><h2 class="rc-card-title">TNPS-Monitor je Standort</h2><span style="font-size:9px; color:#9C9C9C;">Verlauf, alle 5 Min</span></div>
                        <div class="rc-chartwrap"><canvas id="rcTnpsChart"></canvas><div class="rc-ekg-scan" style="animation-delay:3.5s;"></div></div>
                    </div>
                </div>
            </div>

            <!-- RECHTS -->
            <div class="rc-col">
                <div class="rc-card accent-orange" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">KIP-BNT Liga</h2></div>
                    <div id="rcKipLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-blue" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Mobilfunk-BNT Liga</h2></div>
                    <div id="rcMobLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-pink" style="flex:1;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcSideTitle">VVL Liga</h2>
                        <div style="display:flex; gap:5px;">
                            <button id="rcTabSideVvl" class="rc-btn-tab active">VVL</button>
                            <button id="rcTabSideAnsp" class="rc-btn-tab">Anspr.</button>
                            <button id="rcTabSideOff" class="rc-btn-tab">Offen</button>
                        </div>
                    </div>
                    <div id="rcSideLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-dark" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Live-Abschluss-Ticker</h2></div>
                    <div id="rcTickerList" class="rc-scroll" style="flex:1; font-size:11px;">Lade</div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 2: QUALITÄT ===================== -->
        <div class="rc-quali" id="rcPageQualiContent" style="display:none;">
            <div class="rc-quali-strip">
                <div class="rc-kpi"><div class="rc-kpi-l">Ø CS · Ziel ≥ 90 %</div><div class="rc-kpi-v" id="qKpiCs">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø TNPS · Ziel ≥ 70 %</div><div class="rc-kpi-v" id="qKpiTnps">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø AQ · Ziel ≥ 85 %</div><div class="rc-kpi-v" id="qKpiAufleger">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø FQ · Ziel ≥ 30 %</div><div class="rc-kpi-v" id="qKpiFq">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø AHT · Ziel ≤ 13 Min</div><div class="rc-kpi-v" id="qKpiAht">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Detraktoren heute</div><div class="rc-kpi-v" id="qKpiDet">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">FF7-Risiko unter 8 Min</div><div class="rc-kpi-v" id="qKpiKurz">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Nicht-Tracker</div><div class="rc-kpi-v" id="qKpiNonTrack">—</div></div>
            </div>
            <div class="rc-quali-grid">
                <!-- LINKS: Standort-Chart + rotierende Rangliste -->
                <div class="rc-col">
                    <div class="rc-card accent-blue" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title">CS &amp; TNPS je Standort</h2></div>
                        <div class="rc-chartwrap"><canvas id="rcQualiStdChart"></canvas></div>
                    </div>
                    <div class="rc-card accent-blue" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" id="rcQualiRankTitle">Feedbackquote — Top 10</h2><span style="font-size:9px; color:#9C9C9C;">wechselt automatisch</span></div>
                        <div id="rcQualiRank" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                </div>
                <!-- MITTE: Haupttabelle -->
                <div class="rc-card accent-blue" style="min-height:0;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title">Qualitäts-KPIs je Agent</h2>
                        <div style="display:flex; gap:5px;">
                            <button class="rc-btn-tab active" id="qSortCalls">Calls</button>
                            <button class="rc-btn-tab" id="qSortCs">CS</button>
                            <button class="rc-btn-tab" id="qSortTnps">TNPS</button>
                            <button class="rc-btn-tab" id="qSortFq">FQ</button>
                            <button class="rc-btn-tab" id="qSortAufleger">AQ</button>
                        </div>
                    </div>
                    <div class="rc-scroll" style="flex:1;">
                        <table class="rc-table">
                            <thead><tr>
                                <th style="width:34px; text-align:center;">#</th>
                                <th>Agent</th>
                                <th style="width:56px; text-align:center; color:#F5F5F5;">Calls</th>
                                <th style="width:52px; text-align:center;">AHT</th>
                                <th style="width:48px; text-align:center;">AQ %</th>
                                <th style="width:48px; text-align:center;">CS %</th>
                                <th style="width:52px; text-align:center;">TNPS %</th>
                                <th style="width:46px; text-align:center;">FQ %</th>
                                <th style="width:48px; text-align:center;">DDS %</th>
                                <th style="width:40px; text-align:center; color:#E60000;">Det</th>
                                <th style="width:52px; text-align:center; color:#F5F5F5;">Anspr.</th>
                            </tr></thead>
                            <tbody id="rcQualiBody"><tr><td colspan="11" style="text-align:center; padding:24px; color:#9C9C9C;">Warte auf KPI-Quelle — Button oben rechts nutzen</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <!-- RECHTS: Detraktoren-Alarm + Kurz-Telefonierer -->
                <div class="rc-col">
                    <div class="rc-card accent-orange" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" style="color:#E60000;">Detraktoren — Handlung erforderlich</h2></div>
                        <div id="rcDetraktorList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                    <div class="rc-card accent-orange" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" style="color:#FF6666;">FF7-Fruehwarnung — unter 8 Min</h2><span style="font-size:9px; color:#9C9C9C;">Kundenanliegen zu Ende loesen</span></div>
                        <div id="rcKurzTelList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 3: RADAR (Kriegskarte / Burgeroberung) ===================== -->
        <div class="rc-radar" id="rcPageRadarContent">
            <!-- LINKS: nur noch die verkaufsrelevanten Module (Tagesbefehl, Sales-Funnel, Einsatz-Log
                 auf Nutzerwunsch entfernt) -> 3 hoehere Module = weniger Scrollen.
                 KIP-BNT + Mobilfunk-BNT Verkaeufer (Ligen) + "Noch ohne Premium-BNT" (Null-Verkaeufer). -->
            <!-- LINKS: EINE hohe Carousel-Karte statt drei kurzer Stapel-Karten.
                 Wechselt alle ~12 s weich zwischen KIP-BNT / Mobilfunk-BNT / Noch ohne
                 Premium-BNT; der Titel folgt dem sichtbaren Modul, lange Listen fahren
                 per Ping-Pong-Auto-Scroll (rcInitRadarCarousels / rcAutoScrollLoop). -->
            <div class="rc-col">
                <div class="rc-card accent-orange rc-carousel" style="flex:1; min-height:0;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcRadarLeftTitle">KIP-BNT Verkaeufer</h2>
                        <span class="rc-carousel-dots" aria-hidden="true"></span>
                    </div>
                    <div class="rc-carousel-body">
                        <!-- Modul 1: KIP-BNT Verkaeufer (Liga) -->
                        <div class="rc-carousel-pane rc-pane-on" data-title="KIP-BNT Verkaeufer">
                            <div id="rcRadarKipLeaderboard" class="rc-scroll rc-autoscroll">Lade</div>
                        </div>
                        <!-- Modul 2: Mobilfunk-BNT Verkaeufer (Liga) -->
                        <div class="rc-carousel-pane" data-title="Mobilfunk-BNT Verkaeufer">
                            <div id="rcRadarMobLeaderboard" class="rc-scroll rc-autoscroll">Lade</div>
                        </div>
                        <!-- Modul 3: Noch ohne Premium-BNT (rotiert intern Agenten/Teams;
                             Titel folgt dynamisch aus dem versteckten #rcLowPerfTitle). -->
                        <div class="rc-carousel-pane" data-title-src="rcLowPerfTitle">
                            <h2 id="rcLowPerfTitle" style="display:none;">Noch ohne Premium-BNT</h2>
                            <span id="rcLowPerfSub" style="display:none;">Agentenbasis</span>
                            <div id="rcLowPerf" class="rc-scroll rc-autoscroll">Warte auf Daten</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- MITTE: Kriegskarte -->
            <div class="rc-card accent-blue" style="min-height:0;">
                <div class="rc-card-header">
                    <h2 class="rc-card-title" id="rcRadarMainTitle">Burgeroberung — Schlacht um Europa</h2>
                    <span class="rc-mono" style="font-size:10px; color:#E60000;" id="rcRadarStatusLine">SYSTEM AKTIV</span>
                </div>
                <div class="rc-radar-svgwrap" id="rcRadarSvgWrap"></div>
            </div>

            <!-- RECHTS: Kriegsrat, Krieger, Zero-Sellers -->
            <!-- RECHTS: EINE hohe Carousel-Karte. Wechselt weich zwischen
                 Kriegsrat / Krieger vor dem Durchbruch / Stille Kanonen; der Kriegsrat-
                 Titel folgt dynamisch (versteckt #rcRadarKriegsratTitle). -->
            <div class="rc-col">
                <div class="rc-card accent-red rc-carousel" style="flex:1; min-height:0; background:linear-gradient(135deg, #1A1A1A, #2A1111);">
                    <div class="rc-card-header" style="border-bottom-color:#E60000;">
                        <h2 class="rc-card-title" style="color:#FFCCCC;" id="rcRadarRightTitle">Kriegsrat</h2>
                        <span class="rc-carousel-dots" aria-hidden="true"></span>
                    </div>
                    <div class="rc-carousel-body">
                        <!-- Modul 1: Kriegsrat (Titel "Kriegsrat <Standort>" dynamisch) -->
                        <div class="rc-carousel-pane rc-pane-on" data-title-src="rcRadarKriegsratTitle">
                            <h2 id="rcRadarKriegsratTitle" style="display:none;">Kriegsrat</h2>
                            <div id="rcRadarConquestTarget" class="rc-scroll rc-autoscroll" style="padding:8px 10px;">
                                <div style="font-size:12px; color:#9C9C9C;">Analysiere Feindstaerke...</div>
                            </div>
                        </div>
                        <!-- Modul 2: Krieger vor dem Durchbruch -->
                        <div class="rc-carousel-pane" data-title="Krieger vor dem Durchbruch">
                            <div id="rcRadarKrieger" class="rc-scroll rc-autoscroll">Warte auf Daten</div>
                        </div>
                        <!-- Modul 3: Stille Kanonen -->
                        <div class="rc-carousel-pane" data-title="Stille Kanonen — die Front vermisst euch">
                            <div id="rcRadarZeroSellers" class="rc-scroll rc-autoscroll">Warte auf Daten</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 4: COCKPIT (Manager / Teamleiter) ===================== -->
        <div class="rc-cockpit" id="rcPageCockpitContent">
            <div class="rc-quali-strip">
                <div class="rc-kpi"><div class="rc-kpi-l">Kontakte</div><div class="rc-kpi-v" id="ckKontakte">—</div></div>
                <div class="rc-kpi blue"><div class="rc-kpi-l">Ansprachen · Quote</div><div class="rc-kpi-v" id="ckAnspr">—</div></div>
                <div class="rc-kpi green"><div class="rc-kpi-l"><i class="vf-dot" style="background:#E60000;"></i>BNT · BCR-BNT (Liga)</div><div class="rc-kpi-v" id="ckBnt">—</div></div>
                <div class="rc-kpi pink"><div class="rc-kpi-l">VVL · BCR-VVL (Liga)</div><div class="rc-kpi-v" id="ckVvl">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Kritische Agenten</div><div class="rc-kpi-v" id="ckKrit">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l"><i class="vf-dot" style="background:#E60000;"></i>BNT-Prognose 18 Uhr</div><div class="rc-kpi-v" id="ckPace">—</div></div>
                <div class="rc-kpi" style="display:flex; align-items:center; justify-content:center; gap:8px; flex-wrap:wrap;">
                    <button class="rc-btn rc-btn-blue" id="ckBtnExport" style="font-size:11px;">Excel-Export</button>
                    <button class="rc-btn rc-btn-ghost" id="ckBtnStandTag" style="font-size:11px;" title="Das Vorlagen-Blatt 'Stand' fuer einen beliebigen Tag exportieren (z.B. gestern fuer die Team-Mail)">Stand-Export (Tag)</button>
                    <a class="rc-mailbtn" id="ckBtnMailAll" href="#" style="font-size:10.5px; padding:6px 12px;">Mail an Teamleitung</a>
                </div>
            </div>
            <div class="rc-ck-body">
                <div class="rc-ck-classrow" id="rcCkClassKpis"></div>

                <div class="rc-card accent-blue">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title">Produktklassen-Matrix &mdash; Standort &rsaquo; Team &rsaquo; Agent</h2>
                        <span style="font-size:9px; color:#9C9C9C;">Zeile klicken = aufklappen &middot; Spaltenkopf = sortieren</span>
                    </div>
                    <div class="rc-ck-matrixwrap">
                        <table class="rc-ck-matrix"><thead id="rcCkMatrixHead"></thead><tbody id="rcCkMatrix"><tr><td style="padding:16px; color:#9C9C9C;">Warte auf Daten</td></tr></tbody></table>
                    </div>
                </div>

                <div class="rc-ck-2col">
                    <div class="rc-card">
                        <div class="rc-card-header"><h2 class="rc-card-title">Produktmix je Standort</h2><span style="font-size:9px; color:#9C9C9C;">gestapelt &middot; Abschluesse je Klasse</span></div>
                        <div class="rc-ck-chartbox"><canvas id="rcCkMix"></canvas></div>
                        <div class="rc-ck-legend" id="rcCkMixLegend"></div>
                    </div>
                    <div class="rc-card">
                        <div class="rc-card-header">
                            <h2 class="rc-card-title">Trend &mdash; 7 Tage</h2>
                            <div class="rc-ck-trendtabs" id="rcCkTrendTabs">
                                <button class="rc-btn-tab active" data-ck-metric="bnt">BNT gesamt</button>
                                <button class="rc-btn-tab" data-ck-metric="kip">KIP-BNT</button>
                                <button class="rc-btn-tab" data-ck-metric="mob">Mobilfunk</button>
                                <button class="rc-btn-tab" data-ck-metric="vvl">VVL</button>
                            </div>
                        </div>
                        <div class="rc-ck-chartbox"><canvas id="rcCkTrend"></canvas></div>
                    </div>
                </div>

                <div class="rc-card accent-orange">
                    <div class="rc-card-header"><h2 class="rc-card-title">Cross-Selling &mdash; KIP &times; Mobilfunk</h2><span style="font-size:9px; color:#9C9C9C;">Team klicken = Agenten &middot; wer verkauft beides, wer nicht</span></div>
                    <div class="rc-ck-crosswrap" id="rcCkCross"><div style="padding:14px; color:#9C9C9C; font-size:11px;">Warte auf Daten</div></div>
                </div>

                <div class="rc-ck-2col">
                    <div class="rc-card accent-blue">
                        <div class="rc-card-header"><h2 class="rc-card-title">Team-Vergleich</h2><span style="font-size:9px; color:#9C9C9C;">Spalte klicken = sortieren &middot; Zeile klicken = Team-Details</span></div>
                        <div class="rc-scroll rc-ck-tblwrap">
                            <table class="rc-table rc-ck-teamtable"><thead><tr>
                                <th data-ck-sort="name" style="cursor:pointer;">Team</th>
                                <th data-ck-sort="calls"  style="width:42px; text-align:center; cursor:pointer;">Calls</th>
                                <th data-ck-sort="anspr"  style="width:48px; text-align:center; cursor:pointer;">Anspr%</th>
                                <th data-ck-sort="bnt"    style="width:36px; text-align:center; cursor:pointer;">BNT</th>
                                <th data-ck-sort="bcrBnt" style="width:52px; text-align:center; cursor:pointer;">BCR-BNT</th>
                                <th data-ck-sort="vvl"    style="width:36px; text-align:center; cursor:pointer;">VVL</th>
                                <th data-ck-sort="bcrVvl" style="width:52px; text-align:center; cursor:pointer;">BCR-VVL</th>
                                <th data-ck-sort="cs"     style="width:40px; text-align:center; cursor:pointer;">CS</th>
                                <th data-ck-sort="tnps"   style="width:44px; text-align:center; cursor:pointer;">TNPS</th>
                            </tr></thead><tbody id="rcCkTeams"><tr><td colspan="9" style="text-align:center; padding:18px; color:#9C9C9C;">Lade Daten</td></tr></tbody></table>
                        </div>
                    </div>
                    <div class="rc-card accent-blue">
                        <div class="rc-card-header"><h2 class="rc-card-title">Standort-Leistung</h2></div>
                        <div class="rc-scroll rc-ck-tblwrap">
                            <table class="rc-table"><thead><tr>
                                <th>Standort</th><th style="width:44px; text-align:center;">Calls</th>
                                <th style="width:40px; text-align:center;">BNT</th><th style="width:56px; text-align:center;">BCR-BNT</th>
                                <th style="width:40px; text-align:center;">VVL</th><th style="width:56px; text-align:center;">BCR-VVL</th>
                            </tr></thead><tbody id="rcCkStd"><tr><td colspan="6" style="text-align:center; padding:18px; color:#9C9C9C;">Lade Daten</td></tr></tbody></table>
                        </div>
                    </div>
                </div>

                <div class="rc-ck-3col">
                    <div class="rc-card accent-orange">
                        <div class="rc-card-header"><h2 class="rc-card-title" style="color:#E60000;">Kritische Agenten</h2><span style="font-size:9px; color:#9C9C9C;">Sales + Qualitaet</span></div>
                        <div id="rcCkKrit" class="rc-scroll rc-ck-listwrap">Lade Daten</div>
                    </div>
                    <div class="rc-card accent-orange">
                        <div class="rc-card-header"><h2 class="rc-card-title">Vertriebs-Blocker</h2><span style="font-size:9px; color:#9C9C9C;">Liga-Analyse</span></div>
                        <div id="rcCkInsights" class="rc-scroll rc-ck-listwrap">Warte auf KPI-Quelle</div>
                    </div>
                    <div class="rc-card">
                        <div class="rc-card-header"><h2 class="rc-card-title">Woran scheitert es</h2><span style="font-size:9px; color:#9C9C9C;">Top-Ablehnungsgruende</span></div>
                        <div id="rcCkReasons" class="rc-scroll rc-ck-listwrap">Lade Daten</div>
                    </div>
                </div>
            </div>
        </div>

        <div class="rc-marquee"><div class="rc-marquee-content" id="rcNewsMarquee">+++ LIVE-ARENA BEREIT +++ DATEN WERDEN GELADEN +++</div></div>
    `;

    const toastContainer = document.createElement('div');
    toastContainer.id = 'rcToastContainer';
    document.body.appendChild(toastContainer);

    const badge = document.createElement('div');
    badge.id = 'rcLiveBadge';
    Object.assign(badge.style, {display:'none', position:'fixed', bottom:'20px', right:'20px',
        background:'#E60000', color:'#fff', padding:'12px 22px',
        borderRadius:'9999px', cursor:'pointer', zIndex:'9999999', fontWeight:'700'});
    badge.innerHTML = 'Live-Arena oeffnen';
    document.body.appendChild(badge);

    const modal = document.createElement('div');
    modal.id = 'rcMappingModal';
    modal.innerHTML = `
        <div class="rc-card" style="width:400px; text-align:center;">
            <h3 style="font-weight:700; color:#F5F5F5; margin:0 0 10px;">Mitarbeiter-Mapping</h3>
            <p style="font-size:12px; color:#9C9C9C; margin-bottom:14px;">Lade die Mitarbeiter_ID_Und_Namen.xlsx hoch.</p>
            <p style="font-size:11px; color:#9C9C9C; margin-bottom:20px; text-align:left; line-height:1.5;">
                <b style="color:#F5F5F5;">Mehrere Dateien moeglich</b> — sie ergaenzen sich: Fehlen in der aktuellen Liste
                die VO-Nummern, zuerst die aeltere Datei mit den VO-Spalten laden, danach die aktuelle.
                <b style="color:#F5F5F5;">Die zuletzt geladene Datei bestimmt Teams und Stacks</b>; VO-Nummern aus
                frueheren Ladungen bleiben per CCS-ID erhalten. Neu anfangen: <span class="rc-mono">rcResetMapping()</span>.
            </p>
            <div id="rcDropZone">
                <svg viewBox="0 0 24 24" width="34" height="34" style="display:block; margin:0 auto 10px;" fill="none" stroke="#E60000" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                <div style="font-size:13px; font-weight:700; color:#F5F5F5;">Datei hier ablegen oder klicken</div>
                <input type="file" id="rcFileInput" accept=".xlsx" style="display:none;"/>
            </div>
            <button class="rc-btn rc-btn-gray" id="rcBtnCancelMapping">Abbrechen</button>
        </div>`;
    document.body.appendChild(modal);

    // Standort-Picker aufbauen (Flagge + Kuerzel; ein Land kann mehrere Standorte haben)
    (function buildBattlePicker(){
        const p = document.getElementById('rcNationPicker');
        p.innerHTML = ORDER.map(code =>
            `<div class="rc-battle-chip ${window.rcSelectedStandorte.has(code)?'on':''}" data-std="${code}" title="${STANDORT_METADATA[code].name}">${getFlagSvg(code,'small')}<span>${code}</span></div>`
        ).join('');
        p.querySelectorAll('.rc-battle-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const c = chip.dataset.std;
                const sel = window.rcSelectedStandorte;
                if (sel.has(c)) { if (sel.size > 1) sel.delete(c); }
                else {
                    // Duell-Format: max. 2 — beim dritten Klick faellt der zuerst gewaehlte raus
                    if (sel.size >= 2) sel.delete(sel.values().next().value);
                    sel.add(c);
                }
                localStorage.setItem('rcSelectedStandorte', JSON.stringify([...sel]));
                p.querySelectorAll('.rc-battle-chip').forEach(ch => ch.classList.toggle('on', sel.has(ch.dataset.std)));
                if (window.rcLetzteStats) renderStandortBattle(window.rcLetzteStats.standortStats);
            });
        });
    })();

    // ============================================================
    //  STATE & EVENTS
    // ============================================================
    window.rcActiveStandortTab = 'sales';
    window.rcActiveAgentTab = 'total';
    window.rcActiveSideTab = 'vvl';

    function bindTab(id, group, val, cb){
        document.getElementById(id).addEventListener('click', () => {
            group.forEach(g => document.getElementById(g).classList.remove('active'));
            document.getElementById(id).classList.add('active');
            cb(val);
            if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        });
    }
    bindTab('rcTabStdSales', ['rcTabStdSales','rcTabStdRates'], 'sales', v => window.rcActiveStandortTab=v);
    bindTab('rcTabStdRates', ['rcTabStdSales','rcTabStdRates'], 'rates', v => window.rcActiveStandortTab=v);
    const AG_TABS = ['rcTabAgTotal','rcTabAgBnt','rcTabAgAnsp','rcTabAgTeams'];
    bindTab('rcTabAgTotal', AG_TABS, 'total', v => window.rcActiveAgentTab=v);
    bindTab('rcTabAgBnt',   AG_TABS, 'bnt',   v => window.rcActiveAgentTab=v);
    bindTab('rcTabAgAnsp',  AG_TABS, 'ansp',  v => window.rcActiveAgentTab=v);
    bindTab('rcTabAgTeams', AG_TABS, 'teams', v => window.rcActiveAgentTab=v);
    const SIDE_TABS = ['rcTabSideVvl','rcTabSideAnsp','rcTabSideOff'];
    const SIDE_TITLES = { vvl:'VVL Liga', ansp:'Top-Ansprachen', offers:'Offene Angebote — nachfassen' };
    bindTab('rcTabSideVvl',  SIDE_TABS, 'vvl',    v => { window.rcActiveSideTab=v; document.getElementById('rcSideTitle').textContent=SIDE_TITLES[v]; });
    bindTab('rcTabSideAnsp', SIDE_TABS, 'ansp',   v => { window.rcActiveSideTab=v; document.getElementById('rcSideTitle').textContent=SIDE_TITLES[v]; });
    bindTab('rcTabSideOff',  SIDE_TABS, 'offers', v => { window.rcActiveSideTab=v; document.getElementById('rcSideTitle').textContent=SIDE_TITLES[v]; });

    window.toggleDashboard = v => { document.getElementById('rcLiveDashboard').style.display = v?'flex':'none'; document.getElementById('rcLiveBadge').style.display = v?'none':'flex'; };
    window.openMappingModal = () => document.getElementById('rcMappingModal').style.display='flex';
    window.closeMappingModal = () => document.getElementById('rcMappingModal').style.display='none';
    document.getElementById('rcBtnToggle').addEventListener('click', () => window.toggleDashboard(false));
    badge.addEventListener('click', () => window.toggleDashboard(true));
    document.getElementById('rcBtnMapping').addEventListener('click', window.openMappingModal);
    document.getElementById('rcBtnCancelMapping').addEventListener('click', window.closeMappingModal);
    document.getElementById('rcBtnTest').addEventListener('click', () => window.simulateFakeSale());
    document.getElementById('rcBtnKpiQuelle').addEventListener('click', () => window.rcOpenKpiQuelle());
    document.getElementById('rcBtnCompare').addEventListener('click', () => window.rcOpenCompare && window.rcOpenCompare());
    document.getElementById('rcBtnRange').addEventListener('click', () => window.rcOpenRange && window.rcOpenRange());

    // ============================================================
    //  FERNSICHT-ZOOM — global vergroessern, wenn der Monitor hoch/weit haengt.
    //  Setzt --rc-zoom (CSS macht daraus zoom + Groessen-Kompensation, s. Style-Block);
    //  persistent in localStorage, per Kopfleisten-Buttons ODER Strg +/-/0 bedienbar.
    // ============================================================
    const RC_ZOOM_MIN = 1, RC_ZOOM_MAX = 2.2, RC_ZOOM_STEP = 0.1;
    window.rcApplyZoom = function(z, persist){
        z = Math.round(Math.max(RC_ZOOM_MIN, Math.min(RC_ZOOM_MAX, z)) * 100) / 100;
        window.rcZoom = z;
        document.documentElement.style.setProperty('--rc-zoom', z);
        const lbl = document.getElementById('rcZoomLabel');
        if (lbl) { lbl.textContent = Math.round(z * 100) + '%'; lbl.classList.toggle('rc-zoom-on', z !== 1); }
        if (persist !== false) { try { localStorage.setItem('rcZoom', String(z)); } catch(e){} }
        requestAnimationFrame(() => {
            try { window.dispatchEvent(new Event('resize')); } catch(e){}
            if (window.rcWarResize) { try { window.rcWarResize(); } catch(e){} }
        });
    };
    const rcZoomBy = d => window.rcApplyZoom((window.rcZoom || 1) + d);
    const rcZi = document.getElementById('rcZoomIn'), rcZo = document.getElementById('rcZoomOut'), rcZl = document.getElementById('rcZoomLabel');
    if (rcZi) rcZi.addEventListener('click', () => rcZoomBy(+RC_ZOOM_STEP));
    if (rcZo) rcZo.addEventListener('click', () => rcZoomBy(-RC_ZOOM_STEP));
    if (rcZl) rcZl.addEventListener('click', () => window.rcApplyZoom(1));
    window.addEventListener('keydown', e => {
        if (!e.ctrlKey && !e.metaKey) return;
        if (e.key === '+' || e.key === '=') { e.preventDefault(); rcZoomBy(+RC_ZOOM_STEP); }
        else if (e.key === '-' || e.key === '_') { e.preventDefault(); rcZoomBy(-RC_ZOOM_STEP); }
        else if (e.key === '0') { e.preventDefault(); window.rcApplyZoom(1); }
    }, true);
    (function(){ let z = 1; try { z = parseFloat(localStorage.getItem('rcZoom')) || 1; } catch(e){}
        if (z && z !== 1) window.rcApplyZoom(z, false); })();

    // Arena-Kennzahlen anklickbar: Klick zeigt, WER hinter der Zahl steht
    [['kpiBnt','bnt'],['kpiKip','kip'],['kpiMob','mob'],['kpiVvl','vvl'],['kpiPitches','pitches'],['kpiRej','rej'],['kpiCalls','calls'],['kpiOffers','offers']].forEach(([id,kind]) => {
        const el = document.getElementById(id); if (!el) return;
        const kachel = el.closest('.rc-kpi') || el;
        kachel.style.cursor = 'pointer';
        kachel.title = 'Klick: wer steckt dahinter';
        kachel.addEventListener('click', () => { if (window.rcOpenKpiDetail) window.rcOpenKpiDetail(kind); });
    });
    document.getElementById('rcStandortFilter').addEventListener('change', () => {
        // Standort gewechselt -> Team-Auswahl zuruecksetzen (altes Team gilt im neuen Standort nicht)
        const ts = document.getElementById('rcTeamFilter'); if (ts) { ts.value = 'ALL'; ts.dataset.sig = ''; }
        if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
    });
    document.getElementById('rcTeamFilter').addEventListener('change', () => { if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom); });

    // ---- Seitenumschaltung Arena / Qualität / Radar ----
    window.rcActivePage = 'arena';
    window.rcQualiSort = 'calls';
    const RC_PAGES = { arena:['rcPageArena','rcPageArenaContent','grid'], quali:['rcPageQuali','rcPageQualiContent','flex'], radar:['rcPageRadar','rcPageRadarContent','grid'], cockpit:['rcPageCockpit','rcPageCockpitContent','flex'] };
    function switchPage(page){
        window.rcActivePage = page;
        Object.entries(RC_PAGES).forEach(([p,[btnId,contentId,disp]]) => {
            document.getElementById(btnId).classList.toggle('active', p===page);
            document.getElementById(contentId).style.display = p===page ? disp : 'none';
        });
        if (page==='quali' && window.renderQualitaet) window.renderQualitaet();
        if (page==='radar') { if (window.renderRadar) window.renderRadar(); if (window.renderRadarCharts) window.renderRadarCharts(window.rcRotState||0); if (window.rcHeroCallTick) { try { window.rcHeroCallTick(); } catch(e){} } }
        if (page==='cockpit' && window.renderCockpit) window.renderCockpit();
        if (window.rcWarSetActive) window.rcWarSetActive(page==='radar');
    }
    Object.keys(RC_PAGES).forEach(p => document.getElementById(RC_PAGES[p][0]).addEventListener('click', () => switchPage(p)));

    // ---- Auto-Wechsel fuer Wandmonitore: auf Knopfdruck, alle 60 s ----
    // rcAutoRotPages = Rotationsreihenfolge. Qualitaet ist optional zuschaltbar.
    window.rcAutoRot = false;
    window.rcAutoRotSec = 60;                    // Intervall justierbar: rcAutoRotSec = 45
    window.rcAutoRotPages = ['arena', 'radar'];  // Reihenfolge; 'quali' per Knopf dazwischen
    function rcAutoRotSyncBtns(){
        const b = document.getElementById('rcBtnAutoRot');
        if (b){ b.classList.toggle('rc-btn-on', window.rcAutoRot); b.textContent = window.rcAutoRot ? 'Auto-Wechsel: AN' : 'Auto-Wechsel'; }
        const q = document.getElementById('rcBtnAutoRotQuali');
        if (q){ q.classList.toggle('rc-btn-on', window.rcAutoRotPages.indexOf('quali') !== -1); }
    }
    function rcAutoRotToggleQuali(){
        const i = window.rcAutoRotPages.indexOf('quali');
        if (i === -1) window.rcAutoRotPages.splice(1, 0, 'quali');  // zwischen Arena und Radar
        else window.rcAutoRotPages.splice(i, 1);
        rcAutoRotSyncBtns();
    }
    function rcSetAutoRot(on){
        window.rcAutoRot = !!on;
        rcAutoRotSyncBtns();
        if (window.rcAutoRotInterval){ clearInterval(window.rcAutoRotInterval); window.rcAutoRotInterval = null; }
        if (window.rcAutoRot){
            const pages = window.rcAutoRotPages;
            if (pages.length && pages.indexOf(window.rcActivePage) === -1) switchPage(pages[0]);
            window.rcAutoRotInterval = setInterval(() => {
                const ps = window.rcAutoRotPages;
                if (!ps.length) return;
                const idx = ps.indexOf(window.rcActivePage);
                switchPage(ps[(idx + 1) % ps.length]);
            }, (window.rcAutoRotSec || 60) * 1000);
        }
    }
    window.rcSetAutoRot = rcSetAutoRot;
    window.rcAutoRotToggleQuali = rcAutoRotToggleQuali;
    { const _arb = document.getElementById('rcBtnAutoRot'); if (_arb) _arb.addEventListener('click', () => rcSetAutoRot(!window.rcAutoRot)); }
    { const _aqb = document.getElementById('rcBtnAutoRotQuali'); if (_aqb) _aqb.addEventListener('click', rcAutoRotToggleQuali); }
    rcAutoRotSyncBtns();

    // ---- Qualität Sortier-Tabs ----
    const Q_SORT_TABS = [['qSortCalls','calls'],['qSortCs','cs'],['qSortTnps','tnps'],['qSortFq','fq'],['qSortAufleger','auflegerquote']];
    Q_SORT_TABS.forEach(([id,key]) => {
        const btn = document.getElementById(id); if (!btn) return;
        btn.addEventListener('click', () => {
            window.rcQualiSort = key;
            Q_SORT_TABS.forEach(([x]) => { const b = document.getElementById(x); if (b) b.classList.remove('active'); });
            btn.classList.add('active');
            if (window.renderQualitaet) window.renderQualitaet();
        });
    });

    // ---- Auto-Rotation: alle 30 s wechseln die Modul-Ansichten (mehr Bewegung auf dem Monitor) ----
    window.rcRotState = 0;
    window.rcQualiRankMode = 'fq';
    window.rcRotateInterval = setInterval(() => {
        window.rcRotState++;
        const lr = window.rcLastRender;
        try {
            if (window.rcActivePage === 'arena' && lr) {
                // Standorte/Teams: Abschluesse <-> Quoten
                window.rcActiveStandortTab = (window.rcRotState % 2) ? 'rates' : 'sales';
                document.getElementById('rcTabStdSales').classList.toggle('active', window.rcActiveStandortTab==='sales');
                document.getElementById('rcTabStdRates').classList.toggle('active', window.rcActiveStandortTab==='rates');
                // Agenten-Arena: Gesamt -> BNT -> Ansprachen
                const agTabs = ['total','bnt','ansp'];
                window.rcActiveAgentTab = agTabs[window.rcRotState % 3];
                [['rcTabAgTotal','total'],['rcTabAgBnt','bnt'],['rcTabAgAnsp','ansp']].forEach(([id,v]) => document.getElementById(id).classList.toggle('active', v===window.rcActiveAgentTab));
                // Seitenkarte: VVL -> Ansprachen -> Offene Angebote
                window.rcActiveSideTab = ['vvl','ansp','offers'][window.rcRotState % 3];
                [['rcTabSideVvl','vvl'],['rcTabSideAnsp','ansp'],['rcTabSideOff','offers']].forEach(([id,v]) => document.getElementById(id).classList.toggle('active', v===window.rcActiveSideTab));
                document.getElementById('rcSideTitle').textContent = SIDE_TITLES[window.rcActiveSideTab];
                window.renderAgents(lr.agentsArr);
                renderSide(lr.agentsArr, lr.filterVal);
                if (lr.filterVal !== 'ALL') renderStandorte(lr.teamStats, true); else renderStandorte(lr.standortStats, false);
            }
            if (window.rcActivePage === 'quali' && window.renderQualitaet) {
                window.rcQualiRankMode = ['fq','tnps','pot'][window.rcRotState % 3];
                window.renderQualitaet();
            }
            if (window.rcActivePage === 'radar' && window.renderRadarCharts) window.renderRadarCharts(window.rcRotState);
        } catch(e) { rcLog.warn('Rotation:', e); }
    }, 30000);

    // ============================================================
    //  SMART CAROUSEL + AUTO-SCROLL (Radar-Seitenspalten)
    //  ------------------------------------------------------------
    //  Statt drei kurzer, gestapelter Karten je Seite: EINE hohe Karte,
    //  die alle rcRadarCarouselSec Sekunden weich zwischen ihren Modulen
    //  wechselt (Fade). Der Kartentitel folgt dem sichtbaren Modul; fuer
    //  Module mit dynamischem Titel (Kriegsrat-Standort, Agenten/Teams)
    //  liest rcCarouselSyncTitle das versteckte Titel-Element live nach.
    //  Lange Listen fahren per Ping-Pong-Auto-Scroll komplett durchs Bild
    //  (requestAnimationFrame) — ohne Maus, ideal fuer Wandmonitore.
    //  Aufraeumung: rcRadarCarouselInterval (CLEAN-STATE) + rcAutoScrollRaf.
    // ============================================================
    window.rcRadarCarouselSec = 12;            // Sekunden je Modul-Fenster (justierbar)
    window.rcRadarScrollTargets = new Set();   // aktuell sichtbare Auto-Scroll-Listen

    function rcCarouselSyncTitle(card){
        const idx = card._cidx || 0;
        const pane = card.querySelectorAll('.rc-carousel-pane')[idx];
        const titleEl = card.querySelector('.rc-card-title');
        if (!pane || !titleEl) return;
        let t = pane.getAttribute('data-title') || '';
        const srcId = pane.getAttribute('data-title-src');
        if (srcId){ const s = document.getElementById(srcId); if (s){ const tx = (s.textContent || '').trim(); if (tx) t = tx; } }
        if (t && titleEl.textContent !== t) titleEl.textContent = t;
    }
    window.rcRadarSyncTitles = function(){
        document.querySelectorAll('#rcPageRadarContent .rc-carousel').forEach(rcCarouselSyncTitle);
    };

    // Beim Einblenden eines Moduls: Liste sauber nach oben, frische Verweildauer
    function rcAutoScrollArm(sc){ if (!sc) return; sc.scrollTop = 0; sc._as = null; }

    function rcCarouselShow(card, idx){
        const panes = card.querySelectorAll('.rc-carousel-pane');
        if (!panes.length) return;
        idx = ((idx % panes.length) + panes.length) % panes.length;
        card._cidx = idx;
        panes.forEach((p, i) => {
            const on = i === idx;
            p.classList.toggle('rc-pane-on', on);
            const sc = p.querySelector('.rc-autoscroll');
            if (sc){
                if (on){ rcAutoScrollArm(sc); window.rcRadarScrollTargets.add(sc); }
                else { window.rcRadarScrollTargets.delete(sc); sc._as = null; }
            }
        });
        const dots = card.querySelector('.rc-carousel-dots');
        if (dots) Array.from(dots.children).forEach((d, i) => d.classList.toggle('on', i === idx));
        rcCarouselSyncTitle(card);
    }
    window.rcCarouselShow = rcCarouselShow;

    function rcCarouselAdvance(card, dir){
        const panes = card.querySelectorAll('.rc-carousel-pane');
        if (panes.length < 2){ rcCarouselSyncTitle(card); return; }
        rcCarouselShow(card, (card._cidx || 0) + dir);
    }

    // Ping-Pong-Auto-Scroll: EINE RAF-Schleife bedient alle sichtbaren Listen.
    // Tempo adaptiv je Liste (s.speed, s. unten): der Down-Pass dauert ~halbes
    // Modul-Fenster, damit der Boden (alle Namen) sicher sichtbar wird; die
    // restliche Zeit faehrt die Liste im Ping-Pong wieder nach oben.
    const RC_AS_DWELL_TOP = 2600;   // ms Pause oben (Einblenden lesen lassen)
    const RC_AS_DWELL_BOT = 1600;   // ms Pause unten
    let _rcAsLast = 0, _rcTitleT = 0;
    function rcAutoScrollLoop(ts){
        window.rcAutoScrollRaf = requestAnimationFrame(rcAutoScrollLoop);
        const dt = _rcAsLast ? Math.min(0.05, (ts - _rcAsLast) / 1000) : 0;
        _rcAsLast = ts;
        if (window.rcActivePage !== 'radar') return;
        // Dynamische Titel leichtgewichtig nachziehen (nur Schreiben bei Aenderung)
        if (ts - _rcTitleT > 500){ _rcTitleT = ts; try { window.rcRadarSyncTitles(); } catch(e){} }
        window.rcRadarScrollTargets.forEach(sc => {
            if (!sc.isConnected){ window.rcRadarScrollTargets.delete(sc); return; }
            if (sc.offsetParent === null || sc.clientHeight === 0) return; // Pane ausgeblendet
            let s = sc._as;
            if (!s){
                const max0 = Math.max(0, sc.scrollHeight - sc.clientHeight);
                const winS = Math.max(6, (window.rcRadarCarouselSec || 12));
                const sp = max0 > 0 ? Math.min(90, Math.max(16, max0 / (winS * 0.5))) : 24;
                s = sc._as = { phase:'dwellTop', t: ts, pos: sc.scrollTop || 0, h: sc.scrollHeight, speed: sp };
            }
            // Inhalt neu gerendert (Daten-Update) -> sauber von oben, kein Sprung
            if (sc.scrollHeight !== s.h){
                const winS2 = Math.max(6, (window.rcRadarCarouselSec || 12));
                const mx = Math.max(0, sc.scrollHeight - sc.clientHeight);
                s.h = sc.scrollHeight; s.pos = 0; s.phase = 'dwellTop'; s.t = ts;
                s.speed = mx > 0 ? Math.min(90, Math.max(16, mx / (winS2 * 0.5))) : 24;
                sc.scrollTop = 0; return;
            }
            const max = sc.scrollHeight - sc.clientHeight;
            if (max <= 6){ if (sc.scrollTop) sc.scrollTop = 0; s.phase = 'dwellTop'; s.pos = 0; return; }
            if (s.phase === 'dwellTop'){ if (ts - s.t >= RC_AS_DWELL_TOP) s.phase = 'down'; }
            else if (s.phase === 'down'){ s.pos += (s.speed || 24) * dt; if (s.pos >= max){ s.pos = max; s.phase = 'dwellBot'; s.t = ts; } sc.scrollTop = s.pos; }
            else if (s.phase === 'dwellBot'){ if (ts - s.t >= RC_AS_DWELL_BOT) s.phase = 'up'; }
            else if (s.phase === 'up'){ s.pos -= (s.speed || 24) * dt; if (s.pos <= 0){ s.pos = 0; s.phase = 'dwellTop'; s.t = ts; } sc.scrollTop = s.pos; }
        });
    }

    // (Re-)Aufbau: Dots erzeugen, Modul 0 aktiv, Auto-Scroll-RAF sicherstellen.
    window.rcInitRadarCarousels = function(){
        const cards = document.querySelectorAll('#rcPageRadarContent .rc-carousel');
        window.rcRadarScrollTargets = new Set();
        cards.forEach(card => {
            const panes = card.querySelectorAll('.rc-carousel-pane');
            const dots = card.querySelector('.rc-carousel-dots');
            if (dots) dots.innerHTML = Array.from(panes).map(() => '<i></i>').join('');
            card._cidx = null;
            rcCarouselShow(card, 0);
        });
        if (!window.rcAutoScrollRaf) window.rcAutoScrollRaf = requestAnimationFrame(rcAutoScrollLoop);
        return cards.length;
    };

    // Carousel-Takt: versetzt, damit linke und rechte Spalte NICHT gleichzeitig
    // umblenden (halbe Intervalllaenge -> jede Karte wechselt alle rcRadarCarouselSec s).
    window._rcCarHalf = 0;
    window.rcRadarCarouselInterval = setInterval(() => {
        try {
            const cards = document.querySelectorAll('#rcPageRadarContent .rc-carousel');
            if (!cards.length) return;
            const which = window._rcCarHalf % 2; window._rcCarHalf++;
            cards.forEach((card, i) => { if (i % 2 === which) rcCarouselAdvance(card, +1); });
        } catch(e){ rcLog.warn('Carousel:', e); }
    }, Math.max(4000, (window.rcRadarCarouselSec || 12) * 500));

    // Erstaufbau (Radar-DOM steht bereits im statischen Overlay-HTML).
    try { window.rcInitRadarCarousels(); } catch(e){ rcLog.warn('Carousel-Init:', e); }

    // ============================================================
    //  IN-DASHBOARD KONFIGURATOR (Zahnrad) — bearbeitet ALLE Seiten
    //  ------------------------------------------------------------
    //  Ein Einstell-Panel direkt im Dashboard (Kopfleisten-Zahnrad):
    //    - Anzeige & Rotation (Auto-Wechsel, Seiten, Takt, Zoom)
    //    - Kriegsfeld (alle rcWarHud-Textschalter, Sub-Modifier eingerueckt)
    //    - Module (Arena/Qualitaet/Cockpit): ein-/ausblenden, sortieren, Hoehe
    //    - Eigene Info-Seite: Tipps, Giga-Kombi (Nutzenbruecke), Ansprachen ...
    //    - Sichern: zuruecksetzen, Export/Import (JSON)
    //  Alles greift SOFORT live und wird in localStorage gespeichert.
    //  In-Scope-Refs werden ueber window.__rc* bereitgestellt.
    // ============================================================
    window.__rcPagesRef = RC_PAGES;
    window.__rcSwitchPageFn = switchPage;
    window.__rcOverlayEl = overlay;
    (function rcConfigurator(){
        var CFG_KEY = 'rcCfgLayout_v1';
        function load(){ var c={}; try{ c = JSON.parse(localStorage.getItem(CFG_KEY)||'{}')||{}; }catch(e){}
            c.hidden=c.hidden||{}; c.order=c.order||{}; c.size=c.size||{}; c.titles=c.titles||{};
            c.radarHidden=c.radarHidden||{};
            c.custom=c.custom||{}; ['arena','quali','radar','cockpit','info'].forEach(function(p){ c.custom[p]=c.custom[p]||[]; }); c.pages=c.pages||[]; c.pages.forEach(function(pg){ c.custom['cp_'+pg.id]=c.custom['cp_'+pg.id]||[]; if(pg.cols==null) pg.cols=3; });
            c.info=c.info||{}; c.info.enabled=!!c.info.enabled; c.info.inRotation=!!c.info.inRotation;
            c.info.title=c.info.title||'Info & Verkaufshilfe'; c.info.cols=c.info.cols||3;
            // Migration: altes c.info.modules -> c.custom.info
            if(c.info.modules && c.info.modules.length && !c.custom.info.length){ c.custom.info = c.info.modules.map(function(m){ m.zone='seite'; return m; }); }
            delete c.info.modules;
            return c; }
        var CFG = window.rcCfg = load();
        function save(){ try{ localStorage.setItem(CFG_KEY, JSON.stringify(CFG)); }catch(e){} }
        function uid(){ return 'c'+Math.random().toString(36).slice(2,9); }

        var H = {
            esc:function(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); },
            num:function(n){ n=Number(n)||0; return (Math.round(n*10)/10).toString().replace('.',','); },
            std:function(code){ var M={ADP:'Alexandroupolis',AL:'Alanya',B:'Berlin',E:'Essen',P:'Potsdam',SER:'Serres',ZWT:'Zeitwert',NBB:'Neubrandenburg',SKA:'Sakarya'}; return M[code]||code||''; },
            flag:function(code){ return '<span class="b-flag">'+(code||'?')+'</span>'; },
            empty:function(t){ return '<div class="rc-info-empty">'+t+'</div>'; },
            rows:function(list, fn){ return list.map(fn).join(''); }
        };
        var esc = H.esc;

        // ---------- Datenkontext fuer Live-Module ----------
        function D(){
            var st=window.rcLetzteStats||{}, ag=st.agentStats||{}, tm=st.teamStats||{}, sd=st.standortStats||{};
            var bnt=function(o){ return Number(o.bnt)|| ((Number(o.kip)||0)+(Number(o.mob)||0)+(Number(o.env)||0)+(Number(o.fibDsl)||0)+(Number(o.ptv)||0)+(Number(o.sonstBnt)||0)); };
            var vvl=function(o){ return Number(o.vvl)|| ((Number(o.kipVvl)||0)+(Number(o.mobVvl)||0)+(Number(o.fibVvl)||0)); };
            return {
                agents:Object.keys(ag).map(function(k){ var a=ag[k]; return {name:a.name,standort:a.standort,team:a.team,kip:a.kip||0,mob:a.mob||0,vvl:vvl(a),bnt:bnt(a),ansprachen:a.ansprachen||0,kontakte:(a.kontakte||a.calls||0)}; }),
                teams:Object.keys(tm).map(function(k){ var t=tm[k]; return {name:t.name,code:t.code,standort:t.standort,kip:t.kip||0,mob:t.mob||0,vvl:vvl(t),bnt:bnt(t),calls:t.calls||0}; }),
                standorte:Object.keys(sd).map(function(k){ var s=sd[k]; return {code:s.code||k,kip:s.kip||0,mob:s.mob||0,vvl:vvl(s),bnt:bnt(s),calls:(s.calls||s.pitches||0)}; }),
                kpis:Object.keys(window.rcKpiData||{}).map(function(k){ var x=window.rcKpiData[k]; return {agentName:x.agentName,standort:x.standort,cs:x.cs,tnps:x.tnps,ahtSec:x.ahtSec,callCount:x.callCount,fq:x.fq}; }),
                sum:function(key){ var s=0; Object.keys(ag).forEach(function(k){ s+=Number(ag[k][key])||0; }); return s; },
                now:new Date()
            };
        }

        // ---------- Modultypen (Inhalt + Live) ----------
        function lead(mod,d,key,unit){ var lim=Number(mod.limit)||8;
            var list=(d.agents||[]).filter(function(a){return (Number(a[key])||0)>0;}).sort(function(a,b){return (Number(b[key])||0)-(Number(a[key])||0);}).slice(0,lim);
            if(!list.length) return H.empty('Noch keine '+unit+' — Platz 1 ist frei!');
            return '<ol class="b-rank">'+H.rows(list,function(a,i){ return '<li><span class="b-pos '+(i===0?'gold':'')+'">'+(i+1)+'</span><span class="b-nm">'+H.flag(a.standort)+' '+esc(a.name)+'</span><span class="b-val">'+(Number(a[key])||0)+'</span></li>'; })+'</ol>'; }
        var MOD_TYPES = {
            tipp:{label:'Verkaeufer-Tipp',cat:'Inhalt',acc:'#E60000',def:function(){return {title:'Tipp des Tages',items:['Bedarf zuerst: offene Fragen stellen.','Nutzen vor Preis nennen.']};},
                fields:[['title','Titel','text'],['items','Tipps','list']],
                render:function(m){ var it=(m.items||[]).filter(function(x){return x&&x.trim();}); return it.length? '<ul class="rc-info-check">'+it.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul>':H.empty('Noch keine Tipps.'); }},
            gigakombi:{label:'Giga-Kombi-Angebot',cat:'Inhalt',acc:'#3DD68C',def:function(){return {title:'GigaKombi',produkt:'GigaKombi (Mobilfunk + Festnetz)',preis:'ab 0 EUR Mehrkosten',args:['Bis zu 50% Rabatt auf den Mobilfunk-Tarif','Unbegrenztes Datenvolumen im WLAN zuhause'],bruecke:'Sie nutzen ohnehin Festnetz UND Handy — die Kombi spart bares Geld, ohne Leistungsverzicht.',einwand:'"Zu teuer?" -> Kombi-Rabatt ist meist hoeher als die Differenz.'};},
                fields:[['title','Titel','text'],['produkt','Produkt','text'],['preis','Preis/Aktion','text'],['args','Nutzenargumente','list'],['bruecke','Nutzenbruecke','textarea'],['einwand','Einwand kontern','textarea']],
                render:function(m){ var b='<div class="rc-info-offerhead">'+(m.produkt?'<span class="rc-info-prod">'+esc(m.produkt)+'</span>':'')+(m.preis?'<span class="rc-info-price">'+esc(m.preis)+'</span>':'')+'</div>'; var ar=(m.args||[]).filter(function(x){return x&&x.trim();}); if(ar.length) b+='<ul class="rc-info-args">'+ar.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul>'; if(m.bruecke) b+='<div class="rc-info-bridge"><span class="rc-info-k">Nutzenbruecke</span>'+esc(m.bruecke)+'</div>'; if(m.einwand) b+='<div class="rc-info-obj"><span class="rc-info-k">Einwand kontern</span>'+esc(m.einwand)+'</div>'; return b; }},
            ansprache:{label:'Kunden-Ansprache',cat:'Inhalt',acc:'#57D0E0',def:function(){return {title:'Ansprache: Bestandskunde',situation:'Kunde ruft wegen Rechnung an',script:'Schoen, dass Sie anrufen! Ich sehe, dass fuer Sie ein Vorteil bereitliegt — darf ich das kurz zeigen?',followup:'Bei Zoegern: "Kostet Sie nichts ausser zwei Minuten."'};},
                fields:[['title','Titel','text'],['situation','Situation','text'],['script','Wortlaut','textarea'],['followup','Nachfassen','textarea']],
                render:function(m){ var b=''; if(m.situation) b+='<div class="rc-info-sit">'+esc(m.situation)+'</div>'; if(m.script) b+='<div class="rc-info-quote">&bdquo;'+esc(m.script)+'&ldquo;</div>'; if(m.followup) b+='<div class="rc-info-line"><span class="rc-info-k">Nachfassen</span>'+esc(m.followup)+'</div>'; return b; }},
            incentive:{label:'Incentive',cat:'Inhalt',acc:'#EB9700',def:function(){return {title:'Incentive der Woche',reward:'50 EUR Gutschein',condition:'3 KIP-BNT bis Freitag',subtitle:'Fuer jeden erreichbar!'};},
                fields:[['title','Titel','text'],['reward','Belohnung','text'],['condition','Bedingung','text'],['subtitle','Zusatz','text']],
                render:function(m){ var b=''; if(m.reward) b+='<div class="rc-info-reward">'+esc(m.reward)+'</div>'; if(m.condition) b+='<div class="rc-info-line"><span class="rc-info-k">Bedingung</span>'+esc(m.condition)+'</div>'; if(m.subtitle) b+='<div class="rc-info-sub">'+esc(m.subtitle)+'</div>'; return b; }},
            ziel:{label:'Tagesziel (Live)',cat:'Inhalt',acc:'#3DD68C',def:function(){return {title:'Tagesziel KIP-BNT',label:'KIP-BNT heute',source:'kip',current:0,target:20};},
                fields:[['title','Titel','text'],['label','Beschriftung','text'],['source','Live-Quelle','select:manuell|kip|mob|bnt|vvl|ansprachen'],['current','Ist (bei manuell)','number'],['target','Ziel','number']],
                render:function(m,d){ var cur=Number(m.current)||0; if((m.source||'manuell')!=='manuell') cur=d.sum(m.source); var tgt=Number(m.target)||0,fr=tgt>0?Math.min(1,cur/tgt):0; var col=fr>=1?'#3DD68C':(fr>=0.6?'#EB9700':'#E60000'); return '<div class="rc-info-goalnum"><b style="color:'+col+'">'+cur+'</b><span> / '+tgt+'</span></div><div class="rc-info-bar"><i style="width:'+(fr*100).toFixed(1)+'%; background:'+col+';"></i></div><div class="rc-info-sub">'+esc(m.label||'')+(tgt>0?' — '+Math.round(fr*100)+'% erreicht':'')+'</div>'; }},
            countdown:{label:'Countdown',cat:'Inhalt',acc:'#E60000',def:function(){return {title:'Countdown',target:'',subtitle:'bis Schichtende'};},
                fields:[['title','Titel','text'],['target','Zielzeitpunkt','datetime'],['subtitle','Untertitel','text']],
                render:function(m,d){ if(!m.target) return H.empty('Zielzeitpunkt setzen.'); var ms=new Date(m.target).getTime()-d.now.getTime(); var s=Math.max(0,Math.floor(ms/1000)),dd=Math.floor(s/86400);s-=dd*86400;var hh=Math.floor(s/3600);s-=hh*3600;var mm=Math.floor(s/60),ss=s-mm*60,p=function(n){return (n<10?'0':'')+n;}; return '<div class="rc-info-bigcount'+(ms<0?' over':'')+'">'+(ms<0?'ZEIT ABGELAUFEN':(dd>0?dd+'T ':'')+p(hh)+':'+p(mm)+':'+p(ss))+'</div>'+(m.subtitle?'<div class="rc-info-sub" style="text-align:center;">'+esc(m.subtitle)+'</div>':''); }},
            text:{label:'Ankuendigung / Freitext',cat:'Inhalt',acc:'#E60000',def:function(){return {title:'Ankuendigung',body:'Wichtige Info fuer das Team.'};},
                fields:[['title','Titel','text'],['body','Text','textarea']],
                render:function(m){ return m.body? '<div class="rc-info-text">'+esc(m.body).replace(/\n/g,'<br>')+'</div>':H.empty('Text eintragen.'); }},
            live_kip:{label:'KIP-BNT Rangliste',cat:'Live',acc:'#57D0E0',def:function(){return {title:'KIP-BNT Verkaeufer',limit:8};},fields:[['title','Titel','text'],['limit','Plaetze','number']],render:function(m,d){ return lead(m,d,'kip','KIP-BNT'); }},
            live_mob:{label:'Mobilfunk-BNT Rangliste',cat:'Live',acc:'#57D0E0',def:function(){return {title:'Mobilfunk-BNT Verkaeufer',limit:8};},fields:[['title','Titel','text'],['limit','Plaetze','number']],render:function(m,d){ return lead(m,d,'mob','Mobilfunk-BNT'); }},
            live_bnt:{label:'BNT gesamt Rangliste',cat:'Live',acc:'#57D0E0',def:function(){return {title:'BNT gesamt',limit:8};},fields:[['title','Titel','text'],['limit','Plaetze','number']],render:function(m,d){ return lead(m,d,'bnt','BNT'); }},
            live_vvl:{label:'VVL Rangliste',cat:'Live',acc:'#57D0E0',def:function(){return {title:'VVL Verkaeufer',limit:8};},fields:[['title','Titel','text'],['limit','Plaetze','number']],render:function(m,d){ return lead(m,d,'vvl','VVL'); }},
            live_zero:{label:'Stille Kanonen (0 Premium)',cat:'Live',acc:'#57D0E0',def:function(){return {title:'Noch ohne Premium-BNT',limit:8};},fields:[['title','Titel','text'],['limit','Anzahl','number']],
                render:function(m,d){ var list=(d.agents||[]).filter(function(a){return (Number(a.kip)||0)===0&&(Number(a.mob)||0)===0&&((Number(a.ansprachen)||0)>0||(Number(a.kontakte)||0)>0);}).sort(function(a,b){return (Number(b.ansprachen)||0)-(Number(a.ansprachen)||0);}).slice(0,Number(m.limit)||8); if(!list.length) return H.empty('Alle aktiven Agenten haben Premium!'); return '<ul class="b-list">'+H.rows(list,function(a){ return '<li class="warn"><span class="b-nm">'+H.flag(a.standort)+' '+esc(a.name)+'</span><span class="b-meta">'+(Number(a.ansprachen)||0)+' Anspr</span><span class="b-tagr">0 KIP/MOB</span></li>'; })+'</ul>'; }},
            live_kpi:{label:'Qualitaet / KPI (Ligaliste)',cat:'Live',acc:'#57D0E0',def:function(){return {title:'Qualitaet — CS',metric:'cs',limit:8};},fields:[['title','Titel','text'],['metric','Kennzahl','select:cs|tnps|fq|calls|aht'],['limit','Plaetze','number']],
                render:function(m,d){ var met=m.metric||'cs'; var hi=met!=='aht'; var get=function(k){ if(met==='calls')return Number(k.callCount)||0; if(met==='aht')return Number(k.ahtSec)||0; return Number(k[met])||0; }; var list=(d.kpis||[]).filter(function(k){return (Number(k.callCount)||0)>0;}); list.sort(function(a,b){return hi?get(b)-get(a):get(a)-get(b);}); list=list.slice(0,Number(m.limit)||8); if(!list.length) return H.empty('Keine KPI-Quelle (Ligaliste).'); var fmt=function(v){ if(met==='aht'){var mm=Math.floor(v/60),ss=Math.round(v%60);return mm+':'+(ss<10?'0':'')+ss;} return H.num(v)+((met==='cs'||met==='fq')?'%':''); }; return '<ol class="b-rank">'+H.rows(list,function(k,i){ return '<li><span class="b-pos '+(i===0?'gold':'')+'">'+(i+1)+'</span><span class="b-nm">'+H.flag(k.standort)+' '+esc(k.agentName||'?')+'</span><span class="b-val">'+fmt(get(k))+'</span></li>'; })+'</ol>'; }},
            live_teams:{label:'Team-Vergleich',cat:'Live',acc:'#57D0E0',def:function(){return {title:'Team-Vergleich',limit:10};},fields:[['title','Titel','text'],['limit','Anzahl','number']],
                render:function(m,d){ var list=(d.teams||[]).slice().sort(function(a,b){return ((Number(b.kip)||0)+(Number(b.mob)||0))-((Number(a.kip)||0)+(Number(a.mob)||0));}).slice(0,Number(m.limit)||10); if(!list.length) return H.empty('Keine Team-Daten.'); return '<table class="b-table"><thead><tr><th>Team</th><th>KIP</th><th>MOB</th><th>VVL</th><th>Calls</th></tr></thead><tbody>'+H.rows(list,function(t){return '<tr><td>'+H.flag(t.standort)+' '+esc(t.name)+'</td><td>'+(Number(t.kip)||0)+'</td><td>'+(Number(t.mob)||0)+'</td><td>'+(Number(t.vvl)||0)+'</td><td>'+(Number(t.calls)||0)+'</td></tr>';})+'</tbody></table>'; }},
            live_standorte:{label:'Standort-Vergleich',cat:'Live',acc:'#57D0E0',def:function(){return {title:'Standort-Vergleich',limit:12};},fields:[['title','Titel','text'],['limit','Anzahl','number']],
                render:function(m,d){ var list=(d.standorte||[]).slice().sort(function(a,b){return ((Number(b.kip)||0)+(Number(b.mob)||0))-((Number(a.kip)||0)+(Number(a.mob)||0));}); if(!list.length) return H.empty('Keine Standort-Daten.'); return '<table class="b-table"><thead><tr><th>Standort</th><th>KIP</th><th>MOB</th><th>VVL</th><th>Calls</th></tr></thead><tbody>'+H.rows(list,function(s){return '<tr><td>'+H.flag(s.code)+' '+esc(H.std(s.code))+'</td><td>'+(Number(s.kip)||0)+'</td><td>'+(Number(s.mob)||0)+'</td><td>'+(Number(s.vvl)||0)+'</td><td>'+(Number(s.calls)||0)+'</td></tr>';})+'</tbody></table>'; }},
            // ---- Croco (Auftrags-Backend): offene/stornierte Auftraege + ESL-Abgleich ----
            croco_open:{label:'Croco: Offene Auftraege',cat:'Live',acc:'#0090B0',def:function(){return {title:'Offene Auftraege',limit:10};},fields:[['title','Titel','text'],['limit','Standorte','number']],
                render:function(m){ var cv=window.rcCrocoView?window.rcCrocoView():null; if(!cv||!cv.ready) return H.empty('Croco-Daten laden — Kopfleiste "Croco".'); var list=Object.keys(cv.byStd||{}).map(function(k){var s=cv.byStd[k];return {code:k,offen:s.offen||0,ueber:s.ueberfaellig||0};}).filter(function(s){return s.offen>0;}).sort(function(a,b){return b.offen-a.offen;}).slice(0,Number(m.limit)||10); var head='<div class="rc-info-goalnum"><b style="color:#0090B0">'+cv.offen+'</b><span> offen · '+cv.ueberfaellig+' &gt;7&nbsp;Tage</span></div>'; if(!list.length) return head+H.empty('Keine offenen Auftraege im Filter.'); return head+'<table class="b-table"><thead><tr><th>Standort</th><th>Offen</th><th>&gt;7 T</th></tr></thead><tbody>'+H.rows(list,function(s){return '<tr><td>'+H.flag(s.code)+' '+esc(H.std(s.code))+'</td><td>'+s.offen+'</td><td>'+(s.ueber?'<b style="color:#E60000">'+s.ueber+'</b>':'0')+'</td></tr>';})+'</tbody></table>'; }},
            croco_overdue:{label:'Croco: Ueberfaellig (&gt;7 Tage)',cat:'Live',acc:'#E60000',def:function(){return {title:'Ueberfaellige Auftraege',limit:10};},fields:[['title','Titel','text'],['limit','Plaetze','number']],
                render:function(m){ var cv=window.rcCrocoView?window.rcCrocoView():null; if(!cv||!cv.ready) return H.empty('Croco-Daten laden — Kopfleiste "Croco".'); var list=(cv.overdue||[]).slice(0,Number(m.limit)||10); if(!list.length) return H.empty('Kein Auftrag laenger als 7 Tage offen. Sauber!'); return '<ul class="b-list">'+H.rows(list,function(o){var crit=o.ageDays>=14; return '<li'+(crit?' class="warn"':'')+'><span class="b-nm">'+H.flag(o.standort)+' '+esc(o.auftrag||o.vo||'?')+(o.agent?' &middot; '+esc(o.agent):'')+'</span><span class="b-meta">'+esc(o.produkt||o.kunde||'')+'</span><span class="b-tagr" style="color:'+(crit?'#E60000':'#EB9700')+'">'+o.ageDays+' Tage</span></li>';})+'</ul>'; }},
            croco_storno:{label:'Croco: Stornoquote',cat:'Live',acc:'#8F5C00',def:function(){return {title:'Stornoquote',limit:8};},fields:[['title','Titel','text'],['limit','Storno-Liste','number']],
                render:function(m){ var cv=window.rcCrocoView?window.rcCrocoView():null; if(!cv||!cv.ready) return H.empty('Croco-Daten laden — Kopfleiste "Croco".'); var q=cv.stornoquote||0; var col=q<=5?'#008A00':(q<=12?'#EB9700':'#E60000'); var head='<div class="rc-info-goalnum"><b style="color:'+col+'">'+H.num(q)+'%</b><span> Storno &middot; '+cv.storno+' von '+(cv.storno+cv.erledigt)+' final</span></div>'; var list=(cv.stornoList||[]).slice(0,Number(m.limit)||8); if(!list.length) return head+H.empty('Keine Stornos im Filter.'); return head+'<ul class="b-list">'+H.rows(list,function(o){return '<li class="warn"><span class="b-nm">'+H.flag(o.standort)+' '+esc(o.auftrag||o.vo||'?')+(o.agent?' &middot; '+esc(o.agent):'')+'</span><span class="b-meta">'+esc(o.stornogrund||o.produkt||'')+'</span></li>';})+'</ul>'; }},
            croco_recon:{label:'Croco &times; ESL: Storno trotz Verkauf',cat:'Live',acc:'#A32EA8',def:function(){return {title:'Storno trotz ESL-Verkauf',limit:10};},fields:[['title','Titel','text'],['limit','Plaetze','number']],
                render:function(m){ var cv=window.rcCrocoView?window.rcCrocoView():null; if(!cv||!cv.ready) return H.empty('Croco-Daten laden — Kopfleiste "Croco".'); var r=cv.recon||{}; var list=(r.stornoTrotzEsl||[]).slice(0,Number(m.limit)||10); var head='<div class="rc-info-goalnum"><b style="color:'+(list.length?'#E60000':'#008A00')+'">'+(r.stornoTrotzEsl?r.stornoTrotzEsl.length:0)+'</b><span> im ESL gebucht, in Croco storniert</span></div>'; if(!list.length) return head+H.empty('Kein Widerspruch ESL/Croco gefunden.'); return head+'<ul class="b-list">'+H.rows(list,function(o){return '<li class="warn"><span class="b-nm">'+H.flag(o.standort)+' '+esc(o.agent||'?')+'</span><span class="b-meta">VO '+esc(o.vo||'')+' &middot; '+esc(o.produkt||'')+'</span><span class="b-tagr" style="color:#E60000">STORNO</span></li>';})+'</ul>'; }}
        };
        function renderModBody(mod){ var T=MOD_TYPES[mod.type]; if(!T) return ''; try{ return T.render(mod, D(), H); }catch(e){ return '<div class="rc-info-empty">'+esc(e.message)+'</div>'; } }

        // ---------- Native Module (Arena/Quali/Cockpit) ----------
        var PAGES=[['arena','Arena','rcPageArenaContent'],['quali','Qualitaet','rcPageQualiContent'],['cockpit','Cockpit','rcPageCockpitContent']];
        function slug(s){ return (s||'').toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,44); }
        function keyOf(card,page,i){ if(card.dataset.rcCfgkey) return card.dataset.rcCfgkey; var t=card.querySelector('.rc-card-title'); var base=(t&&t.id)?t.id:(t&&t.textContent.trim()?slug(t.textContent):('card'+i)); var k=page+':'+base; card.dataset.rcCfgkey=k; return k; }
        function discover(page,contentId){ var root=document.getElementById(contentId); if(!root) return []; var cards=Array.prototype.slice.call(root.querySelectorAll('.rc-card')).filter(function(c){ if(c.hasAttribute('data-rc-cust')||c.classList.contains('rc-carousel')) return false; var p=c.parentElement; return !(p&&p.closest&&p.closest('.rc-card')); }); return cards.map(function(c,i){ var k=keyOf(c,page,i); var t=c.querySelector('.rc-card-title'); return {key:k,el:c,label:(t?t.textContent.trim():k)}; }); }
        function applyLayout(){ PAGES.forEach(function(pd){ var list=discover(pd[0],pd[2]); if(!list.length) return; var order=CFG.order[pd[0]]; if(order&&order.length){ var seen=[]; list.forEach(function(m){ if(seen.indexOf(m.el.parentElement)<0) seen.push(m.el.parentElement); }); seen.forEach(function(parent){ list.filter(function(m){return m.el.parentElement===parent;}).sort(function(a,b){ var ia=order.indexOf(a.key),ib=order.indexOf(b.key); return (ia<0?999:ia)-(ib<0?999:ib); }).forEach(function(m){ parent.appendChild(m.el); }); }); } list.forEach(function(m){ m.el.classList.toggle('rc-cfg-hidden', !!CFG.hidden[m.key]); var sz=CFG.size[m.key]; if(sz){ m.el.style.flexGrow=String(sz); } var tt=m.el.querySelector('.rc-card-title'); if(tt){ var ov=CFG.titles[m.key]; if(ov!=null&&ov!==''){ if(tt._rcOrig==null) tt._rcOrig=tt.textContent; if(tt.textContent!==ov) tt.textContent=ov; tt._rcOverridden=true; } else if(tt._rcOverridden){ if(tt._rcOrig!=null&&tt.textContent!==tt._rcOrig) tt.textContent=tt._rcOrig; tt._rcOverridden=false; tt._rcOrig=null; } } }); }); }
        window.rcApplyLayout=applyLayout;

        // ---------- Radar-Panes (native) ----------
        function radarStash(){ var s=document.getElementById('rcCfgPaneStash'); if(!s){ s=document.createElement('div'); s.id='rcCfgPaneStash'; s.style.display='none'; document.body.appendChild(s); } return s; }
        function radarPanes(){ var out=[]; var cars=document.querySelectorAll('#rcPageRadarContent .rc-carousel'); Array.prototype.forEach.call(cars,function(car,ci){ var body=car.querySelector('.rc-carousel-body'); if(!body) return; car.setAttribute('data-rc-car',ci); var panes=[].slice.call(body.querySelectorAll('.rc-carousel-pane')).concat([].slice.call(radarStash().querySelectorAll('.rc-carousel-pane[data-rc-car="'+ci+'"]'))); panes.forEach(function(pane){ if(pane.hasAttribute('data-rc-cust')) return; var sc=pane.querySelector('.rc-scroll'); var key='radarpane:'+(sc&&sc.id?sc.id:(pane.getAttribute('data-title')||ci)); pane.setAttribute('data-rc-panekey',key); if(!pane.hasAttribute('data-rc-car')) pane.setAttribute('data-rc-car',ci); var lbl=pane.getAttribute('data-title')||''; if(!lbl){ var src=pane.getAttribute('data-title-src'); var te=src?document.getElementById(src):null; lbl=te?te.textContent.trim():key; } out.push({key:key,el:pane,car:ci,body:body,label:lbl}); }); }); return out; }
        function applyRadar(){ reconcileRadar(); }

        // ---------- Custom-Module (reconcile: selbstheilend, ohne Flackern) ----------
        function userPageDef(page){ return (CFG.pages||[]).filter(function(x){return 'cp_'+x.id===page;})[0]; }
        function pageCols(page){ if(page==='info') return CFG.info.cols||3; if(page.indexOf('cp_')===0){ var pg=userPageDef(page); return (pg&&pg.cols)||3; } return 3; }
        function zonesFor(page){ if(page==='arena') return [['links','Links'],['mitte','Mitte'],['rechts','Rechts']]; if(page==='radar') return [['links','Linke Spalte'],['rechts','Rechte Spalte']]; if(page==='info'||page.indexOf('cp_')===0) return [['seite','Seite']]; return [['ende','Unten']]; }
        function zoneContainer(page,zone){ if(page==='arena'){ var cols=document.querySelectorAll('#rcPageArenaContent > .rc-col'); return ({links:cols[0],mitte:cols[1],rechts:cols[2]})[zone]||cols[0]; } if(page==='radar'){ var b=document.querySelectorAll('#rcPageRadarContent .rc-carousel-body'); return ({links:b[0],rechts:b[1]})[zone]||b[0]; } if(page==='quali') return document.getElementById('rcPageQualiContent'); if(page==='cockpit') return document.querySelector('#rcPageCockpitContent .rc-ck-body')||document.getElementById('rcPageCockpitContent'); if(page.indexOf('cp_')===0) return document.getElementById('rcPageCustom_'+page.slice(3)); if(page==='info') return document.getElementById('rcPageInfoContent'); }
        function makeCustomEl(page,mod){ var T=MOD_TYPES[mod.type]; var el; if(page==='radar'){ el=document.createElement('div'); el.className='rc-carousel-pane'; el.setAttribute('data-title', mod.title||(T?T.label:'')); el.innerHTML='<div class="rc-scroll rc-autoscroll rc-cust-body" style="flex:1;"></div>'; } else { el=document.createElement('div'); el.className='rc-card rc-cfg-custom'; el.style.borderTop='3px solid '+(T?T.acc:'#E60000'); el.style.minHeight='120px'; if(page==='arena') el.style.flex='1 1 auto'; if(page==='info'||page.indexOf('cp_')===0){ var span=Math.min(pageCols(page), mod.w||1); el.style.gridColumn='span '+span; } el.innerHTML='<div class="rc-card-header"><h2 class="rc-card-title">'+esc(mod.title||(T?T.label:''))+'</h2></div><div class="rc-scroll rc-autoscroll rc-cust-body" style="flex:1;"></div>'; } el.setAttribute('data-rc-cust',mod.id); el.setAttribute('data-rc-custpage',page); return el; }
        function isLiveType(t){ return /^live_/.test(t)||/^croco_/.test(t)||t==='ziel'||t==='countdown'; }
        function updateCustomEl(el,page,mod){ var T=MOD_TYPES[mod.type]; var sig=JSON.stringify(mod); var body=el.querySelector('.rc-cust-body');
            if(el._sig!==sig){ el._sig=sig; var tt=el.querySelector('.rc-card-title'); if(tt) tt.textContent=mod.title||(T?T.label:''); if(el.classList.contains('rc-carousel-pane')) el.setAttribute('data-title', mod.title||(T?T.label:'')); if(page==='info') el.style.gridColumn='span '+Math.min(CFG.info.cols||3, mod.w||1); if(body){ body.innerHTML=renderModBody(mod); el._dataRef=window.rcLetzteStats; } }
            else if(isLiveType(mod.type) && body && (el._dataRef!==window.rcLetzteStats || el._crocoRef!==window.rcCrocoTok)){ el._dataRef=window.rcLetzteStats; el._crocoRef=window.rcCrocoTok; body.innerHTML=renderModBody(mod); } }
        function enforceOrder(page,list){ var byCont=new Map(); list.forEach(function(mod){ var el=document.querySelector('[data-rc-cust="'+mod.id+'"][data-rc-custpage="'+page+'"]'); if(!el||!el.parentElement) return; var arr=byCont.get(el.parentElement); if(!arr){ arr=[]; byCont.set(el.parentElement,arr); } arr.push(el); }); byCont.forEach(function(els,cont){ var cur=Array.prototype.filter.call(cont.children,function(c){ return c.hasAttribute('data-rc-cust'); }); var same=cur.length===els.length && cur.every(function(c,i){ return c===els[i]; }); if(!same){ els.forEach(function(el){ cont.appendChild(el); }); } }); }
        function reconcileCustom(page){
            var list=CFG.custom[page]||[]; var want={}; list.forEach(function(m){ want[m.id]=1; });
            Array.prototype.forEach.call(document.querySelectorAll('[data-rc-custpage="'+page+'"]'),function(e){ if(!want[e.getAttribute('data-rc-cust')]) e.remove(); });
            if(page==='info'||page.indexOf('cp_')===0){ var host=(page==='info')?document.getElementById('rcPageInfoContent'):document.getElementById('rcPageCustom_'+page.slice(3)); if(host){ host.style.gridTemplateColumns='repeat('+pageCols(page)+',1fr)'; var em=host.querySelector('.rc-cfg-infoempty'); if(list.length){ if(em) em.remove(); } else if(!em){ host.innerHTML='<div class="rc-cfg-infoempty" style="margin:auto; color:#9C9C9C; text-align:center; font-size:14px;">Noch keine Inhalte.<br>Zahnrad &rarr; Module &rarr; Modul hinzufuegen.</div>'; } } if(page==='info'){ var pb=document.getElementById('rcPageInfo'); if(pb) pb.style.display=(CFG.info.enabled||list.length)?'':'none'; } }
            list.forEach(function(mod){ var el=document.querySelector('[data-rc-cust="'+mod.id+'"][data-rc-custpage="'+page+'"]'); var cont=zoneContainer(page, mod.zone||zonesFor(page)[0][0]); if(!cont) return; if(!el){ el=makeCustomEl(page,mod); cont.appendChild(el); } else if(el.parentElement!==cont){ cont.appendChild(el); } updateCustomEl(el,page,mod); });
            enforceOrder(page,list);
        }
        function reconcileRadar(){ if(!document.querySelector('#rcPageRadarContent .rc-carousel')) return;
            var stash=radarStash();
            radarPanes().forEach(function(p){ var hide=!!CFG.radarHidden[p.key]; if(hide){ if(p.el.parentElement!==stash) stash.appendChild(p.el); } else { if(p.el.parentElement===stash) p.body.appendChild(p.el); } });
            var list=CFG.custom.radar||[]; var want={}; list.forEach(function(m){ want[m.id]=1; });
            Array.prototype.forEach.call(document.querySelectorAll('[data-rc-custpage="radar"]'),function(e){ if(!want[e.getAttribute('data-rc-cust')]) e.remove(); });
            list.forEach(function(mod){ var el=document.querySelector('[data-rc-cust="'+mod.id+'"][data-rc-custpage="radar"]'); var cont=zoneContainer('radar', mod.zone||'links'); if(!cont) return; if(!el){ el=makeCustomEl('radar',mod); cont.appendChild(el); } else if(el.parentElement!==cont){ cont.appendChild(el); } updateCustomEl(el,'radar',mod); });
            var sig=''; Array.prototype.forEach.call(document.querySelectorAll('#rcPageRadarContent .rc-carousel-body'),function(bd,ci){ sig+='|'+ci+':'+Array.prototype.map.call(bd.children,function(c){ return c.getAttribute('data-rc-cust')||c.getAttribute('data-rc-panekey')||''; }).join(','); });
            if(sig!==window._rcRadarSig){ window._rcRadarSig=sig; if(window.rcInitRadarCarousels) window.rcInitRadarCarousels(); }
        }
        function applyCustomStructure(page){ if(page==='radar') reconcileRadar(); else reconcileCustom(page); }
        function refreshCustomBodies(page){ if(page==='radar') reconcileRadar(); else reconcileCustom(page); }
        function applyAllCustom(){ ['arena','quali','cockpit','info'].forEach(reconcileCustom); reconcileRadar(); }
        window.rcRenderInfo=function(){ reconcileCustom('info'); };
        // Selbstheilung: Layout + eigene Module + Radar in einem Rutsch durchsetzen.
        function reconcileAll(){ try{ ensureInfoPage(); }catch(e){} try{ ensureCustomPages(); }catch(e){} try{ applyLayout(); }catch(e){} try{ ['arena','quali','cockpit','info'].forEach(reconcileCustom); }catch(e){} try{ (CFG.pages||[]).forEach(function(pg){ reconcileCustom('cp_'+pg.id); }); }catch(e){} try{ reconcileRadar(); }catch(e){} }
        window.rcReconcile=reconcileAll;

        function ensureInfoPage(){ var ov=window.__rcOverlayEl; if(!ov) return; if(!document.getElementById('rcPageInfoContent')){ var el=document.createElement('div'); el.id='rcPageInfoContent'; el.className='rc-info-page'; el.style.display='none'; var mq=ov.querySelector('.rc-marquee'); if(mq) ov.insertBefore(el,mq); else ov.appendChild(el); } var sw=ov.querySelector('.rc-pageswitch'); if(sw && !document.getElementById('rcPageInfo')){ var btn=document.createElement('button'); btn.className='rc-page-btn'; btn.id='rcPageInfo'; btn.setAttribute('data-page','info'); btn.textContent='Info'; btn.addEventListener('click',function(){ window.__rcSwitchPageFn('info'); }); sw.appendChild(btn); } window.__rcPagesRef.info=['rcPageInfo','rcPageInfoContent','grid']; var rp=window.rcAutoRotPages; if(rp){ var idx=rp.indexOf('info'); if(CFG.info.enabled&&CFG.info.inRotation){ if(idx<0) rp.push('info'); } else if(idx>=0) rp.splice(idx,1); } }
        function ensureCustomPages(){ var ov=window.__rcOverlayEl; if(!ov) return; var sw=ov.querySelector('.rc-pageswitch'); var mq=ov.querySelector('.rc-marquee'); var want={};
            (CFG.pages||[]).forEach(function(pg){ var k='cp_'+pg.id; want[k]=1; var cid='rcPageCustom_'+pg.id, bid='rcPageBtnCustom_'+pg.id;
                var cont=document.getElementById(cid); if(!cont){ cont=document.createElement('div'); cont.id=cid; cont.className='rc-info-page'; cont.style.display='none'; if(mq) ov.insertBefore(cont,mq); else ov.appendChild(cont); }
                var btn=document.getElementById(bid); if(!btn){ btn=document.createElement('button'); btn.className='rc-page-btn'; btn.id=bid; btn.textContent=pg.name||'Seite'; btn.addEventListener('click',(function(kk){ return function(){ window.__rcSwitchPageFn(kk); }; })(k)); if(sw) sw.appendChild(btn); } else { btn.textContent=pg.name||'Seite'; }
                window.__rcPagesRef[k]=[bid,cid,'grid']; var rp2=window.rcAutoRotPages; if(rp2){ var i=rp2.indexOf(k); if(pg.inRotation){ if(i<0) rp2.push(k); } else if(i>=0) rp2.splice(i,1); } });
            Object.keys(window.__rcPagesRef).forEach(function(k){ if(k.indexOf('cp_')===0 && !want[k]){ var id=k.slice(3); var b=document.getElementById('rcPageBtnCustom_'+id); if(b) b.remove(); var c=document.getElementById('rcPageCustom_'+id); if(c) c.remove(); delete window.__rcPagesRef[k]; var rp3=window.rcAutoRotPages; if(rp3){ var i=rp3.indexOf(k); if(i>=0) rp3.splice(i,1); } if(window.rcActivePage===k && window.__rcSwitchPageFn) window.__rcSwitchPageFn('arena'); } });
        }

        // ---------- Panel ----------
        var panel=document.createElement('div'); panel.id='rcCfgPanel';
        panel.innerHTML='<div class="rc-cfg-head"><b>Konfigurator</b><span style="flex:1"></span><button class="rc-cfg-x" id="rcCfgClose">&#10005;</button></div><div class="rc-cfg-tabs" id="rcCfgTabs"></div><div class="rc-cfg-body" id="rcCfgBody"></div>';
        document.body.appendChild(panel);
        var backdrop=document.createElement('div'); backdrop.id='rcCfgBackdrop'; document.body.appendChild(backdrop);
        var TABS=[['anzeige','Anzeige'],['krieg','Kriegsfeld'],['module','Module'],['report','Report'],['sichern','Sichern']];
        var curTab='module', curPage='arena';
        function q(id){ return document.getElementById(id); }
        function on(el,ev,fn){ if(el) el.addEventListener(ev,fn); }
        function openPanel(){ panel.classList.add('on'); backdrop.classList.add('on'); renderTabs(); renderBody(); }
        function closePanel(){ panel.classList.remove('on'); backdrop.classList.remove('on'); }
        function renderTabs(){ q('rcCfgTabs').innerHTML=TABS.map(function(t){ return '<button class="rc-cfg-tab'+(t[0]===curTab?' on':'')+'" data-tab="'+t[0]+'">'+t[1]+'</button>'; }).join(''); }
        function rowr(label,ctrl,hint){ return '<div class="rc-cfg-row"><div class="rc-cfg-rl">'+label+(hint?'<span class="rc-cfg-hint">'+hint+'</span>':'')+'</div><div class="rc-cfg-rc">'+ctrl+'</div></div>'; }
        function swc(id,onv){ return '<label class="rc-sw"><input type="checkbox" id="'+id+'" '+(onv?'checked':'')+'><span></span></label>'; }

        function renderBody(){ var b=q('rcCfgBody'); var h='';
            if(curTab==='anzeige'){
                h+='<div class="rc-cfg-sec">Auto-Wechsel (Wandmonitor)</div>';
                h+=rowr('Auto-Wechsel aktiv', swc('cfgAuto', window.rcAutoRot));
                h+=rowr('Takt Seitenwechsel','<input type="number" id="cfgRotSec" class="rc-cfg-num" min="10" max="600" value="'+(window.rcAutoRotSec||60)+'"> s');
                h+='<div class="rc-cfg-sub2">Seiten in der Rotation</div>';
                [['arena','Arena'],['quali','Qualitaet'],['radar','Radar'],['cockpit','Cockpit'],['info','Info-Seite']].forEach(function(p){ h+=rowr(p[1], swc('cfgRot_'+p[0],(window.rcAutoRotPages||[]).indexOf(p[0])>=0)); });
                h+='<div class="rc-cfg-sec">Info-Seite</div>';
                h+=rowr('Info-Seite als Reiter zeigen', swc('cfgInfoOn', CFG.info.enabled));
                h+='<div class="rc-cfg-sec">Radar-Seitenspalten</div>';
                h+=rowr('Takt Modul-Carousel','<input type="number" id="cfgCarSec" class="rc-cfg-num" min="4" max="60" value="'+(window.rcRadarCarouselSec||12)+'"> s');
                h+='<div class="rc-cfg-sec">Fernsicht</div>';
                h+=rowr('Zoom','<button class="rc-cfg-mini" id="cfgZoomM">&minus;</button> <span id="cfgZoomV">'+Math.round((window.rcZoom||1)*100)+'%</span> <button class="rc-cfg-mini" id="cfgZoomP">+</button>');
            } else if(curTab==='krieg'){
                h+='<div class="rc-cfg-note">Weniger Text auf dem Kriegsfeld = mehr Burgen und Krieger sichtbar. Schalter wirken sofort.</div>';
                var HUD=[['chronik','Chronik (oben links)',0],['tageswertung','Tageswertung (oben rechts)',0],['fortschritt','Fortschrittsbalken (oben)',0],['heroRuf','Helden-Ruf-Banner (Mitte)',0],['heroKompakt','&#8627; kompakt + kurz einblenden',1],['lagebericht','Lagebericht (unten)',0],['aufstiegsLegende','"So steigst du auf"-Legende',0],['tagesziel','"Dein Tagesziel"-Leiste',0],['burgLabels','Burg-Beschriftung',0],['burgKompakt','&#8627; nur Name + Platz + Punkte',1],['einheitenLabels','Einheiten-Namen ueber Truppen',0],['stundenDuell','Stunden-Duell-Anzeige',0],['aufholjagd','Aufholjagd-Hinweis',0]];
                HUD.forEach(function(f){ var onv=!!(window.rcWarHud&&window.rcWarHud[f[0]]); h+='<div class="rc-cfg-row'+(f[2]?' sub':'')+'"><div class="rc-cfg-rl">'+f[1]+'</div><div class="rc-cfg-rc">'+swc('cfgHud_'+f[0],onv)+'</div></div>'; });
                h+=rowr('Standard wiederherstellen','<button class="rc-cfg-btn" id="cfgHudReset">Preset "sauber"</button>');
            } else if(curTab==='module'){
                h+='<div class="rc-cfg-note">Waehle eine Seite. Bestehende Kacheln ein-/ausblenden und sortieren — und eigene Module hinzufuegen (Inhalt oder Live-Daten).</div>';
                var pgList=[['arena','Arena'],['quali','Qualitaet'],['radar','Radar'],['cockpit','Cockpit'],['info','Info-Seite']].concat((CFG.pages||[]).map(function(pg){ return ['cp_'+pg.id, pg.name||'Seite']; }));
                h+='<div class="rc-cfg-pagesel">'+pgList.map(function(p){ return '<button class="rc-cfg-pg'+(p[0]===curPage?' on':'')+'" data-pg="'+p[0]+'">'+esc(p[1])+'</button>'; }).join('')+'<button class="rc-cfg-pg" id="cfgAddPage" style="border-style:dashed; color:var(--vf-red-soft);">+ Neue Seite</button></div>';
                if(curPage.indexOf('cp_')===0){ var _pg=userPageDef(curPage)||{}; h+=rowr('Seitenname','<input type="text" id="cfgPgName" class="rc-cfg-txt" style="width:150px;" value="'+esc(_pg.name||'')+'">'); h+=rowr('Spalten','<input type="number" id="cfgPgCols" class="rc-cfg-num" min="1" max="6" value="'+(_pg.cols||3)+'">'); h+=rowr('In Rotation', swc('cfgPgRot', _pg.inRotation)); h+=rowr('Seite loeschen','<button class="rc-cfg-btn danger" id="cfgPgDel">Loeschen</button>'); }
                // Native Module (nur echte Seiten; Info/eigene Seiten haben keine)
                if(curPage==='arena'||curPage==='quali'||curPage==='cockpit'||curPage==='radar'){
                h+='<div class="rc-cfg-sec">Bestehende Kacheln</div>';
                if(curPage==='radar'){ var panes=radarPanes(); if(!panes.length) h+='<div class="rc-cfg-hint" style="padding:4px 2px;">Radar-Seite oeffnen, damit die Module erkannt werden.</div>'; panes.forEach(function(m,i){ var vis=!CFG.radarHidden[m.key]; h+='<div class="rc-cfg-mod" data-pk="'+esc(m.key)+'"><span class="rc-cfg-mlbl'+(vis?'':' off')+'">'+esc(m.label)+'</span>'+swc('cfgPane_'+i,vis)+'</div>'; }); }
                else { var list=discover(curPage, ({arena:'rcPageArenaContent',quali:'rcPageQualiContent',cockpit:'rcPageCockpitContent'})[curPage]||'rcPageArenaContent'); if(!list.length) h+='<div class="rc-cfg-hint" style="padding:4px 2px;">Seite oeffnen, damit die Module erkannt werden.</div>'; list.forEach(function(m,i){ var vis=!CFG.hidden[m.key]; h+='<div class="rc-cfg-mod" data-mk="'+esc(m.key)+'" data-mp="'+curPage+'"><button class="rc-cfg-ord" data-ord="up">&#9650;</button><button class="rc-cfg-ord" data-ord="down">&#9660;</button><input class="rc-cfg-rename'+(vis?'':' off')+'" data-mk="'+esc(m.key)+'" value="'+esc(CFG.titles[m.key]!=null?CFG.titles[m.key]:m.label)+'" title="Modul umbenennen"><button class="rc-cfg-rreset" data-mk="'+esc(m.key)+'" title="Originalname">&#8634;</button><button class="rc-cfg-sz" data-sz="-1">&minus;</button><button class="rc-cfg-sz" data-sz="1">+</button>'+swc('cfgVis_'+i,vis)+'</div>'; }); }
                }
                // Eigene Module
                h+='<div class="rc-cfg-sec">Eigene Module hinzufuegen</div>';
                h+='<div class="rc-cfg-addbar">'+Object.keys(MOD_TYPES).map(function(t){ return '<button class="rc-cfg-add'+(MOD_TYPES[t].cat==='Live'?' live':'')+'" data-add="'+t+'">+ '+MOD_TYPES[t].label+'</button>'; }).join('')+'</div>';
                (CFG.custom[curPage]||[]).forEach(function(m,i){ var T=MOD_TYPES[m.type]; var zn=zonesFor(curPage);
                    h+='<div class="rc-cfg-imod" data-im="'+i+'"><div class="rc-cfg-imhead"><button class="rc-cfg-ord" data-imord="up">&#9650;</button><button class="rc-cfg-ord" data-imord="down">&#9660;</button><b>'+esc(T?T.label:m.type)+'</b><span style="flex:1"></span>'
                    +(zn.length>1?'<select class="rc-cfg-zone" data-imzone="1">'+zn.map(function(z){return '<option value="'+z[0]+'" '+((m.zone||zn[0][0])===z[0]?'selected':'')+'>'+z[1]+'</option>';}).join('')+'</select>':'')
                    +'<button class="rc-cfg-del" data-imdel="1">&#10005;</button></div><div class="rc-cfg-imfields">'+customFields(m,i)+'</div></div>'; });
            } else if(curTab==='report'){
                var rc=(window.rcReport&&window.rcReport.cfg)||{};
                h+='<div class="rc-cfg-note">Verschickt den <b>Aktuellen Stand</b> (Qualitaet + Vertrieb je Agent, mit Ampeln) als HTML-Report ueber Outlook (PowerShell-Skript esl_mail_report.ps1). Waehle unten, fuer welchen Standort/Stack der Report gilt &mdash; passend zum jeweiligen Verteiler.</div>';
                var _sc=(window.rcReport&&window.rcReport.scopes&&window.rcReport.scopes())||{standorte:[],stacks:[]};
                var _stdOpt='<option value="ALL"'+(!rc.std||rc.std==='ALL'?' selected':'')+'>Alle Standorte</option>'+_sc.standorte.map(function(o){ return '<option value="'+esc(o.code)+'"'+(rc.std===o.code?' selected':'')+'>'+esc(o.name)+'</option>'; }).join('');
                var _stkOpt='<option value="ALL"'+(!rc.stack||rc.stack==='ALL'?' selected':'')+'>Alle Stacks</option>'+_sc.stacks.map(function(s){ return '<option value="'+esc(s)+'"'+(rc.stack===s?' selected':'')+'>'+esc(s)+'</option>'; }).join('');
                h+=rowr('Standort', '<select id="cfgRepStd" class="rc-cfg-txt" style="width:170px;">'+_stdOpt+'</select>');
                h+=rowr('Stack / Abteilung', '<select id="cfgRepStack" class="rc-cfg-txt" style="width:170px;">'+_stkOpt+'</select>');
                h+=rowr('Stuendlich automatisch', swc('cfgRepAuto', rc.autoHourly));
                h+=rowr('Empfaenger', '<input type="text" id="cfgRepTo" class="rc-cfg-txt" style="width:200px;" placeholder="teamleitung@firma.de" value="'+esc(rc.to||'')+'">');
                h+=rowr('Betreff', '<input type="text" id="cfgRepSubj" class="rc-cfg-txt" style="width:200px;" value="'+esc(rc.subject||'')+'">');
                h+=rowr('Report jetzt erzeugen', '<button class="rc-cfg-btn" id="cfgRepNow">Jetzt herunterladen</button>');
                h+='<div class="rc-cfg-hint" style="margin-top:8px;">Betreff-Platzhalter: {datum} {zeit} {scope}. Empfaenger/Betreff werden in die HTML-Datei geschrieben, das PowerShell-Skript liest sie. Tipp: in Chrome/Edge unter Downloads "Vor dem Download nach Speicherort fragen" ausschalten, damit stuendlich automatisch gespeichert wird.</div>';
            } else if(curTab==='sichern'){
                h+='<div class="rc-cfg-note">Konfiguration sichern, weitergeben oder zuruecksetzen (Layout, Kriegsfeld, eigene Module).</div>';
                h+=rowr('Als Datei speichern','<button class="rc-cfg-btn" id="cfgExport">Export JSON</button>');
                h+=rowr('Aus Datei laden','<button class="rc-cfg-btn" id="cfgImport">Import JSON</button>');
                h+=rowr('Alles zuruecksetzen','<button class="rc-cfg-btn danger" id="cfgResetAll">Zuruecksetzen</button>');
                h+='<div class="rc-cfg-hint" style="margin-top:10px;">Konsole: <code>rcCfg</code>, <code>rcApplyLayout()</code>, <code>rcWarHudApply()</code>.</div>';
            }
            b.innerHTML=h; wireBody();
        }
        function customFields(m,i){ var T=MOD_TYPES[m.type]; if(!T) return ''; return T.fields.map(function(f){ var key=f[0],lbl=f[1],type=f[2],val=m[key],ctrl;
            if(type==='textarea') ctrl='<textarea class="rc-cfg-txt" data-if="'+key+'" data-im="'+i+'">'+esc(val||'')+'</textarea>';
            else if(type==='number') ctrl='<input type="number" class="rc-cfg-num" data-if="'+key+'" data-im="'+i+'" value="'+(val==null?'':esc(val))+'">';
            else if(type==='datetime') ctrl='<input type="datetime-local" class="rc-cfg-txt" data-if="'+key+'" data-im="'+i+'" value="'+esc(val||'')+'">';
            else if(type==='list') ctrl='<div data-lk="'+key+'">'+(val||[]).map(function(x,j){return '<div class="rc-cfg-lrow"><input type="text" class="rc-cfg-txt" data-il="'+key+'" data-im="'+i+'" data-ix="'+j+'" value="'+esc(x)+'"><button class="rc-cfg-lrm" data-ilrm="'+key+'" data-im="'+i+'" data-ix="'+j+'">&#10005;</button></div>';}).join('')+'</div><button class="rc-cfg-add sm" data-iladd="'+key+'" data-im="'+i+'">+ Eintrag</button>';
            else if(type&&type.indexOf('select:')===0){ var opts=type.slice(7).split('|'); ctrl='<select class="rc-cfg-txt" data-if="'+key+'" data-im="'+i+'">'+opts.map(function(o){return '<option '+(val===o?'selected':'')+'>'+o+'</option>';}).join('')+'</select>'; }
            else ctrl='<input type="text" class="rc-cfg-txt" data-if="'+key+'" data-im="'+i+'" value="'+esc(val||'')+'">';
            return '<label class="rc-cfg-fl">'+lbl+'</label>'+ctrl; }).join(''); }

        function wireBody(){
            Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-tab'),function(t){ t.addEventListener('click',function(){ curTab=t.getAttribute('data-tab'); renderTabs(); renderBody(); }); });
            Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-pg[data-pg]'),function(t){ t.addEventListener('click',function(){ curPage=t.getAttribute('data-pg'); renderBody(); }); });
            if(curTab==='anzeige'){
                on(q('cfgAuto'),'change',function(e){ if(window.rcSetAutoRot) window.rcSetAutoRot(e.target.checked); });
                on(q('cfgRotSec'),'change',function(e){ window.rcAutoRotSec=Math.max(10,+e.target.value||60); if(window.rcAutoRot&&window.rcSetAutoRot){ window.rcSetAutoRot(false); window.rcSetAutoRot(true); } });
                [['arena'],['quali'],['radar'],['cockpit'],['info']].forEach(function(p){ on(q('cfgRot_'+p[0]),'change',function(e){ var rp=window.rcAutoRotPages,i=rp.indexOf(p[0]); if(e.target.checked){ if(i<0) rp.push(p[0]); } else if(i>=0) rp.splice(i,1); if(p[0]==='info'){ CFG.info.inRotation=e.target.checked; save(); } }); });
                on(q('cfgInfoOn'),'change',function(e){ CFG.info.enabled=e.target.checked; save(); ensureInfoPage(); applyCustomStructure('info'); });
                on(q('cfgCarSec'),'change',function(e){ window.rcRadarCarouselSec=Math.max(4,+e.target.value||12); });
                on(q('cfgZoomM'),'click',function(){ if(window.rcApplyZoom) window.rcApplyZoom((window.rcZoom||1)-0.1); q('cfgZoomV').textContent=Math.round((window.rcZoom||1)*100)+'%'; });
                on(q('cfgZoomP'),'click',function(){ if(window.rcApplyZoom) window.rcApplyZoom((window.rcZoom||1)+0.1); q('cfgZoomV').textContent=Math.round((window.rcZoom||1)*100)+'%'; });
            } else if(curTab==='krieg'){
                Object.keys(window.rcWarHud||{}).forEach(function(k){ var el=q('cfgHud_'+k); if(el) el.addEventListener('change',function(e){ window.rcWarHud[k]=e.target.checked; if(window.rcWarHudApply) window.rcWarHudApply(); }); });
                on(q('cfgHudReset'),'click',function(){ window.rcWarHud=Object.assign({},window.rcWarHudDefaults); try{localStorage.removeItem('rcWarHud');}catch(e){} if(window.rcWarHudApply) window.rcWarHudApply(); renderBody(); });
            } else if(curTab==='module'){
                // Seiten-Verwaltung (eigene Seiten)
                on(q('cfgAddPage'),'click',function(){ var id=uid(); CFG.pages=CFG.pages||[]; CFG.pages.push({id:id,name:'Seite '+(CFG.pages.length+1),cols:3,inRotation:false}); CFG.custom['cp_'+id]=[]; save(); ensureCustomPages(); curPage='cp_'+id; renderBody(); });
                if(curPage.indexOf('cp_')===0){ var _pg=userPageDef(curPage);
                    on(q('cfgPgName'),'input',function(e){ if(_pg){ _pg.name=e.target.value; save(); ensureCustomPages(); } });
                    on(q('cfgPgCols'),'change',function(e){ if(_pg){ _pg.cols=Math.max(1,Math.min(6,+e.target.value||3)); save(); reconcileCustom(curPage); } });
                    on(q('cfgPgRot'),'change',function(e){ if(_pg){ _pg.inRotation=e.target.checked; save(); ensureCustomPages(); } });
                    on(q('cfgPgDel'),'click',function(){ if(!confirm('Seite loeschen?')) return; var did=curPage.slice(3); CFG.pages=(CFG.pages||[]).filter(function(x){return x.id!==did;}); delete CFG.custom['cp_'+did]; save(); ensureCustomPages(); curPage='arena'; renderBody(); });
                }
                // native show/hide/reorder/size
                Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-mod[data-mk]'),function(rowEl){ var key=rowEl.getAttribute('data-mk'),page=rowEl.getAttribute('data-mp'); var vi=rowEl.querySelector('input[type=checkbox]'); on(vi,'change',function(e){ CFG.hidden[key]=!e.target.checked; save(); applyLayout(); var lb=rowEl.querySelector('.rc-cfg-rename'); if(lb) lb.classList.toggle('off',!e.target.checked); }); Array.prototype.forEach.call(rowEl.querySelectorAll('.rc-cfg-ord[data-ord]'),function(bt){ bt.addEventListener('click',function(){ moveNative(page,key,bt.getAttribute('data-ord')); }); }); Array.prototype.forEach.call(rowEl.querySelectorAll('.rc-cfg-sz'),function(bt){ bt.addEventListener('click',function(){ sizeNative(key,+bt.getAttribute('data-sz')); }); }); var ri=rowEl.querySelector('.rc-cfg-rename'); if(ri){ on(ri,'input',function(){ var v=ri.value; if(v==null||v==='') delete CFG.titles[key]; else CFG.titles[key]=v; save(); applyLayout(); }); } var rr=rowEl.querySelector('.rc-cfg-rreset'); if(rr){ on(rr,'click',function(){ delete CFG.titles[key]; save(); applyLayout(); renderBody(); }); } });
                // radar panes
                Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-mod[data-pk]'),function(rowEl){ var key=rowEl.getAttribute('data-pk'); var vi=rowEl.querySelector('input[type=checkbox]'); on(vi,'change',function(e){ CFG.radarHidden[key]=!e.target.checked; save(); applyRadar(); rowEl.querySelector('.rc-cfg-mlbl').classList.toggle('off',!e.target.checked); }); });
                // add custom
                Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-add[data-add]'),function(bt){ bt.addEventListener('click',function(){ var t=bt.getAttribute('data-add'); var m=MOD_TYPES[t].def(); m.type=t; m.id=uid(); m.w=1; m.zone=zonesFor(curPage)[0][0]; CFG.custom[curPage].push(m); if(curPage==='info'){ CFG.info.enabled=true; ensureInfoPage(); } save(); applyCustomStructure(curPage); renderBody(); }); });
                // custom edit
                Array.prototype.forEach.call(document.querySelectorAll('.rc-cfg-imod'),function(box){ var i=+box.getAttribute('data-im'); var arr=CFG.custom[curPage];
                    Array.prototype.forEach.call(box.querySelectorAll('[data-if]'),function(el){ el.addEventListener(el.tagName==='SELECT'?'change':'input',function(){ var k=el.getAttribute('data-if'); var v=el.value; if(el.type==='number') v=v===''?'':Number(v); arr[i][k]=v; save(); applyCustomStructure(curPage); }); });
                    Array.prototype.forEach.call(box.querySelectorAll('[data-il]'),function(el){ el.addEventListener('input',function(){ var k=el.getAttribute('data-il'),ix=+el.getAttribute('data-ix'); arr[i][k][ix]=el.value; save(); refreshCustomBodies(curPage); }); });
                    Array.prototype.forEach.call(box.querySelectorAll('[data-ilrm]'),function(el){ el.addEventListener('click',function(){ var k=el.getAttribute('data-ilrm'),ix=+el.getAttribute('data-ix'); arr[i][k].splice(ix,1); save(); applyCustomStructure(curPage); renderBody(); }); });
                    Array.prototype.forEach.call(box.querySelectorAll('[data-iladd]'),function(el){ el.addEventListener('click',function(){ var k=el.getAttribute('data-iladd'); (arr[i][k]=arr[i][k]||[]).push(''); save(); applyCustomStructure(curPage); renderBody(); }); });
                    on(box.querySelector('[data-imzone]'),'change',function(e){ arr[i].zone=e.target.value; save(); applyCustomStructure(curPage); });
                    Array.prototype.forEach.call(box.querySelectorAll('[data-imord]'),function(el){ el.addEventListener('click',function(){ var dir=el.getAttribute('data-imord'),j=dir==='up'?i-1:i+1; if(j<0||j>=arr.length) return; var t=arr[i]; arr[i]=arr[j]; arr[j]=t; save(); applyCustomStructure(curPage); renderBody(); }); });
                    on(box.querySelector('[data-imdel]'),'click',function(){ arr.splice(i,1); save(); applyCustomStructure(curPage); renderBody(); });
                });
            } else if(curTab==='report'){
                on(q('cfgRepAuto'),'change',function(e){ if(window.rcReport){ window.rcReport.cfg.autoHourly=e.target.checked; window.rcReport.save(); } });
                on(q('cfgRepTo'),'input',function(e){ if(window.rcReport){ window.rcReport.cfg.to=e.target.value; window.rcReport.save(); } });
                on(q('cfgRepSubj'),'input',function(e){ if(window.rcReport){ window.rcReport.cfg.subject=e.target.value; window.rcReport.save(); } });
                on(q('cfgRepNow'),'click',function(){ if(window.rcReportNow) window.rcReportNow(); });
                on(q('cfgRepStd'),'change',function(e){ if(window.rcReport){ window.rcReport.cfg.std=e.target.value; window.rcReport.save(); } });
                on(q('cfgRepStack'),'change',function(e){ if(window.rcReport){ window.rcReport.cfg.stack=e.target.value; window.rcReport.save(); } });
            } else if(curTab==='sichern'){
                on(q('cfgExport'),'click',function(){ var blob=new Blob([JSON.stringify(CFG,null,2)],{type:'application/json'}); var a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='esl-konfig.json'; a.click(); setTimeout(function(){URL.revokeObjectURL(a.href);},800); });
                on(q('cfgImport'),'click',function(){ var inp=document.createElement('input'); inp.type='file'; inp.accept='.json'; inp.onchange=function(e){ var f=e.target.files[0]; if(!f) return; var r=new FileReader(); r.onload=function(){ try{ var c=JSON.parse(r.result); Object.assign(CFG,c); save(); applyLayout(); applyRadar(); applyAllCustom(); ensureInfoPage(); if(window.rcWarHudApply) window.rcWarHudApply(); renderBody(); }catch(err){ alert('Import fehlgeschlagen: '+err.message); } }; r.readAsText(f); }; inp.click(); });
                on(q('cfgResetAll'),'click',function(){ if(!confirm('Layout, Kriegsfeld und eigene Module zuruecksetzen?')) return; try{localStorage.removeItem(CFG_KEY); localStorage.removeItem('rcWarHud');}catch(e){} location.reload(); });
            }
        }
        function moveNative(page,key,dir){ var cid=({arena:'rcPageArenaContent',quali:'rcPageQualiContent',cockpit:'rcPageCockpitContent'})[page]; var list=discover(page,cid); var m=list.filter(function(x){return x.key===key;})[0]; if(!m) return; var parent=m.el.parentElement; var sibs=Array.prototype.slice.call(parent.children).filter(function(c){return c.classList.contains('rc-card');}); var idx=sibs.indexOf(m.el),j=dir==='up'?idx-1:idx+1; if(j<0||j>=sibs.length) return; if(dir==='up') parent.insertBefore(m.el,sibs[j]); else parent.insertBefore(sibs[j],m.el); var full=discover(page,cid); CFG.order[page]=full.map(function(x){return x.key;}); save(); renderBody(); }
        function sizeNative(key,d){ var cur=Number(CFG.size[key])||1; cur=Math.max(0.4,Math.min(4,cur+d*0.3)); CFG.size[key]=Math.round(cur*10)/10; save(); applyLayout(); }

        var gear=document.getElementById('rcCfgBtn'); if(gear) gear.addEventListener('click',function(){ panel.classList.contains('on')?closePanel():openPanel(); });
        on(document.getElementById('rcCfgClose'),'click',closePanel);
        backdrop.addEventListener('click',closePanel);
        document.addEventListener('keydown',function(e){ if(e.key==='Escape'&&panel.classList.contains('on')) closePanel(); });

        function boot(){ reconcileAll(); }
        boot();
        // Selbstheilung: alle 2 s Layout, eigene Module und Radar wieder durchsetzen,
        // damit Portal-Re-Renders (20s-Poll, Auto-Wechsel, Neu-Einfuegen) nichts verwerfen.
        // Live-Module aktualisieren sich dabei; statische bleiben ruhig (nur bei Aenderung neu).
        window.rcCfgInterval=setInterval(function(){ try{ reconcileAll(); }catch(e){} },2000);
    })();


    // ============================================================
    //  STUNDEN-REPORT (lokal per Outlook)
    //  ------------------------------------------------------------
    //  Erzeugt eine eigenstaendige HTML-Report-Datei (Vodafone-Stil) mit
    //  dem aktuellen Stand und laedt sie in den Download-Ordner. Ein
    //  geplantes PowerShell-Skript (esl_mail_report.ps1) nimmt die neueste
    //  Datei und verschickt sie ueber das installierte Outlook.
    //  Empfaenger/Betreff stehen als Kommentar im HTML -> PowerShell liest sie.
    //  Konsole: rcReportNow()  ·  rcReport.cfg  ·  rcReport.setAuto(true)
    //  Aufraeumung: rcReportInterval (CLEAN-STATE).
    // ============================================================
    (function rcReportModule(){
        var KEY='rcReportCfg_v1';
        function load(){ var c={}; try{ c=JSON.parse(localStorage.getItem(KEY)||'{}')||{}; }catch(e){}
            c.autoHourly=!!c.autoHourly; c.to=c.to||''; c.subject=c.subject||'ESL Live-Arena — Stunden-Report {datum} {zeit}';
            c.topN=c.topN||10; c.std=c.std||'ALL'; c.stack=c.stack||'ALL'; c.lastHourKey=c.lastHourKey||''; return c; }
        var CFG=load(); function save(){ try{ localStorage.setItem(KEY,JSON.stringify(CFG)); }catch(e){} }
        function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
        function pad(n){ return (n<10?'0':'')+n; }
        var STD={ADP:'Alexandroupolis',AL:'Alanya',B:'Berlin',E:'Essen',P:'Potsdam',SER:'Serres',ZWT:'Zeitwert',NBB:'Neubrandenburg',SKA:'Sakarya'};

        function scopes(){
            var sd=(window.rcLetzteStats&&window.rcLetzteStats.standortStats)||{};
            var stds=[]; Object.keys(sd).forEach(function(k){ var c=sd[k].code||k; if(c&&stds.indexOf(c)<0) stds.push(c); });
            var sm=(window.rcWcaMapping&&window.rcWcaMapping.stackMap)||{};
            var ag=(window.rcLetzteStats&&window.rcLetzteStats.agentStats)||{};
            var stacks=[]; Object.keys(sm).forEach(function(t){ var s=sm[t]; if(s&&stacks.indexOf(s)<0) stacks.push(s); });
            Object.keys(ag).forEach(function(k){ var s=ag[k].stack; if(s&&stacks.indexOf(s)<0) stacks.push(s); });
            return { standorte:stds.sort().map(function(c){ return {code:c, name:STD[c]||c}; }), stacks:stacks.sort() };
        }
        function scopeLabel(){ var s=(CFG.std&&CFG.std!=='ALL')?(STD[CFG.std]||CFG.std):'Alle Standorte'; var k=(CFG.stack&&CFG.stack!=='ALL')?CFG.stack:'Alle Stacks'; return k+' · '+s; }

        function collect(){
            var selStd=CFG.std||'ALL', selStack=CFG.stack||'ALL';
            var st=window.rcLetzteStats||{}, ag=st.agentStats||{};
            var bnt=function(o){ return Number(o.bnt)|| ((Number(o.kip)||0)+(Number(o.mob)||0)+(Number(o.env)||0)+(Number(o.fibDsl)||0)+(Number(o.ptv)||0)+(Number(o.sonstBnt)||0)); };
            var vvl=function(o){ return Number(o.vvl)|| ((Number(o.kipVvl)||0)+(Number(o.mobVvl)||0)+(Number(o.fibVvl)||0)); };
            var raw=Object.keys(ag).map(function(k){ return ag[k]; }).filter(function(a){
                if(selStd!=='ALL' && normalizeStandort(a.standort)!==selStd) return false;
                if(selStack!=='ALL' && (a.stack||'')!==selStack) return false;
                return true; });
            var agents=raw.map(function(a){ var kpi=(window.rcKpiForAgent&&window.rcKpiForAgent(a))||{}; var calls=Number(kpi.callCount)||0; var anspr=Number(a.ansprachen)||0;
                return { name:a.name, standort:normalizeStandort(a.standort), team:a.team||'', kip:a.kip||0, mob:a.mob||0, vvl:vvl(a), bnt:bnt(a), ansprachen:anspr, calls:calls,
                    cs:(kpi.cs!=null?Number(kpi.cs):null), tnps:(kpi.tnps!=null?Number(kpi.tnps):null), aq:(kpi.auflegerquote!=null?Number(kpi.auflegerquote):null), fq:(kpi.fq!=null?Number(kpi.fq):null), ahtMin:(kpi.ahtSec!=null?Number(kpi.ahtSec)/60:null),
                    anspQuote:(calls?(anspr/calls*100):null), total:(a.kip||0)+(a.mob||0)+bnt(a)+vvl(a) }; });
            agents.sort(function(a,b){ return b.total-a.total; });
            var byStd={}; agents.forEach(function(a){ var s=byStd[a.standort]=byStd[a.standort]||{code:a.standort,kip:0,mob:0,vvl:0,bnt:0,calls:0}; s.kip+=a.kip; s.mob+=a.mob; s.vvl+=a.vvl; s.bnt+=a.bnt; s.calls+=a.calls; });
            var standorte=Object.keys(byStd).map(function(k){return byStd[k];}).sort(function(a,b){return (b.kip+b.mob)-(a.kip+a.mob);});
            var g={kip:0,mob:0,vvl:0,bnt:0,ansp:0,calls:0}; agents.forEach(function(a){ g.kip+=a.kip; g.mob+=a.mob; g.vvl+=a.vvl; g.bnt+=a.bnt; g.ansp+=a.ansprachen; g.calls+=a.calls; });
            var csS=0,csN=0,tnS=0,tnN=0; agents.forEach(function(a){ if(a.cs!=null&&a.calls){csS+=a.cs*a.calls;csN+=a.calls;} if(a.tnps!=null&&a.calls){tnS+=a.tnps*a.calls;tnN+=a.calls;} });
            g.cs=csN?csS/csN:null; g.tnps=tnN?tnS/tnN:null;
            g.anspQuote=g.calls?Math.round(g.ansp/g.calls*100):0; g.bntRate=g.calls?Math.round(g.bnt/g.calls*100):0;
            return {agents:agents, standorte:standorte, g:g, hasData:agents.length>0};
        }

        function buildHtml(){
            var now=new Date();
            var datum=pad(now.getDate())+'.'+pad(now.getMonth()+1)+'.'+now.getFullYear();
            var zeit=pad(now.getHours())+':'+pad(now.getMinutes());
            var d=collect(); var scope=scopeLabel();
            var subj=(CFG.subject||'ESL Report {datum} {zeit}').replace('{datum}',datum).replace('{zeit}',zeit).replace('{scope}',scope);
            var g=d.g;
            var kpi=function(l,v,c){ return '<td style="padding:10px 14px; border:1px solid #2C2C2C; background:#1D1D1D;"><div style="font-size:11px; color:#9C9C9C; text-transform:uppercase; letter-spacing:.5px;">'+l+'</div><div style="font-size:26px; font-weight:800; color:'+(c||'#F5F5F5')+';">'+v+'</div></td>'; };
            var stdRows=d.standorte.map(function(s){ return '<tr><td style="padding:7px 10px; border-bottom:1px solid #232323; font-weight:700;">'+esc(STD[s.code]||s.code)+'</td>'
                +'<td style="padding:7px 10px; border-bottom:1px solid #232323; text-align:right; color:#FFB300;">'+s.kip+'</td>'
                +'<td style="padding:7px 10px; border-bottom:1px solid #232323; text-align:right; color:#22C7E6;">'+s.mob+'</td>'
                +'<td style="padding:7px 10px; border-bottom:1px solid #232323; text-align:right;">'+s.vvl+'</td>'
                +'<td style="padding:7px 10px; border-bottom:1px solid #232323; text-align:right;">'+s.bnt+'</td>'
                +'<td style="padding:7px 10px; border-bottom:1px solid #232323; text-align:right; color:#9C9C9C;">'+s.calls+'</td></tr>'; }).join('');
            // Aktueller Stand — je Agent (Qualitaet + Vertrieb, mit Ampeln)
            var num=function(v,dec){ return v!=null? (dec?v.toFixed(dec):String(Math.round(v))).replace('.',',') : '—'; };
            var qc=function(v,ziel,dec,suff){ return '<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:center; color:'+zielColor(v,ziel)+';">'+(v!=null?num(v,dec)+(suff||''):'—')+'</td>'; };
            var asRows=d.agents.slice(0,120).map(function(a,i){ return '<tr>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; color:#9C9C9C; text-align:center;">'+(i+1)+'</td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; font-weight:700; white-space:nowrap;">'+esc(a.name)+' <span style="color:#9C9C9C; font-weight:400;">'+esc(a.standort)+'</span><div style="color:#7E7E7E; font-weight:400; font-size:10px;">'+esc(a.team)+'</div></td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:center; color:'+zielColor(a.calls,RC_ZIELE.calls)+';">'+(a.calls||0)+'</td>'
                +qc(a.ahtMin,RC_ZIELE.ahtMin,1)+qc(a.aq,RC_ZIELE.aq,0,'%')+qc(a.cs,RC_ZIELE.cs,0,'%')+qc(a.tnps,RC_ZIELE.tnps,0,'%')+qc(a.fq,RC_ZIELE.fq,0,'%')
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:center; color:'+zielColor(a.anspQuote,{min:40})+';">'+(a.anspQuote!=null?Math.round(a.anspQuote)+'%':'—')+'</td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:right; color:#FFB300;">'+a.kip+'</td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:right; color:#22C7E6;">'+a.mob+'</td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:right;">'+a.bnt+'</td>'
                +'<td style="padding:5px 8px; border-bottom:1px solid #232323; text-align:right;">'+a.vvl+'</td></tr>'; }).join('');
            var asTable=d.agents.length? '<div style="font-size:14px; font-weight:800; margin:18px 0 6px; color:#C9C9C9;">Aktueller Stand &mdash; je Agent</div>'
                +'<table style="border-collapse:collapse; width:100%; font-size:12px;"><thead><tr style="color:#9C9C9C; font-size:10px; text-transform:uppercase;">'
                +'<th style="padding:5px 8px; width:24px;">#</th><th style="padding:5px 8px; text-align:left;">Verkaeufer</th><th style="padding:5px 8px;">Calls</th><th style="padding:5px 8px;">AHT</th><th style="padding:5px 8px;">AQ</th><th style="padding:5px 8px;">CS</th><th style="padding:5px 8px;">TNPS</th><th style="padding:5px 8px;">FQ</th><th style="padding:5px 8px;">Ansp</th><th style="padding:5px 8px; text-align:right;">KIP</th><th style="padding:5px 8px; text-align:right;">MOB</th><th style="padding:5px 8px; text-align:right;">BNT</th><th style="padding:5px 8px; text-align:right;">VVL</th></tr></thead><tbody>'+asRows+'</tbody></table>'
                +'<div style="font-size:10px; color:#7E7E7E; margin-top:4px;">Ampeln: CS&ge;90 &middot; TNPS&ge;70 &middot; AQ&ge;85 &middot; FQ&ge;30 &middot; AHT&le;13 Min &middot; &ge;40 Calls. Ansprache-Quote auf Liga-Call-Basis.</div>':'';
            var body='<div style="font-family:Segoe UI,Arial,sans-serif; background:#121212; color:#F5F5F5; padding:20px; max-width:900px;">'
                +'<div style="border-top:4px solid #E60000; background:#1D1D1D; padding:16px 18px; border-radius:6px;">'
                +'<div style="font-size:20px; font-weight:800;">ESL Live-Arena &mdash; Aktueller Stand</div>'
                +'<div style="font-size:13px; color:#9C9C9C; margin-top:2px;">Stand '+datum+' '+zeit+' Uhr &middot; '+esc(scope)+'</div></div>'
                +(d.hasData? '' : '<div style="margin:14px 0; padding:12px; background:#2A1111; border:1px solid #E60000; border-radius:6px;">Keine Daten fuer diesen Standort/Stack &mdash; ggf. Filter pruefen oder Daten laden.</div>')
                +'<table style="border-collapse:collapse; margin:16px 0; width:100%;"><tr>'
                + kpi('Liga-Calls',g.calls) + kpi('Ansprachen',g.ansp+' &middot; '+g.anspQuote+'%','#FF6666') + kpi('BNT gesamt',g.bnt+' &middot; '+g.bntRate+'%','#E60000') + '</tr><tr>'
                + kpi('KIP-BNT',g.kip,'#FFB300') + kpi('Mobilfunk-BNT',g.mob,'#22C7E6') + kpi('VVL',g.vvl) + '</tr>'
                + (g.cs!=null? '<tr>'+kpi('CS (Quali)',(Math.round(g.cs*10)/10).toString().replace('.',',')+'%', g.cs>=90?'#3DD68C':'#EB9700')+kpi('TNPS',(g.tnps!=null?(Math.round(g.tnps*10)/10).toString().replace('.',','):'—'))+kpi('BNT-Rate',g.bntRate+'%')+'</tr>':'')
                +'</table>'
                +(stdRows? '<div style="font-size:14px; font-weight:800; margin:18px 0 6px; color:#C9C9C9;">Standorte</div>'
                +'<table style="border-collapse:collapse; width:100%; font-size:13px;"><thead><tr style="color:#9C9C9C; font-size:11px; text-transform:uppercase;"><th style="text-align:left; padding:6px 10px;">Standort</th><th style="text-align:right; padding:6px 10px;">KIP</th><th style="text-align:right; padding:6px 10px;">MOB</th><th style="text-align:right; padding:6px 10px;">VVL</th><th style="text-align:right; padding:6px 10px;">BNT</th><th style="text-align:right; padding:6px 10px;">Calls</th></tr></thead><tbody>'+stdRows+'</tbody></table>':'')
                + asTable
                +'<div style="font-size:11px; color:#7E7E7E; margin-top:20px;">Automatisch erzeugt von der ESL Live-Arena.</div></div>';
            var head='<!DOCTYPE html><html><head><meta charset="utf-8">'
                +'<!--ESLMAIL to="'+esc(CFG.to||'')+'" subject="'+esc(subj)+'"-->'
                +'<title>'+esc(subj)+'</title></head><body style="margin:0; background:#121212;">';
            return { html: head+body+'</body></html>', bodyHtml:body, subject:subj, filename:'ESL-Report-'+now.getFullYear()+pad(now.getMonth()+1)+pad(now.getDate())+'-'+pad(now.getHours())+pad(now.getMinutes())+'.html' };
        }

        function stamp(){ var n=new Date(); return n.getFullYear()+pad(n.getMonth()+1)+pad(n.getDate())+'-'+pad(n.getHours())+pad(n.getMinutes()); }
        function dl(blob, fn){ try{ var a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download=fn; document.body.appendChild(a); a.click(); setTimeout(function(){ document.body.removeChild(a); URL.revokeObjectURL(a.href); },1500); }catch(e){ if(window.rcLog) rcLog.warn('Report dl:',e); } }

        // Echtes "Aktueller Stand"-Excel (1:1-Vorlage), gefiltert nach Standort/Stack
        function buildXlsx(base, cb){ try{
            if(typeof rcStandRows!=='function' || typeof rcBuildStandSheets!=='function' || typeof rcLoadStyledXlsx!=='function'){ if(window.rcLog) rcLog.warn('Report-Excel: Export-Funktionen fehlen'); cb&&cb(null); return; }
            var scope={ std:CFG.std||'ALL', stack:CFG.stack||'ALL', team:'ALL' };
            var data=rcStandRows(null, scope);
            if(!data || !data.rows || !data.rows.length){ if(window.rcLog) rcLog.warn('Report-Excel: keine Agenten fuer Filter'); cb&&cb(null); return; }
            rcLoadStyledXlsx(function(XL){ try{
                var wb=XL.utils.book_new(); rcBuildStandSheets(XL, wb, !!XL.__styled, data);
                var out=XL.write(wb, {bookType:'xlsx', type:'array'});
                dl(new Blob([out],{type:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}), base+'.xlsx');
                cb&&cb(base+'.xlsx');
            }catch(e){ if(window.rcLog) rcLog.warn('Report-Excel:',e); cb&&cb(null); } });
        }catch(e){ if(window.rcLog) rcLog.warn('Report-Excel:',e); cb&&cb(null); } }

        // Screenshot (PNG) des "Aktueller Stand" — direkt auf Canvas gezeichnet
        // (zuverlaessig in Chrome/Edge; foreignObject wird dort fuer Canvas gesperrt).
        function buildPng(base, cb){ try{
            var d=collect(); var scope=scopeLabel(); var now=new Date();
            var datum=pad(now.getDate())+'.'+pad(now.getMonth()+1)+'.'+now.getFullYear()+' '+pad(now.getHours())+':'+pad(now.getMinutes());
            var cols=[ {k:'#',w:34,a:'center'}, {k:'Verkaeufer',w:210,a:'left'},
                {k:'Calls',w:54,a:'center'}, {k:'AHT',w:54,a:'center'}, {k:'AQ',w:52,a:'center'}, {k:'CS',w:52,a:'center'}, {k:'TNPS',w:58,a:'center'}, {k:'FQ',w:52,a:'center'}, {k:'Ansp',w:54,a:'center'},
                {k:'KIP',w:48,a:'right'}, {k:'MOB',w:48,a:'right'}, {k:'BNT',w:48,a:'right'}, {k:'VVL',w:46,a:'right'} ];
            var PADX=16, rowH=24, headH=88, kpiH=40, thH=28;
            var W=PADX*2; cols.forEach(function(c){ W+=c.w; });
            var maxRows=Math.min(d.agents.length, 60);
            var H=headH+kpiH+thH+maxRows*rowH+ (d.agents.length>maxRows?28:16);
            var cv=document.createElement('canvas'); var sc=2; cv.width=W*sc; cv.height=H*sc; var x=cv.getContext('2d'); x.scale(sc,sc); x.textBaseline='middle';
            x.fillStyle='#121212'; x.fillRect(0,0,W,H);
            x.fillStyle='#E60000'; x.fillRect(0,0,W,4);
            x.fillStyle='#1D1D1D'; x.fillRect(PADX,14,W-2*PADX,58);
            x.fillStyle='#F5F5F5'; x.font='800 20px Segoe UI,Arial,sans-serif'; x.textAlign='left'; x.fillText('ESL Live-Arena — Aktueller Stand', PADX+14, 37);
            x.fillStyle='#9C9C9C'; x.font='13px Segoe UI,Arial,sans-serif'; x.fillText('Stand '+datum+' Uhr · '+scope, PADX+14, 58);
            var g=d.g; x.font='12px Segoe UI,Arial,sans-serif'; x.fillStyle='#C9C9C9'; x.textAlign='left';
            x.fillText('Liga-Calls '+g.calls+'    Ansprachen '+g.ansp+' ('+g.anspQuote+'%)    BNT '+g.bnt+'    KIP '+g.kip+'    MOB '+g.mob+'    VVL '+g.vvl+(g.cs!=null?'    CS '+(Math.round(g.cs*10)/10).toString().replace('.',',')+'%':''), PADX, headH+16);
            var ty=headH+kpiH; x.fillStyle='#1D1D1D'; x.fillRect(PADX,ty,W-2*PADX,thH);
            x.fillStyle='#9C9C9C'; x.font='700 10px Segoe UI,Arial,sans-serif'; var cx=PADX;
            cols.forEach(function(col){ var tx=col.a==='left'?cx+6:(col.a==='right'?cx+col.w-6:cx+col.w/2); x.textAlign=col.a; x.fillText(col.k.toUpperCase(), tx, ty+thH/2); cx+=col.w; });
            var ry=ty+thH;
            d.agents.slice(0,maxRows).forEach(function(a,i){
                if(i%2===1){ x.fillStyle='#171717'; x.fillRect(PADX,ry,W-2*PADX,rowH); }
                var vals=[ String(i+1), a.name+'  '+a.standort, (a.calls||0), (a.ahtMin!=null?a.ahtMin.toFixed(1).replace('.',','):'—'),
                    (a.aq!=null?Math.round(a.aq)+'%':'—'), (a.cs!=null?Math.round(a.cs)+'%':'—'), (a.tnps!=null?Math.round(a.tnps)+'%':'—'), (a.fq!=null?Math.round(a.fq)+'%':'—'),
                    (a.anspQuote!=null?Math.round(a.anspQuote)+'%':'—'), a.kip, a.mob, a.bnt, a.vvl ];
                var cc=[ '#9C9C9C','#F5F5F5', zielColor(a.calls,RC_ZIELE.calls), zielColor(a.ahtMin,RC_ZIELE.ahtMin), zielColor(a.aq,RC_ZIELE.aq), zielColor(a.cs,RC_ZIELE.cs), zielColor(a.tnps,RC_ZIELE.tnps), zielColor(a.fq,RC_ZIELE.fq), zielColor(a.anspQuote,{min:40}), '#FFB300','#22C7E6','#F5F5F5','#F5F5F5' ];
                var cx2=PADX; cols.forEach(function(col,ci){ var tx=col.a==='left'?cx2+6:(col.a==='right'?cx2+col.w-6:cx2+col.w/2); x.textAlign=col.a; x.fillStyle=cc[ci]; x.font=(ci===1?'700 ':'')+'11px Segoe UI,Arial,sans-serif';
                    var t=String(vals[ci]); if(ci===1 && t.length>34) t=t.slice(0,33)+'…'; x.fillText(t, tx, ry+rowH/2); cx2+=col.w; });
                ry+=rowH;
            });
            if(d.agents.length>maxRows){ x.fillStyle='#7E7E7E'; x.font='10px Segoe UI,Arial,sans-serif'; x.textAlign='left'; x.fillText('… und '+(d.agents.length-maxRows)+' weitere Agenten', PADX, ry+13); }
            if(cv.toBlob){ cv.toBlob(function(blob){ if(blob) dl(blob, base+'.png'); cb&&cb(blob?base+'.png':null); },'image/png'); }
            else { var du=cv.toDataURL('image/png'), bin=atob(du.split(',')[1]), arr=new Uint8Array(bin.length); for(var i=0;i<bin.length;i++) arr[i]=bin.charCodeAt(i); dl(new Blob([arr],{type:'image/png'}), base+'.png'); cb&&cb(base+'.png'); }
        }catch(e){ if(window.rcLog) rcLog.warn('Report-PNG:',e); cb&&cb(null); } }

        function download(){ var base='ESL-Report-'+stamp(); var r=buildHtml();
            try{ dl(new Blob([r.html],{type:'text/html;charset=utf-8'}), base+'.html'); }catch(e){ if(window.rcLog) rcLog.warn('Report:',e); }
            buildXlsx(base); buildPng(base); return base+'.html'; }

        window.rcReport={ cfg:CFG, buildHtml:buildHtml, scopes:scopes, buildXlsx:buildXlsx, buildPng:buildPng, now:function(){ return download(); }, save:save, setAuto:function(v){ CFG.autoHourly=!!v; save(); }, setTo:function(t){ CFG.to=t||''; save(); } };
        window.rcReportNow=function(){ return download(); };

        // Stunden-Takt: einmal pro voller Stunde (kurz nach :00), wenn aktiv
        window.rcReportInterval=setInterval(function(){ try{ if(!CFG.autoHourly) return; var n=new Date(); var hk=n.getFullYear()+'-'+pad(n.getMonth()+1)+'-'+pad(n.getDate())+'-'+pad(n.getHours()); if(hk!==CFG.lastHourKey && n.getMinutes()<5){ CFG.lastHourKey=hk; save(); download(); } }catch(e){} },60000);
    })();

    // Drag & Drop Mapping
    (function(){
        const dz = document.getElementById('rcDropZone'), fi = document.getElementById('rcFileInput');
        // Die gewaehlte Excel wird zusaetzlich als Base64 gesichert, damit sie beim
        // naechsten Start ohne Datei-Dialog wieder eingelesen werden kann
        // (rcAutoMapping). Schlaegt das Sichern fehl (Speicher voll), ist nur der
        // Komfort weg — der Import selbst laeuft trotzdem.
        const read = f => {
            const r = new FileReader();
            r.onload = e => {
                verarbeiteMappingExcel(e.target.result);
                try {
                    const b = new Uint8Array(e.target.result); let s = '';
                    for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000));
                    localStorage.setItem('rcWcaMappingXlsx', btoa(s));
                } catch(err){ rcLog.warn('Mapping-Excel konnte nicht gesichert werden (' + err.message + ') — beim naechsten Start ggf. erneut waehlen.'); }
            };
            r.readAsArrayBuffer(f);
        };
        dz.addEventListener('click', () => fi.click());
        fi.addEventListener('change', e => { if (e.target.files[0]) read(e.target.files[0]); });
        dz.addEventListener('dragover', e => { e.preventDefault(); dz.style.borderColor='#E60000'; });
        dz.addEventListener('dragleave', () => dz.style.borderColor='#CFCFCF');
        dz.addEventListener('drop', e => { e.preventDefault(); dz.style.borderColor='#CFCFCF';
            const f = e.dataTransfer.files[0]; if (f && f.name.endsWith('.xlsx')) read(f); else alert('Bitte eine .xlsx Datei nutzen.'); });
    })();

    function verarbeiteMappingExcel(arrayBuffer) {
        if (!window.XLSX) return;
        try {
            const wb = XLSX.read(new Uint8Array(arrayBuffer), { type:'array' });
            // Zwei Mapping-Formate werden unterstuetzt:
            //  ALT: 4 Blaetter (Mitarbeiter_ID_Und_Namen | Stacks_Und_Die_Teams | Standorte),
            //       eine VO je Zeile, Stack ueber ein eigenes Blatt.
            //  NEU: EIN Blatt ("Daten"): Standort|Team|CCS_User|Namen|Stack|VO_ID1..VO_ID4 —
            //       Stack als SPALTE, mehrere VOs je Zeile.
            const s1 = wb.SheetNames.find(n => /name|id|mitarbeiter|daten/i.test(n)) || wb.SheetNames[0];
            // Neben-Blaetter nur suchen, wenn sie NICHT das Hauptblatt sind (Ein-Blatt-Datei!)
            const nb = wb.SheetNames.filter(n => n !== s1);
            const s2 = nb.find(n => /ort|standort/i.test(n));
            const s3 = nb.find(n => /stack/i.test(n));
            const data = XLSX.utils.sheet_to_json(wb.Sheets[s1], { header:1 });
            let voMap={}, ccsMap={}, standortMap={}, stackMap={};
            // Header-Zeile SUCHEN statt Zeile 0 annehmen: in der Praxis stehen ueber der
            // Tabelle schon mal leere Zeilen (falsch eingefuegter Bereich). Ohne die Suche
            // waeren alle Spalten-Indizes -1 und das Mapping stillschweigend leer.
            const hRow = data.findIndex(r => r && r.some(x => /^(ccs_user|namen|standort)$/.test((x||'').toString().toLowerCase().trim())));
            if (hRow > 0) rcLog.warn('Mapping-Blatt "' + s1 + '": Kopfzeile erst in Zeile ' + (hRow+1) + ' gefunden — ' + hRow + ' leere Zeile(n) darueber uebersprungen.');
            if (hRow !== -1) {
                const h = data[hRow].map(x => (x||'').toString().toLowerCase().trim());
                const si=h.indexOf('standort'), ti=h.indexOf('team'), ci=h.indexOf('ccs_user'), ni=h.indexOf('namen');
                const ki=h.indexOf('stack');   // NEUES Format: Stack steht als Spalte im Hauptblatt
                // VO-Spalten einsammeln: "VO_ID"/"vo_nummer" (alt, eine je Zeile) UND
                // "VO_ID1".."VO_ID4" (neu, mehrere je Zeile) -> jede VO zeigt auf denselben Agenten.
                const vis=[]; h.forEach((x,j) => { if (/^vo[_-]?(nummer|id)?\d*$/.test(x)) vis.push(j); });
                for (let i=hRow+1;i<data.length;i++){ const r=data[i]; if(!r||!r.length) continue;
                    const ccs=(r[ci]||'').toString().trim();
                    const info = { name:(r[ni]||'').toString().trim(), team:(r[ti]||'').toString().trim(), standort:(r[si]||'').toString().trim(), ccsId:ccs };
                    if (!info.name) continue;
                    if (ccs) ccsMap[ccs]=info;
                    vis.forEach(j => { const vo=(r[j]||'').toString().trim(); if (vo) voMap[vo]=info; });
                    if (ki!==-1 && info.team) { const st=(r[ki]||'').toString().trim(); if (st) stackMap[info.team]=st; }
                    // Ohne Standorte-Blatt die Abkuerzung aus dem Standort-Namen ableiten
                    if (info.standort) { const abk=normalizeStandort(info.standort); if (abk && abk!=='ALL' && !standortMap[abk]) standortMap[abk]=info.standort; }
                }
            }
            if (s2) {
                const sd = XLSX.utils.sheet_to_json(wb.Sheets[s2], { header:1 });
                if (sd.length) {
                    const h = sd[0].map(x => (x||'').toString().toLowerCase().trim());
                    const ci = h.findIndex(x => x.includes('abk')||x.includes('code')); const ni = h.findIndex(x => !x.includes('abk')&&x.includes('ort'));
                    const cIdx = ci!==-1?ci:1, nIdx = ni!==-1?ni:0;
                    for (let i=1;i<sd.length;i++){ const r=sd[i]; if(!r) continue;
                        const abk=(r[cIdx]||'').toString().toUpperCase().trim(), full=(r[nIdx]||'').toString().trim();
                        if (abk&&full) standortMap[abk]=full;
                    }
                }
            }
            // ALTES Format — Blatt "Stacks_Und_Die_Teams": Standort | Stack | Team.
            // Ergaenzt die Stack-Spalte aus dem Hauptblatt (neues Format), ueberschreibt sie nicht.
            if (s3) {
                const sd = XLSX.utils.sheet_to_json(wb.Sheets[s3], { header:1 });
                if (sd.length) {
                    const h = sd[0].map(x => (x||'').toString().toLowerCase().trim());
                    const si = h.findIndex(x => x.includes('stack')), ti = h.findIndex(x => x.includes('team'));
                    const sIdx = si!==-1?si:1, tIdx = ti!==-1?ti:2;
                    for (let i=1;i<sd.length;i++){ const r=sd[i]; if(!r) continue;
                        const stack=(r[sIdx]||'').toString().trim(), teamId=(r[tIdx]||'').toString().trim();
                        if (stack && teamId) stackMap[teamId]=stack;
                    }
                }
            }
            // Mehrere Mapping-Dateien lassen sich nacheinander importieren: die neue Datei
            // liefert Teams/Stacks, die aeltere die VO-Nummern (die in der neuen fast
            // vollstaendig fehlen). Nur die VO-NUMMERN werden ueber Importe hinweg gesammelt.
            // Die Stammdaten (Agenten/Teams/Stacks) kommen IMMER aus dem zuletzt importierten
            // Stand — wuerde man sie mergen, erschiene ein umbenanntes Team doppelt
            // ("21105083" neben "VKD-TECH-83") und die Zahlen splitten sich darauf auf.
            // Komplett neu anfangen: rcResetMapping() in der Konsole.
            const prev = window.rcWcaMapping || {};
            const nVo = Object.keys(voMap).length;
            let uebernommen = 0;
            if (Object.keys(ccsMap).length && Object.keys(prev.voMap || {}).length) {
                const voAll = Object.assign({}, prev.voMap, voMap);
                voMap = {};
                // Jede VO per CCS-ID an die AKTUELLEN Stammdaten haengen. VOs von Agenten,
                // die es im neuen Stand nicht mehr gibt, fallen weg (ausgeschieden).
                Object.keys(voAll).forEach(vo => {
                    const c = voAll[vo] && voAll[vo].ccsId;
                    if (c && ccsMap[c]) voMap[vo] = ccsMap[c];
                });
                uebernommen = Object.keys(voMap).length - nVo;
            }
            window.rcWcaMapping = { voMap, ccsMap, standortMap, stackMap };
            localStorage.setItem('rcWcaMapping', JSON.stringify(window.rcWcaMapping));
            rcLog.log('Mapping importiert: Blatt "' + s1 + '" · ' + Object.keys(ccsMap).length + ' CCS-IDs · ' +
                Object.keys(voMap).length + ' VO-Nummern' + (uebernommen > 0 ? ' (davon ' + uebernommen + ' aus einem frueheren Import uebernommen)' : '') +
                ' · ' + Object.keys(stackMap).length + ' Teams mit Stack (' +
                ([...new Set(Object.values(stackMap))].sort().join(', ') || 'KEINE') + ')');
            if (!Object.keys(stackMap).length) rcLog.warn('Mapping ohne Stack-Zuordnung — Stack-Filter bleibt deaktiviert. Spalte "Stack" oder Blatt "Stacks_Und_Die_Teams" fehlt.');
            if (!Object.keys(voMap).length) rcLog.warn('Mapping ohne VO-Nummern — ESL-Verkaufsdaten koennen keinem Agenten zugeordnet werden. Spalte "VO_ID"/"VO_ID1..4" fehlt.');
            // Agenten ohne VO koennen keine ESL-Verkaeufe erhalten -> fruehzeitig sichtbar machen
            const mitVo = new Set();
            Object.keys(voMap).forEach(vo => { const c = voMap[vo] && voMap[vo].ccsId; if (c) mitVo.add(String(c)); });
            const fehlt = Object.keys(ccsMap).filter(c => !mitVo.has(String(c))).length;
            if (fehlt) rcLog.warn(fehlt + ' von ' + Object.keys(ccsMap).length + ' Agenten haben KEINE VO-Nummer — ihre ESL-Verkaeufe (BNT/VVL/Ansprache) bleiben leer.' +
                (uebernommen > 0 ? ' Diese Agenten fehlen auch in der zuvor geladenen VO-Datei (z.B. Neuzugaenge).'
                                 : ' Zusaetzlich eine Mapping-Datei mit gefuellten VO-Spalten laden — sie ergaenzt die aktuelle, ersetzt sie nicht.'));
            // Vortage, die mit einem unvollstaendigen Mapping archiviert wurden, jetzt nachziehen
            if (window.rcRepairEslHistory) window.rcRepairEslHistory();
            updateStackFilterOptions();
            window.closeMappingModal();
            if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        } catch(e){ rcLog.error('Mapping-Fehler:', e); }
    }

    // Mapping komplett verwerfen — noetig, wenn Importe sich widersprechen (z.B. ein Team
    // wurde umbenannt UND die alte VO-Datei haengt noch daran). Danach neu importieren.
    window.rcResetMapping = function(){
        window.rcWcaMapping = null;
        try { localStorage.removeItem('rcWcaMapping'); } catch(e){}
        if (window.updateStackFilterOptions) window.updateStackFilterOptions();
        rcLog.log('Mapping verworfen. Jetzt die Mapping-Datei(en) neu importieren.');
    };

    // Stack-Dropdown aus dem Mapping befuellen (Stacks = getrennte Abteilungen)
    // Aktiven Filter sichtbar markieren (roter Rahmen) + Reset-Button ein/aus
    function rcMarkFilters(){
        let any = false;
        ['rcStandortFilter','rcStackFilter','rcTeamFilter'].forEach(id => {
            const el = document.getElementById(id); if (!el) return;
            const on = !el.disabled && el.value && el.value !== 'ALL';
            el.classList.toggle('rc-flt-on', on);
            if (on) any = true;
        });
        const rst = document.getElementById('rcFltReset'); if (rst) rst.style.display = any ? '' : 'none';
    }
    window.rcMarkFilters = rcMarkFilters;

    function updateStackFilterOptions(){
        const sel = document.getElementById('rcStackFilter');
        if (!sel) return;
        const stacks = [...new Set(Object.values((window.rcWcaMapping && window.rcWcaMapping.stackMap) || {}))].filter(Boolean).sort();
        const cur = sel.value;
        if (stacks.length) {
            sel.innerHTML = '<option value="ALL">Alle Stacks</option>' + stacks.map(s => `<option value="${s}">${s}</option>`).join('');
            sel.value = stacks.includes(cur) ? cur : 'ALL';
            sel.disabled = false;
        } else {
            sel.innerHTML = '<option value="ALL">Alle Stacks (Mapping laden)</option>';
            sel.value = 'ALL'; sel.disabled = true;
        }
        sel.style.display = '';   // Stack-Filter NIE verstecken — er ist immer sichtbar
        rcMarkFilters();
    }
    window.updateStackFilterOptions = updateStackFilterOptions;  // nach Mapping-Import erneut aufrufbar
    updateStackFilterOptions();
    document.getElementById('rcStackFilter').addEventListener('change', () => {
        const ts = document.getElementById('rcTeamFilter'); if (ts) { ts.value = 'ALL'; ts.dataset.sig = ''; }
        if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        rcMarkFilters();
    });
    document.getElementById('rcFltReset').addEventListener('click', () => {
        ['rcStandortFilter','rcStackFilter','rcTeamFilter'].forEach(id => { const el = document.getElementById(id); if (el && !el.disabled) { el.value = 'ALL'; el.dataset.sig = ''; } });
        if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        rcMarkFilters();
    });
    document.getElementById('ckBtnExport').addEventListener('click', () => { if (window.rcExportReport) window.rcExportReport(); });
    document.getElementById('ckBtnStandTag').addEventListener('click', () => { if (window.rcOpenStandExport) window.rcOpenStandExport(); });
    // Team-Vergleich sortierbar: Klick auf einen Spaltenkopf sortiert die Rangliste
    (function(){
        const thead = document.querySelector('.rc-ck-teamtable thead');
        if (!thead) return;
        thead.addEventListener('click', e => {
            const th = e.target.closest('[data-ck-sort]'); if (!th) return;
            const key = th.dataset.ckSort;
            const cur = window.rcCkTeamSort || { key:'bcrBnt', dir:'asc' };
            // gleiche Spalte -> Richtung umkehren; neue Spalte -> absteigend (hoechste zuerst), Name aufsteigend
            window.rcCkTeamSort = { key, dir: (cur.key === key) ? (cur.dir === 'asc' ? 'desc' : 'asc') : (key === 'name' ? 'asc' : 'desc') };
            if (window.renderCockpit) window.renderCockpit();
        });
    })();
    // Trend-Zeitraum: 3 oder 7 Tage
    [['rcHistBtn3', 3], ['rcHistBtn7', 7]].forEach(([id, n]) => {
        const b = document.getElementById(id); if (!b) return;
        b.addEventListener('click', () => {
            window.rcHistDays = n;
            document.getElementById('rcHistBtn3').classList.toggle('active', n === 3);
            document.getElementById('rcHistBtn7').classList.toggle('active', n === 7);
            if (window.renderTrendHist) window.renderTrendHist();
        });
    });

    // ============================================================
    //  COCKPIT v2 — Drilldown- & Umschalter-Verdrahtung (Delegation auf stabile Container)
    // ============================================================
    window.rcCkExpStd   = window.rcCkExpStd   || new Set();
    window.rcCkExpTeam  = window.rcCkExpTeam  || new Set();
    window.rcCkExpCross = window.rcCkExpCross || new Set();
    (function(){
        const mx = document.getElementById('rcCkMatrix');
        if (mx) mx.addEventListener('click', e => {
            const tg = e.target.closest('[data-ck-toggle]'); if (!tg) return;
            const v = tg.dataset.ckToggle;
            if (v.indexOf('std:') === 0)  { const c = v.slice(4); window.rcCkExpStd.has(c)  ? window.rcCkExpStd.delete(c)  : window.rcCkExpStd.add(c); }
            else if (v.indexOf('team:') === 0){ const c = v.slice(5); window.rcCkExpTeam.has(c) ? window.rcCkExpTeam.delete(c) : window.rcCkExpTeam.add(c); }
            if (typeof renderCkMatrix === 'function') renderCkMatrix();
        });
        const mh = document.getElementById('rcCkMatrixHead');
        if (mh) mh.addEventListener('click', e => {
            const th = e.target.closest('[data-ck-msort]'); if (!th) return;
            const key = th.dataset.ckMsort;
            const cur = window.rcCkMatrixSort || { key:'gesamt', dir:'desc' };
            window.rcCkMatrixSort = { key, dir: (cur.key === key) ? (cur.dir === 'asc' ? 'desc' : 'asc') : (key === 'name' ? 'asc' : 'desc') };
            if (typeof renderCkMatrix === 'function') renderCkMatrix();
        });
        const tabs = document.getElementById('rcCkTrendTabs');
        if (tabs) tabs.addEventListener('click', e => {
            const b = e.target.closest('[data-ck-metric]'); if (!b) return;
            window.rcCkTrendMetric = b.dataset.ckMetric;
            tabs.querySelectorAll('[data-ck-metric]').forEach(x => x.classList.toggle('active', x === b));
            if (typeof renderCkTrend === 'function') renderCkTrend();
        });
        const cx = document.getElementById('rcCkCross');
        if (cx) cx.addEventListener('click', e => {
            const tg = e.target.closest('[data-ck-cross]'); if (!tg) return;
            const c = tg.dataset.ckCross;
            window.rcCkExpCross.has(c) ? window.rcCkExpCross.delete(c) : window.rcCkExpCross.add(c);
            if (typeof renderCkCross === 'function') renderCkCross();
        });
    })();

    // ============================================================
    //  UHR + MOTIVATIONS-SPRUECHE
    // ============================================================
    function tickClock(){
        const n = new Date();
        const c=document.getElementById('rcClock'), d=document.getElementById('rcClockDate');
        if (c) c.textContent = n.toLocaleTimeString('de-DE');
        if (d) d.textContent = n.toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit',year:'numeric'});
        // Zugzwang-Timer: wie lange wartet die Arena schon auf den naechsten Abschluss?
        const ls = document.getElementById('rcLastSale');
        if (ls) {
            if (!window.rcLastSaleTs) { ls.textContent = ''; ls.className = 'rc-lastsale'; }
            else {
                const diff = Math.max(0, Math.floor((Date.now() - window.rcLastSaleTs) / 1000));
                const mm = Math.floor(diff/60), ss = diff % 60;
                ls.textContent = 'Letzter Abschluss vor ' + mm + ':' + pad2(ss) + ' Min';
                ls.className = 'rc-lastsale' + (mm >= 25 ? ' hot' : (mm >= 15 ? ' warn' : ''));
            }
        }
    }
    window.rcClockInterval = setInterval(tickClock, 1000); tickClock();

    window.rcMotiSprueche = [
        'Jeder Anruf ist eine neue Chance — pack ihn',
        'KIP und Mobilfunk zaehlen doppelt fuers Team',
        'Wer heute dranbleibt, steht morgen ganz oben',
        'Ein Laecheln hoert man auch am Telefon',
        'Der naechste Abschluss wartet nur auf dich',
        'Teamgeist schlaegt Einzelkaempfer — gemeinsam nach vorn'
    ];
    let motiIdx = 0;
    window.rcSprucheInterval = setInterval(() => {
        const el = document.getElementById('rcMotiText'); if (!el) return;
        // abwechselnd echter Datenspruch (falls vorhanden) und Standardspruch
        let line;
        if (window.rcDynamicMoti && window.rcDynamicMoti.length && motiIdx % 2 === 0) {
            line = window.rcDynamicMoti[Math.floor(Math.random()*window.rcDynamicMoti.length)];
        } else {
            line = window.rcMotiSprueche[motiIdx % window.rcMotiSprueche.length];
        }
        el.style.opacity = 0;
        setTimeout(() => { el.innerHTML = line; el.style.opacity = 1; }, 300);
        motiIdx++;
    }, 6500);

    // ============================================================
    //  ZAHLEN-ANIMATION (Count-up)
    // ============================================================
    function setNum(el, n){ const v = n.toLocaleString('de-DE');
        if (el.firstChild && el.firstChild.nodeType === 3) el.firstChild.nodeValue = v; else el.textContent = v; }
    function animateCount(el, to) {
        if (!el) return;
        to = Math.round(to || 0);
        const from = parseInt(el.dataset.v || '0') || 0;
        el.dataset.v = to;
        el.style.animation = 'none'; void el.offsetHeight; el.style.animation = 'rc-kpi-flash 0.5s ease-out';
        if (from === to) { setNum(el, to); return; }
        const dur = 650, st = performance.now();
        // Backstop: garantiert den Endwert, auch wenn requestAnimationFrame pausiert (Tab im Hintergrund)
        setTimeout(() => { if (parseInt(el.dataset.v) === to) setNum(el, to); }, dur + 140);
        (function step(now){
            const p = Math.min((now-st)/dur, 1), e = 1-Math.pow(1-p,3);
            if (parseInt(el.dataset.v) !== to) return; // neuere Animation hat uebernommen
            setNum(el, Math.round(from + (to-from)*e));
            if (p < 1) requestAnimationFrame(step);
        })(performance.now());
    }

    // ============================================================
    //  TOASTS + KONFETTI
    // ============================================================
    // Abschluss-Buehne fuer NEUE Verkaeufe: Kriegs-Fanfare statt Fussball-Jubel
    // (die Leute sind KRIEGER, keine Fussballer). count = wievielter Abschluss
    // des Agenten heute -> TREFFER / DOPPELSCHLAG / DREIFACHSCHLAG.
    // compact=true: kleine, dezente Karte (laeuft ohne Standort-Filter —
    // die grosse Vollbild-Show gibt es nur fuer den eigenen Standort).
    function showGoal(name, produkt, code, timeStr, count, onDone, compact){
        const meta = STANDORT_METADATA[code];
        const city = meta ? meta.name.toUpperCase() : code;
        // TOP-Highlight nur fuer die staerksten BCR-Produkte (KIP-BNT / Mobilfunk-BNT)
        const special = /KIP BNT|MOBILFUNK BNT/i.test(produkt);
        const streak = (count||1) >= 3 ? 3 : ((count||1) === 2 ? 2 : 1);
        const flash = document.createElement('div');
        flash.className = 'rc-goal-flash' + (special ? ' special' : '');
        if (!compact) { document.body.appendChild(flash); setTimeout(() => flash.remove(), 900); }
        const stage = document.createElement('div');
        stage.className = 'rc-goal-stage' + (compact ? ' compact' : '');
        const g = document.createElement('div');
        const kingCls = /KIP BNT/i.test(produkt) ? ' king-kip' : (/MOBILFUNK BNT/i.test(produkt) ? ' king-mob' : '');
        g.className = 'rc-toast-goal' + (special ? ' special' : '') + (streak === 3 ? ' streak3' : '') + kingCls + (compact ? ' compact' : '');
        const head = streak === 3 ? 'DREIFACHSCHLAG' : (streak === 2 ? 'DOPPELSCHLAG' : (special ? 'VOLLTREFFER' : 'TREFFER'));
        const sub = streak > 1 ? `<div class="rc-goal-sub">${count}. Schlag heute</div>` : '';
        const zeit = timeStr || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
        // Kriegs-Badge: Schild mit gekreuzten Schwertern (Flat-Line, kein Emoji)
        const bsz = compact ? 52 : 76;
        const badgeSvg = `<svg viewBox="0 0 96 96" width="${bsz}" height="${bsz}" style="display:block; margin:0 auto;">
            <path d="M48 8 L80 18 L80 46 C80 66 66 80 48 89 C30 80 16 66 16 46 L16 18 Z"
                fill="none" stroke="#FFFFFF" stroke-width="4" stroke-linejoin="round" opacity="0.92"/>
            <g stroke="#FFFFFF" stroke-width="4.5" stroke-linecap="round">
                <line x1="31" y1="30" x2="63" y2="62"/><line x1="65" y1="30" x2="33" y2="62"/>
            </g>
            <g stroke="#FFFFFF" stroke-width="3.4" stroke-linecap="round" opacity="0.95">
                <line x1="27" y1="64" x2="39" y2="56"/><line x1="69" y1="64" x2="57" y2="56"/>
                <line x1="29" y1="26" x2="35" y2="32"/><line x1="67" y1="26" x2="61" y2="32"/>
            </g>
            <g stroke="#FFFFFF" stroke-width="2.6" stroke-linecap="round" opacity="0.6">
                <line x1="48" y1="0" x2="48" y2="7"/><line x1="20" y1="6" x2="24" y2="12"/><line x1="76" y1="6" x2="72" y2="12"/>
            </g></svg>`;
        const dmgLine = (special && window.rcWar && window.rcWar.balance)
            ? `<div class="rc-goal-sub" style="margin-top:10px; color:#FFD700;">DEIN WERT HEUTE: +${/KIP/i.test(produkt) ? ((window.rcWar.score&&window.rcWar.score.kip)||35) : ((window.rcWar.score&&window.rcWar.score.mob)||30)} PUNKTE FUER DEINE BURG</div>`
            : '';
        g.innerHTML = `${badgeSvg}
            <div class="rc-goal-head">${head}</div>
            ${sub}
            <div class="rc-goal-time">${zeit} Uhr</div>
            <div class="rc-goal-city">${getFlagSvg(code, compact ? 'large' : 'xl', true)} ${city}</div>
            <div class="rc-goal-name"><b>${name}</b> <span style="color:rgba(255,255,255,0.72); font-size:${compact ? 13 : 18}px;">(${code})</span></div>
            <div class="rc-goal-prod">schlaegt zu mit <b>${produkt}</b></div>${dmgLine}`;
        stage.innerHTML = compact ? '' : `<i class="rc-goal-ring"></i><i class="rc-goal-ring rg2"></i>`;
        stage.appendChild(g);
        // ---- Wegklicken: Close-Button (X), Klick irgendwo auf die Buehne, oder ESC ----
        const closeBtn = document.createElement('button');
        closeBtn.type = 'button'; closeBtn.className = 'rc-goal-close';
        closeBtn.setAttribute('aria-label', 'Schliessen'); closeBtn.title = 'Schliessen (ESC)';
        closeBtn.innerHTML = '&#10005;';
        stage.appendChild(closeBtn);
        const hint = document.createElement('div');
        hint.className = 'rc-goal-dismiss-hint';
        hint.textContent = 'Klicken oder ESC zum Schliessen';
        stage.appendChild(hint);
        document.body.appendChild(stage);
        let autoTimer = null, closed = false;
        function dismissGoal(){
            if (closed) return; closed = true;
            clearTimeout(autoTimer);
            document.removeEventListener('keydown', onGoalKey);
            stage.style.animation = 'rc-stage-out 0.45s forwards';
            g.style.animation = 'rc-goal-out 0.45s forwards';
            setTimeout(() => { stage.remove(); if (typeof onDone === 'function') onDone(); }, 450);
        }
        function onGoalKey(e){ if (e.key === 'Escape') dismissGoal(); }
        document.addEventListener('keydown', onGoalKey);
        stage.addEventListener('click', dismissGoal); // Klick irgendwo (inkl. Karte/Button) schliesst
        // Konfetti monochrom: Electric Red, Weiss, Hellrot, Hellgrau (compact: nur eine kleine Salve)
        const VF_CONFETTI = ['#E60000','#FFFFFF','#FF6666','#BEBEBE'];
        if (window.confetti) {
            if (compact) confetti({ particleCount:55, spread:60, origin:{y:0.6}, colors:VF_CONFETTI });
            else if (special || streak > 1) { confetti({particleCount:170,spread:100,origin:{y:0.6},colors:VF_CONFETTI}); setTimeout(()=>confetti({particleCount:120,spread:120,origin:{y:0.5},colors:VF_CONFETTI}),350); setTimeout(()=>confetti({particleCount:120,spread:80,origin:{y:0.7},colors:VF_CONFETTI}),800); }
            else confetti({ particleCount:110, spread:85, origin:{y:0.6}, colors:VF_CONFETTI });
        }
        if (streak === 3 && window.confetti && !compact) setTimeout(()=>confetti({particleCount:180,spread:140,origin:{y:0.45},colors:VF_CONFETTI}),1300);
        const dur = compact ? 3200 : (streak === 3 ? 8000 : (special || streak === 2 ? 6500 : 4800));
        autoTimer = setTimeout(dismissGoal, dur); // Auto-Schliessen, sofern nicht weggeklickt
    }

    // Feier-Queue: NUR echte Abschluesse (Rueckblick-Toasts wurden entfernt — wirkten unklar/unprofessionell)
    window.rcCelebrationQueue = []; window.rcIsCelebrating = false;
    function queueCelebration(name, prod, standort, timeStr, count, compact){
        window.rcCelebrationQueue.push({name,prod,standort,timeStr,count,compact});
        processCelebrationQueue();
    }
    window.rcQueueCelebration = queueCelebration; // Debug/QA: Feier-Buehne testen (rcQueueCelebration('Name','KIP BNT','AL','10:05',2))
    function processCelebrationQueue(){
        if (window.rcIsCelebrating || !window.rcCelebrationQueue.length) return;
        window.rcIsCelebrating = true;
        const it = window.rcCelebrationQueue.shift();
        // onDone feuert, sobald das Popup verschwindet (Auto-Timeout ODER Wegklicken) —
        // so rueckt die naechste Feier beim Wegklicken sofort nach statt fix zu warten.
        showGoal(it.name, it.prod, it.standort, it.timeStr, it.count, () => {
            window.rcIsCelebrating = false;
            processCelebrationQueue();
        }, it.compact);
    }
    window.simulateFakeSale = function(){
        const names=["Deniz T.","Ahmet A.","Ebru D.","Oezlem T.","Saray S.","Yeliz A.","Uemit D.","Lara D.","Cihan G."];
        const st=["AL","SER","ADP","B","P","E","ZWT"]; const pr=["Kip BNT","Mobilfunk BNT","Env BNT","VVL (Up-Selling)"];
        const cnt = 1 + (Math.random()*3|0); // 1..3 -> zeigt auch DOPPELPACK/HATTRICK
        queueCelebration(names[Math.random()*names.length|0], pr[Math.random()*pr.length|0], st[Math.random()*st.length|0], new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}), cnt);
    };

    // ============================================================
    //  DATUM / ZEIT
    // ============================================================
    function parseDateTime(rawVal){
        if (rawVal === '' || rawVal == null) return null;
        if (typeof rawVal === 'number') { const d = new Date(Math.round((rawVal-25569)*86400*1000)); return isNaN(d)?null:{date:d, hasTime:(rawVal%1!==0)}; }
        const str = rawVal.toString().trim();
        const tm = str.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
        if (tm) { const t=new Date(); return {date:new Date(t.getFullYear(),t.getMonth(),t.getDate(),+tm[1],+tm[2],tm[3]?+tm[3]:0), hasTime:true}; }
        const dtm = str.match(/(\d{1,2})[.\/](\d{1,2})[.\/](\d{2,4})[ T]+(\d{1,2}):(\d{2})/);
        if (dtm) { let y=+dtm[3]; if(y<100)y+=2000; return {date:new Date(y,dtm[2]-1,+dtm[1],+dtm[4],+dtm[5]), hasTime:true}; }
        const d = new Date(str);
        if (!isNaN(d)) return {date:d, hasTime:str.includes(':')};
        return null;
    }
    const pad2 = n => n.toString().padStart(2,'0');
    const getTimeString = d => d ? `${pad2(d.getHours())}:${pad2(d.getMinutes())}` : '';

    // ============================================================
    //  KATEGORISIERUNG
    // ============================================================
    // Gibt zurueck: {cat, isBnt, isVvl}  cat in kip|mob|env|fibDsl|ptv|sonstBnt|kipVvl|mobVvl|fibVvl|null
    function classify(pgRaw){
        const pg = (pgRaw||'').toString().toUpperCase();
        if (pg.includes('VVL')) {
            if (pg.includes('MOBILFUNK')) return {cat:'mobVvl', isBnt:false, isVvl:true};
            if (pg.includes('KIP')) return {cat:'kipVvl', isBnt:false, isVvl:true};
            return {cat:'fibVvl', isBnt:false, isVvl:true};
        }
        if (pg.includes('KIP') && pg.includes('BNT')) return {cat:'kip', isBnt:true, isVvl:false};
        if (pg.includes('MOBILFUNK') && pg.includes('BNT')) return {cat:'mob', isBnt:true, isVvl:false};
        if (pg.includes('ENV') && pg.includes('BNT')) return {cat:'env', isBnt:true, isVvl:false};
        if (pg.includes('DSL')||pg.includes('FIB')||pg.includes('KABEL')||pg.includes('GLASFASER')) return {cat:'fibDsl', isBnt:true, isVvl:false};
        if (pg.includes('PTV')||pg.includes('PREMIUM')) return {cat:'ptv', isBnt:true, isVvl:false};
        if (pg.includes('BNT')) return {cat:'sonstBnt', isBnt:true, isVvl:false};
        return {cat:null, isBnt:false, isVvl:false};
    }
    const bntOf = o => (o.kip||0)+(o.mob||0)+(o.env||0)+(o.fibDsl||0)+(o.ptv||0)+(o.sonstBnt||0);
    const vvlOf = o => (o.kipVvl||0)+(o.mobVvl||0)+(o.fibVvl||0);
    // OPTION B — Gewichtete Tageswertung: EIN Ziel, ein Punktesystem. Wert je Abschluss.
    // Live tunable via Konsole: rcWar.score.kip = 40 (o.ae.). scoreOf() liest immer live.
    const RC_WAR_SCORE = { kip:35, mob:30, env:20, fibDsl:20, ptv:20, sonstBnt:20, kipVvl:15, mobVvl:15, fibVvl:15 };
    const scoreOf = o => (o.kip||0)*RC_WAR_SCORE.kip + (o.mob||0)*RC_WAR_SCORE.mob + (o.env||0)*RC_WAR_SCORE.env
        + (o.fibDsl||0)*RC_WAR_SCORE.fibDsl + (o.ptv||0)*RC_WAR_SCORE.ptv + (o.sonstBnt||0)*RC_WAR_SCORE.sonstBnt
        + (o.kipVvl||0)*RC_WAR_SCORE.kipVvl + (o.mobVvl||0)*RC_WAR_SCORE.mobVvl + (o.fibVvl||0)*RC_WAR_SCORE.fibVvl;
    // ---- BCR-Relevanz (zentrale Definition) ----
    // BCR (Brutal Conversion Rate): ob ein Produkt in die KPI eingeht, steht direkt
    // in der ESL-Spalte "produktmerkmal" ("BCR-relevant" / "nicht BCR-relevant") und
    // ist UNABHAENGIG von BNT/VVL — eine KIP-VVL kann BCR-relevant, eine PTV-VVL oder
    // ein NBA-Tipp nicht BCR-relevant sein. Die Zaehler o.bcr / o.nonBcr werden pro
    // Verkaufszeile aus dem Produktmerkmal befuellt (siehe processDataStream).
    const bcrOf    = o => o.bcr || 0;
    const nonBcrOf = o => o.nonBcr || 0;
    // Anteil der Nicht-BCR-Abschluesse (0..1); ab RC_NONBCR_WARN gilt es als zu hoch.
    const RC_NONBCR_WARN = 0.5;
    const nonBcrShare = o => { const b = bcrOf(o), v = nonBcrOf(o), t = b + v; return t > 0 ? v / t : 0; };

    // ============================================================
    //  HAUPT-VERARBEITUNG
    // ============================================================
    if (!window.rcCelebratedSales) window.rcCelebratedSales = new Set(); // schon gefeierte Verkaufszeilen (id|kategorie|menge)
    window.rcIsInitialized = false;
    window.rcNewsHistorie = [];
    window.rcMarqueeBuffer = [];
    window.rcRowHourMap = window.rcRowHourMap || new Map();

    window.processDataStream = function(sheetData) {
      try {
        if (!sheetData || !Array.isArray(sheetData) || !sheetData.length) return;
        window.rcLetzterDatenstrom = sheetData;
        window.rcAllSales = [];
        window.rcAllRejections = [];   // je Ablehnung: {name,vo,team,standort,timeStr,grund} — fuer den Klick auf "Ablehnungen"
        const filterVal = document.getElementById('rcStandortFilter').value;
        const teamSel = document.getElementById('rcTeamFilter');
        const filterTeam = (filterVal !== 'ALL' && teamSel) ? teamSel.value : 'ALL';
        const stackSel = document.getElementById('rcStackFilter');
        const filterStack = stackSel ? stackSel.value : 'ALL';
        const mapping = window.rcWcaMapping;
        const stackMap = (mapping && mapping.stackMap) || {};
        const stackOf = t => stackMap[(t||'').toString().trim()] || '';
        window.rcStackOf = stackOf; // fuer Qualitaet/Cockpit
        const teamsByStd = {}; // { code: Set(team) }  fuer das Team-Dropdown
        const teamVoByStd = {}; // { code|team: Set(vo) } — wie viele ESL-Agenten hat ein Team wirklich?

        // Spalten-Indizes (Defaults + Header-Erkennung)
        let idx = { datum:0, standort:1, team:2, vo:3, kunde:4, prod:5, merkmal:6, erg:8, anz:9, grund:-1, ansp:-1, id:-1 };
        const h = sheetData[0].map(x => (x||'').toString().toLowerCase().trim());
        const set = (key, ...names) => { for (const nm of names){ const i = h.indexOf(nm); if (i!==-1){ idx[key]=i; return; } } };
        set('datum','datum'); set('standort','standort'); set('team','team'); set('vo','vo_nummer','vo-nummer','vo');
        set('kunde','kunde','kundenname','customer');
        set('prod','produktgruppe','produktgrupe','produktgruppen'); set('erg','ergebnis','status'); set('anz','anzahl','anz');
        set('merkmal','produktmerkmal','merkmal'); set('ansp','sis_angesprochen','angesprochen'); set('id','id');
        const gi = h.findIndex(x => x.includes('nicht_moeglich')||x.includes('nicht moeglich')||x.includes('grund')); if (gi!==-1) idx.grund=gi;

        // SCHUTZ: Enthaelt der Datenstrom MEHRERE Tage (Portal-Zeitraum verstellt,
        // z.B. nach einem Bereichs-Export), zaehlt die Live-Sicht STRIKT nur HEUTE —
        // Wochensummen duerfen nie als Tageswerte erscheinen ("5000 TX"-Bug).
        // Die Vortage-Zeilen werden nicht verworfen, sondern sofort in die
        // Trend-Historie (rcEslHistory) uebernommen.
        window.rcMultiDayWarn = '';
        if (idx.datum !== -1 && sheetData.length > 1) {
            const tdK = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date());
            const byDayRows = {};
            const heuteRows = [];
            for (let i = 1; i < sheetData.length; i++) {
                const r = sheetData[i]; if (!r) continue;
                const dk = rcRowDayKey(r, idx);
                if (!dk || dk === tdK) heuteRows.push(r);
                else (byDayRows[dk] || (byDayRows[dk] = [])).push(r);
            }
            const fremd = Object.keys(byDayRows);
            if (fremd.length) {
                try { // Vortage direkt archivieren (gleiche Datenbasis wie der Harvester)
                    const histX = JSON.parse(localStorage.getItem('rcEslHistory') || '{}');
                    fremd.forEach(dk => {
                        const agg = rcNewAgg();
                        byDayRows[dk].forEach((r, i2) => rcAccumRow(agg, r, idx, i2));
                        rcFinalizeAgg(agg, dk);
                        if (!histX[dk] || (histX[dk].kontakte || 0) <= agg.kontakte) histX[dk] = agg;
                    });
                    Object.keys(histX).sort().slice(0, -40).forEach(k => delete histX[k]);
                    localStorage.setItem('rcEslHistory', JSON.stringify(histX));
                    window.rcEslHistory = histX;
                } catch(e){}
                window.rcMultiDayWarn = 'Portal-Zeitraum umfasst ' + (fremd.length + 1) + ' Tage — Live-Ansicht zaehlt NUR heute (' +
                    heuteRows.length + ' Zeilen); ' + fremd.length + ' Vortag(e) wurden in die Trend-Historie uebernommen. Im Portal von/bis auf heute stellen.';
                rcLog.warn('Mehrtages-Daten erkannt (' + fremd.sort().join(', ') + ') — Live nur heute, Vortage archiviert.');
                sheetData = [sheetData[0]].concat(heuteRows);
                if (window.renderTrendHist) window.renderTrendHist();
            }
        }

        const agentStats = {}, standortStats = {}, teamStats = {};
        // UNGEFILTERTE Kriegskarten-Daten: die Schlacht auf dem Radar zeigt IMMER
        // alle Standorte (sonst hat der gefilterte Standort keinen Gegner und die
        // Soldaten der anderen verschwinden). Der Standort-/Stack-/Team-Filter wirkt
        // nur auf die Seiten-Panels, NICHT auf das Schlachtfeld selbst.
        const warStdFull = {}, warAgentAnspr = {};
        function ensureWarStd(code){ return warStdFull[code] || (warStdFull[code] =
            { code, total:0, kip:0, mob:0, bnt:0, vvl:0, bcr:0, nonBcr:0, pitches:0, _a:null }); }
        const nationStats = { TR:blankNation(), GR:blankNation(), DE:blankNation(), AT:blankNation() };
        const rejReasons = {}; // Ablehnungsgruende (Pareto fuers Cockpit)
        let gBnt=0, gRej=0, gVvl=0, gKip=0, gMob=0, gOffers=0, gBcr=0, gNonBcr=0;
        // Kontakte/Ansprachen/Ablehnungen = EINDEUTIGE Kontakte (eine id kann mehrere Produktzeilen haben)
        const gCallIds = new Set(), gAnspIds = new Set(), gRejIds = new Set();

        const isFirstRun = (window.rcIsInitialized !== true);
        const now = new Date(), oneHourAgo = new Date(now.getTime()-3600000);
        const startHour = 8, currentHour = now.getHours();
        const loHour = Math.min(startHour, currentHour);
        const hourLabels = []; for (let hh=loHour; hh<=currentHour; hh++) hourLabels.push(pad2(hh)+':00');
        const trend = { total:new Array(hourLabels.length).fill(0), bnt:new Array(hourLabels.length).fill(0),
                        kip:new Array(hourLabels.length).fill(0), mob:new Array(hourLabels.length).fill(0), vvl:new Array(hourLabels.length).fill(0) };
        const anspTrend = new Array(hourLabels.length).fill(0); // Ansprachen je Stunde (fuer das dynamische Diagramm)
        const trendByStd = {}; // { code: [Abschluesse je Stunde] } — Linien je Standort

        // Stunden-Zuordnung eines Kontakts (echte Zeit > gemerkte Stunde > aktuelle Stunde)
        function hourOf(rowId, dObj){
            if (dObj && dObj.hasTime) return dObj.date.getHours();
            if (window.rcRowHourMap.has(rowId)) return window.rcRowHourMap.get(rowId);
            let hv;
            if (isFirstRun) { let s=0; for(let k=0;k<rowId.length;k++) s+=rowId.charCodeAt(k); hv = loHour + (s % hourLabels.length); }
            else hv = currentHour;
            window.rcRowHourMap.set(rowId, hv);
            return hv;
        }

        function blankNation(){ return { anzahl:0, kip:0, mob:0, bnt:0, vvl:0 }; }
        function ensureStd(code, meta){ if (!standortStats[code]) standortStats[code] = { code, name:meta?meta.name:code,
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, calls:0,pitches:0,rejections:0,accepted:0 }; return standortStats[code]; }
        function ensureTeam(teamId, code){ if (!teamStats[teamId]) teamStats[teamId] = { code:teamId, name:teamId, standort:code,
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, calls:0,pitches:0,rejections:0,accepted:0 }; return teamStats[teamId]; }
        function ensureAgent(vo, name, team, code, ccsId){ if (!agentStats[vo]) agentStats[vo] = { vo, name, team, standort:code, ccsId:ccsId||'',
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, ansprachen:0 };
            else if (ccsId && !agentStats[vo].ccsId) agentStats[vo].ccsId = ccsId;
            return agentStats[vo]; }

        // ---- Team-Nummer-Bruecke (gegen Team-AUFSPALTUNG) ----
        // Der ESL-Export liefert den Team-NAMEN ("Vodafone AL 02"), das Mapping die
        // Team-NUMMER (21105082). Ist nur EIN TEIL der Agenten eines Teams gemappt,
        // bekaemen die gemappten die Nummer als Aggregat-Schluessel, die ungemappten
        // den Roh-Namen -> DASSELBE Team erschiene zweimal (Nummer + Name) mit halben
        // Werten, und die Namens-Zeile ohne Liga-Calls (Liga-Join laeuft ueber Nummer).
        // Loesung: aus den GEMAPPTEN Agenten je Roh-Teamname die dominante Nummer
        // ableiten und sie fuer ALLE Agenten dieses Teams als Schluessel verwenden.
        const teamNrBridge = {};
        if (mapping && (mapping.voMap || mapping.ccsMap)) {
            const cnt = {};
            for (let bi = 1; bi < sheetData.length; bi++) {
                const br = sheetData[bi]; if (!br) continue;
                const traw = (br[idx.team]||'').toString().trim();
                const bvo = (br[idx.vo]||'').toString().trim();
                if (!traw || !bvo) continue;
                const bm = (mapping.voMap && mapping.voMap[bvo]) || (mapping.ccsMap && mapping.ccsMap[bvo]);
                if (bm && bm.team) { (cnt[traw] || (cnt[traw] = {}))[bm.team] = (cnt[traw][bm.team] || 0) + 1; }
            }
            Object.keys(cnt).forEach(traw => {
                const best = Object.keys(cnt[traw]).sort((a,b) => cnt[traw][b] - cnt[traw][a])[0];
                if (best) teamNrBridge[traw] = best;
            });
        }

        for (let i=1;i<sheetData.length;i++){
            const row = sheetData[i];
            if (!row || row.length <= Math.max(idx.standort, idx.vo, idx.prod, idx.erg, idx.anz)) continue;

            const datumRaw = (row[idx.datum]||'').toString().trim();
            let standortRaw = (row[idx.standort]||'').toString().toUpperCase().trim();
            let teamRaw = (row[idx.team]||'').toString().trim();
            const voRaw = (row[idx.vo]||'').toString().trim();
            const prodRaw = (row[idx.prod]||'').toString().trim();
            const ergRaw = (row[idx.erg]||'').toString().trim();
            const ergL = ergRaw.toLowerCase();
            const anzahl = parseInt(row[idx.anz]) || 0;
            const angesprochen = idx.ansp!==-1 ? (row[idx.ansp]||'').toString().toLowerCase().trim() : '';
            // BCR-Relevanz kommt direkt aus der Spalte "produktmerkmal" ("BCR-relevant" /
            // "nicht BCR-relevant") — unabhaengig von BNT/VVL. Nur explizit "nicht BCR"
            // gilt als nicht relevant; fehlt die Spalte, zaehlt alles als BCR (neutraler Fallback).
            const merkmalL = idx.merkmal!==-1 ? (row[idx.merkmal]||'').toString().toLowerCase() : '';
            const isBcr = !/nicht\s*bcr/.test(merkmalL);

            let code = normalizeStandort(standortRaw);
            // Team-Schluessel: Mapping-Nummer des Agenten > Bruecke (Team-Nr aus
            // gemappten Kollegen) > Roh-Name. So landet ein Team IMMER unter genau
            // einem Schluessel (keine Aufspaltung mehr).
            let realName = voRaw, team = teamNrBridge[teamRaw] || teamRaw, realCcs = '';
            if (mapping && (mapping.voMap || mapping.ccsMap)) {
                const m = (mapping.voMap && mapping.voMap[voRaw]) || (mapping.ccsMap && mapping.ccsMap[voRaw]);
                if (m) { realName = m.name || voRaw; team = m.team || teamNrBridge[teamRaw] || teamRaw; if (m.standort) code = normalizeStandort(m.standort); realCcs = m.ccsId || ''; }
            }
            const meta = STANDORT_METADATA[code];
            const nationCode = meta ? meta.nation : null;

            // Teams je Standort sammeln (fuer das Dropdown) — aus ALLEN Zeilen
            if (code && team) { (teamsByStd[code] || (teamsByStd[code] = new Set())).add(team);
                if (voRaw) (teamVoByStd[code + '|' + team] || (teamVoByStd[code + '|' + team] = new Set())).add(voRaw); }

            // Scope: Stack, Standort UND Team muessen passen -> bei Filter NUR diese Daten
            // (Stacks sind getrennte Abteilungen, z.B. MF_CARE vs. onecoax_tech — kein Vergleich untereinander)
            const inScope = (filterVal === 'ALL' || code === filterVal)
                         && (filterTeam === 'ALL' || team === filterTeam)
                         && (filterStack === 'ALL' || stackOf(team) === filterStack);

            // Zeit / Stunde bestimmen
            const dObj = parseDateTime(datumRaw);
            const timeStr = (dObj && dObj.hasTime) ? getTimeString(dObj.date) : '';
            const withinHour = dObj ? (dObj.date >= oneHourAgo && dObj.date <= now) : false;

            let rowId = (idx.id!==-1 && row[idx.id]) ? row[idx.id].toString().trim() : `${code}_${voRaw}_${prodRaw}_${anzahl}_${i}`;

            // --- Kontakt-/Quoten-Zaehlung: ALLE Zeilen im Scope (Bugfix ggue. v20) ---
            const isReject = ergL.includes('abgelehnt') || ergL.includes('nicht'); // "nicht moeglich" (Encoding-sicher)
            const isOffer  = ergL.includes('angebot') && !ergL.includes('angenommen'); // offenes Angebot, KEIN Abschluss
            const std = ensureStd(code, meta);
            const tm = (inScope && team) ? ensureTeam(team, code) : null;
            // Ansprache = "Angebot gemacht" (ob angenommen, offen ODER abgelehnt) — NUR "nicht moeglich" zaehlt nicht.
            const istAnsprache = (angesprochen === 'ja') ||
                (angesprochen === '' && (ergL.includes('angenommen') || ergL.includes('angebot') || ergL.includes('abgelehnt')));
            // UNGEFILTERT fuer die Kriegskarte: Ansprachen je Standort (Boten-Patrouillen)
            // und je Agent (namentliche Boten) — unabhaengig vom aktiven Filter.
            if (istAnsprache && code && STANDORT_METADATA[code]) {
                const wf = ensureWarStd(code);
                if (!wf._a) wf._a = new Set();
                if (!wf._a.has(rowId)) { wf._a.add(rowId); wf.pitches++; }
                if (voRaw) { const wa = warAgentAnspr[voRaw] ||
                    (warAgentAnspr[voRaw] = { name:realName, standort:code, ansp:0, _s:new Set() });
                    if (!wa._s.has(rowId)) { wa._s.add(rowId); wa.ansp++; } }
            }
            if (inScope) {
                gCallIds.add(rowId);
                (std._c || (std._c = new Set())).add(rowId);
                if (tm) (tm._c || (tm._c = new Set())).add(rowId);
                if (istAnsprache) {
                    const neu = !gAnspIds.has(rowId);
                    gAnspIds.add(rowId);
                    (std._a || (std._a = new Set())).add(rowId);
                    if (tm) (tm._a || (tm._a = new Set())).add(rowId);
                    if (neu) { const hi = hourOf(rowId, dObj) - loHour; if (hi>=0 && hi<anspTrend.length) anspTrend[hi]++; }
                }
                if (isReject) {
                    gRejIds.add(rowId);
                    (std._r || (std._r = new Set())).add(rowId);
                    if (tm) (tm._r || (tm._r = new Set())).add(rowId);
                    const gr = (idx.grund !== -1) ? (row[idx.grund]||'').toString().trim() : '';
                    if (gr) rejReasons[gr] = (rejReasons[gr]||0) + 1;
                    // Detailzeile fuer den Klick auf "Ablehnungen": wer, warum, wann
                    window.rcAllRejections.push({ name:realName, vo:voRaw, team, standort:code, timeStr, grund: gr || '(kein Grund angegeben)' });
                }
                if (isOffer) { gOffers += anzahl; std.offers = (std.offers||0) + anzahl;
                    // offene Angebote je Agent -> "Nachfassen"-Liste (niedrig haengende Fruechte)
                    if (voRaw) { const agO = ensureAgent(voRaw, realName, team, code, realCcs); agO.offers = (agO.offers||0) + anzahl; }
                }
                // NUR Zeilen im Scope anlegen -> bei Filter erscheinen ausschliesslich diese Agenten
                if (voRaw) {
                    const ag = ensureAgent(voRaw, realName, team, code, realCcs);
                    if (!ag.stack) ag.stack = stackOf(team);
                    (ag._cIds || (ag._cIds = new Set())).add(rowId); // Kontakte je Agent (fuer CR-Berechnung)
                    if (istAnsprache) {
                        if (!ag._anspIds) ag._anspIds = new Set();
                        if (!ag._anspIds.has(rowId)) { ag._anspIds.add(rowId); ag.ansprachen++; }
                    }
                }
                if (tm && !tm.stack) tm.stack = stackOf(team);
            }

            // Ablehnungsgruende -> Marquee
            if (anzahl === 0 && idx.grund !== -1 && (ergL.includes('nicht') || ergL.includes('abgelehnt'))) {
                const grund = (row[idx.grund]||'').toString().trim();
                if (grund) { const hash = `${voRaw}_${grund}`;
                    if (!window.rcNewsHistorie.includes(hash)) { window.rcNewsHistorie.push(hash);
                        if (window.rcNewsHistorie.length>50) window.rcNewsHistorie.shift();
                        window.rcMarqueeBuffer.push(`${getFlagSvg(code,'small')} ${realName} (${code}) — abgelehnt: "${grund}"`);
                        if (window.rcMarqueeBuffer.length>25) window.rcMarqueeBuffer.shift();
                    }
                }
            }

            // --- Abschluss-Zaehlung: NUR "angenommen" ist ein echter Abschluss ---
            // "Angebot" = offenes/unterbreitetes Angebot, KEIN Verkauf -> zaehlt nicht als BNT/VVL
            const accepted = anzahl > 0 && ergL.includes('angenommen');
            if (accepted) {
                const { cat, isBnt, isVvl } = classify(prodRaw);
                if (cat) {
                    // Eindeutiger Schluessel je Verkaufszeile: Kontakt-id + Kategorie + Menge.
                    // Nur "angenommen" landet hier -> ein Angebot, das spaeter angenommen wird, gilt korrekt als NEU.
                    const saleKey = rowId + '|' + cat + '|' + anzahl;
                    const isNew = !window.rcCelebratedSales.has(saleKey);
                    window.rcCelebratedSales.add(saleKey); // auch ausserhalb des Filters merken -> kein Toast-Sturm bei Filterwechsel

                    // UNGEFILTERT fuer die Kriegskarte: jeder Abschluss zaehlt fuer die
                    // Schlacht (Burg-Level, Ranking) und wird als Soldat abgespielt —
                    // egal welcher Standort/Stack gerade im Panel gefiltert ist.
                    if (code && STANDORT_METADATA[code]) {
                        const wf = ensureWarStd(code);
                        wf.total += anzahl;
                        wf[cat] = (wf[cat]||0) + anzahl; // alle Kategorien fuer scoreOf()
                        if (isBnt) wf.bnt += anzahl; if (isVvl) wf.vvl += anzahl;
                        if (isBcr) wf.bcr += anzahl; else wf.nonBcr += anzahl;
                        window.rcAllSales.push({ name:realName, vo:voRaw, team, cat, isBnt, isVvl, prod:prodRaw, kunde:(idx.kunde!==-1?(row[idx.kunde]||'').toString().trim():''), standort:code, timeStr, isBcr, anzahl });
                    }

                    if (inScope) {
                        std.accepted++;
                        const agS = ensureAgent(voRaw, realName, team, code, realCcs);
                        agS[cat] += anzahl;
                        std[cat] += anzahl;
                        if (tm) tm[cat] += anzahl;
                        // BCR-Relevanz (aus Produktmerkmal) getrennt mitzaehlen — je Agent/Team/Standort
                        const bcrKey = isBcr ? 'bcr' : 'nonBcr';
                        agS[bcrKey] = (agS[bcrKey]||0) + anzahl;
                        std[bcrKey] = (std[bcrKey]||0) + anzahl;
                        if (tm) tm[bcrKey] = (tm[bcrKey]||0) + anzahl;
                        if (isBnt) gBnt += anzahl;
                        if (isVvl) gVvl += anzahl;
                        if (isBcr) gBcr += anzahl; else gNonBcr += anzahl;
                        if (cat==='kip') gKip += anzahl;
                        if (cat==='mob') gMob += anzahl;
                        if (nationCode && nationStats[nationCode]) {
                            nationStats[nationCode].anzahl += anzahl;
                            if (isBnt) nationStats[nationCode].bnt += anzahl;
                            if (isVvl) nationStats[nationCode].vvl += anzahl;
                            if (cat==='kip') nationStats[nationCode].kip += anzahl;
                            if (cat==='mob') nationStats[nationCode].mob += anzahl;
                        }
                        // Tagesverlauf-Bucket (gesamt + je Standort)
                        if (isBnt || isVvl) {
                            const hi = hourOf(rowId, dObj) - loHour;
                            if (hi>=0 && hi<hourLabels.length) {
                                trend.total[hi]+=anzahl; if(isBnt) trend.bnt[hi]+=anzahl; if(cat==='kip') trend.kip[hi]+=anzahl; if(cat==='mob') trend.mob[hi]+=anzahl; if(isVvl) trend.vvl[hi]+=anzahl;
                                (trendByStd[code] || (trendByStd[code] = new Array(hourLabels.length).fill(0)))[hi] += anzahl;
                            }
                        }

                        // NEUER Verkauf -> Abschluss-Fenster + Ticker + Radar-Ping (beim ersten Lauf nur letzte Stunde)
                        if (isNew) {
                            const dt = timeStr || (isFirstRun ? '' : new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}));
                            const saleNo = bntOf(agS); // wievielter BNT-Abschluss heute -> Doppelpack/Hattrick
                            // Grosses 3D-Popup NUR fuer BNT, die BCR-relevant sind (User-Vorgabe:
                            // "Pop-Up nicht fuer VVL, nur BNT"). Alles andere laeuft nur im Ticker.
                            // Popup abschaltbar (rcNoCelebrate): im League-Modus/Demo uebernehmen die Stadion-Szenen die Buehne
                            // Filter-Regel (User 17.07.): MIT Standort-Filter nur der eigene Standort
                            // in voller Groesse; OHNE Filter alle Standorte, aber nur als kompakte
                            // Karte — "die sind Krieger, keine Fussballer", kein fettes Vollbild fuer fremde Nationen.
                            const curFilt = (document.getElementById('rcStandortFilter')||{}).value;
                            const hasFilt = curFilt && curFilt !== 'ALL';
                            const filtMatches = (!hasFilt || code === curFilt);
                            if (isBnt && isBcr && !window.rcNoCelebrate && filtMatches && (!isFirstRun || withinHour)) queueCelebration(realName, prodRaw, code, dt, saleNo, !hasFilt);
                            addTicker(code, realName, prodRaw, dt || getTimeString(now), saleNo, isBcr);
                            if (window.rcRadarPing && (!isFirstRun || withinHour)) window.rcRadarPing(code, realName, prodRaw, dt || getTimeString(now), isBcr);
                        }
                    }
                }
            }
        }

        if (isFirstRun && sheetData.length>1) window.rcIsInitialized = true;

        // Zaehler aus den Eindeutig-Sets ableiten (konsistente Basis fuer ALLE Ansichten)
        const gCalls = gCallIds.size, gPitches = gAnspIds.size;
        gRej = gRejIds.size;
        const fromSets = o => { o.calls = o._c ? o._c.size : 0; o.pitches = o._a ? o._a.size : 0; o.rejections = o._r ? o._r.size : 0; };

        // Ableitungen je Standort/Team/Agent
        Object.values(standortStats).forEach(s => { fromSets(s); s.bnt = bntOf(s); s.vvl = vvlOf(s); s.total = s.bnt + s.vvl; s.score = scoreOf(s); });
        Object.values(teamStats).forEach(t => { fromSets(t); t.bnt = bntOf(t); t.vvl = vvlOf(t); t.total = t.bnt + t.vvl; t.score = scoreOf(t); });
        Object.values(agentStats).forEach(a => { a.kontakte = a._cIds ? a._cIds.size : 0; a.bnt = bntOf(a); a.vvl = vvlOf(a); a.total = a.bnt + a.vvl; a.score = scoreOf(a); });

        // Team-Dropdown fuer den aktuell gewaehlten Standort befuellen.
        // Zusaetzlich zu den ESL-Teams auch alle MAPPING-Teams des Standorts anbieten:
        // Liga-only-Stacks (z.B. Alanya MF_CARE) tracken nicht in dieser ESL-Abfrage,
        // sollen aber fuer die Qualitaets-Sicht waehlbar sein ("nur VKD"-Befund 13.07.).
        //
        // ABER: das Mapping kennt weit mehr Teams als heute Daten liefern (Alanya
        // 19 Teams, davon 11 mit Daten; Berlin 11 zu 3). Alphabetisch standen die
        // LEEREN vorn (MF-CARE-01, 21102001, 21103099) -> wer ein Team waehlte,
        // landete fast immer im Nichts, ohne zu erfahren warum (Befund 27.07.).
        // Deshalb bekommt jedes Team seine Datenlage mit und wird danach sortiert.
        let teamsForDrop = new Set(teamsByStd[filterVal] || []);
        if (filterVal !== 'ALL' && mapping && mapping.ccsMap) {
            Object.values(mapping.ccsMap).forEach(m => {
                if (m && m.team && normalizeStandort((m.standort||'').toString()) === filterVal) teamsForDrop.add(m.team.toString().trim());
            });
        }
        if (filterStack !== 'ALL') teamsForDrop = new Set([...teamsForDrop].filter(t => stackOf(t) === filterStack));
        // Liga-Agenten je Team (zentral ueber rcLigaMeta — Liga fuehrt Team-NUMMERN)
        const ligaProTeam = {};
        Object.values(window.rcKpiData || {}).forEach(k => {
            const meta = window.rcLigaMeta ? window.rcLigaMeta(k) : null;
            if (!meta || !meta.team || meta.std !== filterVal) return;
            ligaProTeam[meta.team] = (ligaProTeam[meta.team] || 0) + 1;
        });
        const teamInfo = new Map();
        [...teamsForDrop].forEach(t => teamInfo.set(t, {
            esl: (teamVoByStd[filterVal + '|' + t] || { size: 0 }).size,
            liga: ligaProTeam[t] || 0
        }));
        updateTeamFilter(filterVal, teamInfo);

        window.rcLetzteStats = { agentStats, standortStats, teamStats, nationStats };
        // Ungefilterte Kriegskarten-Daten (immer alle Standorte) — Sets aufraeumen
        Object.values(warStdFull).forEach(w => { delete w._a; });
        window.rcWarStdFull = warStdFull;
        window.rcWarBoteCands = Object.values(warAgentAnspr).map(w => ({ name:w.name, standort:w.standort, ansp:w.ansp }));
        window.rcRejReasons = rejReasons;
        window.rcHourStats = { labels: hourLabels, totals: trend.total.slice() };
        window.rcPace = { bnt: gBnt, bcr: gBcr, nowH: currentHour, nowMin: now.getMinutes() };

        // Tageshistorie fuer den Gestern-Vergleich — nur die ungefilterte Gesamtsicht
        // speichern, sonst verfaelschen Filterwechsel die Historie (max. 8 Tage).
        if (filterVal === 'ALL' && filterTeam === 'ALL' && filterStack === 'ALL') {
            try {
                const dayKey = now.getFullYear() + '-' + pad2(now.getMonth()+1) + '-' + pad2(now.getDate());
                const store = JSON.parse(localStorage.getItem('rcDayTrend') || '{}');
                // Einmalige Heilung: der Bereichs-Harvest-Bug konnte Wochensummen in den
                // heutigen Stundenverlauf schreiben (Max-Logik konserviert sie) -> reset
                try { if (localStorage.getItem('rcDayTrendFix') !== 'v1') {
                    delete store[dayKey];
                    localStorage.setItem('rcDayTrendFix', 'v1');
                } } catch(e){}
                if (!store[dayKey]) store[dayKey] = {};
                store[dayKey][currentHour] = Math.max(store[dayKey][currentHour] || 0, gBcr);
                // BNT separat mitfuehren ('b'-Schluessel) — der Trend-Chart zeigt BNT,
                // die numerischen Stunden-Schluessel bleiben abwaertskompatibel (BCR-rel.)
                store[dayKey]['b' + currentHour] = Math.max(store[dayKey]['b' + currentHour] || 0, gBnt);
                Object.keys(store).sort().slice(0, -8).forEach(k => delete store[k]);
                localStorage.setItem('rcDayTrend', JSON.stringify(store));
                window.rcDayTrend = store;
            } catch(e){}
            // Heute-Aggregat im Historien-Format — Datenbasis fuer Detail-Modals
            // und Tagesvergleich ("Heute" als waehlbarer Tag)
            const byStdT = {}, byAgentT = {};
            Object.values(standortStats).forEach(s => { byStdT[s.code] = { kontakte:s.calls, ansp:s.pitches, bcr:bcrOf(s), nonBcr:nonBcrOf(s), bnt:s.bnt, vvl:s.vvl }; });
            Object.values(agentStats).forEach(a => { byAgentT[a.vo] = { k:a.kontakte, a:a.ansprachen, bcr:bcrOf(a), bnt:a.bnt, vvl:a.vvl, mob:a.mob||0, kip:a.kip||0, ccs:(a.ccsId||'')+'', nm:a.name }; });
            window.rcTodayAgg = { kontakte:gCalls, ansp:gPitches, bcr:gBcr, nonBcr:gNonBcr, bnt:gBnt, vvl:gVvl, byStd:byStdT, byAgent:byAgentT };
            // Selbst-Archivierung: der Heute-Stand wird laufend als Tages-Snapshot
            // gesichert. Damit waechst die Vortage-Historie GARANTIERT jeden Tag —
            // auch wenn das Portal keine rueckwirkenden Tages-Exporte liefert.
            try {
                const hKey = now.getFullYear() + '-' + pad2(now.getMonth()+1) + '-' + pad2(now.getDate());
                const histS = JSON.parse(localStorage.getItem('rcEslHistory') || '{}');
                histS[hKey] = { rows: sheetData.length-1, kontakte:gCalls, ansp:gPitches, bcr:gBcr, nonBcr:gNonBcr,
                    bnt:gBnt, vvl:gVvl, byStd:byStdT, byAgent:byAgentT, srcDay:hKey, live:true };
                Object.keys(histS).sort().slice(0, -40).forEach(k => delete histS[k]);
                localStorage.setItem('rcEslHistory', JSON.stringify(histS));
                window.rcEslHistory = histS;
            } catch(e){}
        }

        // KPI-Strip
        animateCount(document.getElementById('kpiCalls'), gCalls);
        animateCount(document.getElementById('kpiPitches'), gPitches);
        document.getElementById('kpiPitchRate').textContent = ` ${gCalls>0?Math.round(gPitches/gCalls*100):0}%`;
        animateCount(document.getElementById('kpiBnt'), gBnt);
        document.getElementById('kpiBntRate').textContent = ` ${gCalls>0?Math.round(gBnt/gCalls*100):0}%`;
        animateCount(document.getElementById('kpiKip'), gKip);
        animateCount(document.getElementById('kpiMob'), gMob);
        animateCount(document.getElementById('kpiVvl'), gVvl);
        animateCount(document.getElementById('kpiOffers'), gOffers);
        animateCount(document.getElementById('kpiRej'), gRej);
        document.getElementById('kpiRejRate').textContent = ` ${gCalls>0?Math.round(gRej/gCalls*100):0}%`;

        document.getElementById('rcValidRows').textContent = (sheetData.length-1) + ' Zeilen';
        updateFetchStatus(gCalls);
        detectDataIssues(sheetData.length-1);

        // Renders
        const agentsArr = Object.values(agentStats).sort((a,b) => b.total-a.total);
        // Letzten Render-Kontext merken (fuer 30s-Auto-Rotation ohne Neu-Parsing)
        window.rcLastRender = { agentsArr, standortStats, teamStats, filterVal, filterTeam };
        renderAgents(agentsArr);
        if (window.renderAnspFokus) window.renderAnspFokus(agentsArr);
        renderLiga('rcKipLeaderboard', agentsArr, 'kip', '#FF9E9E', filterVal);
        renderLiga('rcMobLeaderboard', agentsArr, 'mob', '#FFFFFF', filterVal);
        if (document.getElementById('rcRadarKipLeaderboard')) renderLiga('rcRadarKipLeaderboard', agentsArr, 'kip', '#FF9E9E', filterVal);
        if (document.getElementById('rcRadarMobLeaderboard')) renderLiga('rcRadarMobLeaderboard', agentsArr, 'mob', '#FFFFFF', filterVal);
        if (window.renderZeroSellers) window.renderZeroSellers(standortStats);
        renderSide(agentsArr, filterVal);
        // Bei Standort-Filter: Standorte-Karte + Battle zeigen die TEAMS dieses Standorts
        if (filterVal !== 'ALL') { renderStandorte(teamStats, true); renderTeamBattle(teamStats, filterVal, filterTeam); }
        else { renderStandorte(standortStats, false); renderStandortBattle(standortStats); }
        renderProducts(sheetData, idx);
        renderTrend(hourLabels, trendByStd, anspTrend);
        if (window.renderTnpsChart) window.renderTnpsChart();
        renderMarquee();
        if (window.renderMomentum) window.renderMomentum();
        buildDynamicMoti(agentsArr, standortStats);
        if (window.renderRadar) window.renderRadar();
        if (window.rcActivePage === 'quali' && window.renderQualitaet) window.renderQualitaet();
        if (window.rcActivePage === 'cockpit' && window.renderCockpit) window.renderCockpit();

        rcLog.log(`v22: ${sheetData.length-1} Zeilen verarbeitet | BNT ${gBnt} · KIP ${gKip} · MOB ${gMob} · VVL ${gVvl}`);
      } catch(err) { rcLog.error('Fehler in processDataStream:', err); }
    };

    // ============================================================
    //  DATEN-TRANSPARENZ (Status, Warnungen)
    // ============================================================
    function getPortalDateRange(){
        try {
            const inps = [...document.querySelectorAll('#filterForm input.hasDatepicker, #filterForm .ui-calendar input')]
                .filter(i => i.value && i.value.trim());
            const vals = [...new Set(inps.map(i => i.value.trim()))];
            if (vals.length === 1) return vals[0];
            if (vals.length >= 2) return vals[0] + '–' + vals[vals.length-1];
        } catch(e){}
        return '';
    }
    function updateFetchStatus(kontakte){
        const el = document.getElementById('rcFetchStatus'); if (!el) return;
        const dr = getPortalDateRange();
        el.textContent = 'aktualisiert ' + new Date().toLocaleTimeString('de-DE')
            + (dr ? ' · Zeitraum ' + dr : '') + ' · ' + (kontakte||0).toLocaleString('de-DE') + ' Kontakte';
    }
    function showWarn(msg){ const b = document.getElementById('rcWarnBar'); if (b){ b.textContent = msg ? 'ACHTUNG — ' + msg : ''; b.style.display = msg ? 'block' : 'none'; } }
    function detectDataIssues(rows){
        let warn = window.rcMultiDayWarn || ''; // Mehrtages-Schutz hat Prioritaet
        // aktiver Spaltenfilter im Portal-Datatable?
        try {
            const active = [];
            document.querySelectorAll('#filterForm input.ui-column-filter, #filterForm .ui-datatable thead input').forEach(f => {
                if (!f || f.classList.contains('hasDatepicker')) return;
                if (f.value && f.value.trim()) active.push(f.value.trim());
            });
            if (active.length) warn = 'Spaltenfilter im Portal aktiv (' + active.slice(0,3).join(', ') + ') — es werden nur gefilterte Daten angezeigt. Zum Leeren die Filterfelder unter den Spalten loeschen.';
        } catch(e){}
        // starker Einbruch der Zeilenzahl (z.B. ploetzlich gesetzter Filter)
        if (!warn && window.rcMaxRows && window.rcMaxRows > 80 && rows < window.rcMaxRows * 0.55)
            warn = 'Nur ' + rows + ' Zeilen geladen (zuvor bis ' + window.rcMaxRows + ') — Spaltenfilter oder Zeitraum pruefen.';
        window.rcMaxRows = Math.max(window.rcMaxRows || 0, rows);
        showWarn(warn);
    }

    // ============================================================
    //  RENDER-FUNKTIONEN
    // ============================================================
    function rankClass(i){ return i===0?'r1':(i===1?'r2':(i===2?'r3':'')); }

    // HTML-Attribut-Escape fuer data-Attribute (Namen mit Anfuehrungszeichen etc.)
    const rcAttr = s => (s==null?'':s.toString()).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');

    window.renderAgents = function(agentsArr){
        const tab = window.rcActiveAgentTab;
        const leaderboard = document.getElementById('rcAgentLeaderboard');
        const headName = document.getElementById('rcAgentHeadName');

        // Teams-Ansicht: aggregierte Team-Zeilen (bei Standort-Filter nur dessen Teams)
        if (tab === 'teams') {
            if (headName) headName.textContent = 'Team';
            const teams = window.rcLetzteStats ? Object.values(window.rcLetzteStats.teamStats) : [];
            const arr = teams.slice().sort((a,b) => b.total-a.total).slice(0,50);
            let html = '';
            arr.forEach((t, i) => {
                const rc = rankClass(i), hl = i===0?'rc-table-row-1':(i===1?'rc-table-row-2':(i===2?'rc-table-row-3':''));
                html += `<tr class="${hl}" data-rc-team="${rcAttr(t.code)}" title="Klick: Team-Details">
                    <td style="text-align:center;"><div class="rc-rank-badge ${rc}">${i+1}</div></td>
                    <td><b style="font-size:12px;">${getFlagSvg(t.standort,'small')} Team ${t.name}</b><span class="rc-mono" style="color:#9A9A9A; font-size:9px; margin-left:5px; font-weight:400;">${shortName(t.standort)} · ${t.pitches||0} Anspr · ${t.calls||0} Kont</span></td>
                    <td style="text-align:center; color:#FF6666;" class="rc-mono">${t.kip}</td>
                    <td style="text-align:center; color:#F5F5F5;" class="rc-mono">${t.mob}</td>
                    <td style="text-align:center; color:#F5F5F5;" class="rc-mono">${t.bnt}</td>
                    <td style="text-align:center; color:#9C9C9C;" class="rc-mono">${t.vvl}</td>
                    <td style="text-align:center; color:#F5F5F5; font-size:13px;" class="rc-mono">${t.total}</td>
                </tr>`;
            });
            leaderboard.innerHTML = html || `<tr><td colspan="7" style="text-align:center; padding:20px; color:#9C9C9C;">Keine Team-Daten</td></tr>`;
            return;
        }

        if (headName) headName.textContent = 'Verkaeufer';
        const sortKey = tab==='bnt' ? (a=>a.bnt) : (tab==='ansp' ? (a=>a.ansprachen) : (a=>a.total));
        const arr = agentsArr.slice().sort((a,b) => sortKey(b)-sortKey(a)).slice(0,50);

        let html = '';
        arr.forEach((ag, i) => {
            const rc = rankClass(i), hl = i===0?'rc-table-row-1':(i===1?'rc-table-row-2':(i===2?'rc-table-row-3':''));
            // Koenigsprodukte farbig: KIP=Gold, Mobilfunk=Cyan (nur wenn vorhanden)
            const kipC = ag.kip>0 ? '#FFC633' : '#6E6E6E', mobC = ag.mob>0 ? '#3BD6E6' : '#6E6E6E';
            // echte Ansprache-Quote aus Liga-Calls (rcKpiForAgent), nur wenn KPI-Quelle da
            const kpi = window.rcKpiForAgent ? window.rcKpiForAgent(ag) : null;
            let anspSub = '';
            if (kpi && kpi.callCount >= 3) {
                const q = Math.round((ag.ansprachen||0) / kpi.callCount * 100);
                const qc = q >= 40 ? '#3FBF8F' : q >= 20 ? '#E8A33C' : '#FF6B6B';
                anspSub = ` · <span style="color:${qc};">AQ ${q}%</span>`;
            }
            html += `<tr class="${hl}" data-rc-vo="${rcAttr(ag.vo)}" data-rc-name="${rcAttr(ag.name)}" title="Klick: Agenten-Details">
                <td style="text-align:center;"><div class="rc-rank-badge ${rc}">${i+1}</div></td>
                <td><b style="font-size:12px;">${getFlagSvg(ag.standort,'small')} ${ag.name}</b><span class="rc-mono" style="color:#9A9A9A; font-size:9px; margin-left:5px; font-weight:400;">${ag.team||''}${anspSub}</span></td>
                <td style="text-align:center; color:${kipC}; font-weight:${ag.kip>0?700:400};" class="rc-mono">${ag.kip}</td>
                <td style="text-align:center; color:${mobC}; font-weight:${ag.mob>0?700:400};" class="rc-mono">${ag.mob}</td>
                <td style="text-align:center; color:#F5F5F5;" class="rc-mono">${ag.bnt}</td>
                <td style="text-align:center; color:#9C9C9C;" class="rc-mono">${ag.vvl}</td>
                <td style="text-align:center; color:#F5F5F5; font-size:13px;" class="rc-mono">${tab==='ansp'?ag.ansprachen:ag.total}</td>
            </tr>`;
        });
        leaderboard.innerHTML = html || `<tr><td colspan="7" style="text-align:center; padding:20px; color:#9C9C9C;">Keine Abschluesse vorhanden</td></tr>`;
    };

    // Tages-Momentum: echte Stunden-BNT (rcHourStats), Best-Stunde, Pace/Hochrechnung
    // (rcPace) und der Gestern-Vergleich zur selben Stunde (rcDayTrend). Nur echte Werte;
    // ohne Daten sauberer Platzhalter statt Fehler.
    window.renderMomentum = function(){
        const el = document.getElementById('rcMomentumPanel'); if (!el) return;
        const hs = window.rcHourStats, pc = window.rcPace;
        if (!hs || !hs.totals || !hs.totals.some(v => v > 0)) {
            el.innerHTML = '<div style="padding:12px; font-size:11px; color:#7E7E7E; font-weight:700;">Warte auf Daten &mdash; noch keine Abschluesse heute</div>';
            return;
        }
        const totals = hs.totals, labels = hs.labels || totals.map((_,i)=>i+':00');
        const maxV = Math.max(1, ...totals);
        let bestI = 0; totals.forEach((v,i)=>{ if (v > totals[bestI]) bestI = i; });
        const sumBnt = totals.reduce((a,b)=>a+b,0);
        const activeH = totals.filter(v=>v>0).length || 1;
        // Balkenreihe
        let bars = '<div style="display:flex; align-items:flex-end; gap:2px; height:52px; padding:4px 6px 2px;">';
        totals.forEach((v,i) => {
            const h = Math.round(6 + (v/maxV)*40), on = i===bestI;
            const col = on ? '#FFB300' : (v>0 ? '#E60000' : 'rgba(255,255,255,0.10)');
            bars += `<div title="${labels[i]}: ${v} BNT" style="flex:1; min-width:0; height:${h}px; background:${col}; border-radius:2px 2px 0 0;"></div>`;
        });
        bars += '</div>';
        const bestLabel = labels[bestI] || (bestI+':00');
        // Gestern zur selben Stunde (kumulierte BNT via 'b'+Stunde)
        let gesternTxt = 'Gestern: keine Vergleichsdaten';
        try {
            const store = window.rcDayTrend || JSON.parse(localStorage.getItem('rcDayTrend') || '{}');
            const keys = Object.keys(store).sort();
            const todayKey = keys[keys.length-1];
            const prevKey = keys.filter(k => k < todayKey).pop();
            const nowH = pc ? pc.nowH : (new Date()).getHours();
            if (prevKey) {
                let yBnt = null;
                for (let h = nowH; h >= 0; h--) { if (store[prevKey]['b'+h] != null) { yBnt = store[prevKey]['b'+h]; break; } }
                if (yBnt != null) {
                    const d = sumBnt - yBnt, sign = d>0?'+':'', dc = d>0?'#3FBF8F':(d<0?'#FF6B6B':'#E8A33C');
                    gesternTxt = `Gestern um ${nowH}:00 &rarr; <b style="color:#F5F5F5;">${yBnt} BNT</b> &middot; <b style="color:${dc};">${sign}${d}</b> heute`;
                }
            }
        } catch(e){}
        // Pace + Hochrechnung (linear, ehrlich als "~" markiert)
        let paceTxt = '';
        if (pc && sumBnt > 0) {
            const perH = sumBnt / activeH;
            const restH = Math.max(0, 17 - pc.nowH);
            const proj = Math.round(sumBnt + perH * restH);
            paceTxt = `Tempo <b>${perH.toFixed(1)} BNT/h</b> &middot; Hochrechnung Tagesende <b style="color:#FFB300;">~${proj} BNT</b>`;
        }
        el.innerHTML = bars
            + `<div style="padding:2px 8px 0; font-size:10px; color:#9A9A9A; font-weight:700;">Beste Stunde <b style="color:#FFB300;">${bestLabel}</b> (${totals[bestI]} BNT) &middot; heute gesamt <b style="color:#F5F5F5;">${sumBnt}</b></div>`
            + `<div style="padding:5px 8px 0; font-size:11px; color:#C9C9C9;">${gesternTxt}</div>`
            + (paceTxt ? `<div style="padding:4px 8px 0; font-size:11px; color:#C9C9C9;">${paceTxt}</div>` : '');
    };

    // Ansprache-Fokus: wer telefoniert (Ligaliste), aber macht keine/wenige Ansprachen auf ESL
    window.renderAnspFokus = function(agentsArr){
        const el = document.getElementById('rcAnspFokus');
        if (!el) return;
        const warnSvg = h => `<svg viewBox="0 0 24 24" width="14" height="14" style="flex-shrink:0;"><path d="M12 3 L22 20 H2 Z" fill="none" stroke="${h?'#E60000':'#820000'}" stroke-width="2" stroke-linejoin="round"/><line x1="12" y1="10" x2="12" y2="14.5" stroke="${h?'#E60000':'#820000'}" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17.2" r="1.1" fill="${h?'#E60000':'#820000'}"/></svg>`;
        const list = [];
        let matched = 0;   // ESL-Agenten MIT Liga-Treffer (Join-Kontrolle)
        (agentsArr || []).forEach(ag => {
            const kpi = window.rcKpiForAgent(ag);
            if (!kpi) return;
            matched++;
            if (!kpi.callCount || kpi.callCount < 5) return;
            const anspr = ag.ansprachen || 0;
            const q = anspr / kpi.callCount;
            if (anspr === 0) list.push({ ag, calls: kpi.callCount, anspr, q, hart: true });
            else if (q < 0.25) list.push({ ag, calls: kpi.callCount, anspr, q, hart: false });
        });
        if (!list.length) {
            // Die Leermeldung MUSS lesbar sein: #0D0D0D stammt aus dem hellen Theme
            // und war auf der dunklen Karte (#1D1D1D) unsichtbar — das Panel wirkte
            // "komplett leer", obwohl es etwas zu sagen hatte (Befund 27.07.).
            // Ausserdem ehrlich unterscheiden, WARUM nichts da ist: ohne Liga-Join
            // wuerde sonst "Stark" gemeldet, obwohl gar nichts geprueft werden konnte.
            const nKpi = Object.keys(window.rcKpiData || {}).length;
            const nAg = (agentsArr || []).length;
            let txt, col = '#F5F5F5';
            if (!nKpi)        { txt = 'Warte auf KPI-Quelle (Button oben)'; col = '#7E7E7E'; }
            else if (!nAg)    { txt = 'Keine ESL-Agenten im aktuellen Filter'; col = '#7E7E7E'; }
            else if (!matched){ txt = 'Kein Agent mit der Ligaliste verknuepft (' + nKpi + ' Liga-Agenten, ' + nAg + ' ESL-Agenten) — Mapping pruefen'; col = '#FF6666'; }
            else              { txt = 'Stark — alle ' + matched + ' Agenten mit Calls machen Ansprachen'; }
            el.innerHTML = `<div style="padding:10px; font-size:11px; color:${col}; font-weight:700;">${txt}</div>`;
            return;
        }
        list.sort((a,b) => (a.q - b.q) || (b.calls - a.calls));
        el.innerHTML = list.slice(0, 20).map(x => `<div class="rc-warn-item${x.hart?' hart':''}" data-rc-vo="${rcAttr(x.ag.vo)}" data-rc-name="${rcAttr(x.ag.name)}" title="Klick: Agenten-Details">
            ${warnSvg(x.hart)}
            <span class="nm">${getFlagSvg(x.ag.standort,'small')} ${x.ag.name}</span>
            <span class="wv">${x.calls} Calls · ${x.anspr} Anspr · <b style="color:${x.hart?'#E60000':'#820000'};">${Math.round(x.q*100)} %</b></span>
        </div>`).join('');
    };

    // ============================================================
    //  SEITE 2: QUALITÄT — alle Service-KPIs aus der Ligaliste
    // ============================================================
    const fmtAht = sec => sec == null ? '—' : `${Math.floor(sec/60)}:${(''+Math.round(sec%60)).padStart(2,'0')}`;

    window.renderQualitaet = function(){
        const body = document.getElementById('rcQualiBody');
        if (!body) return;

        // ESL-Ansprachen/-Abschluesse: Join primaer per CCS-ID (verlaesslich), Name nur als Fallback
        const anspByCcs = {}, anspByName = {}, totByCcs = {}, totByName = {};
        if (window.rcLetzteStats) {
            Object.values(window.rcLetzteStats.agentStats).forEach(a => {
                if (a.ccsId) { anspByCcs[a.ccsId] = a.ansprachen || 0; totByCcs[a.ccsId] = a.total || 0; }
                anspByName[window.rcNormName(a.name)] = a.ansprachen || 0;
                totByName[window.rcNormName(a.name)] = a.total || 0;
            });
        }
        const eslAnsp = k => (k.ccsId && anspByCcs[k.ccsId] != null) ? anspByCcs[k.ccsId]
                            : (anspByName[window.rcNormName(k.agentName)] != null ? anspByName[window.rcNormName(k.agentName)] : null);
        const eslTotal = k => (k.ccsId && totByCcs[k.ccsId] != null) ? totByCcs[k.ccsId]
                            : (totByName[window.rcNormName(k.agentName)] != null ? totByName[window.rcNormName(k.agentName)] : 0);

        // Scope zentral ueber rcLigaInScope — dieselbe Basis wie rcLigaAgg.
        // Frueher wurde hier roh gefiltert (k.team === filterTeam); die Ligaliste
        // liefert aber die Team-NUMMER, das Dropdown den Team-NAMEN -> der Filter
        // traf nie und die Seite blieb bei jeder Team-Auswahl leer.
        const scope = window.rcActiveScope();
        const alleKpi = Object.values(window.rcKpiData || {});
        const list = alleKpi.filter(k => window.rcLigaInScope(k, scope));
        // Standort/Team der Liga-Zeile fuer Anzeige + Gruppierung immer gemappt
        const stdOf  = k => window.rcLigaMeta(k).std;
        const teamOf = k => window.rcLigaMeta(k).team;

        const setV = (id, txt, col) => { const e = document.getElementById(id); if (e) { e.textContent = txt; if (col) e.style.color = col; } };
        if (!list.length) {
            const leerTxt = !alleKpi.length
                ? 'Warte auf KPI-Quelle — Button oben rechts nutzen'
                : 'Keine Liga-Agenten in diesem Filter (' + [scope.std, scope.stack, scope.team].filter(x => x && x !== 'ALL').join(' / ') +
                  ') — ' + alleKpi.length + ' Agenten geladen. Team-/Stack-Zuordnung kommt aus dem Mapping: ggf. Mitarbeiter-Excel neu importieren.';
            body.innerHTML = `<tr><td colspan="11" style="text-align:center; padding:24px; color:#9C9C9C;">${leerTxt}</td></tr>`;
            ['qKpiCs','qKpiTnps','qKpiAufleger','qKpiFq','qKpiAht','qKpiDet','qKpiKurz','qKpiNonTrack'].forEach(id => setV(id,'—','#7E7E7E'));
            return;
        }

        // Kopf-Leiste: Durchschnitte mit Ziel-Ampel (FF7 kommt erst nach 7 Tagen -> bewusst nicht angezeigt)
        const avg = key => { const v = list.filter(k => k[key] != null); return v.length ? (v.reduce((s,k)=>s+k[key],0)/v.length) : null; };
        const avgCs = avg('cs'), avgTnps = avg('tnps'), avgAq = avg('auflegerquote'), avgFq = avg('fq');
        const ahtVals = list.filter(k => k.ahtSec != null && k.ahtSec > 0);
        const avgAhtMin = ahtVals.length ? (ahtVals.reduce((s,k)=>s+k.ahtSec,0)/ahtVals.length/60) : null;
        const detSum = list.reduce((s,k)=>s+(k.det||0),0);
        // FF7-Schutz: unter 8 Min AHT leidet die 7-Tage-Loesungsquote — sofort gegensteuern
        const kurzArr = list.filter(k => k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 480 && k.callCount >= 5)
                            .sort((a,b) => a.ahtSec - b.ahtSec);
        let nonTrack = 0;
        list.forEach(k => { const a = eslAnsp(k) || 0; if ((k.callCount>=10 && (a/k.callCount)<0.2) || (k.callCount>=5 && a===0)) nonTrack++; });

        const pct = v => v!=null ? v.toFixed(1).replace('.',',')+' %' : '—';
        setV('qKpiCs',   pct(avgCs),   zielColor(avgCs,  RC_ZIELE.cs));
        setV('qKpiTnps', pct(avgTnps), zielColor(avgTnps,RC_ZIELE.tnps));
        setV('qKpiAufleger', pct(avgAq), zielColor(avgAq, RC_ZIELE.aq));
        setV('qKpiFq',   pct(avgFq),   zielColor(avgFq,  RC_ZIELE.fq));
        setV('qKpiAht',  avgAhtMin!=null ? avgAhtMin.toFixed(1).replace('.',',')+' Min' : '—', zielColor(avgAhtMin, RC_ZIELE.ahtMin));
        setV('qKpiDet',  detSum, detSum>0 ? '#E60000' : '#F5F5F5');
        setV('qKpiKurz', kurzArr.length, kurzArr.length>0 ? '#820000' : '#F5F5F5');
        setV('qKpiNonTrack', nonTrack, nonTrack>0 ? '#E60000' : '#F5F5F5');

        // Chart links: CS & TNPS je Standort (horizontale Balken)
        (function(){
            const ctx = document.getElementById('rcQualiStdChart');
            if (!ctx || !window.Chart) return;
            const per = {};
            list.forEach(k => { const c = stdOf(k);
                (per[c] || (per[c] = { cs:[], tnps:[] }));
                if (k.cs != null) per[c].cs.push(k.cs);
                if (k.tnps != null) per[c].tnps.push(k.tnps);
            });
            const codes = ORDER.filter(c => per[c] && (per[c].cs.length || per[c].tnps.length));
            const mean = a => a.length ? +(a.reduce((s,x)=>s+x,0)/a.length).toFixed(1) : null;
            const dCs = codes.map(c => mean(per[c].cs)), dTn = codes.map(c => mean(per[c].tnps));
            const labels = codes.map(c => shortName(c));
            if (window.rcQualiStdChartInstance && (window.rcQualiStdChartInstance.canvas !== ctx || window.rcQualiStdChartInstance.data.labels.length !== labels.length)) {
                try { window.rcQualiStdChartInstance.destroy(); } catch(e){}
                window.rcQualiStdChartInstance = null;
            }
            if (window.rcQualiStdChartInstance) {
                const ch = window.rcQualiStdChartInstance;
                ch.data.labels = labels; ch.data.datasets[0].data = dCs; ch.data.datasets[1].data = dTn; ch.update();
            } else {
                window.rcQualiStdChartInstance = new Chart(ctx, { type:'bar',
                    data:{ labels, datasets:[
                        { label:'CS %',   data:dCs, backgroundColor:'rgba(255,255,255,0.9)', borderRadius:3 },
                        { label:'TNPS %', data:dTn, backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 } ] },
                    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
                        animation:{ duration:800 },
                        plugins:{ legend:{ labels:{ color:'#C9C9C9', boxWidth:9, font:{size:9.5, family:"'VodafoneVF','Vodafone',Arial,sans-serif"} } } },
                        scales:{ x:{ grid:{color:'rgba(255,255,255,0.07)'}, ticks:{color:'#9C9C9C', font:{size:8.5}}, suggestedMax:100 },
                                 y:{ grid:{display:false}, ticks:{color:'#C9C9C9', font:{size:10}} } } } });
            }
        })();

        // Rotierende Rangliste links unten: Feedbackquote -> TNPS -> Abschluss-Potenzial (alle 30 s)
        const rankMode = window.rcQualiRankMode || 'fq';
        const rankTitle = document.getElementById('rcQualiRankTitle');
        const rankEl = document.getElementById('rcQualiRank');
        if (rankMode === 'pot') {
            // Wer Kunden begeistert, aber (fast) nichts abschliesst: Vertrauen ist da — Ansprache fehlt.
            if (rankTitle) rankTitle.textContent = 'Abschluss-Potenzial — Vertrauen ist da';
            const potArr = list.filter(k => k.callCount >= 8 && ((k.cs != null && k.cs >= 85) || (k.tnps != null && k.tnps >= 60)) && eslTotal(k) <= 1)
                .sort((a,b) => ((b.cs||0)+(b.tnps||0)) - ((a.cs||0)+(a.tnps||0))).slice(0,10);
            if (rankEl) rankEl.innerHTML = potArr.length ? potArr.map((k,i) => `<div class="rc-list-item" data-rc-ccs="${rcAttr(k.ccsId)}" data-rc-name="${rcAttr(k.agentName)}">
                    <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                    <div style="flex:1;"><b style="font-size:11.5px;">${getFlagSvg(stdOf(k),'small')} ${k.agentName}</b>
                        <div style="font-size:9px; color:#FF6666; font-weight:700;">Kunden happy — jetzt den Abschluss holen</div></div>
                    <div class="rc-mono" style="color:#F5F5F5; font-size:11px;">${k.cs!=null?'CS '+k.cs.toFixed(0)+'%':''} ${k.tnps!=null?'· TNPS '+k.tnps.toFixed(0)+'%':''}<div style="color:#E60000; text-align:right;">${eslTotal(k)} Abschl.</div></div>
                </div>`).join('') : `<div style="padding:8px; color:#F5F5F5; font-size:11px; font-weight:700;">Alle Top-Servicekraefte schliessen bereits ab</div>`;
        } else {
            if (rankTitle) rankTitle.textContent = rankMode === 'fq' ? 'Feedbackquote — Top 10' : 'TNPS — Top 10';
            const rankKey = rankMode, rankZiel = rankMode === 'fq' ? RC_ZIELE.fq : RC_ZIELE.tnps;
            const rankArr = list.filter(k => k[rankKey] != null && k.callCount >= 5).sort((a,b) => b[rankKey] - a[rankKey]).slice(0,10);
            if (rankEl) rankEl.innerHTML = rankArr.length ? rankArr.map((k,i) => `<div class="rc-list-item" data-rc-ccs="${rcAttr(k.ccsId)}" data-rc-name="${rcAttr(k.agentName)}">
                    <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                    <div style="flex:1;"><b style="font-size:11.5px;">${getFlagSvg(stdOf(k),'small')} ${k.agentName}</b></div>
                    <div class="rc-mono" style="color:${zielColor(k[rankKey], rankZiel)}; font-size:13px;">${k[rankKey].toFixed(1).replace('.',',')} %</div>
                </div>`).join('') : `<div style="padding:8px; color:#9C9C9C; font-size:11px;">Noch keine belastbaren Werte</div>`;
        }

        // FF7-Fruehwarnung: unter 8 Min wird das Kundenanliegen selten wirklich geloest — unter 6:30 ist es kritisch
        const kurzEl = document.getElementById('rcKurzTelList');
        if (kurzEl) {
            kurzEl.innerHTML = kurzArr.length ? kurzArr.slice(0,12).map(k => `<div class="rc-warn-item${k.ahtSec < 390 ? ' hart' : ''}" data-rc-ccs="${rcAttr(k.ccsId)}" data-rc-name="${rcAttr(k.agentName)}">
                <span class="nm">${getFlagSvg(stdOf(k),'small')} ${k.agentName}${k.ahtSec < 390 ? ' <span style="color:#E60000; font-size:8.5px; font-weight:700; letter-spacing:0.5px;">SOFORT EINGREIFEN</span>' : ''}</span>
                <span class="wv">Ø <b style="color:${k.ahtSec<390?'#E60000':'#FF6666'};">${fmtAht(k.ahtSec)} Min</b> · ${k.callCount} Calls</span>
            </div>`).join('') : `<div style="padding:10px; color:#F5F5F5; font-size:11px; font-weight:700;">Alle Gespraechszeiten im Zielbereich</div>`;
        }

        // Detraktoren-Modul rechts: sofortiger Handlungsbedarf
        const detEl = document.getElementById('rcDetraktorList');
        if (detEl) {
            const detArr = list.filter(k => (k.det||0) > 0).sort((a,b) => (b.det||0)-(a.det||0) || (b.dds||0)-(a.dds||0));
            detEl.innerHTML = detArr.length ? detArr.slice(0,12).map(k => {
                const kritisch = k.dds != null && k.dds > RC_ZIELE.dds.max;
                return `<div class="rc-det-item${kritisch?' rc-det-critical':''}" data-rc-ccs="${rcAttr(k.ccsId)}" data-rc-name="${rcAttr(k.agentName)}">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <b style="font-size:12px; color:#F5F5F5;">${getFlagSvg(stdOf(k),'small')} ${k.agentName}</b>
                        <span class="rc-mono" style="color:#E60000; font-size:14px;">${k.det}</span>
                    </div>
                    <div style="font-size:10px; color:#E60000; margin-top:2px;">
                        ${kritisch ? `DDS ${k.dds.toFixed(1).replace('.',',')} % — ueber Limit, sofort gegensteuern` : `Detraktoren heute — Gespraech nachhalten`}
                    </div>
                </div>`; }).join('')
                : `<div style="padding:10px; color:#F5F5F5; font-size:11px; font-weight:700;">Keine Detraktoren — Qualitaet stabil</div>`;
        }

        // Haupttabelle
        const sk = window.rcQualiSort || 'calls';
        list.sort((a,b) => {
            const va = (sk==='calls') ? (a.callCount||0) : (a[sk]!=null?a[sk]:-1);
            const vb = (sk==='calls') ? (b.callCount||0) : (b[sk]!=null?b[sk]:-1);
            return vb - va;
        });
        const cell = (v, ziel) => `<td style="text-align:center; color:${zielColor(v, ziel)};" class="rc-mono">${v!=null?v.toFixed(1).replace('.',','):'—'}</td>`;
        let html = '';
        list.slice(0,80).forEach((k, i) => {
            const hl = i===0?'rc-table-row-1':(i===1?'rc-table-row-2':(i===2?'rc-table-row-3':''));
            const ansp = eslAnsp(k);
            const isNonTrack = (k.callCount>=10 && ansp!=null && (ansp/k.callCount)<0.2) || (k.callCount>=5 && ansp===0);
            const rowStyle = isNonTrack ? ' style="background:rgba(230,0,0,0.06); box-shadow:inset 3px 0 0 #820000;"' : '';
            const callCol = zielColor(k.callCount, RC_ZIELE.calls);
            html += `<tr class="${hl}"${rowStyle} data-rc-ccs="${rcAttr(k.ccsId)}" data-rc-name="${rcAttr(k.agentName)}" title="Klick: Agenten-Details">
                <td style="text-align:center;"><div class="rc-rank-badge ${rankClass(i)}">${i+1}</div></td>
                <td><b style="font-size:12px;">${getFlagSvg(stdOf(k),'small')} ${k.agentName}</b>${isNonTrack?' <span style="color:#E60000; font-size:8.5px; font-weight:700; letter-spacing:0.4px;">KEINE ANSPRACHE</span>':''}<div class="rc-mono" style="color:#9A9A9A; font-size:9px; font-weight:400;">${teamOf(k)}</div></td>
                <td style="text-align:center; color:${callCol}; font-size:13px;" class="rc-mono">${k.callCount!=null?k.callCount:'—'}</td>
                <td style="text-align:center; color:${zielColor(k.ahtSec!=null?k.ahtSec/60:null, RC_ZIELE.ahtMin)};" class="rc-mono">${fmtAht(k.ahtSec)}</td>
                ${cell(k.auflegerquote, RC_ZIELE.aq)}
                ${cell(k.cs, RC_ZIELE.cs)}
                ${cell(k.tnps, RC_ZIELE.tnps)}
                ${cell(k.fq, RC_ZIELE.fq)}
                ${cell(k.dds, RC_ZIELE.dds)}
                <td style="text-align:center; color:${(k.det||0)>0?'#E60000':'#F5F5F5'};" class="rc-mono">${k.det!=null?k.det:'—'}</td>
                <td style="text-align:center; color:#F5F5F5; font-size:12px;" class="rc-mono">${ansp!=null?ansp:'—'}</td>
            </tr>`;
        });
        body.innerHTML = html;
    };

    // ============================================================
    //  SEITE 3: RADAR — KRIEGSKARTE (Burgeroberung, Feldherren-Optik)
    // ============================================================
    // Handplatzierte Schlachtfeld-Positionen im 1000x640-Raum — bewusst KEINE
    // Geo-Projektion mehr: jede Burg hat Luft fuer Labels/HP-Balken, die
    // Tuerkei steht prominent im Osten statt gequetscht in der Ecke.
    // Grobe Himmelsrichtungen bleiben erhalten (DE Nordwest, GR Sued, TR Ost).
    const RC_WAR_POS = {
        E:   [150, 170], B:   [350, 165], NBB: [455, 95],  P:   [235, 280],
        ZWT: [475, 300], SER: [330, 480], ADP: [510, 525],
        SKA: [740, 215], AL:  [775, 440]
    };
    const RC_WAR_REGIONS = [
        { name:'DEUTSCHLAND',  codes:['E','B','NBB','P'], label:[295, 215], col:'220,220,220' },
        { name:'OESTERREICH',  codes:['ZWT'],             label:[475, 355], col:'150,150,150' },
        { name:'GRIECHENLAND', codes:['SER','ADP'],       label:[420, 588], col:'80,140,210'  },
        { name:'TUERKEI',      codes:['SKA','AL'],        label:[770, 330], col:'230,0,0'     }
    ];

    window.rcRadarEvents = window.rcRadarEvents || [];

    function buildRadar(){
        const wrap = document.getElementById('rcRadarSvgWrap');
        if (!wrap || window.rcRadarBuilt) return;
        // Reichsgebiete: weicher Farbfleck + gestrichelte Grenze je Nation
        let zones = '', labels = '';
        RC_WAR_REGIONS.forEach(r => {
            const pts = r.codes.map(c => RC_WAR_POS[c]).filter(Boolean);
            if (!pts.length) return;
            const cx = pts.reduce((s,p)=>s+p[0],0)/pts.length, cy = pts.reduce((s,p)=>s+p[1],0)/pts.length;
            const rx = Math.max(115, ...pts.map(p=>Math.abs(p[0]-cx)+108));
            const ry = Math.max(95,  ...pts.map(p=>Math.abs(p[1]-cy)+88));
            zones += `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="rgba(${r.col},0.05)" filter="url(#rcMapBlur)"/>
                <ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="none" stroke="rgba(${r.col},0.26)" stroke-width="1.4" stroke-dasharray="7 5"/>`;
            labels += `<text x="${r.label[0]}" y="${r.label[1]}" text-anchor="middle" font-family="Georgia, 'Times New Roman', serif" font-size="16" font-weight="700" letter-spacing="7" fill="rgba(${r.col},0.38)">${r.name}</text>`;
        });
        // Kartenschmuck: Gebirgszuege + Fluesse wie auf alten Feldherren-Karten
        const mounts = [[600,120],[643,142],[588,162],[655,182],[615,205],[660,330],[625,362],[663,392],[300,360],[342,385],[268,395],[560,245],[865,520],[905,545],[840,555]]
            .map(m => `<path d="M${m[0]-13},${m[1]+8} L${m[0]},${m[1]-9} L${m[0]+13},${m[1]+8} M${m[0]-4},${m[1]-2} L${m[0]+3},${m[1]+4}" fill="none" stroke="rgba(160,140,110,0.32)" stroke-width="1.6" stroke-linejoin="round"/>`).join('');
        const rivers = `<path d="M60,430 C180,415 240,455 330,428 C420,402 435,362 520,372" fill="none" stroke="rgba(90,130,160,0.26)" stroke-width="3"/>
            <path d="M910,70 C865,160 885,260 832,330 C790,388 700,392 660,472" fill="none" stroke="rgba(90,130,160,0.22)" stroke-width="3"/>`;
        // Kompassrose unten rechts
        const compass = `<g transform="translate(942,588)" opacity="0.45">
            <circle r="26" fill="none" stroke="#8A745A" stroke-width="1.2"/>
            <circle r="16" fill="none" stroke="#8A745A" stroke-width="0.7"/>
            <path d="M0,-24 L4,0 L0,24 L-4,0 Z" fill="#8A745A"/>
            <path d="M-24,0 L0,4 L24,0 L0,-4 Z" fill="#5E4E3A"/>
            <text y="-30" text-anchor="middle" font-family="Georgia,serif" font-size="11" font-weight="700" fill="#A08A66">N</text></g>`;
        // Feine Schraffur (Pergament-Textur)
        let hatch = '';
        for (let i = -640; i < 1000; i += 27) hatch += `<line x1="${i}" y1="0" x2="${i+640}" y2="640" stroke="rgba(255,255,255,0.015)" stroke-width="1"/>`;
        wrap.innerHTML = `<svg viewBox="0 0 1000 640" preserveAspectRatio="xMidYMid meet">
            <defs>
                <radialGradient id="rcMapLight" cx="0.5" cy="0.42" r="0.78">
                    <stop offset="0" stop-color="#251E14"/><stop offset="0.62" stop-color="#1B1610"/><stop offset="1" stop-color="#0E0B07"/>
                </radialGradient>
                <filter id="rcMapBlur" x="-40%" y="-40%" width="180%" height="180%"><feGaussianBlur stdDeviation="7"/></filter>
                <clipPath id="rcRadarClip"><rect x="0" y="0" width="1000" height="640"/></clipPath>
            </defs>
            <rect x="0" y="0" width="1000" height="640" fill="url(#rcMapLight)"/>
            <g clip-path="url(#rcRadarClip)">
                ${hatch}${zones}${rivers}${mounts}${labels}${compass}
                <rect x="6" y="6" width="988" height="628" fill="none" stroke="#3A2F22" stroke-width="2"/>
                <rect x="11" y="11" width="978" height="618" fill="none" stroke="rgba(138,116,90,0.35)" stroke-width="1"/>
                <g id="rcRadarPings"></g>
            </g>
        </svg>`;
        window.rcRadarBuilt = true;
    }

    window.renderRadar = function(){
        buildRadar();
        // Umschalter Sales League <-> Burg (klassisch) im Karten-Header
        (function(){
            const status = document.getElementById('rcRadarStatusLine');
            const head = status ? status.parentElement : null;
            if (head && !document.getElementById('rcRadarModeBtn')) {
                const btn = document.createElement('button');
                btn.id = 'rcRadarModeBtn';
                btn.style.cssText = 'margin-left:auto; margin-right:8px; background:#16202C; color:#F5F5F5; border:1px solid rgba(255,255,255,0.25); border-radius:4px; font:700 10px VodafoneVF,Vodafone,Arial; padding:3px 10px; cursor:pointer;';
                btn.onclick = () => window.rcSetRadarMode(window.rcRadarMode === 'league' ? 'burg' : 'league');
                head.insertBefore(btn, status || null);
                window.rcSetRadarMode(window.rcRadarMode); // Beschriftung + Titel setzen
            }
        })();
        const stats = (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        const kpis = Object.values(window.rcKpiData || {});
        // Risiko-Lage je Standort: FF7-Faelle (AHT < 8 Min), Detraktoren, Liga-Calls
        const risk = {};
        kpis.forEach(k => {
            const c = normalizeStandort(k.standort);
            const r = risk[c] || (risk[c] = { ff7:0, det:0, calls:0 });
            r.calls += k.callCount || 0;
            if (k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 480 && (k.callCount||0) >= 5) r.ff7++;
            r.det += k.det || 0;
        });
        let totalSales = 0, totalBcr = 0, totalNonBcr = 0;
        ORDER.forEach(code => {
            const s = stats[code];
            const bcr = s ? bcrOf(s) : 0, nonBcr = s ? nonBcrOf(s) : 0;
            const cnt = s ? (s.total||0) : 0; totalSales += cnt; totalBcr += bcr; totalNonBcr += nonBcr;
            const el = document.getElementById('rcBlipCnt_' + code);
            // Blip zeigt BCR-relevante Abschluesse und (falls vorhanden) die nicht-relevanten
            if (el) el.textContent = nonBcr > 0 ? `${bcr} BCR-rel. · ${nonBcr} n.rel.` : `${bcr} BCR-rel.`;
            // Krisenherd-Ring: FF7-Haeufung, Detraktoren, schwache Ansprache ODER zu viel Nicht-BCR
            const r = risk[code] || { ff7:0, det:0, calls:0 };
            const anspQ = (r.calls >= 30 && s) ? (s.pitches||0) / r.calls : null;
            const nbShare = nonBcrShare(s || {});
            const vvlLastig = (bcr + nonBcr) >= 4 && nbShare > RC_NONBCR_WARN;
            const hot = r.ff7 >= 2 || r.det >= 3 || (anspQ != null && anspQ < 0.3) || vvlLastig;
            if (window.rcWarSetWarn) window.rcWarSetWarn(code, hot);
            const warnEl = document.getElementById('rcBlipWarn_' + code);
            const warnTxt = document.getElementById('rcBlipWarnTxt_' + code);
            if (warnEl) warnEl.style.display = hot ? '' : 'none';
            if (warnTxt) {
                const parts = [];
                if (r.ff7 >= 2) parts.push(r.ff7 + ' FF7');
                if (r.det >= 3) parts.push(r.det + ' DET');
                if (anspQ != null && anspQ < 0.3) parts.push('ANSP ' + Math.round(anspQ*100) + '%');
                if (vvlLastig) parts.push('N-BCR ' + Math.round(nbShare*100) + '%');
                warnTxt.textContent = parts.join(' · ');
                warnTxt.style.display = hot ? '' : 'none';
            }
        });
        // Einsatzlage ueber dem Log: was ist gerade offen?
        let nFF7 = 0, nDet = 0, nNoAnsp = 0;
        kpis.forEach(k => {
            if (k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 480 && (k.callCount||0) >= 5) nFF7++;
            if ((k.det||0) > 0) nDet++;
        });
        if (window.rcLetzteStats) Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
            const kpi = window.rcKpiForAgent(ag);
            if (kpi && (kpi.callCount||0) >= 5 && (ag.ansprachen||0) === 0) nNoAnsp++;
        });
        const ops = document.getElementById('rcRadarOps');
        if (ops) ops.textContent = (nFF7 || nDet || nNoAnsp)
            ? `Offen: ${nFF7} FF7 · ${nDet} Det · ${nNoAnsp} o. Anspr.` : 'Keine offenen Einsaetze';
        // Action-Radar: Basen mit Tages-Zahlen versorgen (Level, Gewusel, Fuehrung)
        if (window.rcWarSync) window.rcWarSync(stats);
        const line = document.getElementById('rcRadarStatusLine');
        if (line) {
            // Power-Hour: die staerkste Stunde des Tages als Benchmark fuer die laufende Stunde
            let ph = '';
            const hs = window.rcHourStats;
            if (hs && hs.totals && hs.totals.length) {
                const bi = hs.totals.indexOf(Math.max(...hs.totals));
                if (hs.totals[bi] > 0) ph = ' · POWER-HOUR ' + hs.labels[bi] + ' (' + hs.totals[bi] + ') · AKTUELLE STUNDE ' + (hs.totals[hs.totals.length-1] || 0);
            }
            const nb = (totalBcr + totalNonBcr) > 0 ? Math.round(totalNonBcr / (totalBcr + totalNonBcr) * 100) : 0;
            line.textContent = 'SYSTEM AKTIV · ' + totalBcr + ' BCR-REL. · ' + totalNonBcr + ' NICHT-BCR-REL. (' + nb + '%)' + ph + ' · ' + new Date().toLocaleTimeString('de-DE');
        }
        // Einsatz-Log — BCR-relevant rot, nicht relevant grau markiert
        const log = document.getElementById('rcRadarLog');
        if (log && window.rcRadarEvents.length) {
            log.innerHTML = window.rcRadarEvents.map(e => {
                const nrel = e.bcr === false;
                return `<div class="rc-radar-log-item" style="border-left-color:${nrel?'#6E6E6E':'#E60000'}; background:${nrel?'rgba(126,126,126,0.12)':'rgba(230,0,0,0.12)'};">[${e.time}] <b>${e.call}</b> — ${nrel?'nicht BCR-rel.':'BCR-rel.'}: ${e.prod} <span style="color:#9C9C9C;">(${e.name})</span></div>`;
            }).join('');
        }
        if (window.renderRadarIntel) window.renderRadarIntel();
        if (window.renderRadarMission) window.renderRadarMission();
        if (window.renderRadarKrieger) window.renderRadarKrieger();
        if (window.renderLowPerformer) window.renderLowPerformer();
    };

    // Manager-Panels im Radar: Funnel (wo geht Umsatz verloren?) und
    // Quadranten-Matrix (welcher Agent braucht welches Coaching?)
    window.renderRadarIntel = function(){
        const fEl = document.getElementById('rcRadarFunnel');
        const mEl = document.getElementById('rcRadarMatrix');
        if (!fEl && !mEl) return;
        const stats = (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        const filterVal = (document.getElementById('rcStandortFilter')||{}).value || 'ALL';
        const teamSel = document.getElementById('rcTeamFilter');
        const filterTeam = (filterVal !== 'ALL' && teamSel) ? teamSel.value : 'ALL';
        // Liga-Calls im selben Scope wie die ESL-Zahlen (zentral: Standort+Team+Stack)
        const ligaCalls = window.rcLigaAgg ? window.rcLigaAgg().total : 0;
        const sum = key => Object.values(stats).reduce((s,x) => s + (x[key]||0), 0);
        const bcr = sum('bcr'), nonBcr = sum('nonBcr');
        const ansp = sum('pitches'), sales = sum('bnt') + sum('vvl'),
              offers = sum('offers'), rej = sum('rejections'), eslKontakte = sum('calls');
        const nbShareAll = (bcr + nonBcr) > 0 ? nonBcr / (bcr + nonBcr) : 0;
        // Erste Funnel-Stufe: echte Telefonate aus der Ligaliste; ohne KPI-Quelle die ESL-Kontakte
        const baseCalls = ligaCalls > 0 ? ligaCalls : eslKontakte;
        const baseLbl = ligaCalls > 0 ? 'Calls (Ligaliste)' : 'Kontakte (ESL)';
        if (fEl) {
            if (!baseCalls) { fEl.innerHTML = '<div style="color:#9C9C9C; font-size:11px;">Warte auf Daten</div>'; }
            else {
                const q1 = ansp / baseCalls * 100;        // Ansprachequote (Ziel 40 %)
                const q2 = ansp ? sales / ansp * 100 : 0; // Abschluss aus Ansprache (Heuristik-Ziel 20 %)
                const lever = (q1/40 <= q2/20) ? 1 : 2;   // schlechteste relative Zielerreichung = groesster Hebel
                const row = (lbl, val, pct, col) => `<div class="rc-fn-row">
                    <div class="rc-fn-top"><span class="lbl">${lbl}</span><b>${val.toLocaleString('de-DE')}</b></div>
                    <div class="rc-fn-bar"><div class="rc-fn-fill" style="width:${Math.max(3,pct)}%; background:${col};"></div></div>
                </div>`;
                const conv = (q, ziel, isLever) => `<div class="rc-fn-conv">&darr; <b style="color:${zielColor(q,{min:ziel})};">${q.toFixed(1).replace('.',',')} %</b>${isLever?'<span class="rc-fn-lever">Groesster Hebel</span>':''}</div>`;
                // Nicht-BCR-Anteil: je hoeher, desto mehr Fokus-Problem -> Warnfarbe
                const nbCol = nbShareAll > RC_NONBCR_WARN ? '#E60000' : (nbShareAll > 0.35 ? '#FF6666' : '#F5F5F5');
                fEl.innerHTML =
                    row(baseLbl, baseCalls, 100, '#F5F5F5') +
                    conv(q1, 40, lever === 1) +
                    row('Ansprachen', ansp, ansp/baseCalls*100, '#FF6666') +
                    conv(q2, 20, lever === 2) +
                    row('Abschluesse', sales, sales/baseCalls*100, '#E60000') +
                    `<div class="rc-fn-conv" style="display:flex; justify-content:space-between;">
                        <span>davon <b style="color:#E60000;">${bcr} BCR-relevant</b> &middot; <b style="color:${nbCol};">${nonBcr} nicht</b></span>
                        <span>Nicht-BCR-Anteil <b style="color:${nbCol};">${Math.round(nbShareAll*100)} %</b>${nbShareAll > RC_NONBCR_WARN ? ' <span class="rc-fn-lever">zu hoch</span>' : ''}</span>
                    </div>
                    <div class="rc-fn-split">
                        <div class="rc-fn-chip"><b>${offers}</b><span>Offen</span></div>
                        <div class="rc-fn-chip"><b>${rej}</b><span>Abgelehnt</span></div>
                        <div class="rc-fn-chip"><b>${eslKontakte}</b><span>${ligaCalls > 0 ? 'Getrackt (' + Math.round(eslKontakte/ligaCalls*100) + ' %)' : 'ESL-Kontakte'}</span></div>
                    </div>`;
            }
            // Karten-Hinweis: Gestern-Vergleich zur gleichen Stunde (nur Gesamtsicht)
            const hint = document.getElementById('rcFunnelHint');
            if (hint) {
                let t = 'Calls → Ansprachen → Abschluesse';
                try {
                    const store = window.rcDayTrend || JSON.parse(localStorage.getItem('rcDayTrend') || '{}');
                    const d = new Date(), hh = d.getHours();
                    const yd = new Date(d.getTime() - 86400000);
                    const ydKey = yd.getFullYear() + '-' + pad2(yd.getMonth()+1) + '-' + pad2(yd.getDate());
                    const y = store[ydKey];
                    if (y && filterVal === 'ALL') {
                        // 'b'-Schluessel = BNT-Stundenwerte; numerische = alte BCR-rel. (Fallback)
                        let yv = null, yvAlt = null;
                        Object.keys(y).forEach(k => {
                            if (k.charAt(0) === 'b') { const h = +k.slice(1); if (!isNaN(h) && h <= hh) yv = y[k]; }
                            else { const h = +k; if (!isNaN(h) && h <= hh) yvAlt = y[k]; }
                        });
                        if (yv == null) yv = yvAlt;
                        if (yv != null) t = 'Gestern um diese Zeit: ' + yv + ' BNT';
                    }
                } catch(e){}
                hint.textContent = t;
            }
        }
        if (mEl) {
            // Quadranten: Qualitaet ok = CS>=85 oder TNPS>=60; Sales ok = 2+ Abschluesse (min. 5 Calls)
            const cells = { champ:[], risk:[], coach:[], alarm:[] };
            if (window.rcLetzteStats) Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
                const kpi = window.rcKpiForAgent(ag);
                if (!kpi || (kpi.callCount||0) < 5) return;
                const q = (kpi.cs != null && kpi.cs >= 85) || (kpi.tnps != null && kpi.tnps >= 60);
                const s = (ag.total||0) >= 2;
                (s && q ? cells.champ : (s && !q ? cells.risk : (!s && q ? cells.coach : cells.alarm))).push(ag.name);
            });
            const cell = (cls, title, act, actCol, list) => `<div class="rc-quad-cell ${cls}">
                <div class="rc-quad-t">${title}</div>
                <div class="rc-quad-n">${list.length}</div>
                <div class="rc-quad-act" style="color:${actCol};">${act}</div>
                <div class="rc-quad-names">${list.slice(0,3).join('<br>')}${list.length > 3 ? '<br>+' + (list.length-3) + ' weitere' : ''}</div>
            </div>`;
            mEl.innerHTML =
                cell('q-champ', 'Champions', 'Feiern + Best Practice teilen', '#E60000', cells.champ) +
                cell('q-risk', 'Verkauf top, Qualitaet leidet', 'FF7 / CS sichern — sofort', '#FF6666', cells.risk) +
                cell('', 'Vertrauen da, kein Abschluss', 'Ansprache coachen', '#F5F5F5', cells.coach) +
                cell('q-alarm', 'Beides schwach', 'Prioritaet fuer Teamleitung', '#E60000', cells.alarm);
        }
    };

    // Rotierende Radar-Charts rechts: 4 Sichten, alle 30 s einen weiter
    window.renderRadarCharts = function(state){
        if (!window.Chart) return;
        const stats = (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        const codes = ORDER.filter(c => stats[c] && stats[c].calls > 0);
        if (!codes.length) return;
        // TNPS je Standort aus den KPI-Daten
        const tnpsPer = {};
        Object.values(window.rcKpiData || {}).forEach(k => {
            if (k.tnps == null) return;
            const c = normalizeStandort(k.standort);
            (tnpsPer[c] || (tnpsPer[c] = [])).push(k.tnps);
        });
        const mean = a => a && a.length ? +(a.reduce((s,x)=>s+x,0)/a.length).toFixed(1) : null;
        const ligaR = window.rcLigaAgg ? window.rcLigaAgg() : { byStd:{} };
        const views = [
            { t:'BNT (Neuvertraege) je Standort', col:'rgba(230,0,0,0.85)', fn:c => (stats[c].bnt || 0) },
            { t:'BCR gesamt (Liga-Basis) in %',   col:'rgba(255,255,255,0.9)', fn:c => ligaR.byStd[c] ? +(bcrOf(stats[c])/ligaR.byStd[c]*100).toFixed(1) : 0 },
            { t:'Nicht-BCR-Anteil je Standort in %', col:'rgba(130,0,0,0.85)', fn:c => +(nonBcrShare(stats[c])*100).toFixed(1) },
            { t:'Ansprachequote je Standort',     col:'rgba(74,77,78,0.85)', fn:c => stats[c].calls ? +((stats[c].pitches||0)/stats[c].calls*100).toFixed(1) : 0 },
            { t:'Ø TNPS je Standort in %',        col:'rgba(126,126,126,0.8)', fn:c => mean(tnpsPer[c]) }
        ];
        const labels = codes.map(c => shortName(c));
        const drawInto = (canvasId, instKey, titleId, view) => {
            const ctx = document.getElementById(canvasId); if (!ctx) return;
            const tEl = document.getElementById(titleId); if (tEl) tEl.textContent = view.t;
            const data = codes.map(view.fn);
            if (window[instKey] && window[instKey].canvas !== ctx) { try { window[instKey].destroy(); } catch(e){} window[instKey] = null; }
            if (window[instKey]) {
                const ch = window[instKey];
                ch.data.labels = labels;
                ch.data.datasets[0].data = data;
                ch.data.datasets[0].label = view.t;
                ch.data.datasets[0].backgroundColor = view.col;
                ch.update();
            } else {
                window[instKey] = new Chart(ctx, { type:'bar',
                    data:{ labels, datasets:[{ label:view.t, data, backgroundColor:view.col, borderRadius:3 }] },
                    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, animation:{ duration:700 },
                        plugins:{ legend:{ display:false } },
                        scales:{ x:{ grid:{color:'rgba(255,255,255,0.07)'}, ticks:{color:'#9C9C9C', font:{size:8.5}} },
                                 y:{ grid:{display:false}, ticks:{color:'#C9C9C9', font:{size:9.5}} } } } });
            }
        };
        const i = ((state || 0) % views.length + views.length) % views.length;
        drawInto('rcRadarChartA', 'rcRadarChartA_i', 'rcRadarChartATitle', views[i]);
        drawInto('rcRadarChartB', 'rcRadarChartB_i', 'rcRadarChartBTitle', views[(i+1) % views.length]);
    };

    window.rcRadarPing = function(code, name, prod, time, isBcr){
        const m = STANDORT_METADATA[code]; if (!m || !RC_WAR_POS[code]) return;
        window.rcRadarEvents.unshift({ time: time || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}), call: m.short, name, prod, code, bcr: isBcr !== false });
        if (window.rcRadarEvents.length > 14) window.rcRadarEvents.pop();
        buildRadar();
        const g = document.getElementById('rcRadarPings');
        if (g) {
            const [x,y] = RC_WAR_POS[code];
            const ping = document.createElementNS('http://www.w3.org/2000/svg','g');
            ping.setAttribute('class','rc-ping-g');
            ping.setAttribute('style',`transform-origin:${x}px ${y}px;`);
            // BCR-Ping = Electric Red, Nicht-BCR (VVL) = neutrales Grau
            ping.innerHTML = `<circle cx="${x}" cy="${y}" r="10" fill="none" stroke="${isBcr === false ? '#9A9A9A' : '#E60000'}" stroke-width="2.5"/>`;
            g.appendChild(ping);
            setTimeout(() => ping.remove(), 2700);
        }
        // Action-Radar: Abschluss in eine Gefechts-Einheit uebersetzen (Panzer/Rakete/...)
        if (window.rcWarSpawn) window.rcWarSpawn(code, name, prod, isBcr, time);
        if (window.rcActivePage === 'radar') window.renderRadar();
    };

    // ============================================================
    //  ACTION-RADAR — Schlachtfeld im Age-of-Empires-Stil (Canvas ueber
    //  der SVG-Karte). Jeder Standort ist eine BURG mit Nationalflagge
    //  auf dem Turm; jeder Abschluss schickt ein gut sichtbares,
    //  verspieltes Maennchen mit Hero-Tag des Verkaeufers los:
    //    Mobilfunk-BNT -> Ritter marschiert zur Rivalen-Burg und gewinnt
    //                     dort ein Schwert-Duell gegen einen Verteidiger
    //    KIP-BNT       -> Katapult schleudert einen Felsbrocken (Staub+Truemmer)
    //    Giga/DSL      -> Bogenschuetze feuert einen Pfeilhagel
    //    Premium-TV    -> Lanzenreiter attackiert im Galopp
    //    ENV/Sonstige  -> Speerwerfer
    //    VVL           -> Versorgungskarren + Holz-Palisade (Bestand sichern)
    //  Liga-Calls erzeugen Dorf-Gewusel (Bauern mit Saecken und Schubkarren).
    //  Der Tagesfuehrer traegt die goldene Krone. Alles Vektor-Canvas —
    //  kein Sprite-Asset, kein CDN, kein Build-Step, keine Emojis.
    // ============================================================
    const RC_WAR = {
        active:false, canvas:null, ctx:null, lastT:0, t:0, qT:0,
        view:{ s:1, ox:0, oy:0, w:0, h:0, dpr:1 },
        bases:{}, units:[], fx:[], scars:[], feed:[], queue:[],
        leader:null, shake:0, basesBuilt:false,
        burst:0, bT:2,
        unitScale:2,
        baseScale:1.6,
        score: RC_WAR_SCORE,   // OPTION B: gewichtete Tageswertung, live tunable (rcWar.score.kip=40)
        ziele:{ kipProAgent:1, mobProAgent:2 }, // Persoenliches Tagesziel je Agent (Live-Handle: rcWar.ziele)
        kingPulse:{ kip:0, mob:0 }, // Puls-Animation der Koenigs-Counter bei neuem KIP/MOB-Verkauf
        // BURGEROBERUNG — Conquest System
        // KNALLER-Balance (19.07.2026 — "jeder Abschluss hinterlaesst Spuren"):
        //   dmgOther 6->12: Nicht-KIP/MOB reisst jetzt spuerbar HP ab.
        //   regenPerMin 3->0.5 UND regenCsGate: NUR Burgen mit CS>=90 heilen —
        //     "Qualitaet verteidigt" ist damit real (schwache Burgen bleiben wund).
        //   rebuildMin ENTFERNT: erobert bleibt erobert bis zum Freikauf (1 KIP+1 MOB).
        // Live justierbar in der Konsole: rcWar.balance.dmgKip = ...
        balance:{ hpByLevel:[300, 380, 460, 560, 700], dmgKip:100, dmgMob:70, dmgOther:12, regenPerMin:0.5, regenCsGate:90 },
        cam:{ x:500, y:320, z:1, tx:500, ty:320, tz:1, hold:0 },  // Kino-Kamera (Nahaufnahmen)
        banner:null,         // grosses Event-Banner {lines[], col, t, dur}
        conquestLog: [],     // [{attacker, defender, time}]
        chronik: [],         // CHRONIK DES TAGES — lesbare Ereignis-Liste (max 10)
        duelHistory: [],     // abgeschlossene Stunden-Duelle {h, a, b, sa, sb, win}
        duel: null,          // aktives Stunden-Duell (in Saeule C gesetzt)
        nationElim: {}       // {nation: true} wenn alle Burgen einer Nation gefallen
    };
    window.rcWar = RC_WAR; // Debug-Zugriff

    const RC_WAR_MAXU = 9;
    const rcWarLabelOfs = { SKA:{dx:-30,align:'right'}, AL:{dx:-30,align:'right'}, E:{dx:26,align:'left'} };
    const rcWarFont = (px, bold) => (bold?'700 ':'') + px + "px 'VodafoneVF','Vodafone',Arial,sans-serif";
    const heroName = n => { const t = (n||'').toString().trim().split(/\s+/); return t.length >= 2 ? t[0] + ' ' + t[1][0] + '.' : (t[0]||''); };
    const catLabel = c => ({ kip:'KIP', mob:'MOB', fibDsl:'GIGA', ptv:'TV', env:'ENV', sonstBnt:'BNT', kipVvl:'VVL', mobVvl:'VVL', fibVvl:'VVL' })[c] || 'BNT';
    // Grund der Mission — steht sichtbar unter dem Hero-Tag (WARUM rennt der da?)
    const reasonOf = c => ({ kip:'KIP-BNT VERKAUFT', mob:'MOBILFUNK-BNT VERKAUFT', fibDsl:'GIGA-BNT VERKAUFT', ptv:'PREMIUM-TV VERKAUFT',
        env:'ENV-BNT VERKAUFT', sonstBnt:'BNT VERKAUFT', kipVvl:'KIP-VVL GESICHERT', mobVvl:'MOBILFUNK-VVL GESICHERT', fibVvl:'VVL GESICHERT' })[c] || 'ABSCHLUSS';
    const rcWarDist = (a,b) => Math.hypot(b.x-a.x, b.y-a.y);
    const rcWarAng = (a,b) => Math.atan2(b.y-a.y, b.x-a.x);
    // Nationalflaggen-Farben (bewusst Original — Nationalstolz auf der Karte)
    const RC_FLAGS = {
        TR: ctxF => { ctxF.fillStyle='#E30A17'; ctxF.fillRect(0,0,12,8);
            ctxF.fillStyle='#FFFFFF'; ctxF.beginPath(); ctxF.arc(4.6,4,2.1,0,7); ctxF.fill();
            ctxF.fillStyle='#E30A17'; ctxF.beginPath(); ctxF.arc(5.3,4,1.7,0,7); ctxF.fill();
            ctxF.fillStyle='#FFFFFF'; ctxF.beginPath(); ctxF.arc(7.6,4,0.8,0,7); ctxF.fill(); },
        GR: ctxF => { for (let i=0;i<5;i++){ ctxF.fillStyle = i%2 ? '#FFFFFF' : '#0D5EAF'; ctxF.fillRect(0,i*1.6,12,1.6); }
            ctxF.fillStyle='#0D5EAF'; ctxF.fillRect(0,0,4.6,4.8);
            ctxF.strokeStyle='#FFFFFF'; ctxF.lineWidth=0.9;
            ctxF.beginPath(); ctxF.moveTo(2.3,0); ctxF.lineTo(2.3,4.8); ctxF.moveTo(0,2.4); ctxF.lineTo(4.6,2.4); ctxF.stroke(); },
        DE: ctxF => { ctxF.fillStyle='#111111'; ctxF.fillRect(0,0,12,2.7); ctxF.fillStyle='#DD0000'; ctxF.fillRect(0,2.7,12,2.7);
            ctxF.fillStyle='#FFCE00'; ctxF.fillRect(0,5.4,12,2.6); },
        AT: ctxF => { ctxF.fillStyle='#ED2939'; ctxF.fillRect(0,0,12,2.7); ctxF.fillStyle='#FFFFFF'; ctxF.fillRect(0,2.7,12,2.7);
            ctxF.fillStyle='#ED2939'; ctxF.fillRect(0,5.4,12,2.6); }
    };

    function rcWarEnsureBases(){
        if (RC_WAR.basesBuilt) return RC_WAR.bases;
        const hp0 = RC_WAR.balance.hpByLevel[0];
        ORDER.forEach(code => {
            const m = STANDORT_METADATA[code]; if (!m || !RC_WAR_POS[code]) return;
            const [x, y] = RC_WAR_POS[code];
            let h = 0; for (let i=0;i<code.length;i++) h += code.charCodeAt(i);
            RC_WAR.bases[code] = { code, x, y, color:m.color||'#9C9C9C', nation:m.nation, short:m.short||code,
                total:0, bcr:0, nonBcr:0, ansp:0, ligaCalls:0, level:1, warn:false, shield:0,
                workers:[], seed:h, synced:false,
                // BURGEROBERUNG
                hp:hp0, maxHp:hp0, burgLevel:1, conqueredBy:null, comebackCount:0,
                postKip:0, postMob:0, // Freikauf-Tracker
                lastAttacker:null, conquests:[], kipMobCount:0, todeszone:false,
                dmgFlash:0  // visual flash when taking damage
            };
        });
        RC_WAR.basesBuilt = true;
        // TAGES-PERSISTENZ: gespeicherten HEUTE-Stand auf die frischen Basen legen
        try { rcWarApplyDayState(); } catch(e){}
        return RC_WAR.bases;
    }

    function rcWarAddFeed(txt, col, time){
        RC_WAR.feed.unshift({ txt, col: col||'#C9C9C9', age:0, time: time || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}) });
        if (RC_WAR.feed.length > 5) RC_WAR.feed.pop();
    }
    function rcWarAddFx(f){ f.t = 0; RC_WAR.fx.push(f); }
    function rcWarFloat(x, y, txt, col){ rcWarAddFx({ kind:'float', x, y, txt, col: col||'#F5F5F5', dur:1.8 }); }
    // Krieger-Spruch als lesbarer Chip ueber der Einheit (~2.5 s). Bewusst
    // frech-motivierend, buerotauglich, keine Beleidigungen/keine echten Namen.
    function rcWarSpruch(x, y, txt, col){ rcWarAddFx({ kind:'spruch', x, y, txt, col: col||'#FFD700', dur:2.5 }); }
    // Koenigsschlag-Einschlag: goldener Ring+Funken fuer KIP, bunter (Cyan/Magenta)
    // fuer Mobilfunk — hebt die doppelt zaehlenden Premium-Treffer optisch ab.
    function rcWarKingBurst(x, y, gold){ rcWarAddFx({ kind:'kingburst', x, y, gold:!!gold, seed:Math.random()*6.283, dur: gold?0.65:0.55 }); }
    const RC_SPRUCH = {
        TR: ['SYSTEM: FEINDBURG ERFASST.','ANATOLISCHE PRAEZISION.','ZAHNRAEDER MAHLEN EUCH.','VOLLDAMPF VORAUS!','ZIEL ERFASST — ABSCHLUSS FIX.','DER HALBMOND MARSCHIERT.','KEIN LEERLAUF, NUR TREFFER.','KESSELDRUCK MAXIMAL.'],
        GR: ['MIT STIL EROBERT!','POMPONS HOCH, BURG RUNTER!','OPA! DAS SITZT.','STECHSCHRITT INS KONTOR.','EHRENGARDE LIEFERT.','ELEGANT ABGERAEUMT.','KEINER MARSCHIERT SO WIE WIR.'],
        DE: ['AUS DEM ACKER — IN DIE SCHLACHT!','KNOLLE ROLLT, BURG FAELLT!','FRISCH GEERNTET, HART GEKAEMPFT!','KARTOFFEL-POWER!','ERST SCHAELEN, DANN SIEGEN.','ORDNUNG MUSS SEIN.','GRUENDLICH EROBERT.','PUENKTLICH ZUM SIEG.'],
        AT: ['30 KILO REINE WUCHT!','DUENN ABER TOEDLICH.','HALT MIR MAL DIE RUESTUNG!','SPARGEL SCHLAEGT ZU.','WACKELT, ABER WIRKT.','MEHR HELM ALS MANN — TROTZDEM TREFFER.','LEICHTGEWICHT, SCHWERGEWICHTS-ABSCHLUSS.']
    };
    const RC_SPRUCH_PROD = {
        kip: ['KIP-BNT — DER KOENIGSSCHLAG!','KIP SITZT — VOLLE WUCHT!','KIP-BNT: DOPPELTE BEUTE!'],
        mob: ['MOBILFUNK — VOLLE FREQUENZ!','MOBILFUNK-BNT: SIGNAL STEHT!','MOBILFUNK — DOPPELT ZAEHLT!']
    };
    // 40% Chance einen Spruch ueber der real eingreifenden Einheit einzublenden.
    function rcWarSpruchFor(u){
        if (!u || !u.src || Math.random() >= 0.4) return;
        const nat = u.src.nation || '';
        let pool = null, col;
        if ((u.cat === 'kip' || u.cat === 'mob') && Math.random() < 0.5) {
            pool = RC_SPRUCH_PROD[u.cat]; col = u.cat === 'kip' ? '#FFD700' : '#3BD6E6';
        } else {
            pool = RC_SPRUCH[nat]; col = (u.src && u.src.color) || '#F5F5F5';
        }
        if (!pool || !pool.length) return;
        const us = RC_WAR.unitScale || 1;
        rcWarSpruch(u.x, u.y - 30*us, pool[Math.floor(Math.random()*pool.length)], col);
    }
    // Staubwolke + fliegende Truemmer (Katapult-Einschlag, Lanzenstoss etc.)
    function rcWarDust(x, y, r, col, big){
        r = r * (0.7 + 0.35 * (RC_WAR.unitScale || 1)); // skaliert mit Figurengroesse
        const parts = [];
        const n = big ? 14 : 7;
        for (let i=0;i<n;i++) parts.push({ a: Math.random()*6.283, sp: (big?42:24)*(0.4+Math.random()*0.9),
            col: Math.random() < 0.5 ? '#6E5A3E' : '#4E4E4E', w: 1.5+Math.random()*1.5 });
        const puffs = [];
        for (let i=0;i<(big?4:2);i++) puffs.push({ dx:(Math.random()-0.5)*r*0.8, dy:(Math.random()-0.5)*r*0.5, r: r*(0.35+Math.random()*0.4) });
        rcWarAddFx({ kind:'dust', x, y, r, col, big:!!big, parts, puffs, dur: big?1.2:0.8 });
        if (big) {
            RC_WAR.shake = Math.min(8, RC_WAR.shake + 5);
            RC_WAR.scars.push({ x: x+(Math.random()-0.5)*4, y: y+(Math.random()-0.5)*4, r: 6+Math.random()*4, t:0, dur:480 });
            if (RC_WAR.scars.length > 40) RC_WAR.scars.shift();
        } else if (Math.random() < 0.4) {
            RC_WAR.scars.push({ x, y, r: 3+Math.random()*2, t:0, dur:300 });
            if (RC_WAR.scars.length > 40) RC_WAR.scars.shift();
        }
    }
    // Schwerter-Klirren: kurzer Funkenstern zwischen zwei Kaempfern
    function rcWarClang(x, y){
        rcWarAddFx({ kind:'clang', x, y, dur:0.28, rot: Math.random()*6.283 });
    }

    // ---------- KINO-KAMERA: Nahaufnahme auf das Geschehen ----------
    // Bei KIP/MOB-Angriffen, Eroberungen und Befreiungen zoomt die Karte auf
    // die Szene und blendet ein grosses Banner mit dem Verkaeufer-Namen ein.
    // Danach faehrt die Kamera weich auf die Gesamtkarte zurueck.
    function rcWarCinema(fx, fy, z, hold, lines, col){
        const cam = RC_WAR.cam;
        cam.tx = fx; cam.ty = fy; cam.tz = z; cam.hold = hold;
        if (lines && lines.length) RC_WAR.banner = { lines, col: col || '#E60000', t: 0, dur: hold + 0.6 };
    }

    function rcWarPickTarget(code){
        const myBase = RC_WAR.bases[code];
        if (!myBase) return null;
        
        // Free-For-All: Jeder gegen Jeden (Ausnahme AL ignoriert SKA und umgekehrt)
        const enemies = ORDER.map(c => RC_WAR.bases[c]).filter(b => {
            if (!b || b.code === code || b.conqueredBy) return false;
            if ((code === 'AL' && b.code === 'SKA') || (code === 'SKA' && b.code === 'AL')) return false;
            return true;
        });

        if (!enemies.length) {
            // Wenn alle aktiven Feinde erobert sind, greife bereits eroberte Burgen an
            const conquered = ORDER.map(c => RC_WAR.bases[c]).filter(b => 
                b && b.conqueredBy && b.conqueredBy !== code
            );
            return conquered.length ? conquered.sort((a,b) => b.hp - a.hp)[0] : null;
        }
        
        // Groessten Konkurrenten angreifen (hoechste HP = staerkste Bedrohung)
        enemies.sort((a,b) => b.hp - a.hp);
        return enemies[0];
    }

    function rcWarSyncWorkers(b, target){
        while (b.workers.length < target) {
            const cart = b.workers.length % 4 === 3; // jeder vierte ist ein Transporter
            const a = Math.random()*6.283, r = 15 + Math.random()*14;
            b.workers.push({ kind: cart?'cart':'inf', x: Math.cos(a)*r, y: Math.sin(a)*r,
                tx:0, ty:0, sp: cart ? 14+Math.random()*8 : 6+Math.random()*6, wait:0, ph: Math.random()*6.283 });
        }
        if (b.workers.length > target) b.workers.length = target;
    }

    window.rcWarSetWarn = function(code, hot){ const b = RC_WAR.bases[code]; if (b) b.warn = !!hot; };

    window.rcWarSync = function(stats){
        rcWarEnsureBases();
        // Die Kriegskarte zeigt IMMER alle Standorte — daher die ungefilterten
        // War-Daten bevorzugen (der Panel-Filter darf das Schlachtfeld nicht leeren).
        stats = window.rcWarStdFull || stats;
        // Liga-Calls je Standort UNGEFILTERT direkt aus rcKpiData (rcLigaAgg wuerde
        // den aktiven Filter anwenden und fremde Burgen auf 0 Calls setzen).
        const liga = {};
        const qual = {};
        Object.values(window.rcKpiData || {}).forEach(k => {
            const c = normalizeStandort(k.standort);
            liga[c] = (liga[c] || 0) + (k.callCount || 0);
            const q = qual[c] || (qual[c] = { csS:0, csN:0, tnS:0, tnN:0 });
            if (k.cs != null) { q.csS += k.cs; q.csN++; }
            if (k.tnps != null) { q.tnS += k.tnps; q.tnN++; }
        });
        let leader = null, max = 0;
        ORDER.forEach(code => {
            const b = RC_WAR.bases[code]; if (!b) return;
            const s = stats && stats[code];
            const total = s ? (s.total||0) : 0;
            const score = s ? scoreOf(s) : 0; b.score = score; // OPTION B: gewichtete Wertung ist die EINE Wahrheit
            b.bcr = s ? (s.bcr||0) : 0; b.nonBcr = s ? (s.nonBcr||0) : 0;
            b.ansp = s ? (s.pitches||0) : 0; b.ligaCalls = liga[code] || 0;
            const q = qual[code];
            b.cs = (q && q.csN) ? q.csS/q.csN : null;
            b.tnps = (q && q.tnN) ? q.tnS/q.tnN : null;
            // BURGEROBERUNG: burgLevel aus KIP+MOB BNTs
            const kipMob = (s ? ((s.kip||0) + (s.mob||0)) : 0);
            const oldBL = b.burgLevel || 1;
            b.kipMobCount = kipMob;
            const newBL = kipMob >= 10 ? 5 : kipMob >= 6 ? 4 : kipMob >= 3 ? 3 : kipMob >= 1 ? 2 : 1;
            const maxHps = RC_WAR.balance.hpByLevel;
            if (b.synced && newBL > oldBL) {
                const namen = ['','STEINBURG','FESTUNG','ZITADELLE','IMPERIUM'];
                b.burgLevel = newBL;
                b.maxHp = maxHps[newBL - 1];
                b.hp = Math.min(b.hp + (maxHps[newBL-1] - maxHps[oldBL-1]), b.maxHp); // HP auffuellen
                rcWarFloat(b.x, b.y - 40, 'AUSBAU: ' + namen[newBL-1] + '!', '#FFD700');
                rcWarAddFeed(shortName(code).toUpperCase() + ' AUFSTIEG ZUR ' + namen[newBL-1] + '!', '#FFD700');
                RC_WAR.shake = 0.3;
            } else {
                b.burgLevel = newBL;
                b.maxHp = maxHps[newBL - 1];
                if (b.hp > b.maxHp) b.hp = b.maxHp;
            }
            const lvl = total >= 15 ? 5 : total >= 10 ? 4 : total >= 6 ? 3 : total >= 3 ? 2 : 1;
            b.level = lvl; b.total = total; b.synced = true;
            rcWarSyncWorkers(b, b.ligaCalls > 0 ? Math.max(2, Math.min(8, Math.round(b.ligaCalls/22))) : (total > 0 ? 2 : 0));
            if (score > max && !b.conqueredBy) { max = score; leader = code; }
        });
        // Stunden-Snapshot fuer das Tageswertungs-Delta ("+X seit Vorstunde"):
        // beim Stundenwechsel den aktuellen KIP/MOB-Stand je Burg festhalten.
        const snapH = new Date().getHours();
        if (RC_WAR._hourSnapH !== snapH) {
            RC_WAR._hourSnapH = snapH; RC_WAR._hourSnap = {};
            ORDER.forEach(c => { const bb = RC_WAR.bases[c]; if (bb) RC_WAR._hourSnap[c] = bb.score || 0; });
        }

        // --- BATTLE ROYALE ELIMINATION CRON ---
        if (!RC_WAR.eliminations) RC_WAR.eliminations = {};
        const hour = new Date().getHours();
        const elimHours = []; // OPTION B: keine Todeszonen/Eroberung mehr — Wettlauf statt Vernichtung
        const hasKpi = Object.keys(liga).length > 0;
        
        // Beim Inject werden VERPASSTE Todeszonen nur als "gesehen" markiert,
        // nicht nachgeholt — sonst sind um 15 Uhr sofort drei Burgen weg und
        // die Karte startet als Friedhof. Nur live erlebte Stunden zaehlen.
        if (!RC_WAR.elimInit) {
            RC_WAR.elimInit = true;
            elimHours.forEach(h => { if (hour >= h) RC_WAR.eliminations[h] = true; });
        }
        if (hasKpi) {
            elimHours.forEach(h => {
                if (hour >= h && !RC_WAR.eliminations[h]) {
                    RC_WAR.eliminations[h] = true;
                    const activeBases = ORDER.map(c => RC_WAR.bases[c]).filter(b => b && !b.conqueredBy);
                    if (activeBases.length > 1) {
                        activeBases.sort((a,b) => {
                            const crA = a.ligaCalls > 0 ? (a.total / a.ligaCalls) : 0;
                            const crB = b.ligaCalls > 0 ? (b.total / b.ligaCalls) : 0;
                            return crA - crB; // Aufsteigend nach CR% sortieren
                        });
                        const winner = activeBases[activeBases.length - 1]; // Höchste CR%
                        const loser = activeBases[0]; // Geringste CR%
                        
                        if (winner && loser && winner.code !== loser.code) {
                            loser.conqueredBy = winner.code;
                            loser.hp = 0;
                            loser.fallAt = Date.now();
                            loser.todeszone = true; // Markieren für riesige Flagge
                            winner.conquests.push(loser.code);
                            rcWarChronik('TODESZONE ' + h + ':00 — ' + shortName(winner.code).toUpperCase() + ' ELIMINIERT ' + shortName(loser.code).toUpperCase(), '#FF3333', h + ':00');
                            RC_WAR.shake = Math.min(9, RC_WAR.shake + 8);
                            rcWarMarkDirty();
                        }
                    }
                }
            });
        }

        // KEIN rueckwirkender Tages-Schaden mehr beim Inject: der alte
        // Free-For-All-Block hat den gesamten Tagespool (bei echten Volumen
        // ~7000+ Schaden gegen ~3600 Karten-HP) auf einmal abgefeuert —
        // Ergebnis war die tote Karte ("Sieger: NIEMAND"). Die Karte startet
        // stattdessen intakt; die Pings der letzten Stunde (processDataStream,
        // withinHour) liefern die frischen Kampfspuren, und ab dann zaehlt
        // jeder Live-Abschluss genau einmal.

        // === OPTION B RANGLISTE: EIN Ziel = Platz 1 ===
        // Rang, Abstand zum Vordermann und Burgstaerke (HP-Balken = Score/Fuehrender).
        const ranked = ORDER.map(c => RC_WAR.bases[c]).filter(Boolean)
            .sort((a,b) => ((b.score||0)-(a.score||0)) || ((b.total||0)-(a.total||0)));
        const leadScore = ranked.length ? (ranked[0].score||0) : 0;
        const prevRank = RC_WAR._prevRankMap;
        const nowRank = {};
        ranked.forEach((b, i) => {
            b.rank = i + 1;
            b.aboveCode = i > 0 ? ranked[i-1].code : null;
            b.gapAbove = i > 0 ? Math.max(0, Math.round((ranked[i-1].score||0) - (b.score||0))) : 0;
            b.maxHp = 100;
            b.hp = leadScore > 0 ? Math.max(6, Math.round((b.score||0)/leadScore*100)) : 100;
            nowRank[b.code] = b.rank;
        });
        if (prevRank) {
            let topMover = null;
            ranked.forEach(b => {
                const pr = prevRank[b.code];
                if (pr != null && b.rank < pr && (b.score||0) > 0) {
                    if (!topMover || b.rank < topMover.rank) topMover = b;
                    const passedCode = ORDER.find(c => nowRank[c] === b.rank + 1);
                    const passedN = passedCode ? shortName(passedCode).toUpperCase() : '';
                    rcWarChronik(shortName(b.code).toUpperCase() + ' KLETTERT AUF PLATZ ' + b.rank + (passedN ? ' — VORBEI AN ' + passedN : ''), '#FFCE00');
                }
            });
            if (topMover) {
                const passedCode = ORDER.find(c => nowRank[c] === topMover.rank + 1);
                const passedN = passedCode ? shortName(passedCode).toUpperCase() : '';
                rcWarCinema(topMover.x, topMover.y, 1.55, 4.2, [
                    'UEBERHOLT!',
                    shortName(topMover.code).toUpperCase() + ' UEBERNIMMT PLATZ ' + topMover.rank,
                    passedN ? 'VORBEI AN ' + passedN : 'AUFSTIEG!'
                ], '#FFCE00');
                RC_WAR.shake = Math.min(9, RC_WAR.shake + 4);
            }
        }
        RC_WAR._prevRankMap = nowRank;

        if (leader && max > 0 && RC_WAR.leader !== leader) {
            if (RC_WAR.leader) rcWarAddFeed(shortName(leader).toUpperCase() + ' UEBERNIMMT DIE TAGESFUEHRUNG', '#E60000');
            RC_WAR.leader = leader;
        }
        rcWarSeedChronik();
        if (window.rcWarUpdateConquestGoal) window.rcWarUpdateConquestGoal();
        if (window.rcLeagueSync) window.rcLeagueSync();
    };

    // KRIEGSRAT — Feind-Aufklaerung aus Sicht des gefilterten Standorts
    // (ohne Filter: Sicht von Alanya = Team Tuerkei). Beantwortet konkret:
    // wie viele BNTs braucht der Feind noch, um UNS zu vernichten — und wie
    // viele brauchen WIR gegen jeden einzelnen Feind. Dazu Todeszonen-Countdown.
    window.rcWarUpdateConquestGoal = function() {
        const el = document.getElementById('rcRadarConquestTarget');
        if (!el || !RC_WAR.basesBuilt) return;
        const bal = RC_WAR.balance;
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        let fCode;
        // OPTION B: Rangliste ist die Wahrheit. Ranked einmal nach Score.
        const rankedK = ORDER.map(c => RC_WAR.bases[c]).filter(Boolean)
            .sort((a,b) => ((b.score||0)-(a.score||0)) || ((b.total||0)-(a.total||0)));
        const stats = window.rcWarStdFull || (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        if (fv && fv !== 'ALL' && RC_WAR.bases[fv]) fCode = fv;
        else {
            const duel = RC_WAR.duel;
            if (duel && duel.active && RC_WAR.bases[duel.a]) fCode = duel.a;
            else {
                let best = null, bestGap = Infinity;
                rankedK.forEach(b => { if ((b.rank||9) > 1 && (b.score||0) > 0 && (b.gapAbove||0) < bestGap) { bestGap = b.gapAbove||0; best = b.code; } });
                fCode = best || (rankedK[0] && rankedK[0].code) || 'AL';
            }
        }
        const my = RC_WAR.bases[fCode];
        const ttl = document.getElementById('rcRadarKriegsratTitle');
        if (ttl) ttl.textContent = 'Kriegsrat ' + shortName(fCode);

        const kipW = (RC_WAR.score && RC_WAR.score.kip) || 35;
        let myHtml = '';
        if (my) {
            if ((my.rank||1) === 1 || !my.aboveCode) {
                const chaser = rankedK[1];
                const lead = chaser ? Math.max(0, Math.round((my.score||0) - (chaser.score||0))) : 0;
                myHtml = `<div style="background:rgba(255,206,0,0.10); border-left:3px solid #FFCE00; padding:8px 10px; margin-bottom:8px;">
                        <div style="color:#FFCE00; font-weight:700; font-size:13px;">${shortName(fCode).toUpperCase()} FUEHRT DIE WERTUNG — ${Math.round(my.score||0)} PUNKTE</div>
                        <div style="color:#F5F5F5; font-size:11px;">${chaser ? 'Vorsprung <b style="color:#FFCE00;">'+lead+' Punkte</b> auf '+shortName(chaser.code)+' (Platz 2) — Vorsprung halten!' : 'Alleinige Spitze.'}</div>
                    </div>`;
            } else {
                myHtml = `<div style="background:rgba(0,200,220,0.08); border-left:3px solid #57D0E0; padding:8px 10px; margin-bottom:8px;">
                        <div style="color:#57D0E0; font-weight:700; font-size:13px;">${shortName(fCode).toUpperCase()} — PLATZ ${my.rank} · ${Math.round(my.score||0)} PUNKTE</div>
                        <div style="color:#F5F5F5; font-size:11px;">Noch <b style="color:#FFCE00;">${my.gapAbove||0} Punkte</b> bis Platz ${my.rank-1} (${shortName(my.aboveCode)}) — 1 KIP-BNT = +${kipW}, ein Sprung reicht!</div>
                    </div>`;
            }
        }

        const foeRows = rankedK.map((b, i) => {
            const isFocus = b.code === fCode;
            const s = stats[b.code] || {};
            const gapTxt = i === 0 ? '<span style="color:#FFCE00; font-weight:700;">FUEHRT</span>'
                : 'noch <b style="color:'+((b.gapAbove||0)<=20?'#66DD88':'#C9B08A')+';">'+(b.gapAbove||0)+'</b> bis Platz '+i;
            return `<div class="rc-list-item" data-rc-std="${rcAttr(b.code)}" style="${isFocus?'background:rgba(255,255,255,0.05);':''}">
                <div style="flex:1;"><b>${i+1}. ${getFlagSvg(b.code,'small')} ${shortName(b.code)}</b>
                <span class="rc-mono" style="font-size:9px; color:#9C9C9C;"> ${Math.round(b.score||0)} PKT · ${s.kip||0} KIP/${s.mob||0} MOB</span></div>
                <div class="rc-mono" style="font-size:10px;">${gapTxt}</div>
            </div>`;
        }).join('');

        el.innerHTML = myHtml
            + `<div style="font-size:10px; color:#C9B08A; text-transform:uppercase; letter-spacing:1px; margin:6px 0 4px;">Tageswertung — ein Ziel: Platz 1:</div>`
            + foeRows
            + `<div style="font-size:9.5px; color:#6E6E6E; margin-top:6px; line-height:1.4;">Jeder Abschluss baut die eigene Burg und schiebt dich nach oben. Ueberholst du den Standort ueber dir, tauscht ihr die Plaetze.</div>`;
    };

    // ---------- CHRONIK DES TAGES: lesbare, persistente Ereignis-Liste ----------
    // Ersetzt den fluechtigen 5-Zeilen-Funk-Feed als Haupt-Erzaehlung: echte
    // Verkaeufe, Eroberungen, Freikaeufe/Comebacks, Duell-Ergebnisse. Max 10.
    function rcWarChronik(txt, col, time){
        const t = time || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
        const c = RC_WAR.chronik;
        if (c.length && c[0].txt === txt) return; // exakte Doppel-Sofort-Eintraege vermeiden
        c.unshift({ time:t, txt, col: col||'#DCDCDC' });
        if (c.length > 10) c.pop();
        rcWarMarkDirty();
    }

    // Chronik-Erstbefuellung aus den ECHTEN heutigen Verkaeufen (rcAllSales):
    // damit die Erzaehlung auch ohne frischen Live-Abschluss nicht leer ist —
    // jede Zeile ist ein tatsaechlich stattgefundener Abschluss von heute.
    function rcWarSeedChronik(){
        if (RC_WAR.chronik.length) return;
        const src = window.rcAllSales;
        if (!src || !src.length) return;
        src.slice().sort((a,b) => (b.timeStr||'').localeCompare(a.timeStr||'')).slice(0, 8).forEach(s => {
            RC_WAR.chronik.push({ time: s.timeStr || '', col: s.isBcr !== false ? '#F5F5F5' : '#9C9C9C',
                txt: heroName(s.name).toUpperCase() + ' (' + shortName(s.standort).toUpperCase() + ') · ' + reasonOf(s.cat) });
        });
    }

    // ---------- TAGES-PERSISTENZ: HP/Eroberungen/Chronik ueberleben Reload ----------
    // localStorage 'rcWarDayState' wird throttled (~2s) geschrieben, beim Boot
    // nur geladen, wenn das Datum HEUTE ist — sonst frischer Tag.
    RC_WAR._dsDirty = false; RC_WAR._dsLast = 0; RC_WAR._pendingDay = null;
    function rcWarDayKey(){ const d = new Date(); return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
    function rcWarMarkDirty(){ RC_WAR._dsDirty = true; }
    function rcWarSaveDayState(force){
        const now = Date.now();
        if (!force && (now - RC_WAR._dsLast) < 2000) return; // Throttle
        RC_WAR._dsLast = now; RC_WAR._dsDirty = false;
        try {
            const hp={}, cq={}, fa={}, cb={}, pk={}, pm={}, tz={};
            ORDER.forEach(c => { const b = RC_WAR.bases[c]; if (!b) return;
                hp[c] = Math.round(b.hp);
                if (b.conqueredBy) cq[c] = b.conqueredBy;
                if (b.fallAt) fa[c] = b.fallAt;
                if (b.comebackCount) cb[c] = b.comebackCount;
                if (b.postKip) pk[c] = b.postKip;
                if (b.postMob) pm[c] = b.postMob;
                if (b.todeszone) tz[c] = 1;
            });
            localStorage.setItem('rcWarDayState', JSON.stringify({
                datum: rcWarDayKey(), hp, conqueredBy:cq, fallAt:fa, comebackCount:cb,
                postKip:pk, postMob:pm, todeszone:tz,
                conquestLog: RC_WAR.conquestLog.slice(-30),
                chronik: RC_WAR.chronik.slice(0, 10),
                eliminations: RC_WAR.eliminations || {},
                duelHistory: RC_WAR.duelHistory.slice(-12)
            }));
        } catch(e){}
    }
    function rcWarApplyDayState(){
        let st = null;
        try { st = JSON.parse(localStorage.getItem('rcWarDayState') || 'null'); } catch(e){}
        if (!st || st.datum !== rcWarDayKey()) return;
        ORDER.forEach(c => { const b = RC_WAR.bases[c]; if (!b) return;
            if (st.hp && st.hp[c] != null) b.hp = Math.min(b.maxHp, st.hp[c]);
            if (st.conqueredBy && st.conqueredBy[c]) b.conqueredBy = st.conqueredBy[c];
            if (st.fallAt && st.fallAt[c]) b.fallAt = st.fallAt[c];
            if (st.comebackCount && st.comebackCount[c]) b.comebackCount = st.comebackCount[c];
            if (st.postKip && st.postKip[c]) b.postKip = st.postKip[c];
            if (st.postMob && st.postMob[c]) b.postMob = st.postMob[c];
            if (st.todeszone && st.todeszone[c]) b.todeszone = true;
        });
        if (Array.isArray(st.conquestLog)) RC_WAR.conquestLog = st.conquestLog.slice();
        if (Array.isArray(st.chronik)) RC_WAR.chronik = st.chronik.slice(0, 10);
        if (Array.isArray(st.duelHistory)) RC_WAR.duelHistory = st.duelHistory.slice();
        if (st.eliminations) RC_WAR.eliminations = st.eliminations;
    }

    // ---------- FREIKAUF/COMEBACK: eigene eroberte Burg zurueckholen ----------
    // 1 KIP + 1 MOB (LIVE) befreit die eigene Burg. An den echten EINSCHLAG
    // gekoppelt, damit der Befreiungsmoment eine sichtbare Tat ist.
    function rcWarTryFreikauf(myBase, cat, hero, time){
        if (!myBase || !myBase.conqueredBy) return;
        if (cat === 'kip') myBase.postKip = (myBase.postKip||0) + 1;
        if (cat === 'mob') myBase.postMob = (myBase.postMob||0) + 1;
        if ((myBase.postKip||0) >= 1 && (myBase.postMob||0) >= 1) {
            myBase.conqueredBy = null; myBase.fallAt = null; myBase.todeszone = false;
            myBase.postKip = 0; myBase.postMob = 0;
            myBase.hp = Math.round(myBase.maxHp * 0.5);
            myBase.comebackCount = (myBase.comebackCount||0) + 1;
            myBase.winGlow = 2.4;
            const nm = shortName(myBase.code).toUpperCase();
            rcWarFloat(myBase.x, myBase.y - 40, 'COMEBACK!', '#00FF88');
            rcWarChronik(nm + ' KAEMPFT SICH FREI — COMEBACK Nr. ' + myBase.comebackCount, '#00FF88', time);
            RC_WAR.shake = Math.min(9, RC_WAR.shake + 5);
            rcWarCinema(myBase.x, myBase.y, 1.6, 4.5, [
                'COMEBACK — ' + nm + ' IST WIEDER FREI!',
                (hero ? hero.toUpperCase() + ' BRACHTE DEN BEFREIUNGSSCHLAG' : 'DIE BURG STEHT WIEDER')
            ], '#00FF88');
            if (window.rcWarUpdateConquestGoal) window.rcWarUpdateConquestGoal();
            rcWarMarkDirty();
        } else if (cat === 'kip' || cat === 'mob') {
            rcWarFloat(myBase.x, myBase.y - 34, 'FREIKAUF (fehlt: ' + (myBase.postKip ? 0 : 1) + ' KIP, ' + (myBase.postMob ? 0 : 1) + ' MOB)', '#88CCFF');
        }
    }

    // ---------- EINSCHLAG-SCHADEN: HP-Wirkung erst beim TREFFER ----------
    // Der Verkauf ist laengst gezaehlt (Chronik/Feed); hier faellt nur die HP —
    // gekoppelt an Katapult-Einschlag / gewonnenes Duell / Pfeil-/Lanzen-Treffer.
    function rcWarImpactDamage(atkCode, target, cat, hero, time){
        // OPTION B: kein Schaden, kein Erobern. Der Einschlag inszeniert das AUFHOLEN —
        // der Angreifer stuermt den Rang ueber sich. Score/Rang sind laengst in
        // rcWarSync gesetzt; hier nur Wucht, Aufbau-Puls und ein Punkte-Feedback.
        if (!target || target.code === atkCode) return;
        const w = (RC_WAR.score && RC_WAR.score[cat]) || 15;
        const myBase = RC_WAR.bases[atkCode];
        target.dmgFlash = 0.5;
        if (myBase) { myBase.buildPulse = 1.0; myBase.lastAttacker = atkCode;
            rcWarFloat(myBase.x, myBase.y - 42, '+' + w + ' PUNKTE', cat==='kip' ? '#FFCE00' : cat==='mob' ? '#57D0E0' : '#C9B08A'); }
        RC_WAR.shake = Math.min(9, RC_WAR.shake + (cat==='kip'?5:cat==='mob'?4:2));
        rcWarMarkDirty();
    }

    window.rcWarSpawn = function(code, name, prod, isBcr, time){
        if (window.rcRadarMode === 'league' && window.rcLeagueSpawn) { window.rcLeagueSpawn(code, name, prod, isBcr, time); return; }
        rcWarEnsureBases();
        if (!RC_WAR.bases[code]) return;
        const cls = classify((prod||'').toString());
        let kind = null;
        if (cls.isVvl) kind = 'cart';
        else if (cls.cat === 'mob') kind = 'knight';
        else if (cls.cat === 'kip') kind = 'catapult';
        else if (cls.cat === 'fibDsl') kind = 'archer';
        else if (cls.cat === 'ptv') kind = 'rider';
        else if (cls.cat) kind = 'spearman';
        if (!kind) return;
        const myBase = RC_WAR.bases[code];

        // BURGEROBERUNG: Der VERKAUF ist real und wird SOFORT gezaehlt
        // (Chronik). Die HP-WIRKUNG passiert aber erst beim EINSCHLAG der
        // Einheit (Katapult-Treffer, gewonnenes Duell, Pfeil-/Lanzentreffer) —
        // siehe rcWarImpactDamage in der Physik. So bedeutet jeder Balken-
        // Verlust einen sichtbaren Moment. Replays sind reine Show (kein
        // Schaden, keine Chronik).
        if (!RC_WAR._replay) {
            if (cls.cat === 'kip') RC_WAR.kingPulse.kip = 1; else if (cls.cat === 'mob') RC_WAR.kingPulse.mob = 1;
            if (cls.cat !== 'kip' && cls.cat !== 'mob') rcWarChronik(heroName(name).toUpperCase() + ' (' + shortName(code).toUpperCase() + ') · ' + reasonOf(cls.cat),
                isBcr !== false ? '#F5F5F5' : '#9C9C9C', time); // KIP/MOB: eigener Koenigs-Spotlight unten
            // STUNDEN-DUELL: KIP/MOB der Duellanten zaehlen fuer den Score
            const duel = RC_WAR.duel;
            if (duel && duel.active && (cls.cat === 'kip' || cls.cat === 'mob')) {
                const _dN = heroName(name).toUpperCase();
                if (code === duel.a) { duel.scoreA++; duel.lastA = _dN; rcWarFloat(myBase.x, myBase.y - 52, _dN + ' +1  (' + duel.scoreA + ':' + duel.scoreB + ')', '#FFD700'); rcWarChronik('STUNDEN-DUELL: ' + _dN + ' (' + shortName(code).toUpperCase() + ') PUNKTET — ' + duel.scoreA + ':' + duel.scoreB, '#FFD700', time); }
                else if (code === duel.b) { duel.scoreB++; duel.lastB = _dN; rcWarFloat(myBase.x, myBase.y - 52, _dN + ' +1  (' + duel.scoreA + ':' + duel.scoreB + ')', '#FFD700'); rcWarChronik('STUNDEN-DUELL: ' + _dN + ' (' + shortName(code).toUpperCase() + ') PUNKTET — ' + duel.scoreA + ':' + duel.scoreB, '#FFD700', time); }
            }
            // PERSOENLICHER KOENIGS-SPOTLIGHT: JEDER echte KIP/MOBILFUNK-BNT wird gezaehlt
            // (persoenliche Tages-Streak in RC_WAR._kingCount), leuchtet in der Chronik auf
            // und feuert einen King-Burst an der eigenen Burg. Der grosse Kino-Moment (Zoom +
            // Banner mit Name/Streak/Punkten) laeuft zentral in rcWarLaunch (bessere Kadrierung).
            if (!RC_WAR._kingCount) RC_WAR._kingCount = {};
            const _hN = heroName(name).toUpperCase(), _sN = shortName(code).toUpperCase();
            if (cls.cat === 'kip' || cls.cat === 'mob') {
                const _isKip = cls.cat === 'kip';
                const _kkey = _hN + '|' + cls.cat;
                const _nK = (RC_WAR._kingCount[_kkey] = (RC_WAR._kingCount[_kkey] || 0) + 1);
                const _col = _isKip ? '#FFD700' : '#3BD6E6';
                const _plabel = _isKip ? 'KIP-BNT' : 'MOBILFUNK-BNT';
                rcWarKingBurst(myBase.x, myBase.y, _isKip);
                rcWarChronik((_nK >= 2 ? _nK + '. ' : '') + _plabel + ' — ' + _hN + ' (' + _sN + ')', _col, time);
            }
        }
        // Goldener Held: LIVE-KIP/MOB-Verkaeufer marschieren als grosse
        // Goldfigur mit Aura + Krone ueber die Karte (User-Wunsch 17.07.)
        const ev = { code, name, kind, isBcr: isBcr !== false, cat: cls.cat, time: time || '', replay: !!RC_WAR._replay,
            golden: !RC_WAR._replay && (cls.cat === 'kip' || cls.cat === 'mob') };
        if (!RC_WAR.active || RC_WAR.units.length >= RC_WAR_MAXU) {
            RC_WAR.queue.push(ev);
            if (RC_WAR.queue.length > 14) RC_WAR.queue.shift();
            return;
        }
        rcWarLaunch(ev);
    };

    // ---------- Tages-Replay: die heutigen Abschluesse als Dauer-Show ----------
    // Kein Warten auf den naechsten Live-Abschluss: rcAllSales (alle heutigen
    // Verkaeufe) wird chronologisch und endlos als langsamer Strom abgespielt
    // (ein Einsatz alle ~8-14 s). Echte Live-Events haben immer Vorrang —
    // Replay pausiert, sobald Einheiten unterwegs oder Events in der Queue sind.
    // Tempo justierbar: window.rcWar.replayEvery (Sekunden, Standard 8).
    RC_WAR.replayEvery = 18;
    RC_WAR.rT = 0.8; RC_WAR.rIdx = 0; RC_WAR.rSrc = null; RC_WAR.rList = [];
    function rcWarReplayNext(){
        // Live-Events gehen vor; Boten zaehlen nicht als Gefechts-Einheiten
        const fighters = RC_WAR.units.filter(u => u.kind !== 'bote').length;
        if (fighters >= 4 || RC_WAR.queue.length) return;
        const src = window.rcAllSales;
        if (!src || !src.length) return;
        if (RC_WAR.rSrc !== src) { // neuer Parse-Zyklus -> Liste chronologisch neu aufbauen
            RC_WAR.rSrc = src;
            RC_WAR.rList = src.slice().sort((a,b) => (a.timeStr||'99:99').localeCompare(b.timeStr||'99:99'));
        }
        if (!RC_WAR.rList.length) return;
        const s = RC_WAR.rList[RC_WAR.rIdx % RC_WAR.rList.length];
        RC_WAR.rIdx++;
        RC_WAR._replay = true;
        try { window.rcWarSpawn(s.standort, s.name, s.prod, s.isBcr, s.timeStr || ''); }
        finally { RC_WAR._replay = false; }
    }

    // Boten-Patrouillen: die ECHTEN Ansprache-Werte halten die Karte in Bewegung.
    // Gewichtete Auswahl — wer viele Ansprachen macht, ist oefter als Bote mit
    // Fahne unterwegs (Burg -> Rivalen-Burg -> Kundengespraech -> zurueck).
    function rcWarSpawnBote(){
        if (!RC_WAR.active) return;
        if (RC_WAR.units.filter(u => u.kind === 'bote').length >= 2) return;
        rcWarEnsureBases();
        // Boten aus der UNGEFILTERTEN Ansprache-Liste (alle Standorte) — sonst
        // patrouillieren nur die Boten des gefilterten Standorts.
        const pool = window.rcWarBoteCands || [];
        const cands = pool.filter(a => (a.ansp||0) > 0 && RC_WAR.bases[a.standort]);
        if (!cands.length) return;
        const tot = cands.reduce((s,a) => s + a.ansp, 0);
        let pick = Math.random() * tot, ag = cands[0];
        for (const a of cands) { pick -= a.ansp; if (pick <= 0) { ag = a; break; } }
        const b = RC_WAR.bases[ag.standort];
        const tgt = rcWarPickTarget(ag.standort); if (!tgt) return;
        const aTo = rcWarAng(b, tgt);
        const us = RC_WAR.unitScale || 1;
        RC_WAR.units.push({ kind:'bote', tag:'BOT', hero: heroName(ag.name), col:'#9C9C9C',
            src:b, dst:tgt, x:b.x, y:b.y, t:0, alpha:1, state:'hin',
            reason: ag.ansp + ' ANSPRACHEN HEUTE',
            face: (tgt.x >= b.x ? 1 : -1),
            mx: tgt.x - Math.cos(aTo)*26*us, my: tgt.y - Math.sin(aTo)*26*us });
    }

    // Boten tragen INFORMATION: beim Ankommen zeigt der Bote 4 s einen lesbaren
    // Chip an der Zielburg — rotierend echte Zahlen (Ansprache-Quote / Stunde /
    // letzter Abschluss). Keine Deko: jede Zahl kommt aus den Live-Daten.
    function rcWarBoteChip(dst){
        const opts = [];
        if (dst && dst.ligaCalls > 0) opts.push('ANSPRACHE-QUOTE ' + shortName(dst.code).toUpperCase() + ': ' + Math.round((dst.ansp||0)/dst.ligaCalls*100) + '%');
        try { const hs = window.rcHourStats;
            if (hs && hs.totals && hs.totals.length) opts.push('STUNDE LAEUFT: ' + (hs.totals[hs.totals.length-1]||0) + ' ABSCHLUESSE'); } catch(e){}
        try { const src = window.rcAllSales;
            if (src && src.length) { let last = ''; for (const s of src) { if (s.timeStr && s.timeStr > last) last = s.timeStr; }
                if (last) { const p = last.split(':'); const now = new Date();
                    const diff = (now.getHours()*60+now.getMinutes()) - (+p[0]*60 + +p[1]);
                    if (diff >= 0 && diff < 600) opts.push('LETZTER ABSCHLUSS VOR ' + diff + ' MIN'); } } } catch(e){}
        if (!opts.length) return null;
        return opts[(RC_WAR.boteChipIdx = (RC_WAR.boteChipIdx||0) + 1) % opts.length];
    }

    // ---------- LAGEBERICHT: konkrete Ansagen aus den ECHTEN Werten ----------
    // Beantwortet auf der Karte: wer fuehrt, wer braucht wie viel fuer den
    // naechsten Platz, wessen Qualitaet verteidigt, wo liegen offene Chancen.
    RC_WAR.briefT = 0; RC_WAR.briefIdx = 0;
    function rcWarBriefLines(){
        const lines = [];
        const ranked = ORDER.map(c => RC_WAR.bases[c]).filter(b => b && b.synced).sort((a,b) => (b.total||0) - (a.total||0));
        if (!ranked.length) return lines;
        const L = ranked[0];
        if (new Date().getHours() >= 18 && L.total > 0)
            lines.push({ t: 'TAGESSIEG: ' + shortName(L.code).toUpperCase() + ' MIT ' + L.total + ' ABSCHLUESSEN — DIE KRONE IST VERTEIDIGT', col:'#FFCE00' });
        if (L.total > 0) {
            const second = ranked[1];
            lines.push({ t: shortName(L.code).toUpperCase() + ' FUEHRT MIT ' + L.total + ' ABSCHLUESSEN' +
                (second && second.total > 0 ? ' — VORSPRUNG ' + (L.total - second.total) : ''), col:'#E60000' });
        }
        // Aufholjagd: was fehlt KONKRET auf den naechsten Platz (realistisch, nah)
        for (let i = 1; i < ranked.length; i++) {
            const b = ranked[i];
            if (!b || (b.total === 0 && b.ligaCalls === 0)) continue;
            const need = (ranked[i-1].total || 0) - (b.total || 0) + 1;
            if (need > 0 && need <= 8)
                lines.push({ t: shortName(b.code).toUpperCase() + ' BRAUCHT ' + need + ' ABSCHLUSS' + (need > 1 ? 'E' : '') +
                    ' FUER PLATZ ' + i + ' (' + shortName(ranked[i-1].code).toUpperCase() + ': ' + ranked[i-1].total + ')', col:'#F5F5F5' });
        }
        // Qualitaet verteidigt: Schildwall + Moral wuerdigen
        ranked.forEach(b => {
            if (b.cs != null && b.cs >= 90)
                lines.push({ t: shortName(b.code).toUpperCase() + ': CS ' + b.cs.toFixed(0) + '% — SCHILDWALL AKTIV, ANGRIFFE PRALLEN AB', col:'#DCDCDC' });
            else if (b.tnps != null && b.tnps >= 70)
                lines.push({ t: shortName(b.code).toUpperCase() + ': TNPS ' + b.tnps.toFixed(0) + '% — MORAL HOCH, KUNDEN KAEMPFEN MIT', col:'#DCDCDC' });
        });
        // Groesste offene Chance: viele Calls, wenig Ansprache
        let low = null;
        ranked.forEach(b => {
            if (b.ligaCalls >= 30) { const q = b.ansp / b.ligaCalls; if (!low || q < low.q) low = { b, q }; }
        });
        if (low && low.q < 0.35) {
            const offen = Math.max(1, Math.round(low.b.ligaCalls * 0.4 - low.b.ansp));
            lines.push({ t: shortName(low.b.code).toUpperCase() + ': NUR ' + Math.round(low.q*100) + '% ANSPRACHE BEI ' + low.b.ligaCalls +
                ' CALLS — ' + offen + ' CHANCEN LIEGEN AUF DER STRASSE', col:'#FF6666' });
        }
        // Burgen kurz vor dem Fall: konkreter Sturm-Aufruf
        const balB = RC_WAR.balance;
        ORDER.map(c => RC_WAR.bases[c]).filter(b => b && !b.conqueredBy).forEach(b => {
            const nk = Math.ceil(b.hp / balB.dmgKip);
            if (nk <= 2) lines.push({ t: 'NUR NOCH ' + nk + ' KIP-BNT UND ' + shortName(b.code).toUpperCase() + ' FAELLT — WER HOLT SICH DIE BURG?', col:'#FF9E9E' });
        });
        // Krieger vor dem Durchbruch: NAMENTLICH rufen — typgerechte Ansage
        try {
            const fvB = (document.getElementById('rcStandortFilter')||{}).value;
            const kandidaten = rcWarKrieger((fvB && fvB !== 'ALL') ? fvB : null).slice(0, 4);
            kandidaten.forEach(k => {
                const who = heroName(k.name).toUpperCase() + ' (' + shortName(k.std).toUpperCase() + ')';
                if (k.type === 'quali')
                    lines.push({ t: 'DIE FRONT RUFT ' + who + ': CS ' + (k.cs != null ? k.cs.toFixed(0) : '?') + '% — DEINE QUALITAET IST EINE FESTUNG, JETZT FEHLT NUR DEIN KIP!', col:'#88CCFF' });
                else if (k.type === 'still')
                    lines.push({ t: 'DIE FRONT RUFT ' + who + ': ' + k.calls + ' CALLS — DEINE ERSTE ANSPRACHE IST DER ANGRIFF!', col:'#FF9E9E' });
                else
                    lines.push({ t: 'DIE FRONT RUFT ' + who + ': ' + k.ansp + ' ANSPRACHEN' + (k.cs != null ? ', CS ' + k.cs.toFixed(0) + '%' : '') + ' — DEIN ERSTER TREFFER ENTSCHEIDET!', col:'#FFCE00' });
            });
        } catch(e){}
        return lines;
    }

    function rcWarLaunch(ev){
        const b = RC_WAR.bases[ev.code]; if (!b) return;
        const col = ev.isBcr ? '#E60000' : '#9A9A9A';
        const hero = heroName(ev.name);
        const t0 = ev.time || null; // Original-Verkaufszeit (Replay) fuer den Funk-Feed
        if (ev.kind === 'cart') {
            // Versorgungskarren: Bauer schiebt den Karren von aussen in die Burg -> Palisade
            const cx = 500, cy = 320;
            let dx = b.x - cx, dy = b.y - cy; const dl = Math.hypot(dx,dy) || 1; dx/=dl; dy/=dl;
            const sx = b.x + dx*130, sy = b.y + dy*130;
            RC_WAR.units.push({ kind:'cart', col, hero, tag:'VER', src:b, cat:ev.cat, time0:t0, reason:reasonOf(ev.cat),
                x: sx, y: sy, t: 0, face: (b.x >= sx ? 1 : -1), state:'drive', alpha:1, last: true });
            return;
        }
        const tgt = rcWarPickTarget(ev.code);
        if (!tgt) { rcWarDust(b.x, b.y-10, 14, col); rcWarFloat(b.x, b.y-30, '+1 ' + catLabel(ev.cat), col); return; }
        // NAHAUFNAHME NUR bei LIVE-KIP/MOB (min. 8 s Abstand). Replays bekommen
        // KEINE grosse Kino-Einblendung mehr (die verdeckte die Karte) — sie
        // laufen still als kleine "REPLAY"-badgte Show durch (siehe rcWarDrawTag).
        // GROSSER KOENIGS-SPOTLIGHT (nur LIVE-KIP/MOB): Kino-Zoom auf die Szene mit Namen,
        // persoenlicher Tages-Streak und Punktegewinn — in Gold (KIP) bzw. Cyan (MOBILFUNK),
        // damit die zwei Koenigsprodukte lauter sind als alles andere. Throttle 4.5 s.
        if (!ev.replay && (ev.kind === 'catapult' || ev.kind === 'knight') && (RC_WAR.t - (RC_WAR.lastCine == null ? -999 : RC_WAR.lastCine)) >= 4.5) {
            RC_WAR.lastCine = RC_WAR.t;
            const mzx = (b.x + tgt.x)/2, mzy = (b.y + tgt.y)/2;
            const dz = rcWarDist(b, tgt);
            const zoom = Math.max(1.25, Math.min(1.8, 820/(dz + 260)));
            const _isKip = ev.kind === 'catapult';
            const _pts = (RC_WAR.score && RC_WAR.score[ev.cat]) || (_isKip ? 35 : 30);
            const _plabel = _isKip ? 'KIP-BNT' : 'MOBILFUNK-BNT';
            if (!RC_WAR._milestones) RC_WAR._milestones = {};
            const _ms = RC_WAR._milestones, _mk = _isKip ? 'firstKip' : 'firstMob';
            const _nK = (RC_WAR._kingCount && RC_WAR._kingCount[hero.toUpperCase() + '|' + ev.cat]) || 1;
            let _kicker;
            if (!_ms[_mk]) { _ms[_mk] = true; _kicker = 'ERSTER ' + _plabel + ' DES TAGES'; }
            else if (_nK >= 2) _kicker = _nK + '. ' + _plabel + ' HEUTE — HEISS!';
            else _kicker = _plabel + ' — KOENIGSSCHUSS';
            rcWarCinema(mzx, mzy, zoom, 4.4, [
                _kicker,
                hero.toUpperCase() + ' (' + shortName(ev.code).toUpperCase() + ')',
                (_isKip ? 'KATAPULT AUF ' : 'RITTER STUERMT ') + shortName(tgt.code).toUpperCase() + '  \u00b7  +' + _pts + ' PUNKTE'
            ], _isKip ? '#FFD700' : '#3BD6E6');
        }
        const base = { col, hero, src:b, dst:tgt, cat:ev.cat, t:0, alpha:1, time0:t0, reason:reasonOf(ev.cat),
                       face: (tgt.x >= b.x ? 1 : -1), x:b.x, y:b.y, golden: !!ev.golden, replay: !!ev.replay };
        if (ev.kind === 'knight') {
            // Duell-Punkt: kurz vor der Zielburg (skaliert mit Figurengroesse)
            const a = rcWarAng(b, tgt);
            const dd = 24 * (RC_WAR.unitScale||1) + 14 * (RC_WAR.baseScale||1);
            RC_WAR.units.push(Object.assign(base, { kind:'knight', tag:'RIT', state:'march',
                mx: tgt.x - Math.cos(a)*dd, my: tgt.y - Math.sin(a)*dd, swing:0, clangT:0 }));
        } else if (ev.kind === 'catapult') {
            RC_WAR.units.push(Object.assign(base, { kind:'catapult', tag:'KAT', state:'roll',
                mx: b.x + (tgt.x-b.x)*0.3, my: b.y + (tgt.y-b.y)*0.3, arm:0, rockT:-1 }));
        } else if (ev.kind === 'archer') {
            const a = rcWarAng(b, tgt);
            const d = Math.max(30, rcWarDist(b, tgt) - 85);
            RC_WAR.units.push(Object.assign(base, { kind:'archer', tag:'BOG', state:'march',
                mx: b.x + Math.cos(a)*d, my: b.y + Math.sin(a)*d, arrows:3, shotT:0 }));
        } else if (ev.kind === 'rider') {
            const a = rcWarAng(b, tgt);
            const rd = 20 * (RC_WAR.unitScale||1) + 12 * (RC_WAR.baseScale||1);
            RC_WAR.units.push(Object.assign(base, { kind:'rider', tag:'REI', state:'gallop',
                mx: tgt.x - Math.cos(a)*rd, my: tgt.y - Math.sin(a)*rd }));
        } else {
            const a = rcWarAng(b, tgt);
            const d = rcWarDist(b, tgt) * 0.45;
            RC_WAR.units.push(Object.assign(base, { kind:'spearman', tag:'SPR', state:'march',
                mx: b.x + Math.cos(a)*d, my: b.y + Math.sin(a)*d, spears:2, shotT:0 }));
        }
    }

    // ============================================================
    //  STUNDEN-DUELL — Dringlichkeit ohne Liga-Crawler, rein aus ESL-Daten.
    //  Jede volle Stunde treten die zwei nächststehenden Burgen der
    //  Tageswertung 15 Min an: wer mehr KIP+MOB im Fenster holt, gewinnt.
    //  Duellanten-Treffer schlagen doppelt zu (siehe rcWarImpactDamage).
    //  Debug: rcWar.duel.start()  ·  rcWar.duel.durationMin = 15
    // ============================================================
    RC_WAR.duel = {
        active:false, a:null, b:null, endAt:0, scoreA:0, scoreB:0, startH:null,
        lastHour:-1, durationMin:15,
        _pickPair(){
            const bs = ORDER.map(c => RC_WAR.bases[c]).filter(b => b && b.synced && !b.conqueredBy);
            if (bs.length < 2) return null;
            bs.sort((a,b) => ((b.score||0) - (a.score||0)) || ((b.total||0) - (a.total||0)));
            let best = null, gap = Infinity;
            for (let i=0;i<bs.length-1;i++){
                const g = Math.abs((bs[i].score||0) - (bs[i+1].score||0));
                if (g < gap) { gap = g; best = [bs[i], bs[i+1]]; }
            }
            return best;
        },
        start(){
            rcWarEnsureBases();
            const pair = this._pickPair();
            if (!pair) return false;
            this.active = true; this.a = pair[0].code; this.b = pair[1].code;
            this.scoreA = 0; this.scoreB = 0; this.startH = new Date().getHours();
            this.endAt = Date.now() + (this.durationMin || 15) * 60000;
            const aN = shortName(this.a).toUpperCase(), bN = shortName(this.b).toUpperCase();
            rcWarChronik('STUNDEN-KOENIGSJAGD GESTARTET — ' + aN + ' vs ' + bN + ' (KIP + MOBILFUNK)', '#FFD700');
            rcWarCinema(500, 320, 1.22, 3.4, ['STUNDEN-KOENIGSJAGD', aN + ' vs ' + bN, 'WER HOLT DIE MEISTEN KIP + MOBILFUNK?'], '#FFD700');
            rcWarMarkDirty();
            return true;
        },
        end(){
            const aN = shortName(this.a).toUpperCase(), bN = shortName(this.b).toUpperCase();
            let winCode = null;
            if (this.scoreA === 0 && this.scoreB === 0) {
                const nh = pad2((new Date().getHours()+1) % 24);
                rcWarChronik('KOENIGSJAGD ' + aN + ' 0:0 ' + bN + ' — KEIN KIP/MOB, NAECHSTE ' + nh + ':00', '#9C9C9C');
                rcWarCinema(500, 320, 1.2, 3.6, ['KOENIGSJAGD BEENDET', aN + '  0 : 0  ' + bN, 'KEIN KIP/MOB — NAECHSTE ' + nh + ':00'], '#9C9C9C');
            } else {
                winCode = this.scoreA >= this.scoreB ? this.a : this.b;
                const wN = shortName(winCode).toUpperCase();
                const wB = RC_WAR.bases[winCode]; if (wB) wB.winGlow = 3.2;
                rcWarChronik('KOENIGSJAGD ' + aN + ' ' + this.scoreA + ':' + this.scoreB + ' ' + bN + ' — ' + wN + ' HOLT DIE KRONE', '#FFD700');
                rcWarCinema(wB ? wB.x : 500, wB ? wB.y : 320, 1.55, 5, ['STUNDEN-KOENIGSJAGD ENTSCHIEDEN', aN + '  ' + this.scoreA + ' : ' + this.scoreB + '  ' + bN, wN + ' HOLT DIE MEISTEN KIP + MOBILFUNK!'], '#FFD700');
            }
            RC_WAR.duelHistory.push({ h:this.startH, a:this.a, b:this.b, sa:this.scoreA, sb:this.scoreB, win:winCode });
            if (RC_WAR.duelHistory.length > 24) RC_WAR.duelHistory.shift();
            this.active = false; this.a = null; this.b = null;
            rcWarMarkDirty(); rcWarSaveDayState(true);
        },
        tick(){
            const nowH = new Date().getHours();
            if (!this.active && this.lastHour !== nowH) {
                // Beim allerersten Tick nur die Stunde merken (kein Sofort-Start
                // beim Oeffnen); erst der ECHTE Stundenwechsel startet ein Duell.
                if (this.lastHour === -1) this.lastHour = nowH;
                else { this.lastHour = nowH; this.start(); }
            }
            if (this.active && Date.now() >= this.endAt) this.end();
        }
    };
    window.rcWar.duel = RC_WAR.duel; // Debug-Handle

    // ---------- Simulation ----------
    function rcWarUpdate(dt){
        RC_WAR.t += dt;
        RC_WAR.kingPulse.kip = Math.max(0, RC_WAR.kingPulse.kip - dt*1.5);
        RC_WAR.kingPulse.mob = Math.max(0, RC_WAR.kingPulse.mob - dt*1.5);
        RC_WAR.shake = Math.max(0, RC_WAR.shake - RC_WAR.shake*3.2*dt);
        // Kino-Kamera weich nachfuehren; nach Ablauf zurueck zur Gesamtkarte
        const cam = RC_WAR.cam;
        cam.hold -= dt;
        if (cam.hold <= 0) { cam.tx = 500; cam.ty = 320; cam.tz = 1; }
        const ck = Math.min(1, dt*2.4);
        cam.x += (cam.tx - cam.x)*ck; cam.y += (cam.ty - cam.y)*ck; cam.z += (cam.tz - cam.z)*ck;
        if (RC_WAR.banner) { RC_WAR.banner.t += dt; if (RC_WAR.banner.t > RC_WAR.banner.dur) RC_WAR.banner = null; }
        // Helden-Ruf (DOM) weicht dem Kino-Banner (Canvas) — beide sitzen oben mittig
        const heroDim = (RC_WAR.banner || (RC_WAR.duel && RC_WAR.duel.active)) ? '0.08' : '1';
        if (RC_WAR._heroDim !== heroDim) {
            RC_WAR._heroDim = heroDim;
            const hc = document.getElementById('rcHeroCall');
            if (hc) { hc.style.transition = 'opacity 0.35s'; hc.style.opacity = heroDim; }
        }
        // Warteschlange gestaffelt abspulen (Show-Effekt beim Einblenden)
        RC_WAR.qT -= dt;
        if (RC_WAR.qT <= 0 && RC_WAR.queue.length && RC_WAR.units.length < RC_WAR_MAXU) {
            rcWarLaunch(RC_WAR.queue.shift()); RC_WAR.qT = 0.45;
        }
        // Tages-Replay: laufend Einsaetze aus den ECHTEN heutigen Abschluessen —
        // die Karte steht nie still, solange heute verkauft wurde
        RC_WAR.rT -= dt;
        if (RC_WAR.rT <= 0) {
            rcWarReplayNext();
            RC_WAR.rT = RC_WAR.burst > 0 ? (RC_WAR.burst--, 1.4) : RC_WAR.replayEvery * (0.8 + Math.random()*0.5);
        }
        // Boten-Patrouillen (Ansprache-Werte) als Grundrauschen zwischen den Burgen
        RC_WAR.bT -= dt;
        if (RC_WAR.bT <= 0) { rcWarSpawnBote(); RC_WAR.bT = 5 + Math.random()*4; }
        // Lagebericht rotiert alle 7 s zur naechsten Ansage
        RC_WAR.briefT -= dt;
        if (RC_WAR.briefT <= 0) { RC_WAR.briefT = 7; RC_WAR.briefIdx++; }
        // STUNDEN-DUELL: Auto-Start zur vollen Stunde + Ende-Pruefung
        if (RC_WAR.duel && RC_WAR.duel.tick) RC_WAR.duel.tick();
        // Basen: Schild-Timer + Selbstheilung + Wiederaufbau + Gewusel
        Object.values(RC_WAR.bases).forEach(b => {
            if (b.shield > 0) b.shield -= dt;
            // Selbstheilung NUR fuer Burgen mit echtem Qualitaets-Schildwall
            // (CS >= regenCsGate): "Qualitaet verteidigt" wird damit real —
            // schwache Burgen heilen NICHT und bleiben verwundbar. Langsam
            // (0.5 HP/min), damit Fortschritt nicht weggeheilt wird.
            if (!b.conqueredBy && b.hp < b.maxHp && b.cs != null && b.cs >= (RC_WAR.balance.regenCsGate || 90)) {
                b.hp = Math.min(b.maxHp, b.hp + (RC_WAR.balance.regenPerMin || 0) / 60 * dt);
            }
            // KEIN Auto-Wiederaufbau mehr: erobert bleibt erobert bis zum
            // Freikauf (1 KIP + 1 MOB). Eine gefallene Burg ist ein echter,
            // sichtbarer Verlust — genau das macht den Kampf bedeutsam.
            // winGlow: kurzer Goldschimmer nach Comeback/Duell-Sieg
            if (b.winGlow > 0) b.winGlow = Math.max(0, b.winGlow - dt);
            b.workers.forEach(w => {
                if (w.wait > 0) { w.wait -= dt; return; }
                const dx = w.tx - w.x, dy = w.ty - w.y, d = Math.hypot(dx,dy);
                if (d < 1.4) {
                    if (w.kind === 'cart') { // Transporter pendeln Depot <-> Tor
                        const a = (w.ph + (w.flip?Math.PI:0)); w.flip = !w.flip;
                        w.tx = Math.cos(a)*24; w.ty = Math.sin(a)*24; w.wait = 0.5 + Math.random();
                    } else {
                        const a = Math.random()*6.283, r = 13 + Math.random()*16;
                        w.tx = Math.cos(a)*r; w.ty = Math.sin(a)*r; w.wait = Math.random()*1.6;
                    }
                } else { w.x += dx/d*w.sp*dt; w.y += dy/d*w.sp*dt; w.rot = Math.atan2(dy,dx); }
            });
        });
        // Einheiten — Maerschieren via mx/my (Marschziel), face = Blickrichtung (Sprites
        // stehen aufrecht wie bei Age of Empires und werden nur gespiegelt)
        const marchTo = (u, spd, arriveDist) => {
            const d = Math.hypot(u.mx - u.x, u.my - u.y);
            if (d < (arriveDist || 3)) return true;
            const a = Math.atan2(u.my - u.y, u.mx - u.x);
            u.x += Math.cos(a)*spd*dt; u.y += Math.sin(a)*spd*dt;
            u.face = Math.cos(a) >= 0 ? 1 : -1;
            // Gang-Charakter je Nation: GR stolziert im Laufsteg-Takt (langsam,
            // betont wie ein Topmodel), DE torkelt unrund UND weicht in
            // Schlangenlinien vom Kurs ab (besoffen), TR/Rest marschiert sauber
            const gnat = (u.src && u.src.nation) || '';
            const natMul = gnat === 'DE' ? 0.8 * (1 + 0.45*Math.sin((u.step||0)*0.37))
                         : gnat === 'GR' ? 0.7 : 1;
            u.step = (u.step || 0) + dt * (spd > 90 ? 16 : 9) * natMul;
            if (gnat === 'DE' && spd <= 90) {
                const pa = a + Math.PI/2, sway = Math.sin((u.step||0)*0.55) * 16 * dt;
                u.x += Math.cos(pa)*sway; u.y += Math.sin(pa)*sway;
            }
            return false;
        };
        const finish = (u, feedTxt, floatTxt) => {
            rcWarFloat(u.src.x, u.src.y - 36, floatTxt, u.col);
            rcWarAddFeed('[' + u.tag + '] ' + u.hero + ' · ' + u.src.short.toUpperCase() + ' >> ' + u.dst.short.toUpperCase() + ' · ' + feedTxt, u.col, u.time0);
            rcWarSpruchFor(u); // frecher Nation-/Produkt-Spruch beim realen Eingreifen (40%)
        };
        // Sieges-Gag je Nation: kurze Jubelpose (~1.2 s), rein kosmetisch.
        // GR = Sirtaki-Pirouette mit Luftkuss, DE = Bierkrug-Prost.
        // TR bekommt BEWUSST keinen Gag (User-Vorgabe: wuerdevoll), AT/Rest neutral.
        const RC_GAG_BY_NATION = {}; // Physik-Gags (Pirouette/Prost) deaktiviert — Charakter kommt jetzt aus Nation-Sprites + Spruech-Floats (Stage 2)
        const startGag = (u) => {
            const g = RC_GAG_BY_NATION[(u.src && u.src.nation) || ''];
            if (g) { u.gag = g; u.gagT = 0; }
            // dazu gelegentlich eine Gag-Zeile im Funk-Feed (liebevoll, ohne Emojis)
            if (Math.random() < 0.45) {
                const n = (u.src && u.src.nation) || '';
                const t = n === 'GR' ? 'KURZER SIRTAKI VOR DEN TOREN — DANN ZURUECK AN DIE LEITUNG'
                        : n === 'DE' ? u.hero.toUpperCase() + ' HEBT DEN BIERKRUG — SELBSTVERSTAENDLICH ALKOHOLFREI, ES IST SCHICHT'
                        : u.hero.toUpperCase() + ' VERBEUGT SICH — DER GEGNER APPLAUDIERT ANSTANDSHALBER';
                rcWarAddFeed(t, '#C9C9C9', u.time0);
            }
        };
        RC_WAR.units.forEach(u => {
            u.t += dt;
            // Gag-Uhr: laeuft 0..1 in 1.2 s, danach raeumt sie sich selbst weg
            if (u.gag) { u.gagT = Math.min(1, (u.gagT || 0) + dt / 1.2); if (u.gagT >= 1) u.gag = null; }
            if (u.t < 0) return;
            if (u.kind === 'knight') {
                if (u.state === 'march') {
                    if (marchTo(u, 52)) {
                        u.state = 'duel'; u.t = 0; u.clangT = 0.35;
                        // Verteidiger der Zielburg tritt vor die Tore — das Duell beginnt.
                        // Starke Qualitaet (CS >= 90 %) macht den Verteidiger zaeher!
                        u.def = { x: u.x + (u.face||1)*15*(RC_WAR.unitScale||1), y: u.y, col: u.dst.color };
                        u.face = (u.def.x >= u.x) ? 1 : -1;
                        u.duelDur = (u.dst.cs != null && u.dst.cs >= 90) ? 5.0 : 3.1;
                        if (u.duelDur > 4) rcWarFloat(u.dst.x, u.dst.y - 40, 'CS-SCHILD ' + u.dst.cs.toFixed(0) + '% — ZAEHER KAMPF', '#DCDCDC');
                    }
                } else if (u.state === 'duel') {
                    u.swing = Math.sin(u.t * 9);
                    u.clangT -= dt;
                    if (u.clangT <= 0) { u.clangT = 0.5 + Math.random()*0.3; rcWarClang((u.x + u.def.x)/2, u.y - 11*(RC_WAR.unitScale||1)); }
                    if (u.t > (u.duelDur || 3.1)) {
                        u.state = 'victory'; u.t = 0;
                        rcWarFloat(u.def.x, u.def.y - 24, 'SIEG', u.col);
                        if (u.cat === 'mob') rcWarKingBurst(u.def.x, u.def.y - 8*(RC_WAR.unitScale||1), false); // Mobilfunk-Ritter = bunter Effekt
                        if (!u.replay) rcWarImpactDamage(u.src.code, u.dst, u.cat, u.hero, u.time0); // MOB-Treffer -> HP
                        finish(u, 'SCHWERT-DUELL GEWONNEN', '+1 MOB');
                        startGag(u);
                    }
                } else if (u.state === 'victory') {
                    // Verteidiger kippt um, der Sieger reckt das Schwert in die Hoehe
                    if (u.t > 1.8) { u.state = 'fade'; u.t = 0; }
                } else if (u.state === 'fade') {
                    u.alpha = Math.max(0, 1 - u.t/0.8); if (u.alpha <= 0) u.done = true;
                }
            } else if (u.kind === 'catapult') {
                if (u.state === 'roll') {
                    u.face = (u.dst.x >= u.x) ? 1 : -1;
                    if (marchTo(u, 38)) { u.state = 'windup'; u.t = 0; }
                } else if (u.state === 'windup') {
                    u.arm = Math.min(1, u.t / 0.9) * 0.15;       // Wurfarm langsam spannen
                    if (u.t > 0.9) { u.state = 'shoot'; u.t = 0; }
                } else if (u.state === 'shoot') {
                    u.arm = Math.min(1, u.t / 0.22);             // Arm schnellt hoch
                    if (u.rockT < 0 && u.arm >= 1) {
                        u.rockT = 1.35;                          // Flugzeit des Felsbrockens
                        const jx = u.dst.x + (Math.random()-0.5)*14, jy = u.dst.y + (Math.random()-0.5)*14;
                        rcWarAddFx({ kind:'rock', x:u.x, y:u.y-16, x2:jx, y2:jy,
                            mid:{ x:(u.x+jx)/2, y:Math.min(u.y,jy) - 95 }, dur:1.35 });
                        u.hitX = jx; u.hitY = jy;
                    }
                    if (u.rockT >= 0) {
                        u.rockT -= dt;
                        if (u.rockT <= 0 && !u.hit) {
                            u.hit = true;
                            // Einschlag-Optik (Staub/Truemmer); der Schildwall-Text
                            // + die HP-Halbierung kommen zentral aus rcWarImpactDamage
                            const shielded = (u.dst && u.dst.cs != null && u.dst.cs >= 90);
                            if (shielded) { rcWarClang(u.hitX, u.hitY - 6); rcWarDust(u.hitX, u.hitY, 14, u.col); }
                            else { rcWarDust(u.hitX, u.hitY, 24, u.col, true); rcWarFloat(u.hitX, u.hitY - 24, 'VOLLTREFFER', u.col); }
                            if (u.cat === 'kip' && !shielded) { rcWarKingBurst(u.hitX, u.hitY, true); RC_WAR.shake = Math.min(10, RC_WAR.shake + 2); } // KIP = groesserer goldener Einschlag
                            if (!u.replay) rcWarImpactDamage(u.src.code, u.dst, u.cat, u.hero, u.time0); // KIP-Treffer -> HP
                            finish(u, 'KATAPULT-VOLLTREFFER', '+1 KIP');
                            startGag(u);
                            u.state = 'linger'; u.t = 0;
                        }
                    }
                } else if (u.state === 'linger') { if (u.t > 1.2) { u.state = 'fade'; u.t = 0; } }
                else if (u.state === 'fade') { u.alpha = Math.max(0, 1 - u.t/0.8); if (u.alpha <= 0) u.done = true; }
            } else if (u.kind === 'archer') {
                if (u.state === 'march') {
                    if (marchTo(u, 58)) { u.state = 'volley'; u.t = 0; u.shotT = 0.3; }
                } else if (u.state === 'volley') {
                    u.face = (u.dst.x >= u.x) ? 1 : -1;
                    u.draw = Math.min(1, (u.shotT > 0.2 ? (0.45-u.shotT) : 0) / 0.25); // Bogen spannen
                    u.shotT -= dt;
                    if (u.shotT <= 0 && u.arrows > 0) {
                        u.arrows--; u.shotT = 0.5;
                        const jx = u.dst.x + (Math.random()-0.5)*16, jy = u.dst.y + (Math.random()-0.5)*16;
                        rcWarAddFx({ kind:'arrow', x:u.x + u.face*4, y:u.y - 12, x2:jx, y2:jy,
                            mid:{ x:(u.x+jx)/2, y:Math.min(u.y,jy) - 45 }, flug:0.75, dur:1.6, col:u.col });
                        if (u.arrows === 0) { u.state = 'after'; u.t = 0; }
                    }
                } else if (u.state === 'after') {
                    if (u.t > 1.1 && !u.fed) { u.fed = true; if (!u.replay) rcWarImpactDamage(u.src.code, u.dst, u.cat, u.hero, u.time0); finish(u, 'PFEILHAGEL', '+1 GIGA'); }
                    if (u.t > 1.6) { u.state = 'fade'; u.t = 0; }
                } else if (u.state === 'fade') {
                    u.alpha = Math.max(0, 1 - u.t/0.8); if (u.alpha <= 0) u.done = true;
                }
            } else if (u.kind === 'rider') {
                if (u.state === 'gallop') {
                    if (marchTo(u, 115)) {
                        u.state = 'strike'; u.t = 0;
                        rcWarClang(u.x + (u.face||1)*18*(RC_WAR.unitScale||1), u.y - 9*(RC_WAR.unitScale||1));
                        rcWarDust(u.mx + (u.face||1)*8, u.my, 12, u.col);
                    }
                } else if (u.state === 'strike') {
                    if (u.t > 0.9 && !u.fed) { u.fed = true; if (!u.replay) rcWarImpactDamage(u.src.code, u.dst, u.cat, u.hero, u.time0); finish(u, 'LANZEN-ATTACKE', '+1 TV'); }
                    if (u.t > 1.4) { u.state = 'retreat'; u.t = 0; u.face = -(u.face||1); }
                } else if (u.state === 'retreat') {
                    u.x += u.face*95*dt; u.step = (u.step||0) + dt*16;
                    u.alpha = Math.max(0, 1 - u.t/1.1); if (u.alpha <= 0) u.done = true;
                }
            } else if (u.kind === 'spearman') {
                if (u.state === 'march') {
                    if (marchTo(u, 55)) { u.state = 'throw'; u.t = 0; u.shotT = 0.25; }
                } else if (u.state === 'throw') {
                    u.face = (u.dst.x >= u.x) ? 1 : -1;
                    u.shotT -= dt;
                    if (u.shotT <= 0 && u.spears > 0) {
                        u.spears--; u.shotT = 0.65;
                        const jx = u.dst.x + (Math.random()-0.5)*14, jy = u.dst.y + (Math.random()-0.5)*14;
                        rcWarAddFx({ kind:'arrow', spear:true, x:u.x + u.face*5, y:u.y - 13, x2:jx, y2:jy,
                            mid:{ x:(u.x+jx)/2, y:Math.min(u.y,jy) - 55 }, flug:0.85, dur:1.7, col:u.col });
                        if (u.spears === 0) { u.state = 'after'; u.t = 0; }
                    }
                } else if (u.state === 'after') {
                    if (u.t > 1.2 && !u.fed) { u.fed = true; if (!u.replay) rcWarImpactDamage(u.src.code, u.dst, u.cat, u.hero, u.time0); finish(u, 'SPEERWURF SITZT', '+1 ' + catLabel(u.cat)); }
                    if (u.t > 1.7) { u.state = 'fade'; u.t = 0; }
                } else if (u.state === 'fade') {
                    u.alpha = Math.max(0, 1 - u.t/0.8); if (u.alpha <= 0) u.done = true;
                }
            } else if (u.kind === 'cart') {
                u.mx = u.src.x; u.my = u.src.y;
                if (marchTo(u, 46, 16 * (RC_WAR.baseScale||1))) {
                    u.done = true;
                    u.src.shield = 8;
                    rcWarFloat(u.src.x, u.src.y - 36, 'VORRAETE EINGEFAHREN', '#F5F5F5');
                    rcWarAddFeed('[VER] ' + u.hero + ' · ' + u.src.short.toUpperCase() + ' · VVL — PALISADE STEHT', u.col, u.time0);
                }
            } else if (u.kind === 'bote') {
                if (u.state === 'hin') {
                    if (marchTo(u, 62)) { u.state = 'talk'; u.t = 0; u.chip = rcWarBoteChip(u.dst); }
                } else if (u.state === 'talk') {
                    u.face = (u.dst.x >= u.x) ? 1 : -1;
                    if (u.t > 4.0) { u.state = 'zurueck'; u.mx = u.src.x; u.my = u.src.y; } // 4s Info-Chip lesbar
                } else if (u.state === 'zurueck') {
                    if (marchTo(u, 62, 14 * (RC_WAR.baseScale||1))) u.done = true;
                }
            }
        });
        RC_WAR.units = RC_WAR.units.filter(u => !u.done);
        // Effekte
        RC_WAR.fx.forEach(f => {
            if (f.delay && f.delay > 0) { f.delay -= dt; return; }
            f.t += dt;
        });
        RC_WAR.fx = RC_WAR.fx.filter(f => (f.delay && f.delay > 0) || f.t < f.dur);
        RC_WAR.scars.forEach(s => s.t += dt);
        RC_WAR.scars = RC_WAR.scars.filter(s => s.t < s.dur);
        RC_WAR.feed.forEach(f => f.age += dt);
        // TAGES-PERSISTENZ: gesammelte Zustandsaenderungen throttled sichern
        if (RC_WAR._dsDirty && (Date.now() - RC_WAR._dsLast) >= 2000) rcWarSaveDayState();
    }

    // ---------- Zeichnen ----------
    function rcWarResize(){
        const c = RC_WAR.canvas; if (!c) return;
        const w = c.offsetWidth, h = c.offsetHeight;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        if (w === RC_WAR.view.w && h === RC_WAR.view.h && dpr === RC_WAR.view.dpr) return;
        c.width = Math.max(1, Math.round(w*dpr)); c.height = Math.max(1, Math.round(h*dpr));
        const s = Math.min(w/1000, h/640);
        RC_WAR.view = { w, h, dpr, s, ox: (w - 1000*s)/2, oy: (h - 640*s)/2 };
    }

    function rcWarDrawFlag(ctx, b, px, py){
        // Mast + wehende Nationalflagge auf der Turmspitze (skaliert mit der Burg)
        ctx.save();
        ctx.translate(px, py);
        const FS = Math.max(1, (RC_WAR.baseScale || 1) * 0.9);
        ctx.scale(FS, FS);
        ctx.strokeStyle = '#6E6E6E'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -12); ctx.stroke();
        ctx.save();
        ctx.translate(0.5, -12);
        ctx.transform(1, Math.sin(RC_WAR.t*3 + b.seed)*0.08, 0, 1, 0, 0); // Wehen
        // If conquered, show conqueror's flag
        const flagNation = b.conqueredBy || b.nation;
        const fl = RC_FLAGS[flagNation];
        if (fl) fl(ctx); else { ctx.fillStyle = b.color; ctx.fillRect(0,0,12,8); }
        ctx.strokeStyle = 'rgba(255,255,255,0.25)'; ctx.strokeRect(0,0,12,8);
        ctx.restore();
        // Tagesfuehrung: goldene, leicht schwebende Krone ueber der Flagge
        if (RC_WAR.leader === b.code && b.total > 0) {
            const cy = -18 + Math.sin(RC_WAR.t*2)*1.2;
            ctx.fillStyle = '#FFCE00';
            ctx.beginPath();
            ctx.moveTo(-5, cy);
            ctx.lineTo(-5, cy - 4); ctx.lineTo(-2.5, cy - 1.6); ctx.lineTo(0, cy - 5.2);
            ctx.lineTo(2.5, cy - 1.6); ctx.lineTo(5, cy - 4); ctx.lineTo(5, cy);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#8A6E00'; ctx.lineWidth = 0.6; ctx.stroke();
            ctx.fillStyle = '#E60000'; ctx.beginPath(); ctx.arc(0, cy - 1.6, 0.9, 0, 7); ctx.fill(); // Rubin
        }
        ctx.restore();
    }

    function rcWarDrawBase(ctx, b){
        const BS = RC_WAR.baseScale || 1;
        const bl = b.burgLevel || 1; // 1=Holzhuette, 2=Steinburg, 3=Festung, 4=Zitadelle, 5=Imperium
        const hpPct = b.maxHp > 0 ? b.hp / b.maxHp : 1;
        const isConquered = !!b.conqueredBy;
        const isAlanya = b.code === 'AL';
        // Gold-Aura nach Duell-Sieg / Comeback (kurzer Triumph, Weltkoordinaten)
        if (b.winGlow > 0) rcWarDrawGoldAura(ctx, b.x, b.y - 4, (RC_WAR.baseScale||1) * 1.7);
        ctx.save();
        ctx.translate(b.x, b.y);
        ctx.scale(BS, BS);
        // Alanya Heimat-Glow
        if (isAlanya && !isConquered) {
            const glowR = 30 + bl * 5 + Math.sin(RC_WAR.t * 2) * 3;
            const grd = ctx.createRadialGradient(0, 0, 5, 0, 0, glowR);
            grd.addColorStop(0, 'rgba(230,0,0,0.15)');
            grd.addColorStop(1, 'rgba(230,0,0,0)');
            ctx.fillStyle = grd;
            ctx.beginPath(); ctx.arc(0, 0, glowR, 0, 7); ctx.fill();
        }
        // Damage flash overlay
        if (b.dmgFlash > 0) {
            const flashR = 25 + bl * 4;
            ctx.fillStyle = 'rgba(255,0,0,' + (b.dmgFlash * 0.3).toFixed(2) + ')';
            ctx.beginPath(); ctx.arc(0, 0, flashR, 0, 7); ctx.fill();
            b.dmgFlash = Math.max(0, b.dmgFlash - 0.02);
        }
        // === CONQUERED STATE: Ruine ===
        if (isConquered) {
            // Rubble pile
            ctx.fillStyle = '#3A3028';
            ctx.beginPath();
            ctx.moveTo(-18, 4); ctx.lineTo(-14, -6); ctx.lineTo(-6, -3); ctx.lineTo(0, -8);
            ctx.lineTo(7, -4); ctx.lineTo(14, -7); ctx.lineTo(18, 3); ctx.closePath();
            ctx.fill();
            ctx.strokeStyle = '#2A2018'; ctx.lineWidth = 0.8; ctx.stroke();
            // Scattered stones
            ctx.fillStyle = '#4A4038';
            [[-12,2],[-5,-1],[3,1],[10,-2],[-8,-4],[6,-5],[0,3]].forEach(([sx,sy]) => {
                ctx.fillRect(sx-1.5, sy-1, 3, 2);
            });
            // Smoke wisps from ruins
            for (let i = 0; i < 3; i++) {
                const sx = -8 + i * 8, phase = RC_WAR.t * 1.5 + i * 2.1;
                const sy = -8 - Math.abs(Math.sin(phase)) * 12;
                const alpha = 0.15 + 0.1 * Math.sin(phase);
                ctx.fillStyle = 'rgba(120,110,100,' + alpha.toFixed(2) + ')';
                ctx.beginPath(); ctx.arc(sx + Math.sin(phase*0.7)*3, sy, 3 + Math.sin(phase)*1.5, 0, 7); ctx.fill();
            }
            // Conqueror's flag planted in rubble
            ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.5;
            ctx.beginPath(); ctx.moveTo(0, 5); ctx.lineTo(0, -18); ctx.stroke();
            // Draw conqueror nation flag
            const conquNat = RC_WAR.bases[b.conqueredBy] ? RC_WAR.bases[b.conqueredBy].nation : b.conqueredBy;
            if (RC_FLAGS[conquNat]) {
                ctx.save(); ctx.translate(1, -18);
                // Riesen-Flagge für Todeszonen-Opfer
                const scale = b.todeszone ? 2.8 : 1.2;
                ctx.scale(scale, scale);
                RC_FLAGS[conquNat](ctx);
                ctx.restore();
            }
            ctx.restore();
        } else {
            // === LIVING CASTLE — 5 Tiers ===
            const pad = 12 + bl * 3;
            // Burggraben (ab Festung, Level 3+)
            if (bl >= 3) {
                ctx.strokeStyle = 'rgba(30,80,140,0.5)'; ctx.lineWidth = bl >= 4 ? 3.5 : 2;
                ctx.beginPath();
                for (let i=0;i<8;i++){ const a = Math.PI/8 + i*Math.PI/4; const px = Math.cos(a)*(pad+10), py = Math.sin(a)*(pad+10)*0.72; i ? ctx.lineTo(px,py) : ctx.moveTo(px,py); }
                ctx.closePath(); ctx.stroke();
            }
            // Burghof
            ctx.beginPath();
            for (let i=0;i<8;i++){ const a = Math.PI/8 + i*Math.PI/4; const px = Math.cos(a)*(pad+4), py = Math.sin(a)*(pad+4)*0.72; i ? ctx.lineTo(px,py) : ctx.moveTo(px,py); }
            ctx.closePath();
            ctx.fillStyle = bl >= 5 ? 'rgba(80,65,30,0.7)' : 'rgba(52,46,36,0.6)'; ctx.fill();
            ctx.strokeStyle = b.color; ctx.lineWidth = 1.2; ctx.globalAlpha = 0.55; ctx.stroke(); ctx.globalAlpha = 1;
            // Mauer (ab Steinburg)
            if (bl >= 2) {
                const wallCol = bl >= 5 ? '#A08860' : bl >= 4 ? '#8C8C8C' : '#6E6E6E';
                ctx.strokeStyle = wallCol; ctx.lineWidth = bl >= 4 ? 3 : 2;
                ctx.beginPath();
                for (let i=0;i<8;i++){ const a = Math.PI/8 + i*Math.PI/4; const px = Math.cos(a)*(pad+1), py = Math.sin(a)*(pad+1)*0.72; i ? ctx.lineTo(px,py) : ctx.moveTo(px,py); }
                ctx.closePath(); ctx.stroke();
                // Zinnen
                ctx.fillStyle = wallCol;
                for (let i=0;i<12;i++){ const a = i*Math.PI/6 + 0.26; ctx.fillRect(Math.cos(a)*(pad+1)-1.1, Math.sin(a)*(pad+1)*0.72-1.6, 2.2, 2.6); }
            }
            // CS-Schildwall
            if (b.cs != null && b.cs >= 90) {
                ctx.strokeStyle = '#B0B0B0'; ctx.lineWidth = 1.5; ctx.setLineDash([3,2]);
                ctx.beginPath();
                for (let i=0;i<8;i++){ const a = Math.PI/8 + i*Math.PI/4; const px = Math.cos(a)*(pad+6), py = Math.sin(a)*(pad+6)*0.72; i ? ctx.lineTo(px,py) : ctx.moveTo(px,py); }
                ctx.closePath(); ctx.stroke(); ctx.setLineDash([]);
            }
            // Palisade (VVL)
            if (b.shield > 0) {
                const k = Math.min(1, b.shield/2) * (0.75 + 0.25*Math.sin(RC_WAR.t*4));
                ctx.globalAlpha = k;
                for (let i=0;i<16;i++){
                    const a = i*Math.PI/8 + 0.2;
                    const rx = Math.cos(a)*(pad+8), ry = Math.sin(a)*(pad+8)*0.72;
                    ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 2;
                    ctx.beginPath(); ctx.moveTo(rx, ry+2); ctx.lineTo(rx, ry-5); ctx.stroke();
                    ctx.fillStyle = '#A67C4E';
                    ctx.beginPath(); ctx.moveTo(rx-1.3, ry-4.5); ctx.lineTo(rx, ry-8); ctx.lineTo(rx+1.3, ry-4.5); ctx.closePath(); ctx.fill();
                }
                ctx.globalAlpha = 1;
            }
            // Gebaeude je Stufe
            const slots = [[-14,6],[13,7],[-16,-3],[15,-2],[0,13],[-8,11],[9,12]];
            const numHouses = bl >= 5 ? 7 : bl >= 4 ? 5 : bl >= 3 ? 4 : bl >= 2 ? 2 : 1;
            for (let i=0;i<Math.min(slots.length, numHouses);i++){
                const [sx,sy] = slots[(i + b.seed) % slots.length];
                const houseCol = bl >= 5 ? '#F0E0B8' : '#D9CBB2';
                const roofCol = bl >= 5 ? '#B8860B' : '#8A4A32';
                ctx.fillStyle = houseCol;
                ctx.fillRect(sx-3.5, sy-5, 7, 5);
                ctx.strokeStyle = '#6E5A3E'; ctx.lineWidth = 0.6; ctx.strokeRect(sx-3.5, sy-5, 7, 5);
                ctx.beginPath(); ctx.moveTo(sx-1.2, sy-5); ctx.lineTo(sx-1.2, sy); ctx.moveTo(sx+1.4, sy-5); ctx.lineTo(sx+1.4, sy); ctx.stroke();
                ctx.fillStyle = roofCol;
                ctx.beginPath(); ctx.moveTo(sx-4.5, sy-5); ctx.lineTo(sx, sy-8.5); ctx.lineTo(sx+4.5, sy-5); ctx.closePath(); ctx.fill();
            }
            // Turm-Dimensionen skalieren mit burgLevel
            const tw = 10 + bl * 3, th = 12 + bl * 4;
            const towerCol = bl >= 5 ? '#8A7848' : bl >= 4 ? '#6A6A6A' : '#5C5C5C';
            // Burgturm zentral
            ctx.fillStyle = towerCol;
            ctx.fillRect(-tw/2, -th, tw, th);
            ctx.strokeStyle = '#2E2E2E'; ctx.lineWidth = 0.9; ctx.strokeRect(-tw/2, -th, tw, th);
            ctx.strokeStyle = 'rgba(0,0,0,0.18)'; ctx.lineWidth = 0.5;
            for (let yy=-th+4; yy<-4; yy+=4){ ctx.beginPath(); ctx.moveTo(-tw/2+1, yy); ctx.lineTo(tw/2-1, yy); ctx.stroke(); }
            // Zinnen
            const nz = 3 + (bl > 2 ? 1 : 0) + (bl >= 5 ? 1 : 0);
            ctx.fillStyle = towerCol; ctx.strokeStyle = '#2E2E2E'; ctx.lineWidth = 0.6;
            for (let i=0;i<=nz;i++){ const zx = -tw/2 + i*(tw/nz) - 1.4; ctx.fillRect(zx, -th-3.4, 2.8, 3.8); ctx.strokeRect(zx, -th-3.4, 2.8, 3.8); }
            // Torbogen
            ctx.fillStyle = '#241C12';
            ctx.beginPath(); ctx.moveTo(-3.2, 0); ctx.lineTo(-3.2, -3.6); ctx.arc(0, -3.6, 3.2, Math.PI, 0); ctx.lineTo(3.2, 0); ctx.closePath(); ctx.fill();
            ctx.fillStyle = '#1A1A1A'; ctx.fillRect(-1.1, -th+4, 2.2, 3);
            // Seitentuerme (ab Festung)
            if (bl >= 3) {
                for (const sx of [-tw/2-4.5, tw/2+4.5]) {
                    ctx.fillStyle = bl >= 5 ? '#7A6838' : '#4E4E4E'; ctx.fillRect(sx-3, -th*0.62, 6, th*0.62);
                    ctx.strokeStyle = '#2E2E2E'; ctx.lineWidth = 0.7; ctx.strokeRect(sx-3, -th*0.62, 6, th*0.62);
                    ctx.fillStyle = bl >= 5 ? '#B8860B' : '#8A4A32';
                    ctx.beginPath(); ctx.moveTo(sx-3.8, -th*0.62); ctx.lineTo(sx, -th*0.62-6); ctx.lineTo(sx+3.8, -th*0.62); ctx.closePath(); ctx.fill();
                }
            }
            // Dritter Turm (Zitadelle+): hinten mittig, hoeher
            if (bl >= 4) {
                const btw = 5, bth = th * 0.5;
                ctx.fillStyle = bl >= 5 ? '#8A7848' : '#555';
                ctx.fillRect(-btw/2, -th - bth + 4, btw, bth);
                ctx.strokeStyle = '#2E2E2E'; ctx.lineWidth = 0.6; ctx.strokeRect(-btw/2, -th - bth + 4, btw, bth);
                ctx.fillStyle = bl >= 5 ? '#B8860B' : '#8A4A32';
                ctx.beginPath(); ctx.moveTo(-btw/2-1, -th-bth+4); ctx.lineTo(0, -th-bth-3); ctx.lineTo(btw/2+1, -th-bth+4); ctx.closePath(); ctx.fill();
            }
            // Goldene Kuppel (Imperium)
            if (bl >= 5) {
                ctx.fillStyle = '#FFD700';
                ctx.beginPath(); ctx.arc(0, -th-3.4, 4.5, Math.PI, 0); ctx.fill();
                ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.arc(0, -th-3.4, 4.5, Math.PI, 0); ctx.stroke();
                // Wehende Banner links und rechts
                for (const sgn of [-1, 1]) {
                    const bx = sgn * (tw/2 + 8), by = -th * 0.3;
                    ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1;
                    ctx.beginPath(); ctx.moveTo(bx, by+5); ctx.lineTo(bx, by-8); ctx.stroke();
                    ctx.fillStyle = b.color;
                    const wave = Math.sin(RC_WAR.t * 3 + sgn) * 2;
                    ctx.beginPath(); ctx.moveTo(bx, by-8); ctx.quadraticCurveTo(bx+sgn*4, by-6+wave, bx+sgn*7, by-7);
                    ctx.lineTo(bx+sgn*7, by-3); ctx.quadraticCurveTo(bx+sgn*4, by-4+wave, bx, by-4); ctx.closePath(); ctx.fill();
                }
            }
            // Katapult auf dem Dach (Zitadelle+)
            if (bl >= 4) {
                const kx = tw/2 - 2, ky = -th + 2;
                ctx.fillStyle = '#6E5A3E'; ctx.fillRect(kx-2, ky-1, 4, 2);
                const armAng = Math.sin(RC_WAR.t * 0.5) * 0.3 - 0.8;
                ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.5;
                ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(kx + Math.cos(armAng)*6, ky + Math.sin(armAng)*6); ctx.stroke();
            }
            // OPTION B: keine Schadens-/Brand-Visuals mehr — eine niedrige Wertung ist
            // kein Brand, sondern eine noch kleine Burg. Nur der Qualitaets-Alarm bleibt.
            // Warn fire (quality alarm — kept from original)
            if (b.warn && hpPct >= 0.2) {
                const fx0 = tw/2 + 2.5, fy0 = -th*0.4;
                const fl = Math.sin(RC_WAR.t*11 + b.seed);
                ctx.fillStyle = '#E60000';
                ctx.beginPath(); ctx.moveTo(fx0-2, fy0); ctx.quadraticCurveTo(fx0-2.6, fy0-3.5-fl, fx0, fy0-5.5-fl*1.4); ctx.quadraticCurveTo(fx0+2.6, fy0-3.5+fl, fx0+2, fy0); ctx.closePath(); ctx.fill();
            }
            ctx.restore();
        }
        // === ELEMENTS DRAWN IN WORLD SPACE (after ctx.restore) ===
        if (!isConquered) {
            // Dorf-Gewusel als LOD-Punkte (Performance): frueher wurde JEDER Worker als
            // volle rcWarDrawMan/-Barrow-Figur gezeichnet (bis ~110/Frame = der groesste
            // Draw-Fresser). Jetzt billige Team-Farb-Punkte mit gebuendeltem Schatten —
            // 2 fillStyle-Sets je Burg statt hunderter Pfad-Operationen. Reine Deko,
            // kein Gameplay. Karren = kleiner Block, damit sie als Transporter lesbar
            // bleiben. Radius skaliert mit baseScale (BS), also unitScale/baseScale-treu.
            const ws = b.workers;
            if (ws.length) {
                const dr = 2.3 * BS;                 // Punkt-Radius, an baseScale gekoppelt
                if (!RC_WAR._loDetail) {             // ab Sprite-Schwelle Schatten weglassen
                    ctx.fillStyle = 'rgba(0,0,0,0.26)';
                    for (let i = 0; i < ws.length; i++) { const w = ws[i]; ctx.beginPath();
                        ctx.ellipse(b.x + w.x*BS, b.y + w.y*BS + dr*0.85, dr*1.15, dr*0.5, 0, 0, 6.283); ctx.fill(); }
                }
                ctx.fillStyle = b.color;
                for (let i = 0; i < ws.length; i++) { const w = ws[i];
                    const bob = Math.sin(RC_WAR.t*6 + w.ph) * 0.9 * BS;    // etwas Leben, sehr billig
                    const wx = b.x + w.x*BS, wy = b.y + w.y*BS - dr + bob;
                    if (w.kind === 'cart') ctx.fillRect(wx - dr*1.1, wy - dr*0.55, dr*2.2, dr*1.1);
                    else { ctx.beginPath(); ctx.arc(wx, wy, dr, 0, 6.283); ctx.fill(); }
                }
            }
            // Ehrengarde
            if (RC_WAR.leader === b.code && b.total > 0) {
                const wob = Math.sin(RC_WAR.t*1.1);
                const pad2 = 12 + (b.burgLevel||1) * 3;
                for (const sgn of [-1, 1]) {
                    rcWarDrawMan(ctx, b.x + sgn*pad2*BS*0.8 + wob*7*sgn, b.y + 12*BS,
                        { col: b.color, face: (Math.cos(RC_WAR.t*1.1)*sgn) >= 0 ? 1 : -1,
                          step: RC_WAR.t*6, arms:'spear', helmet:true, size:0.85, nation: b.nation });
                }
            }
            // Wachposten (Zitadelle+)
            if (bl >= 4 && !isConquered) {
                for (let i = 0; i < 2; i++) {
                    const ga = (RC_WAR.t * 0.4 + i * Math.PI) % (Math.PI * 2);
                    const gpad = 12 + bl * 3 + 5;
                    const gx = b.x + Math.cos(ga) * gpad * BS, gy = b.y + Math.sin(ga) * gpad * BS * 0.72;
                    rcWarDrawMan(ctx, gx, gy, { col: b.color, face: Math.cos(ga) >= 0 ? 1 : -1, step: RC_WAR.t * 5, arms:'spear', helmet:true, size:0.7, nation: b.nation });
                }
            }
        }
        // Flag
        const flagY = isConquered ? -18 * BS : (-(12 + bl*4) - 4) * BS;
        rcWarDrawFlag(ctx, b, b.x, b.y + flagY / BS);
        // === HP BAR ===
        const barW = 48, barH = 6;
        const barX = b.x - barW/2, barY = b.y - (isConquered ? 28 : (22 + bl*5)) * BS;
        // Background
        ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(barX-1, barY-1, barW+2, barH+2);
        // HP fill
        // OPTION B: Balken = Burgstaerke (eigener Score im Verhaeltnis zum Fuehrenden)
        const isLead = RC_WAR.leader === b.code || b.rank === 1;
        const hpCol = isLead ? '#FFCE00' : hpPct > 0.6 ? '#57D0E0' : hpPct > 0.3 ? '#3E9BD0' : '#3A6E9C';
        const fillW = Math.max(0, barW * hpPct);
        ctx.fillStyle = hpCol; ctx.fillRect(barX, barY, fillW, barH);
        if (window.rcWarHud.burgLabels) {
        // Platz + Punkte — TV-lesbar (>=12px)
        ctx.font = rcWarFont(12, true); ctx.textAlign = 'center';
        ctx.fillStyle = isLead ? '#FFCE00' : '#FFFFFF';
        ctx.fillText('PLATZ ' + (b.rank||'-') + ' · ' + Math.round(b.score||0) + ' PKT', b.x, barY - 5);
        // Konkreter Handlungsimpuls direkt an der Burg (nur im Detail-Modus)
        if (!isConquered && !window.rcWarHud.burgKompakt) {
            ctx.font = rcWarFont(12, true);
            if (b.rank === 1 || !b.aboveCode) { ctx.fillStyle = '#FFCE00';
                ctx.fillText('FUEHRT DIE WERTUNG', b.x, barY + barH + 14); }
            else { ctx.fillStyle = (b.gapAbove||0) <= 20 ? '#66DD88' : '#C9B08A';
                ctx.fillText('noch ' + (b.gapAbove||0) + ' bis Platz ' + (b.rank-1), b.x, barY + barH + 14); }
        }
        // Label: Name + Score
        const o = rcWarLabelOfs[b.code] || { dx:26, align:'left' };
        const lx = b.x + o.dx * Math.max(1, BS*0.85), ly = b.y + (o.dy != null ? o.dy : -6);
        ctx.textAlign = o.align === 'right' ? 'right' : 'left';
        ctx.font = rcWarFont(11, true); ctx.fillStyle = isConquered ? '#C0C0C0' : '#F5F5F5';
        ctx.fillText(b.short, lx, ly);
        if (!window.rcWarHud.burgKompakt) {
            ctx.font = rcWarFont(9);
            ctx.fillStyle = isConquered ? '#555' : (b.bcr > 0 ? (RC_WAR.leader === b.code ? '#E60000' : '#C9C9C9') : '#7E7E7E');
            ctx.fillText(b.bcr + ' BCR-rel.' + (b.nonBcr > 0 ? ' · ' + b.nonBcr + ' n.rel.' : ''), lx, ly + 11);
            // Burgstufe label
            const stufenName = ['Holzhuette','Steinburg','Festung','Zitadelle','Imperium'][bl-1];
            ctx.font = rcWarFont(7); ctx.fillStyle = bl >= 5 ? '#FFD700' : bl >= 4 ? '#88BBFF' : '#7E7E7E';
            ctx.fillText(stufenName + ' · Platz ' + (b.rank||'-'), lx, ly + 21);
            // Quality line
            let qTxt = '', qCol = '#7E7E7E';
            if (b.cs != null && b.cs >= 90) { qTxt = 'SCHILDWALL CS ' + b.cs.toFixed(0) + '%'; qCol = '#DCDCDC'; }
            else if (b.tnps != null && b.tnps >= 70) { qTxt = 'MORAL TNPS ' + b.tnps.toFixed(0) + '%'; qCol = '#DCDCDC'; }
            if (qTxt) { ctx.font = rcWarFont(8, true); ctx.fillStyle = qCol; ctx.fillText(qTxt, lx, ly + 30); }
            if (b.warn) { ctx.font = rcWarFont(8, true); ctx.fillStyle = '#FF6666'; ctx.fillText('ALARM', lx, ly + (qTxt ? 39 : 30)); }
            // Conquest count stars
            if (b.conquests && b.conquests.length > 0 && !isConquered) {
                ctx.font = rcWarFont(8, true); ctx.fillStyle = '#FFD700';
                ctx.fillText('★'.repeat(b.conquests.length), lx, ly + (qTxt ? 48 : 39));
            }
        }
        }
        ctx.textAlign = 'left';
    }

    // ---------- Figuren-Baukasten v2: Karikaturen-Rig (dick, watschelnd, Ursprung = Fuesse) ----------
    // DE = Bierbauch + Pickelhaube (Karikatur) · GR = Evzone mit Fustanella, taenzelnd (Karikatur)
    // TR = BEWUSST WUERDEVOLL: schlank, stolze Haltung, KEINE Witzfigur (User-Vorgabe 16.07.2026)
    // o: { col (Akzent/Waffenrock), face (1|-1), step (Laufphase), size, helmet, fallen (0..1),
    //      arms: 'sword'|'bow'|'spear'|'carry'|'flag'|null, swing (-1..1), raise (0..1), draw (0..1),
    //      nation: 'DE'|'GR'|'TR'|'AT'|sonst, gag: 'prost'|'pirouette'|null, gagT (0..1) }
    function rcWarDrawMan(ctx, x, y, o){
        o = o || {};
        const s = (o.size || 1) * (RC_WAR.unitScale || 1);
        const nat = o.nation || '', gag = o.gag || null;
        const gt = Math.max(0, Math.min(1, o.gagT || 0));
        const OUT = 'rgba(20,16,10,0.5)', SKIN = '#E8B88A', tun = o.col || '#9C9C9C';
        const ph = o.step || 0, wob = Math.sin(ph);
        const rr = (X,Y,W,H,R) => { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(X,Y,W,H,R); else ctx.rect(X,Y,W,H); };
        ctx.save(); ctx.translate(x, y);
        // weicher Bodenschatten (Maschine/Spargel schlanker)
        ctx.fillStyle = 'rgba(0,0,0,0.28)';
        ctx.beginPath(); ctx.ellipse(0, 0.8*s, (nat === 'TR' ? 4.7 : nat === 'AT' ? 4.0 : nat === 'DE' ? 5.9 : nat === 'GR' ? 4.8 : 5.6)*s, 1.7*s, 0, 0, 7); ctx.fill();
        ctx.scale(s * (o.face || 1), s);
        if (o.fallen) ctx.rotate(-o.fallen * Math.PI/2); // ruecklings umkippen
        // Kopfhoehe: AT hat einen ueberlangen Hals -> Kopf sitzt hoeher
        const hy = nat === 'AT' ? -20.4 : nat === 'TR' ? -17.2 : -16.6;
        const chx = nat === 'TR' ? 0.8 : 0, ax = 3.1 + chx;
        const mtx = 4.6, mty = hy - 1.6;                     // Schnurrbart-Anker (Fallback)
        const step = nat === 'GR' ? wob*2.3 : nat === 'DE' ? wob*2.0 : nat === 'AT' ? wob*1.7 : wob*2.2;
        // Armfarbe: Stahl fuer die Kriegsmaschine, Kartoffelbraun fuer DE, Haut/Duenn sonst
        const ARM = nat === 'TR' ? '#828A94' : nat === 'DE' ? '#8A5C30' : nat === 'AT' ? '#C9B89A' : SKIN;
        ctx.lineCap = 'round';
        // Umhang der Schwertkaempfer weht hinter dem Ruecken (hinter dem Koerper zuerst)
        if (o.arms === 'sword' && !o.fallen) {
            const fl2 = 1.4 + Math.abs(wob)*1.8;
            const gaC = ctx.globalAlpha; ctx.globalAlpha = gaC * 0.8;
            ctx.fillStyle = tun;
            ctx.beginPath();
            ctx.moveTo(-1.6, -14.6);
            ctx.quadraticCurveTo(-5.6 - fl2, -11, -4.6 - fl2, -1.4 + wob*0.7);
            ctx.quadraticCurveTo(-3.4 - fl2*0.4, -3.6, -1, -4.6);
            ctx.closePath(); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.6; ctx.stroke();
            ctx.globalAlpha = gaC;
        }

        // =====================================================================
        //  KOERPER JE NATION — jede Nation sofort an Silhouette erkennbar
        // =====================================================================
        if (nat === 'TR') {
            // --- Osmanische Yeniceri-KRIEGSMASCHINE: Stahl+Messing, Dampf, Boerk ---
            const STEEL = '#5E656E', STEELD = '#3A4048', BRASS = '#C8A24A', GLOW = '#FF3B2F';
            const pist = wob*1.6; // Kolbenhub der Beine
            // Beinkolben
            ctx.strokeStyle = STEELD; ctx.lineWidth = 2.6;
            ctx.beginPath(); ctx.moveTo(-1.7,-5); ctx.lineTo(-1.7+pist,0); ctx.moveTo(1.7,-5); ctx.lineTo(1.7-pist,0); ctx.stroke();
            ctx.strokeStyle = BRASS; ctx.lineWidth = 0.6; // Messing-Gelenke
            ctx.beginPath(); ctx.arc(-1.7+pist*0.5,-2.6,0.6,0,7); ctx.arc(1.7-pist*0.5,-2.6,0.6,0,7); ctx.stroke();
            // Panzer-Fuesse
            ctx.fillStyle = STEEL; ctx.strokeStyle = OUT; ctx.lineWidth = 0.5;
            for (const fx of [-1.7+pist, 1.7-pist]) { rr(fx-1.3,-1.3,2.6,1.6,0.3); ctx.fill(); ctx.stroke(); }
            // Dampf-Puff beim Marsch (steigt auf, verpufft)
            if (o.step) { const pt = (RC_WAR.t*1.6) % 1, pa = 0.34*(1-pt);
                ctx.fillStyle = 'rgba(222,227,232,'+pa.toFixed(2)+')';
                ctx.beginPath(); ctx.arc(-3.6,-13.5-pt*5,1.1+pt*1.5,0,7); ctx.fill();
                ctx.beginPath(); ctx.arc(-4.4,-11.5-pt*4,0.8+pt*1.1,0,7); ctx.fill(); }
            // kantiger Metallkorpus
            ctx.fillStyle = STEEL; ctx.strokeStyle = OUT; ctx.lineWidth = 0.9;
            rr(-4,-14.6,8,9.1,1.3); ctx.fill(); ctx.stroke();
            // Panzerfuge + Team-Schaerpe diagonal
            ctx.strokeStyle = STEELD; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.moveTo(-4,-10.6); ctx.lineTo(4,-10.6); ctx.stroke();
            ctx.strokeStyle = tun; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(-3.6,-13.8); ctx.lineTo(3.6,-7.2); ctx.stroke();
            // zentrales drehendes Zahnrad
            ctx.save(); ctx.translate(0.4,-10.1); ctx.rotate(RC_WAR.t*2.2*(o.step?1:0.35));
            ctx.fillStyle = BRASS; ctx.strokeStyle = '#8A6E2E'; ctx.lineWidth = 0.4;
            ctx.beginPath(); for (let i=0;i<10;i++){ const a=i/10*6.283, r=i%2?1.05:2.0; ctx.lineTo(Math.cos(a)*r, Math.sin(a)*r); } ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = STEELD; ctx.beginPath(); ctx.arc(0,0,0.6,0,7); ctx.fill(); ctx.restore();
            // Messing-Nieten
            ctx.fillStyle = BRASS; for (const rv of [[-3,-13.7],[3,-13.7],[-3,-6.7],[3,-6.7]]) { ctx.beginPath(); ctx.arc(rv[0],rv[1],0.5,0,7); ctx.fill(); }
            // Metallschaedel
            ctx.fillStyle = STEEL; ctx.strokeStyle = OUT; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.arc(0,hy,2.95,0,7); ctx.fill(); ctx.stroke();
            // gluehender Visierschlitz (roter Gradient) + Augenpunkte
            const vg = ctx.createLinearGradient(-2.4,hy,2.6,hy);
            vg.addColorStop(0,'#7A0E08'); vg.addColorStop(0.5,GLOW); vg.addColorStop(1,'#7A0E08');
            ctx.fillStyle = vg; rr(-2.2,hy-0.7,4.4,1.4,0.7); ctx.fill();
            ctx.fillStyle = '#FFE2DE'; ctx.beginPath(); ctx.arc(-1,hy,0.42,0,7); ctx.arc(1.6,hy,0.42,0,7); ctx.fill();
            // Boerk: hoher weisser Yeniceri-Ueskuef + langer herabhaengender Aermel 'yelken' hinten
            ctx.fillStyle = '#EDE8DC'; ctx.strokeStyle = OUT; ctx.lineWidth = 0.6;
            ctx.beginPath(); ctx.moveTo(-1.7,hy-7.2); ctx.quadraticCurveTo(-7.8,hy-5.4,-7.2,hy+1.4); ctx.quadraticCurveTo(-6.7,hy+4.0,-4.5,hy+3.0); ctx.quadraticCurveTo(-4.6,hy-2.4,-2.0,hy-3.6); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = '#F2EEE4'; ctx.strokeStyle = OUT; ctx.lineWidth = 0.75;
            ctx.beginPath(); ctx.moveTo(-2.5,hy-2.5); ctx.lineTo(2.5,hy-2.5); ctx.lineTo(3.0,hy-11.8); ctx.quadraticCurveTo(0,hy-13.1,-3.0,hy-11.8); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = BRASS; ctx.fillRect(-2.7,hy-3.3,5.4,1.3);
            ctx.fillStyle = BRASS; ctx.strokeStyle = '#8A6E2E'; ctx.lineWidth = 0.4; rr(-1.3,hy-7.1,2.6,3.1,0.5); ctx.fill(); ctx.stroke();
            ctx.fillStyle = GLOW; ctx.beginPath(); ctx.arc(0,hy-5.5,0.55,0,7); ctx.fill(); // Ziersaphir
        } else if (nat === 'GR') {
            // --- Evzone-Garde: Minirock-Fustanella, Farion, Tsarouchia, hoher Stechschritt ---
            const WHITE = '#F4F1E8';
            const lift = Math.max(0, Math.sin(ph))*4.4, lift2 = Math.max(0, -Math.sin(ph))*4.4;
            // weisse Strumpf-Beine, eines hebt hoch (Stechschritt)
            ctx.strokeStyle = WHITE; ctx.lineWidth = 1.8;
            ctx.beginPath(); ctx.moveTo(-1.4,-5); ctx.lineTo(-1.4, -lift); ctx.moveTo(1.4,-5); ctx.lineTo(1.4, -lift2); ctx.stroke();
            // Tsarouchia: rote Schnabelschuhe mit dickem schwarzem Bommel
            for (const f of [[-1.4,-lift],[1.4,-lift2]]) {
                const fx=f[0], fy=f[1];
                ctx.fillStyle = '#C9241E';
                ctx.beginPath(); ctx.moveTo(fx-1.2,fy); ctx.quadraticCurveTo(fx+1.8,fy+0.5,fx+1.5,fy-1.7); ctx.quadraticCurveTo(fx+0.5,fy-0.3,fx-1.2,fy); ctx.closePath(); ctx.fill();
                ctx.strokeStyle = OUT; ctx.lineWidth = 0.4; ctx.stroke();
                ctx.fillStyle = '#111'; ctx.beginPath(); ctx.arc(fx+1.6,fy-2.0,0.9,0,7); ctx.fill();
            }
            // Fustanella als kurzer Minirock (weiss, ausgestellt, Zickzack-Saum, kurz -> viel Bein)
            ctx.fillStyle = WHITE; ctx.strokeStyle = OUT; ctx.lineWidth = 0.7;
            ctx.beginPath(); ctx.moveTo(-3.0,-9.2); ctx.lineTo(3.0,-9.2); ctx.lineTo(6.1,-6.0);
            for (let k=1;k<=6;k++) ctx.lineTo(6.1 - k*(12.2/6), k%2 ? -5.3 : -6.1);
            ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.strokeStyle = '#D3CDBE'; ctx.lineWidth = 0.4;
            ctx.beginPath(); for (let k=-3;k<=3;k++){ ctx.moveTo(k*1.0,-8.9); ctx.lineTo(k*1.85,-6.0); } ctx.stroke();
            // weisses Hemd + Team-Weste
            ctx.fillStyle = WHITE; ctx.beginPath(); ctx.ellipse(0,-11.2,3.2,3.0,0,0,7); ctx.fill(); ctx.strokeStyle = OUT; ctx.lineWidth = 0.7; ctx.stroke();
            ctx.fillStyle = tun; ctx.beginPath(); ctx.moveTo(-2.7,-13.6); ctx.lineTo(2.7,-13.6); ctx.lineTo(1.7,-9); ctx.lineTo(-1.7,-9); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = WHITE; ctx.lineWidth = 1.0; ctx.beginPath(); ctx.moveTo(-2.4,-9.4); ctx.lineTo(2.4,-13.8); ctx.stroke(); // Bandelier
            // Kopf + stolzes Gesicht + Schnurrbart
            ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(0,hy,2.7,0,7); ctx.fill(); ctx.strokeStyle = OUT; ctx.lineWidth = 0.7; ctx.stroke();
            ctx.fillStyle = '#0D0D0D'; ctx.fillRect(-0.4,hy-1.1,0.6,0.6); ctx.fillRect(1.4,hy-1.1,0.6,0.6);
            ctx.strokeStyle = '#3A2A1A'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-0.7,hy+1.3); ctx.quadraticCurveTo(0.7,hy+2.3,2.1,hy+1.3); ctx.stroke();
            // Evzonen-Farion: flache rote Wollkappe (KEIN osmanischer Fes) + lange schwarze Quaste zur Schulter
            ctx.fillStyle = '#C9241E'; ctx.strokeStyle = OUT; ctx.lineWidth = 0.6;
            rr(-2.5,hy-2.9,5.0,1.9,0.5); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.ellipse(0,hy-2.9,2.5,0.75,0,0,7); ctx.fill(); ctx.stroke();
            ctx.strokeStyle = '#161616'; ctx.lineWidth = 0.8; ctx.beginPath(); ctx.moveTo(2.0,hy-2.5); ctx.quadraticCurveTo(4.8,hy-1.0,4.3,hy+4.4); ctx.stroke();
            ctx.fillStyle = '#161616'; ctx.beginPath(); ctx.arc(4.2,hy+4.8,0.75,0,7); ctx.fill();
        } else if (nat === 'DE') {
            // --- Kartoffel-Krieger: knolliger Erdapfel-Leib, Pickelhaube mit Spitze ---
            const POT = '#B07A44', POTD = '#8A5C30', DENT = '#5A3A1E', PICK = '#3A3E42', PICKD = '#24272B';
            // stummelige Kartoffel-Beinchen
            ctx.strokeStyle = POTD; ctx.lineWidth = 2.4;
            ctx.beginPath(); ctx.moveTo(-1.7,-4.6); ctx.lineTo(-1.7+wob*1.7,0); ctx.moveTo(1.7,-4.6); ctx.lineTo(1.7-wob*1.7,0); ctx.stroke();
            // kleine Erd-Stiefel
            ctx.fillStyle = PICK; ctx.strokeStyle = OUT; ctx.lineWidth = 0.5;
            for (const fx of [-1.7+wob*1.7, 1.7-wob*1.7]) { rr(fx-1.5,-1.5,3.0,1.7,0.5); ctx.fill(); ctx.stroke(); }
            // knolliger Kartoffel-Leib (dick, unregelmaessig)
            ctx.fillStyle = POT; ctx.strokeStyle = OUT; ctx.lineWidth = 0.9;
            ctx.beginPath(); ctx.ellipse(0,-8.6,4.7,5.3,0,0,7); ctx.fill(); ctx.stroke();
            // Kartoffel-Augen (Dellen) auf dem Leib
            ctx.fillStyle = DENT;
            for (const d of [[-2.3,-10.6],[2.0,-7.2],[-1.4,-5.4],[2.6,-11.0]]) { ctx.beginPath(); ctx.ellipse(d[0],d[1],0.45,0.32,0.6,0,7); ctx.fill(); }
            // kleiner gruener Keim seitlich (macht die Knolle lesbar)
            ctx.strokeStyle = '#6E8B3D'; ctx.lineWidth = 0.7; ctx.beginPath(); ctx.moveTo(-3.2,-12.2); ctx.quadraticCurveTo(-4.5,-13.5,-3.8,-14.8); ctx.stroke();
            ctx.fillStyle = '#7EA03F'; ctx.beginPath(); ctx.ellipse(-3.8,-15.0,0.6,0.95,-0.3,0,7); ctx.fill();
            // Team-Schaerpe schraeg ueber den Bauch
            ctx.strokeStyle = tun; ctx.lineWidth = 1.7; ctx.beginPath(); ctx.moveTo(-3.5,-6.0); ctx.lineTo(3.3,-10.8); ctx.stroke();
            // runde Kartoffel-Schulterknollen
            ctx.fillStyle = POTD; ctx.strokeStyle = OUT; ctx.lineWidth = 0.6;
            ctx.beginPath(); ctx.ellipse(-4.4,-12.2,1.6,1.5,0,0,7); ctx.fill(); ctx.stroke();
            ctx.beginPath(); ctx.ellipse(4.4,-12.2,1.6,1.5,0,0,7); ctx.fill(); ctx.stroke();
            // Kartoffel-Kopf (knollig-oval)
            ctx.fillStyle = POT; ctx.strokeStyle = OUT; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.ellipse(0,hy+0.5,3.0,2.6,0.08,0,7); ctx.fill(); ctx.stroke();
            // grimmiges Gesicht + Kopf-Delle
            ctx.fillStyle = '#0D0D0D'; ctx.fillRect(-1.3,hy-0.3,0.7,0.7); ctx.fillRect(0.7,hy-0.3,0.7,0.7);
            ctx.strokeStyle = '#3A2416'; ctx.lineWidth = 0.7;
            ctx.beginPath(); ctx.moveTo(-1.7,hy-1.2); ctx.lineTo(-0.5,hy-0.9); ctx.moveTo(1.7,hy-1.2); ctx.lineTo(0.5,hy-0.9); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-1.0,hy+1.6); ctx.quadraticCurveTo(0,hy+1.05,1.0,hy+1.6); ctx.stroke();
            ctx.fillStyle = DENT; ctx.beginPath(); ctx.ellipse(2.0,hy+0.9,0.4,0.3,0,0,7); ctx.fill();
            // Pickelhaube: dunkle Kuppel + Spitze (der deutsche Bezug)
            ctx.fillStyle = PICK; ctx.strokeStyle = OUT; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.arc(0,hy-1.0,3.05,Math.PI,2*Math.PI); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = PICKD; ctx.fillRect(-3.1,hy-1.2,6.2,0.85);
            ctx.fillStyle = PICK; ctx.strokeStyle = OUT; ctx.lineWidth = 0.5;
            ctx.beginPath(); ctx.moveTo(-0.7,hy-3.6); ctx.lineTo(0.7,hy-3.6); ctx.lineTo(0,hy-6.0); ctx.closePath(); ctx.fill(); ctx.stroke();
            ctx.fillStyle = PICKD; ctx.beginPath(); ctx.arc(0,hy-3.6,0.7,0,7); ctx.fill();
        } else if (nat === 'AT') {
            // --- Spargel-Ritter: spindelduerr, schlackernde Ueberruestung, langer Hals ---
            const LOOSE = '#8C9096', LOOSED = '#6A6E74';
            const jig = Math.sin(RC_WAR.t*11 + ph)*0.7; // Klappern der zu grossen Ruestung
            // duenne Beinchen
            ctx.strokeStyle = '#7A6A52'; ctx.lineWidth = 0.9;
            ctx.beginPath(); ctx.moveTo(-1.1,-5); ctx.lineTo(-1.1+wob*1.5,0); ctx.moveTo(1.1,-5); ctx.lineTo(1.1-wob*1.5,0); ctx.stroke();
            // viel zu grosse Eisenschuhe
            ctx.fillStyle = LOOSE; ctx.strokeStyle = OUT; ctx.lineWidth = 0.5;
            for (const fx of [-1.1+wob*1.5, 1.1-wob*1.5]) { rr(fx-1.6,-1.7,3.3,1.9,0.3); ctx.fill(); ctx.stroke(); }
            // duenner Torso schimmert unter der Ruestung durch
            ctx.strokeStyle = '#C9B89A'; ctx.lineWidth = 1.3; ctx.beginPath(); ctx.moveTo(0,-13); ctx.lineTo(0,-4.2); ctx.stroke();
            // schlackernde Ueberruestung (breiter als der Koerper, wackelt)
            ctx.save(); ctx.translate(jig,0);
            ctx.fillStyle = LOOSE; ctx.strokeStyle = OUT; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.moveTo(-4.0,-11.6); ctx.lineTo(4.0,-11.6); ctx.lineTo(2.9,-3.4); ctx.lineTo(-2.9,-3.4); ctx.closePath(); ctx.fill(); ctx.stroke();
            // Ausschnitt zeigt den duennen Brustkorb -> Ruestung sitzt sichtbar zu weit
            ctx.strokeStyle = '#B7A788'; ctx.lineWidth = 0.9; ctx.beginPath(); ctx.moveTo(-1.3,-11.6); ctx.quadraticCurveTo(0,-9.2,1.3,-11.6); ctx.stroke();
            ctx.fillStyle = tun; ctx.beginPath(); ctx.moveTo(-1.4,-10.8); ctx.lineTo(1.4,-10.8); ctx.lineTo(0,-6.9); ctx.closePath(); ctx.fill();
            ctx.fillStyle = LOOSED; ctx.strokeStyle = OUT; ctx.lineWidth = 0.5;
            rr(-5.4,-12.2,2.9,2.0,0.4); ctx.fill(); ctx.stroke(); rr(2.5,-12.2,2.9,2.0,0.4); ctx.fill(); ctx.stroke();
            ctx.restore();
            // ueberlanger, sehr duenner Hals (deutlich sichtbar zwischen Ruestung und Helm)
            ctx.strokeStyle = SKIN; ctx.lineWidth = 0.85; ctx.beginPath(); ctx.moveTo(0,-11.6); ctx.lineTo(0,hy+1.6); ctx.stroke();
            // kleiner Kopf, nur Mund/Kinn sichtbar
            ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(0,hy,1.95,0,7); ctx.fill(); ctx.strokeStyle = OUT; ctx.lineWidth = 0.6; ctx.stroke();
            ctx.strokeStyle = '#5A4A33'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.arc(0,hy+1.1,0.7,0.25,2.9); ctx.stroke();
            // viel zu grosser Kuebelhelm, ueber die Augen gerutscht
            ctx.fillStyle = LOOSE; ctx.strokeStyle = OUT; ctx.lineWidth = 0.7;
            rr(-2.9,hy-3.4+jig*0.4,5.8,5.1,0.9); ctx.fill(); ctx.stroke();
            ctx.fillStyle = LOOSED; ctx.fillRect(-2.6,hy-0.1+jig*0.4,5.2,0.85); // Schlitz zu tief -> deckt die Augen
        } else {
            // --- Fallback: bisheriger stammelnder Krieger (generisch) ---
            ctx.strokeStyle = '#33261A'; ctx.lineWidth = 2.1;
            ctx.beginPath(); ctx.moveTo(-1.6,-5); ctx.lineTo(-1.6 + step, 0); ctx.moveTo(1.6,-5); ctx.lineTo(1.6 - step, 0); ctx.stroke();
            ctx.fillStyle = '#2E2216';
            ctx.beginPath(); ctx.arc(-1.6 + step, -0.3, 0.95, 0, 7); ctx.fill();
            ctx.beginPath(); ctx.arc(1.6 - step, -0.3, 0.95, 0, 7); ctx.fill();
            // Rumpf-Sway (Arme folgen der Schlagseite)
            ctx.translate(wob*0.45, 0); ctx.rotate(wob*0.05);
            const bx = wob*0.45, bw = 4.9, bh = 4.4 + Math.abs(wob)*0.3;
            ctx.fillStyle = tun; ctx.beginPath(); ctx.ellipse(bx, -8.4, bw, bh, 0, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.8; ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,0.22)'; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.ellipse(bx - bw*0.18, -9.1, bw*0.62, bh*0.6, -0.35, Math.PI*0.95, Math.PI*1.6); ctx.stroke();
            ctx.fillStyle = '#4E3A26'; ctx.fillRect(bx-bw+0.5, -8.7, (bw-0.5)*2, 1.5);
            ctx.fillStyle = '#D9B24A'; ctx.fillRect(bx-0.9, -8.9, 1.8, 1.9);
            ctx.fillStyle = tun; ctx.beginPath(); ctx.ellipse(0, -12.6, 3.4, 2.5, 0, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.8; ctx.stroke();
            ctx.fillStyle = SKIN; ctx.beginPath(); ctx.ellipse(0.5, hy+2.5, 2.15, 0.95, 0, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.5; ctx.stroke();
            ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(0, hy, 2.9, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.8; ctx.stroke();
            ctx.fillStyle = '#0D0D0D';
            ctx.fillRect(0.5, hy-1.2, 0.55, 0.55); ctx.fillRect(1.45, hy-1.2, 0.55, 0.55);
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.6; ctx.beginPath(); ctx.arc(1.1, hy+1, 1, 0.4, 2.3); ctx.stroke();
            ctx.fillStyle = '#DFA478'; ctx.beginPath(); ctx.arc(2.1, hy+0.4, 1.15, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.5; ctx.stroke();
            if (o.helmet) {
                ctx.fillStyle = '#C9C9C9'; ctx.beginPath(); ctx.arc(0, hy-0.4, 3.05, Math.PI*0.95, Math.PI*0.05); ctx.fill();
                ctx.fillStyle = tun; ctx.fillRect(-0.7, hy-5.4, 1.4, 3.6);
            } else {
                ctx.fillStyle = '#6E4E2E'; ctx.beginPath(); ctx.arc(0, hy-0.8, 2.9, Math.PI, 0); ctx.fill();
            }
        }
        // Arme + Geraet (Gag-Posen ersetzen die Waffenhaltung)
        ctx.strokeStyle = ARM; ctx.lineWidth = 1.6;
        const sw2 = o.swing || 0, raise = o.raise || 0;
        if (gag === 'prost') {
            // Bierkrug hoch — Prost! Freie Hand stemmt in die Huefte
            const a = -0.4 - Math.sin(gt*Math.PI)*1.25;
            const hx1 = ax + Math.cos(a)*3.4, hy1 = -12.2 + Math.sin(a)*3.4;
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12.2); ctx.lineTo(hx1, hy1); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-3,-12.2); ctx.lineTo(-5.2,-10); ctx.lineTo(-3.6,-7.6); ctx.stroke();
            ctx.fillStyle = '#B8BCC0';
            ctx.fillRect(hx1-1.3, hy1-3.4, 2.6, 3.4);
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.7; ctx.strokeRect(hx1-1.3, hy1-3.4, 2.6, 3.4);
            ctx.beginPath(); ctx.arc(hx1+1.7, hy1-1.7, 0.9, -Math.PI/2, Math.PI/2); ctx.stroke(); // Henkel
            ctx.fillStyle = '#FAF6EC'; // Schaumkrone
            ctx.beginPath();
            ctx.arc(hx1-0.8, hy1-3.6, 0.7, 0, 7); ctx.arc(hx1, hy1-4, 0.8, 0, 7); ctx.arc(hx1+0.8, hy1-3.5, 0.65, 0, 7);
            ctx.fill();
        } else if (gag === 'pirouette') {
            // eine Hand elegant ueber dem Kopf, Luftkuss-Herz fliegt davon
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12.4); ctx.lineTo(ax+1.2,-16.5); ctx.lineTo(ax-0.4,-20.5); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-3,-12.4); ctx.lineTo(-5.6,-13.6); ctx.stroke();
            const hx2 = 6 + gt*9, hy2 = -19 - gt*6, hr = 1.5;
            const ga = ctx.globalAlpha; ctx.globalAlpha = ga * Math.max(0, 1 - gt*0.9);
            ctx.fillStyle = '#E2241A'; // Herz per Bezier (kein Emoji)
            ctx.beginPath();
            ctx.moveTo(hx2, hy2 + hr);
            ctx.bezierCurveTo(hx2 - hr*1.7, hy2 - hr*0.5, hx2 - hr*0.7, hy2 - hr*1.9, hx2, hy2 - hr*0.55);
            ctx.bezierCurveTo(hx2 + hr*0.7, hy2 - hr*1.9, hx2 + hr*1.7, hy2 - hr*0.5, hx2, hy2 + hr);
            ctx.fill();
            ctx.globalAlpha = ga;
        } else if (gag === 'zwirbel') {
            // Hand zwirbelt genuesslich am Schnurrbart-Ende
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12.2); ctx.lineTo(ax+2.6,-14.6); ctx.lineTo(mtx-0.4, mty+0.4); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(-3,-12.2); ctx.lineTo(-4.6,-9.4); ctx.stroke();
            ctx.fillStyle = SKIN; ctx.beginPath(); ctx.arc(mtx-0.2, mty+0.2, 0.8, 0, 7); ctx.fill();
        } else if (o.arms === 'sword') {
            // Schildarm — der Schild deckt die halbe Wampe, Buckel in Teamfarbe
            ctx.beginPath(); ctx.moveTo(-3,-12.2); ctx.lineTo(-5.2,-9.6); ctx.stroke();
            ctx.fillStyle = '#6E4E2E'; ctx.beginPath(); ctx.ellipse(-6, -9.4, 2.4, 3.2, 0, 0, 7); ctx.fill();
            ctx.strokeStyle = OUT; ctx.lineWidth = 0.8; ctx.stroke();
            // Metallrand + Buckel: der Schild sieht nach Ruestkammer aus, nicht nach Sperrholz
            ctx.strokeStyle = '#C9CDD1'; ctx.lineWidth = 0.55;
            ctx.beginPath(); ctx.ellipse(-6, -9.4, 1.85, 2.6, 0, 0, 7); ctx.stroke();
            ctx.fillStyle = tun; ctx.beginPath(); ctx.arc(-6, -9.4, 0.9, 0, 7); ctx.fill();
            // Schwertarm: Siegerpose > Kampfschwung > Ruhe
            const ang = raise ? (-1.9 - raise*0.5) : (-0.55 + sw2*0.75);
            const hx1 = ax + Math.cos(ang)*2.8, hy1 = -11.6 + Math.sin(ang)*2.8;
            ctx.strokeStyle = ARM; ctx.lineWidth = 1.6;
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12); ctx.lineTo(hx1, hy1); ctx.stroke();
            ctx.save(); ctx.translate(hx1, hy1); ctx.rotate(ang);
            ctx.strokeStyle = '#E8E8E8'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0.5, 0); ctx.lineTo(9, 0); ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,0.55)'; ctx.lineWidth = 0.5; // Klingen-Glanz
            ctx.beginPath(); ctx.moveTo(1.5, -0.35); ctx.lineTo(8.2, -0.35); ctx.stroke();
            ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.moveTo(1.8, -1.8); ctx.lineTo(1.8, 1.8); ctx.stroke();
            ctx.fillStyle = '#D9B24A'; ctx.beginPath(); ctx.arc(-0.5, 0, 0.7, 0, 7); ctx.fill(); // Gold-Knauf
            ctx.restore();
        } else if (o.arms === 'bow') {
            const d = o.draw || 0, bo = 5.4;
            ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.3;
            ctx.beginPath(); ctx.arc(bo, -11.8, 4.6, -Math.PI/2.3, Math.PI/2.3); ctx.stroke();
            const tX = bo + Math.cos(Math.PI/2.3)*4.6, tY1 = -11.8 - Math.sin(Math.PI/2.3)*4.6, tY2 = -11.8 + Math.sin(Math.PI/2.3)*4.6;
            const nockX = bo - d*3.4;
            ctx.strokeStyle = '#DCDCDC'; ctx.lineWidth = 0.5;
            ctx.beginPath(); ctx.moveTo(tX, tY1); ctx.lineTo(nockX, -11.8); ctx.lineTo(tX, tY2); ctx.stroke();
            if (d > 0.1) { // eingelegter Pfeil
                ctx.strokeStyle = '#C9B08A'; ctx.lineWidth = 0.8;
                ctx.beginPath(); ctx.moveTo(nockX, -11.8); ctx.lineTo(nockX + 8, -11.8); ctx.stroke();
            }
            ctx.strokeStyle = ARM; ctx.lineWidth = 1.6;
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12); ctx.lineTo(bo, -11.8); ctx.moveTo(-3,-12); ctx.lineTo(nockX, -11.8); ctx.stroke();
            ctx.fillStyle = '#6E4E2E'; ctx.fillRect(-5.4, -14.6, 1.9, 5.2); // Koecher
        } else if (o.arms === 'spear') {
            const ang = -0.35 - sw2*0.55;
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12); ctx.lineTo(ax+1.6,-13.2); ctx.stroke();
            ctx.save(); ctx.translate(ax+1.6,-13.2); ctx.rotate(ang);
            ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(8, 0); ctx.stroke();
            ctx.fillStyle = '#DCDCDC'; ctx.beginPath(); ctx.moveTo(8, -1.2); ctx.lineTo(11, 0); ctx.lineTo(8, 1.2); ctx.closePath(); ctx.fill();
            ctx.restore();
        } else if (o.arms === 'carry') {
            // Sack auf der Wampe balanciert, beide Arme stuetzen (wippt im Takt)
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12); ctx.lineTo(4.4,-13.2); ctx.moveTo(-3,-12); ctx.lineTo(1.4,-14.6); ctx.stroke();
            ctx.fillStyle = '#C9B08A';
            ctx.beginPath(); ctx.ellipse(3, -14.6 + wob*0.3, 3, 2.2, -0.35, 0, 7); ctx.fill();
            ctx.strokeStyle = '#8A6E4E'; ctx.lineWidth = 0.5; ctx.stroke();
        } else if (o.arms === 'flag') {
            // Bote: Stab mit Wimpel in der Teamfarbe
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12); ctx.lineTo(5,-12.8); ctx.stroke();
            ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1;
            ctx.beginPath(); ctx.moveTo(5, -5.5); ctx.lineTo(5, -21); ctx.stroke();
            ctx.fillStyle = tun;
            ctx.beginPath(); ctx.moveTo(5, -21); ctx.lineTo(11.5, -19.2); ctx.lineTo(5, -17.4); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 0.5; ctx.stroke();
        } else if (nat === 'GR') {
            // GR-Basispose: eine Hand elegant erhoben, die andere pendelt
            ctx.beginPath(); ctx.moveTo(-3,-12.4); ctx.lineTo(-4.6 - step*0.25, -8.8); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(ax-0.6,-12.4); ctx.lineTo(ax+1.6,-15.4); ctx.lineTo(ax+0.8,-18.4); ctx.stroke();
        } else {
            // kurze Aermchen pendeln um den Bauch
            ctx.beginPath(); ctx.moveTo(-3,-12.4); ctx.lineTo(-4.4 - step*0.3, -8.6);
            ctx.moveTo(ax-0.6,-12.4); ctx.lineTo(ax+1.6 + step*0.3, -8.6); ctx.stroke();
        }
        ctx.restore();
    }
    function rcWarDrawBarrow(ctx, x, y, o){
        const bs = 0.75 * (RC_WAR.unitScale || 1) * 0.85;
        ctx.save(); ctx.translate(x, y); ctx.scale(bs * (o.face||1), bs);
        ctx.fillStyle = '#8A6238';
        ctx.beginPath(); ctx.moveTo(3.4,-6); ctx.lineTo(10,-6); ctx.lineTo(8.6,-1.8); ctx.lineTo(4.4,-1.8); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#5A4020'; ctx.lineWidth = 0.7; ctx.stroke();
        ctx.fillStyle = '#C9B08A';
        ctx.beginPath(); ctx.arc(5.8,-6.6,1.6,0,7); ctx.fill(); ctx.beginPath(); ctx.arc(8,-6.8,1.5,0,7); ctx.fill();
        ctx.fillStyle = '#33261A'; ctx.beginPath(); ctx.arc(8.8, -0.8, 1.9, 0, 7); ctx.fill();
        ctx.restore();
        rcWarDrawMan(ctx, x, y, { col:o.col, face:o.face, step:o.step, size:0.64, arms:null, nation: o.nation });
    }

    // Pferd mit Lanzenreiter (Premium-TV-Attacke)
    function rcWarDrawHorse(ctx, x, y, o){
        ctx.save(); ctx.translate(x, y);
        const hs = 1.3 * (RC_WAR.unitScale || 1);
        ctx.scale((o.face||1)*hs, hs);
        ctx.fillStyle = 'rgba(0,0,0,0.32)';
        ctx.beginPath(); ctx.ellipse(0, 0.8, 8.5, 2, 0, 0, 7); ctx.fill();
        const g = Math.sin(o.step||0);
        // Beine (Galopp)
        ctx.strokeStyle = '#4E3A26'; ctx.lineWidth = 1.5; ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(4.5,-5); ctx.lineTo(4.5+g*3, 0); ctx.moveTo(2.6,-5); ctx.lineTo(2.6-g*3, 0);
        ctx.moveTo(-3,-5); ctx.lineTo(-3-g*3, 0); ctx.moveTo(-4.8,-5); ctx.lineTo(-4.8+g*3, 0);
        ctx.stroke();
        // Koerper, Hals, Kopf, Ohr
        ctx.fillStyle = '#7A5A3A'; ctx.beginPath(); ctx.ellipse(0, -7.5, 7.2, 3.4, 0, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.moveTo(4.6,-9.5); ctx.quadraticCurveTo(7.5,-12, 8,-13.5); ctx.lineTo(9.6,-12.8); ctx.quadraticCurveTo(8.6,-10, 6.4,-7.6); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#6E4E2E'; ctx.beginPath(); ctx.ellipse(9.4,-13.2, 2, 1.1, -0.35, 0, 7); ctx.fill();
        ctx.fillStyle = '#4E3A26'; ctx.beginPath(); ctx.moveTo(8.6,-14.2); ctx.lineTo(9.2,-15.7); ctx.lineTo(9.9,-14.2); ctx.closePath(); ctx.fill();
        // Maehne + Schweif
        ctx.strokeStyle = '#4E3A26'; ctx.lineWidth = 1.6;
        ctx.beginPath(); ctx.moveTo(5,-10.5); ctx.quadraticCurveTo(6.8,-12.5, 7.6,-13.8); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(-7,-8.5); ctx.quadraticCurveTo(-9.5-g, -6, -9,-3.4); ctx.stroke();
        // Reiter mit Lanze + Wimpel
        ctx.strokeStyle = '#33261A'; ctx.lineWidth = 1.4;
        ctx.beginPath(); ctx.moveTo(-0.5,-9.5); ctx.lineTo(0.6,-5.6); ctx.stroke();
        ctx.fillStyle = o.col || '#9C9C9C';
        ctx.beginPath(); ctx.moveTo(-2.6,-15.5); ctx.lineTo(1.8,-15.5); ctx.lineTo(2.4,-9.8); ctx.lineTo(-3.2,-9.8); ctx.closePath(); ctx.fill();
        ctx.fillStyle = '#E8B88A'; ctx.beginPath(); ctx.arc(-0.4,-17.6, 2.3, 0, 7); ctx.fill();
        ctx.fillStyle = '#C9C9C9'; ctx.beginPath(); ctx.arc(-0.4,-18, 2.4, Math.PI*0.95, Math.PI*0.05); ctx.fill();
        const la = o.lunge ? -0.03 : -0.18;
        ctx.save(); ctx.translate(1.5,-14.5); ctx.rotate(la);
        ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1.1; ctx.beginPath(); ctx.moveTo(-3,0); ctx.lineTo(13,0); ctx.stroke();
        ctx.fillStyle = '#DCDCDC'; ctx.beginPath(); ctx.moveTo(13,-1); ctx.lineTo(15.5,0); ctx.lineTo(13,1); ctx.closePath(); ctx.fill();
        ctx.fillStyle = o.col || '#9C9C9C'; ctx.beginPath(); ctx.moveTo(6,-0.6); ctx.lineTo(10,-2.8); ctx.lineTo(10,-0.6); ctx.closePath(); ctx.fill();
        ctx.restore();
        ctx.restore();
    }

    // Holz-Katapult mit Wurfarm (o.arm: 0 = gespannt, 1 = geschleudert)
    function rcWarDrawCatapult(ctx, x, y, o){
        ctx.save(); ctx.translate(x, y);
        const cs = 1.3 * (RC_WAR.unitScale || 1);
        ctx.scale((o.face||1)*cs, cs);
        ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.beginPath(); ctx.ellipse(0, 0.8, 9, 2.2, 0, 0, 7); ctx.fill();
        for (const wx of [-5.5, 5.5]) { // Raeder mit Speichen
            ctx.fillStyle = '#4E3A26'; ctx.beginPath(); ctx.arc(wx, -2.2, 2.6, 0, 7); ctx.fill();
            ctx.strokeStyle = '#2E2216'; ctx.lineWidth = 0.8;
            ctx.beginPath(); ctx.arc(wx, -2.2, 2.6, 0, 7); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(wx-2.2,-2.2); ctx.lineTo(wx+2.2,-2.2); ctx.moveTo(wx,-4.4); ctx.lineTo(wx,0); ctx.stroke();
        }
        ctx.fillStyle = '#8A6238'; // Rahmen + Stuetzbock
        ctx.fillRect(-8, -5.5, 16, 2.6);
        ctx.beginPath(); ctx.moveTo(-4,-5.5); ctx.lineTo(0,-10.5); ctx.lineTo(4,-5.5); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#5A4020'; ctx.lineWidth = 0.7; ctx.strokeRect(-8, -5.5, 16, 2.6);
        // Wurfarm (Drehpunkt oben am Bock)
        const th0 = Math.PI - 0.25, th1 = -1.1;
        const aA = th0 + (th1 - th0) * (o.arm || 0);
        ctx.save(); ctx.translate(0, -9.5); ctx.rotate(aA);
        ctx.strokeStyle = '#6E4E2E'; ctx.lineWidth = 1.8;
        ctx.beginPath(); ctx.moveTo(-4, 0); ctx.lineTo(13, 0); ctx.stroke();
        ctx.fillStyle = '#4E3A26'; ctx.fillRect(-6, -1.8, 3, 3.6); // Gegengewicht
        ctx.strokeStyle = '#8A6238'; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(13.6, 0, 2.1, 0, 7); ctx.stroke(); // Korb
        if ((o.arm || 0) < 0.9) { ctx.fillStyle = '#9C9C9C'; ctx.beginPath(); ctx.arc(13.6, 0, 1.7, 0, 7); ctx.fill(); }
        ctx.restore();
        ctx.fillStyle = '#2E2216'; ctx.beginPath(); ctx.arc(0, -9.5, 1.3, 0, 7); ctx.fill(); // Achse
        ctx.restore();
    }

    // Grosser Versorgungskarren + schiebender Bauer (VVL)
    function rcWarDrawCart(ctx, u){
        const face = u.face || 1;
        const ks = 1.3 * (RC_WAR.unitScale || 1);
        ctx.save(); ctx.translate(u.x, u.y); ctx.scale(face*ks, ks);
        ctx.fillStyle = 'rgba(0,0,0,0.32)'; ctx.beginPath(); ctx.ellipse(5, 0.8, 9, 2, 0, 0, 7); ctx.fill();
        ctx.fillStyle = '#8A6238'; // Kasten
        ctx.beginPath(); ctx.moveTo(1,-9); ctx.lineTo(12,-9); ctx.lineTo(10.6,-3); ctx.lineTo(2.4,-3); ctx.closePath(); ctx.fill();
        ctx.strokeStyle = '#5A4020'; ctx.lineWidth = 0.8; ctx.stroke();
        ctx.fillStyle = '#C9B08A'; // Saecke
        ctx.beginPath(); ctx.arc(4.4,-9.6,2,0,7); ctx.fill();
        ctx.beginPath(); ctx.arc(7.6,-10,2.2,0,7); ctx.fill();
        ctx.beginPath(); ctx.arc(10.2,-9.4,1.7,0,7); ctx.fill();
        ctx.strokeStyle = '#8A6E4E'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.arc(7.6,-10,2.2,0,7); ctx.stroke();
        for (const wx of [4, 9.4]) { // Raeder mit drehenden Speichen
            ctx.fillStyle = '#33261A'; ctx.beginPath(); ctx.arc(wx,-2,2.4,0,7); ctx.fill();
            ctx.save(); ctx.translate(wx,-2); ctx.rotate(RC_WAR.t*4);
            ctx.strokeStyle = '#161616'; ctx.lineWidth = 0.7;
            ctx.beginPath(); ctx.moveTo(-2,0); ctx.lineTo(2,0); ctx.moveTo(0,-2); ctx.lineTo(0,2); ctx.stroke();
            ctx.restore();
        }
        ctx.restore();
        rcWarDrawMan(ctx, u.x - face*10*(RC_WAR.unitScale||1), u.y, { col: (u.src && u.src.color) || u.col, face, step: u.step, size:1.2, arms:null, nation: u.src && u.src.nation });
    }

    // Goldener Held: pulsierende Gold-Aura, rotierender Strahlenkranz und
    // eine schwebende Krone — der LIVE-KIP/MOB-Verkaeufer ist der Star der Karte
    function rcWarDrawGoldAura(ctx, x, y, sc){
        const t = RC_WAR.t;
        ctx.save(); ctx.translate(x, y);
        const R = 24 * sc, cyc = -9 * sc;
        const gr = ctx.createRadialGradient(0, cyc, 2, 0, cyc, R);
        gr.addColorStop(0, 'rgba(255,215,0,0.32)');
        gr.addColorStop(0.6, 'rgba(255,190,0,0.13)');
        gr.addColorStop(1, 'rgba(255,190,0,0)');
        ctx.fillStyle = gr;
        ctx.beginPath(); ctx.arc(0, cyc, R, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(255,215,0,0.55)'; ctx.lineWidth = 1.3;
        for (let i = 0; i < 8; i++) {
            const a = t*0.9 + i*Math.PI/4, r0 = R*0.6, r1 = r0 + 5 + Math.sin(t*5 + i)*2.2;
            ctx.beginPath();
            ctx.moveTo(Math.cos(a)*r0, cyc + Math.sin(a)*r0);
            ctx.lineTo(Math.cos(a)*r1, cyc + Math.sin(a)*r1);
            ctx.stroke();
        }
        // schwebende Krone (Zacken + Juwel), wippt sanft
        const cy = cyc - R - 2 + Math.sin(t*2.2)*2;
        const ks = Math.max(0.9, sc*0.5);
        ctx.save(); ctx.translate(0, cy); ctx.scale(ks, ks);
        ctx.fillStyle = '#FFD700'; ctx.strokeStyle = '#B8860B'; ctx.lineWidth = 0.7;
        ctx.beginPath();
        ctx.moveTo(-5, 0); ctx.lineTo(-5, -4); ctx.lineTo(-2.5, -1.8); ctx.lineTo(0, -5.4);
        ctx.lineTo(2.5, -1.8); ctx.lineTo(5, -4); ctx.lineTo(5, 0); ctx.closePath();
        ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#E2241A'; ctx.beginPath(); ctx.arc(0, -1, 0.9, 0, 7); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,' + (0.45 + 0.45*Math.sin(t*6)).toFixed(2) + ')';
        ctx.beginPath(); ctx.arc(0, -6.4, 1, 0, 7); ctx.fill();
        ctx.restore();
        ctx.restore();
    }

    function rcWarDrawUnit(ctx, u){
        if (u.t < 0) return;
        ctx.save();
        ctx.globalAlpha = (u.alpha != null ? u.alpha : 1) * (u.replay ? 0.6 : 1); // Replays dezenter (FOKUS auf Koenige)
        const tunic = (u.src && u.src.color) || u.col; // Teamfarbe der Heimat-Burg
        const gsz = u.golden ? 1.75 : 1; // Goldene Helden sind DEUTLICH groesser
        if (u.kind === 'knight') {
            if (u.def) {
                // Verteidiger in den Farben der Zielburg — kippt bei der Niederlage um
                const fallen = u.state === 'victory' ? Math.min(1, u.t/0.7) : (u.state === 'fade' ? 1 : 0);
                rcWarDrawMan(ctx, u.def.x, u.def.y, { col: u.def.col, face: (u.x >= u.def.x ? 1 : -1),
                    arms:'sword', swing: u.state === 'duel' ? -Math.sin(u.t*9 + 1.3) : 0, helmet:true, fallen, size:1.35,
                    nation: u.dst && u.dst.nation });
            }
            if (u.golden) rcWarDrawGoldAura(ctx, u.x, u.y, (RC_WAR.unitScale||1) * 1.35 * gsz);
            rcWarDrawMan(ctx, u.x, u.y, { col: tunic, face: u.face, step: u.state === 'march' ? u.step : 0,
                arms:'sword', swing: u.state === 'duel' ? (u.swing||0) : 0,
                raise: (u.state === 'victory' || u.state === 'fade') ? 1 : 0, helmet:true, size:1.35*gsz,
                nation: u.src && u.src.nation, gag: u.gag, gagT: u.gagT });
        } else if (u.kind === 'catapult') {
            rcWarDrawCatapult(ctx, u.x, u.y, { face:u.face, arm:u.arm||0 });
            const crewX = u.x - (u.face||1)*17*(RC_WAR.unitScale||1);
            if (u.golden) rcWarDrawGoldAura(ctx, crewX, u.y, (RC_WAR.unitScale||1) * 1.1 * gsz);
            rcWarDrawMan(ctx, crewX, u.y, { col:tunic, face:u.face,
                step: u.state === 'roll' ? u.step : 0, arms:null, size:1.1*gsz, nation: u.src && u.src.nation, gag: u.gag, gagT: u.gagT });
        } else if (u.kind === 'archer') {
            rcWarDrawMan(ctx, u.x, u.y, { col:tunic, face:u.face, step: u.state === 'march' ? u.step : 0,
                arms:'bow', draw: u.state === 'volley' ? (0.4 + 0.6*Math.abs(Math.sin(u.t*6))) : 0, size:1.35,
                nation: u.src && u.src.nation, gag: u.gag, gagT: u.gagT });
        } else if (u.kind === 'rider') {
            rcWarDrawHorse(ctx, u.x, u.y, { col:tunic, face:u.face, step:u.step||0, lunge: u.state === 'strike' });
        } else if (u.kind === 'spearman') {
            rcWarDrawMan(ctx, u.x, u.y, { col:tunic, face:u.face, step: u.state === 'march' ? u.step : 0,
                arms:'spear', swing: u.state === 'throw' ? Math.abs(Math.sin(u.t*5)) : 0, size:1.35,
                nation: u.src && u.src.nation, gag: u.gag, gagT: u.gagT });
        } else if (u.kind === 'cart') {
            rcWarDrawCart(ctx, u);
        } else if (u.kind === 'bote') {
            rcWarDrawMan(ctx, u.x, u.y, { col:tunic, face:u.face, step: u.state !== 'talk' ? (u.step||0) : 0, arms:'flag', size:1.05, nation: u.src && u.src.nation });
            if (u.state === 'talk') { // Sprechblase: das Kundengespraech laeuft
                const us = RC_WAR.unitScale || 1;
                const bx = u.x + (u.face||1)*10*us, by = u.y - 25*us;
                ctx.fillStyle = 'rgba(245,245,245,0.92)';
                ctx.beginPath(); ctx.ellipse(bx, by, 8, 5.2, 0, 0, 7); ctx.fill();
                ctx.beginPath(); ctx.moveTo(bx-3, by+4); ctx.lineTo(bx-7, by+8.5); ctx.lineTo(bx-0.5, by+4.6); ctx.closePath(); ctx.fill();
                ctx.fillStyle = '#161616';
                const on = Math.floor(RC_WAR.t*3) % 3;
                for (let i=0;i<3;i++){ ctx.globalAlpha = i===on ? 1 : 0.35; ctx.beginPath(); ctx.arc(bx-3.4+i*3.4, by, 1.1, 0, 7); ctx.fill(); }
                ctx.globalAlpha = u.alpha != null ? u.alpha : 1;
                // INFO-CHIP an der Zielburg: lesbare echte Zahl (12px Logikraum)
                if (u.chip && u.dst) {
                    ctx.font = rcWarFont(12, true);
                    const cw = ctx.measureText(u.chip).width + 16;
                    const cxp = u.dst.x - cw/2, cyp = u.dst.y - 62 * (RC_WAR.baseScale||1);
                    ctx.globalAlpha = 0.94;
                    ctx.fillStyle = 'rgba(20,26,36,0.92)';
                    ctx.beginPath();
                    if (ctx.roundRect) ctx.roundRect(cxp, cyp, cw, 20, 5); else ctx.rect(cxp, cyp, cw, 20);
                    ctx.fill();
                    ctx.strokeStyle = '#C9B08A'; ctx.lineWidth = 1; ctx.stroke();
                    ctx.fillStyle = '#EADFC8'; ctx.textAlign = 'center';
                    ctx.fillText(u.chip, u.dst.x, cyp + 14);
                    ctx.textAlign = 'left'; ctx.globalAlpha = u.alpha != null ? u.alpha : 1;
                }
            }
        }
        ctx.restore();
        // Hero-Tag (mitwandernd) — der Ego-Push. Goldene Helden behalten ihr
        // Namensschild immer, damit der Held-Moment sichtbar bleibt.
        if (window.rcWarHud.einheitenLabels || u.golden) rcWarDrawTag(ctx, u);
    }

    function rcWarDrawTag(ctx, u){
        // Standortname sichtbar ueber dem Charakter (User-Wunsch);
        // goldene Helden bekommen ein GROSSES goldenes Schild mit HELD-Prefix
        const std = (u.src && u.src.short) ? ' · ' + u.src.short.toUpperCase() : '';
        const showReason = u.reason && !u.replay; // Replays: nur schlanker Tag, kein Grund-Kasten (FOKUS)
        const txt = (u.golden ? 'HELD ' : '') + u.tag + ' · ' + u.hero + std;
        const us = RC_WAR.unitScale || 1;
        const fpx = Math.round(8.5 * Math.max(1, us*0.72) * (u.golden ? 1.6 : 1));
        const rpx = Math.round(fpx * 0.78);
        ctx.font = rcWarFont(fpx, true);
        // measureText-Cache je Einheit: Tag-Text ist konstant, Schluessel = Text+fpx,
        // damit sich der Cache bei unitScale-Wechsel oder Gold-Aufstieg selbst invalidiert.
        let w;
        if (u._tagKey === txt && u._tagFpx === fpx) w = u._tagW;
        else { w = ctx.measureText(txt).width + 12; u._tagKey = txt; u._tagFpx = fpx; u._tagW = w; }
        if (showReason) {
            ctx.font = rcWarFont(rpx, true);
            let rw;
            if (u._rKey === u.reason && u._rRpx === rpx) rw = u._rW;
            else { rw = ctx.measureText(u.reason).width + 12; u._rKey = u.reason; u._rRpx = rpx; u._rW = rw; }
            w = Math.max(w, rw);
        }
        const hh = fpx + 6 + (showReason ? rpx + 3 : 0);
        const lift = u.golden ? 25*us*1.75 + 16 : 25*us; // Krone nicht verdecken
        const x = u.x - w/2, y = u.y - (lift + hh + 4);
        ctx.globalAlpha = (u.alpha != null ? u.alpha : 1) * 0.94 * (u.replay ? 0.48 : 1);
        ctx.fillStyle = u.golden ? 'rgba(40,30,4,0.9)' : 'rgba(13,13,13,0.82)';
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x, y, w, hh, 6); else ctx.rect(x, y, w, hh);
        ctx.fill();
        ctx.strokeStyle = u.golden ? '#FFD700' : u.col; ctx.lineWidth = u.golden ? 2 : 1.2; ctx.stroke();
        ctx.textAlign = 'center';
        ctx.font = rcWarFont(fpx, true); ctx.fillStyle = u.golden ? '#FFD700' : '#F5F5F5';
        ctx.fillText(txt, u.x, y + fpx + 1);
        if (showReason) { // der GRUND der Mission — sichtbar (nicht bei Replays)
            ctx.font = rcWarFont(rpx, true); ctx.fillStyle = u.golden ? '#FFF3C4' : (u.col === '#9A9A9A' ? '#C9C9C9' : '#FF6666');
            ctx.fillText(u.reason, u.x, y + fpx + rpx + 4);
        }
        // REPLAY-Mini-Badge ueberm Kopf statt grossem Mitte-Banner (verdeckt nichts)
        if (u.replay) {
            const rp = Math.max(7, Math.round(fpx * 0.62));
            ctx.font = rcWarFont(rp, true);
            const rw = ctx.measureText('REPLAY').width + 8;
            ctx.globalAlpha = (u.alpha != null ? u.alpha : 1) * 0.82;
            ctx.fillStyle = 'rgba(30,30,22,0.85)';
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(u.x - rw/2, y - rp - 6, rw, rp + 4, 3); else ctx.rect(u.x - rw/2, y - rp - 6, rw, rp + 4);
            ctx.fill();
            ctx.fillStyle = '#B0A070'; ctx.textAlign = 'center';
            ctx.fillText('REPLAY', u.x, y - 4);
        }
        ctx.textAlign = 'left'; ctx.globalAlpha = 1;
    }

    function rcWarDrawFx(ctx, f){
        const p = Math.min(1, f.t / f.dur);
        if (f.kind === 'dust') {
            // Staubwolke + fliegende Erd-/Steintruemmer
            const e = 1 - Math.pow(1-p, 2.2);
            ctx.globalAlpha = 1-p;
            f.puffs.forEach(pf => {
                ctx.fillStyle = 'rgba(140,124,96,0.5)';
                ctx.beginPath(); ctx.arc(f.x+pf.dx, f.y+pf.dy - e*6, pf.r*(0.5+e), 0, 7); ctx.fill();
            });
            f.parts.forEach(pt => {
                const d = pt.sp * e;
                ctx.fillStyle = pt.col;
                ctx.fillRect(f.x + Math.cos(pt.a)*d - pt.w/2, f.y + Math.sin(pt.a)*d*0.6 - e*8 - pt.w/2, pt.w, pt.w);
            });
            ctx.globalAlpha = 1;
        } else if (f.kind === 'clang') {
            // Schwerter-Klirren: Funkenstern (skaliert mit Figurengroesse)
            const k = 1-p;
            const cs = Math.max(1, (RC_WAR.unitScale||1)*0.8);
            ctx.save(); ctx.translate(f.x, f.y); ctx.rotate(f.rot); ctx.scale(cs, cs);
            ctx.strokeStyle = 'rgba(255,240,180,' + k.toFixed(2) + ')'; ctx.lineWidth = 1.2;
            for (let i=0;i<5;i++){ const a = i*Math.PI*2/5;
                ctx.beginPath(); ctx.moveTo(Math.cos(a)*(1.5+p*2), Math.sin(a)*(1.5+p*2));
                ctx.lineTo(Math.cos(a)*(4.5+p*4), Math.sin(a)*(4.5+p*4)); ctx.stroke(); }
            ctx.fillStyle = 'rgba(255,255,255,' + (k*0.9).toFixed(2) + ')';
            ctx.beginPath(); ctx.arc(0, 0, 1.6, 0, 7); ctx.fill();
            ctx.restore();
        } else if (f.kind === 'rock') {
            // Katapult-Felsbrocken im Bogenflug, rotierend
            const q = 1-p;
            const sx = q*q*f.x + 2*q*p*f.mid.x + p*p*f.x2;
            const sy = q*q*f.y + 2*q*p*f.mid.y + p*p*f.y2;
            ctx.save(); ctx.translate(sx, sy); ctx.rotate(f.t*7);
            ctx.fillStyle = '#7E7E7E';
            const rr = 2.6 + Math.sin(Math.PI*p)*1.2;
            ctx.beginPath(); ctx.moveTo(-rr, 0.4); ctx.lineTo(-rr*0.4, -rr); ctx.lineTo(rr*0.7, -rr*0.7); ctx.lineTo(rr, 0.3); ctx.lineTo(rr*0.2, rr); ctx.closePath(); ctx.fill();
            ctx.strokeStyle = '#4E4E4E'; ctx.lineWidth = 0.7; ctx.stroke();
            ctx.restore();
        } else if (f.kind === 'arrow') {
            // Pfeil/Speer im Bogenflug — bleibt kurz im Ziel stecken und verblasst
            const fp = Math.min(1, f.t / f.flug);
            const q = 1-fp;
            const sx = q*q*f.x + 2*q*fp*f.mid.x + fp*fp*f.x2;
            const sy = q*q*f.y + 2*q*fp*f.mid.y + fp*fp*f.y2;
            const tx = 2*q*(f.mid.x-f.x) + 2*fp*(f.x2-f.mid.x);
            const ty = 2*q*(f.mid.y-f.y) + 2*fp*(f.y2-f.mid.y);
            ctx.save(); ctx.translate(sx, sy); ctx.rotate(Math.atan2(ty, tx));
            ctx.globalAlpha = fp >= 1 ? Math.max(0, 1 - (f.t - f.flug)/(f.dur - f.flug)) : 1;
            const L = f.spear ? 10 : 7;
            ctx.strokeStyle = '#C9B08A'; ctx.lineWidth = f.spear ? 1.2 : 0.9;
            ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(0, 0); ctx.stroke();
            ctx.fillStyle = '#DCDCDC';
            ctx.beginPath(); ctx.moveTo(0, -1.1); ctx.lineTo(2.4, 0); ctx.lineTo(0, 1.1); ctx.closePath(); ctx.fill();
            if (!f.spear) { // Federn
                ctx.strokeStyle = f.col || '#E60000'; ctx.lineWidth = 0.9;
                ctx.beginPath(); ctx.moveTo(-L, 0); ctx.lineTo(-L-1.6, -1.4); ctx.moveTo(-L, 0); ctx.lineTo(-L-1.6, 1.4); ctx.stroke();
            }
            ctx.globalAlpha = 1;
            ctx.restore();
        } else if (f.kind === 'flash') {
            ctx.fillStyle = 'rgba(255,255,255,' + (0.85*(1-p)).toFixed(2) + ')';
            ctx.beginPath(); ctx.arc(f.x, f.y, f.r*(0.6+p), 0, 7); ctx.fill();
        } else if (f.kind === 'smoke') {
            ctx.fillStyle = 'rgba(140,140,140,' + (0.4*(1-p)).toFixed(2) + ')';
            ctx.beginPath(); ctx.arc(f.x, f.y, f.r*(1+p*1.6), 0, 7); ctx.fill();
        } else if (f.kind === 'float') {
            ctx.font = rcWarFont(Math.round(10.5 * Math.max(1, (RC_WAR.unitScale||1)*0.8)), true); ctx.textAlign = 'center';
            ctx.globalAlpha = p < 0.15 ? p/0.15 : (1 - Math.max(0, p-0.55)/0.45);
            ctx.fillStyle = f.col;
            ctx.strokeStyle = 'rgba(13,13,13,0.85)'; ctx.lineWidth = 3; ctx.lineJoin = 'round';
            ctx.strokeText(f.txt, f.x, f.y - p*26);
            ctx.fillText(f.txt, f.x, f.y - p*26);
            ctx.globalAlpha = 1; ctx.textAlign = 'left';
        } else if (f.kind === 'spruch') {
            // lesbarer Sprech-Chip (>=12px), steigt sanft, faded am Ende aus
            const us = Math.max(1, (RC_WAR.unitScale||1)*0.85), fs = Math.round(12*us);
            ctx.font = rcWarFont(fs, true); ctx.textAlign = 'center';
            const rise = 8 + p*14;
            const a = p < 0.1 ? p/0.1 : (1 - Math.max(0, p-0.8)/0.2);
            ctx.globalAlpha = Math.max(0, a);
            const tw = ctx.measureText(f.txt).width, padX = 6*us, padY = 3.2*us;
            const bw = tw + padX*2, bh = fs + padY*2;
            const bx = f.x - bw/2, by = f.y - rise - bh;
            ctx.fillStyle = 'rgba(13,13,13,0.9)';
            ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, bw, bh, 4*us); else ctx.rect(bx, by, bw, bh); ctx.fill();
            ctx.strokeStyle = f.col; ctx.lineWidth = 1.3; ctx.lineJoin = 'round'; ctx.stroke();
            ctx.beginPath(); ctx.moveTo(f.x-3.2*us, by+bh-0.6); ctx.lineTo(f.x, by+bh+4*us); ctx.lineTo(f.x+3.2*us, by+bh-0.6); ctx.closePath();
            ctx.fillStyle = 'rgba(13,13,13,0.9)'; ctx.fill();
            ctx.fillStyle = f.col; ctx.fillText(f.txt, f.x, by + bh - padY - 1);
            ctx.globalAlpha = 1; ctx.textAlign = 'left';
        } else if (f.kind === 'kingburst') {
            const us = RC_WAR.unitScale || 1;
            const R = (f.gold ? 34 : 27) * us * (0.28 + p);
            ctx.globalAlpha = Math.max(0, 1 - p);
            const ringCol = f.gold ? '#FFD700' : '#22C7E6';
            ctx.strokeStyle = ringCol; ctx.lineWidth = (f.gold ? 2.6 : 1.9) * us * (1 - p*0.6);
            ctx.beginPath(); ctx.arc(f.x, f.y, R, 0, 7); ctx.stroke();
            ctx.strokeStyle = 'rgba(255,255,255,' + (0.55*(1-p)).toFixed(2) + ')'; ctx.lineWidth = 1*us;
            ctx.beginPath(); ctx.arc(f.x, f.y, R*0.68, 0, 7); ctx.stroke();
            const n = f.gold ? 12 : 10;
            ctx.lineWidth = 1.5*us*(1-p);
            for (let i=0;i<n;i++){
                const a = (f.seed||0) + i/n*6.283, r0 = R*0.5, r1 = R*1.18;
                ctx.strokeStyle = f.gold ? '#FFE27A' : (i%2 ? '#22C7E6' : '#FF3B9A'); // Mobilfunk bewusst bunt
                ctx.beginPath(); ctx.moveTo(f.x+Math.cos(a)*r0, f.y+Math.sin(a)*r0); ctx.lineTo(f.x+Math.cos(a)*r1, f.y+Math.sin(a)*r1); ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }
    }

    function rcWarDraw(){
        const ctx = RC_WAR.ctx; if (!ctx) return;
        // Optionaler Draw-Profiler (rcWar._prof = {n:0,ms:0}) — misst reine Zeichenzeit
        // ueber N Frames. Aus = ein einziger Branch/Frame, kein messbarer Overhead.
        const _pf0 = (RC_WAR._prof && typeof performance !== 'undefined') ? performance.now() : 0;
        rcWarResize();
        const v = RC_WAR.view;
        ctx.setTransform(1,0,0,1,0,0);
        ctx.clearRect(0, 0, RC_WAR.canvas.width, RC_WAR.canvas.height);
        const shx = (Math.random()-0.5)*RC_WAR.shake, shy = (Math.random()-0.5)*RC_WAR.shake;
        ctx.setTransform(v.dpr*v.s, 0, 0, v.dpr*v.s, v.dpr*(v.ox + shx*v.s), v.dpr*(v.oy + shy*v.s));
        // Kino-Kamera: Welt um den Fokuspunkt herum zoomen (HUD bleibt fix)
        const cam = RC_WAR.cam;
        ctx.translate(500, 320); ctx.scale(cam.z, cam.z); ctx.translate(-cam.x, -cam.y);
        // Angriffslinien: wer marschiert gerade auf wen?
        ctx.setLineDash([5,6]);
        RC_WAR.units.forEach(u => {
            if (!u.src || !u.dst || u.kind === 'bote' || u.replay) return; // Replay-Linien weg = weniger Chaos
            if (u.golden) { ctx.strokeStyle = u.cat === 'kip' ? 'rgba(255,206,0,0.5)' : 'rgba(59,214,230,0.5)'; ctx.lineWidth = 2.4; } // Koenigs-Marsch leuchtet
            else { ctx.strokeStyle = 'rgba(230,0,0,0.16)'; ctx.lineWidth = 1.3; }
            ctx.beginPath(); ctx.moveTo(u.src.x, u.src.y); ctx.lineTo(u.dst.x, u.dst.y); ctx.stroke();
        });
        ctx.setLineDash([]);
        // Einschlagskrater (Spuren des Tageskampfs)
        RC_WAR.scars.forEach(s => {
            const k = 1 - s.t/s.dur;
            ctx.fillStyle = 'rgba(0,0,0,' + (0.5*k).toFixed(2) + ')';
            ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.fill();
            if (s.t < 22) { ctx.strokeStyle = 'rgba(230,0,0,' + (0.45*(1-s.t/22)).toFixed(2) + ')'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 7); ctx.stroke(); }
        });
        // Malreihenfolge nach Bildtiefe (suedlichere Objekte verdecken noerdlichere)
        const drawList = [];
        let _wkTot = 0;
        ORDER.forEach(c => { const bb = RC_WAR.bases[c]; if (bb) { drawList.push({ t:'base', o:bb, y:bb.y }); _wkTot += (bb.workers ? bb.workers.length : 0); } });
        RC_WAR.units.forEach(u => drawList.push({ t:'unit', o:u, y:u.y }));
        // Sprite-Budget: bei sehr vielen Worker-Punkten die Schatten weglassen (weitere LOD-Stufe)
        RC_WAR._loDetail = (_wkTot + RC_WAR.units.length) > 90;
        drawList.sort((a,b) => a.y - b.y).forEach(d => {
            if (d.t === 'base') rcWarDrawBase(ctx, d.o);
            else rcWarDrawUnit(ctx, d.o);
        });
        RC_WAR.fx.forEach(f => { if (!f.delay || f.delay <= 0) rcWarDrawFx(ctx, f); });
        // ---- Ab hier HUD in festen Bildschirm-Koordinaten (Kamera-unabhaengig) ----
        ctx.setTransform(v.dpr*v.s, 0, 0, v.dpr*v.s, v.dpr*v.ox, v.dpr*v.oy);
        rcWarDrawHud(ctx);
        // LAGEBERICHT unten mittig: die aktuelle Ansage aus den echten Werten
        const briefs = window.rcWarHud.lagebericht ? rcWarBriefLines() : [];
        if (briefs.length) {
            const br = briefs[RC_WAR.briefIdx % briefs.length];
            ctx.font = rcWarFont(15, true);
            const bw = ctx.measureText('LAGEBERICHT: ' + br.t).width + 34;
            const bx = 500 - bw/2, by = 640 - 40;
            ctx.globalAlpha = 0.92;
            ctx.fillStyle = 'rgba(13,13,13,0.85)';
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(bx, by, bw, 28, 14); else ctx.rect(bx, by, bw, 28);
            ctx.fill();
            ctx.strokeStyle = br.col; ctx.lineWidth = 1.4; ctx.stroke();
            ctx.fillStyle = br.col; ctx.textAlign = 'center';
            ctx.fillText('LAGEBERICHT: ' + br.t, 500, by + 19);
            ctx.textAlign = 'left'; ctx.globalAlpha = 1;
        }
        // CHRONIK DES TAGES oben links — lesbar (12px), persistent: echte
        // Verkaeufe, Eroberungen, Freikaeufe/Comebacks, Duell-Ergebnisse.
        const chron = RC_WAR.chronik;
        if (window.rcWarHud.chronik && chron.length) {
            const rows = chron.slice(0, 7);
            const trunc = s => s.length > 48 ? s.slice(0, 47) + '...' : s;
            ctx.textAlign = 'left';
            ctx.font = rcWarFont(12);
            // measureText-Cache: Zeit+Text je Chronik-Eintrag sind konstant (12px HUD,
            // unabhaengig von unitScale) -> einmal messen, am Eintrag ablegen.
            let cw = RC_WAR._chronHdrW || (RC_WAR._chronHdrW = ctx.measureText('CHRONIK DES TAGES').width);
            rows.forEach(f => {
                if (f._chW == null) f._chW = ctx.measureText(f.time + '  ' + trunc(f.txt)).width;
                cw = Math.max(cw, f._chW);
            });
            const boxW = cw + 22, rowH = 16, boxH = 22 + rows.length*rowH + 3;
            ctx.globalAlpha = 0.86;
            ctx.fillStyle = 'rgba(13,13,13,0.82)'; ctx.fillRect(12, 74, boxW, boxH);
            ctx.strokeStyle = 'rgba(138,116,90,0.5)'; ctx.lineWidth = 1; ctx.strokeRect(12, 74, boxW, boxH);
            ctx.font = rcWarFont(11, true); ctx.fillStyle = '#C9B08A';
            ctx.fillText('CHRONIK DES TAGES', 20, 89);
            let cy = 106;
            rows.forEach(f => {
                ctx.fillStyle = f.col; ctx.fillRect(14, cy - 10, 2.5, 13);
                ctx.font = rcWarFont(12); ctx.fillStyle = '#9C9C9C';
                ctx.fillText(f.time, 21, cy);
                const tw = (f._chTimeW != null) ? f._chTimeW : (f._chTimeW = ctx.measureText(f.time + '  ').width);
                ctx.fillStyle = f.col;
                ctx.fillText(trunc(f.txt), 21 + tw, cy);
                cy += rowH;
            });
            ctx.globalAlpha = 1;
        }
        if (RC_WAR._prof && _pf0) { RC_WAR._prof.n++; RC_WAR._prof.ms += performance.now() - _pf0; }
    }

    // ---------- HUD: feste Overlays fuer die Monitor-Lesbarkeit ----------
    // Anzeigetafel (Tageswertung), Spielregeln-Legende, Kino-Banner mit
    // Letterbox-Balken und Alarm-Vignette des gefilterten Standorts.
    // ---------- KOENIGS-COUNTER: die zwei Koenigsprodukte als Stars ganz oben ----------
    // Zwei grosse Live-Fortschritts-Anzeigen (KIP-BNT gold, MOBILFUNK-BNT cyan) mit Ist/Ziel
    // + Balken. Ziel = aktive Agenten (im Scope) x rcWar.ziele. Respektiert den aktiven
    // Standort/Team/Stack-Filter automatisch, weil agentStats bereits gescopt ist.
    function rcWarKingTotals(){
        const st = window.rcLetzteStats, ag = (st && st.agentStats) || {};
        let kip = 0, mob = 0, n = 0;
        for (const k in ag){ const a = ag[k]; kip += (a.kip||0); mob += (a.mob||0); n++; }
        const z = RC_WAR.ziele || {}; const kpa = z.kipProAgent||1, mpa = z.mobProAgent||2;
        return { kip, mob, agents:n, kipZiel: Math.round(n*kpa), mobZiel: Math.round(n*mpa) };
    }
    function rcWarDrawKingGauge(ctx, gx, gy, gw, gh, o){
        const pulse = o.pulse||0, cx = gx + gw/2, cy = gy + gh/2;
        ctx.save();
        if (pulse > 0.001){ const sc = 1 + 0.09*pulse; ctx.translate(cx, cy); ctx.scale(sc, sc); ctx.translate(-cx, -cy); }
        ctx.globalAlpha = 1; ctx.fillStyle = 'rgba(11,11,11,0.92)';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(gx, gy, gw, gh, 8); else ctx.rect(gx, gy, gw, gh); ctx.fill();
        ctx.lineWidth = 2 + 2*pulse; ctx.strokeStyle = o.glow; ctx.globalAlpha = 0.55 + 0.45*pulse; ctx.stroke(); ctx.globalAlpha = 1;
        const reached = o.ziel > 0 && o.ist >= o.ziel;
        ctx.textAlign = 'left'; ctx.font = rcWarFont(14, true); ctx.fillStyle = o.col;
        ctx.fillText(o.title, gx + 12, gy + 19);
        const tw = ctx.measureText(o.title).width;
        ctx.font = rcWarFont(11, true);
        if (reached){ ctx.fillStyle = '#66DD88'; ctx.fillText('\u00b7 ZIEL ERREICHT', gx + 12 + tw + 8, gy + 19); }
        else { ctx.fillStyle = '#C9B08A'; ctx.fillText('\u00b7 NOCH ' + Math.max(0, o.ziel - o.ist) + ' BIS ZIEL', gx + 12 + tw + 8, gy + 19); }
        ctx.textAlign = 'right'; ctx.font = rcWarFont(25, true); ctx.fillStyle = o.col;
        ctx.fillText(o.ist + ' / ' + o.ziel, gx + gw - 12, gy + 24);
        const bx = gx + 12, by = gy + 33, bw = gw - 24, bh = 12;
        ctx.textAlign = 'left'; ctx.fillStyle = 'rgba(255,255,255,0.12)';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, bw, bh, 6); else ctx.rect(bx, by, bw, bh); ctx.fill();
        const frac = o.ziel > 0 ? Math.min(1, o.ist/o.ziel) : (o.ist > 0 ? 1 : 0);
        if (frac > 0){ const fw = Math.max(bh, bw*frac);
            const grad = ctx.createLinearGradient(bx, 0, bx + bw, 0); grad.addColorStop(0, o.c0); grad.addColorStop(1, o.c1);
            ctx.fillStyle = grad; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, fw, bh, 6); else ctx.rect(bx, by, fw, bh); ctx.fill();
            if (pulse > 0.001){ ctx.globalAlpha = 0.5*pulse; ctx.fillStyle = '#FFFFFF';
                ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, fw, bh, 6); else ctx.rect(bx, by, fw, bh); ctx.fill(); ctx.globalAlpha = 1; } }
        ctx.restore();
    }
    function rcWarDrawKingCounter(ctx){
        const T = rcWarKingTotals(), x = 10, y = 6, w = 980, gap = 8, h = 54, gw = (w - gap)/2;
        rcWarDrawKingGauge(ctx, x, y, gw, h, { title:'KIP-BNT HEUTE', ist:T.kip, ziel:T.kipZiel,
            col:'#FFD700', glow:'#FFCE00', c0:'#FFB000', c1:'#FFE24D', pulse: RC_WAR.kingPulse.kip });
        rcWarDrawKingGauge(ctx, x + gw + gap, y, gw, h, { title:'MOBILFUNK-BNT HEUTE', ist:T.mob, ziel:T.mobZiel,
            col:'#57D0E0', glow:'#3BD6E6', c0:'#1E9AAE', c1:'#7FE8F5', pulse: RC_WAR.kingPulse.mob });
    }

    function rcWarDrawHud(ctx){
        const bal = RC_WAR.balance;
        if (window.rcWarHud.fortschritt) rcWarDrawKingCounter(ctx);
        // === TAGESWERTUNG oben rechts: EIN Ziel = Platz 1. Rang · PUNKTE · Rueckstand ===
        // OPTION B: gewichtete Wertung (rcWar.score) ist die EINE Wahrheit. Jede Zeile
        // zeigt den Score und WIEVIEL bis zum Standort direkt darueber fehlt.
        const rank = ORDER.map(c => RC_WAR.bases[c]).filter(Boolean)
            .sort((a,b) => ((b.score||0) - (a.score||0)) || ((b.total||0) - (a.total||0)));
        if (window.rcWarHud.tageswertung && rank.length) {
            const rh = 19, sw = 300, sx = 1000 - sw - 10, sy = 74;
            ctx.globalAlpha = 0.9;
            ctx.fillStyle = 'rgba(13,13,13,0.85)'; ctx.fillRect(sx, sy, sw, rank.length*rh + 34);
            ctx.strokeStyle = 'rgba(138,116,90,0.55)'; ctx.lineWidth = 1; ctx.strokeRect(sx, sy, sw, rank.length*rh + 34);
            ctx.font = rcWarFont(13, true); ctx.fillStyle = '#C9B08A'; ctx.textAlign = 'left';
            ctx.fillText('TAGESWERTUNG', sx + 10, sy + 15);
            ctx.textAlign = 'right'; ctx.font = rcWarFont(10, true); ctx.fillStyle = '#C9B08A';
            ctx.fillText('PUNKTE', sx + sw - 92, sy + 15);
            ctx.fillText('RUECKSTAND', sx + sw - 10, sy + 15);
            rank.forEach((b, i) => {
                const yy = sy + 40 + i*rh + 11;
                const dead = !!b.conqueredBy;
                ctx.textAlign = 'left';
                ctx.font = rcWarFont(14, true);
                ctx.fillStyle = dead ? '#6E6E6E' : (i === 0 ? '#FFCE00' : '#F5F5F5');
                const crown = i === 0 ? '♦ ' : '';
                ctx.fillText(crown + (i+1) + '. ' + b.short.substring(0, 11), sx + 10, yy);
                const sc = Math.round(b.score||0);
                ctx.textAlign = 'right';
                ctx.font = rcWarFont(13, true);
                ctx.fillStyle = dead ? '#883333' : (i === 0 ? '#FFCE00' : '#DCDCDC');
                ctx.fillText(String(sc), sx + sw - 92, yy);
                // Rueckstand zum Standort GENAU EINEN RANG DARUEBER (Nordstern: noch Y bis Platz N)
                ctx.font = rcWarFont(12, true);
                if (i === 0) { ctx.fillStyle = '#FFCE00'; ctx.fillText('FUEHRT', sx + sw - 10, yy); }
                else if (dead) { ctx.fillStyle = '#5A5A5A'; ctx.fillText('-', sx + sw - 12, yy); }
                else { const gap = Math.max(0, Math.round((rank[i-1].score||0) - sc));
                    ctx.fillStyle = gap <= 20 ? '#66DD88' : '#C9A15A';
                    ctx.fillText(gap === 0 ? 'GLEICHAUF' : 'noch ' + gap, sx + sw - 10, yy); }
            });
            ctx.globalAlpha = 1; ctx.textAlign = 'left';
        }
        // === SPIELREGELN unten links: jeder soll SOFORT verstehen, was zaehlt ===
        const scw = RC_WAR.score || {};
        const legend = [
            ['KIP-BNT (Katapult)', '+' + (scw.kip||35) + ' PKT', '#FFCE00'],
            ['MOBILFUNK-BNT (Ritter)', '+' + (scw.mob||30) + ' PKT', '#57D0E0'],
            ['ANDERE BNT (Giga/TV/Env)', '+' + (scw.sonstBnt||20) + ' PKT', '#C9C9C9'],
            ['VVL GESICHERT', '+' + (scw.kipVvl||15) + ' PKT', '#9CC0A0']
        ];
        const lh = 13, lw = 250, lx0 = 12, ly0 = 640 - legend.length*lh - 63;
        if (window.rcWarHud.aufstiegsLegende) {
        ctx.globalAlpha = 0.82;
        ctx.fillStyle = 'rgba(13,13,13,0.8)'; ctx.fillRect(lx0, ly0, lw, legend.length*lh + 35);
        ctx.strokeStyle = 'rgba(138,116,90,0.5)'; ctx.lineWidth = 1; ctx.strokeRect(lx0, ly0, lw, legend.length*lh + 35);
        ctx.font = rcWarFont(8, true); ctx.fillStyle = '#C9B08A';
        ctx.fillText('SO STEIGST DU AUF — WERT JE ABSCHLUSS', lx0 + 8, ly0 + 12);
        legend.forEach((l, i) => {
            const yy = ly0 + 22 + i*lh + 7;
            ctx.font = rcWarFont(8); ctx.fillStyle = l[2]; ctx.textAlign = 'left';
            ctx.fillText(l[0], lx0 + 8, yy);
            ctx.font = rcWarFont(8, true); ctx.textAlign = 'right';
            ctx.fillText(l[1], lx0 + lw - 8, yy);
        });
        ctx.globalAlpha = 1; ctx.textAlign = 'left';
        }
        // DAUERHAFTES PERSOENLICHES TAGESZIEL JE AGENT (live aus rcWar.ziele)
        if (window.rcWarHud.tagesziel) {
        const _zL = RC_WAR.ziele || {}, _gy = ly0 + legend.length*lh + 30;
        ctx.globalAlpha = 0.95;
        ctx.fillStyle = 'rgba(255,206,0,0.10)'; ctx.fillRect(lx0 + 4, _gy - 10, lw - 8, 14);
        ctx.font = rcWarFont(9, true); ctx.fillStyle = '#FFD700'; ctx.textAlign = 'left';
        ctx.fillText('DEIN TAGESZIEL: ' + (_zL.kipProAgent||1) + ' KIP-BNT + ' + (_zL.mobProAgent||2) + ' MOBILFUNK-BNT', lx0 + 8, _gy);
        ctx.globalAlpha = 1; ctx.textAlign = 'left';
        }
        // === AUFHOLJAGD-VIGNETTE: der eigene (gefilterte) Standort jagt den Rang darueber ===
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fb = (fv && fv !== 'ALL') ? RC_WAR.bases[fv] : null;
        if (window.rcWarHud.aufholjagd && fb && fb.rank > 1 && fb.aboveCode) {
            const pulse = 0.12 + 0.07*Math.sin(RC_WAR.t*3);
            const g = ctx.createRadialGradient(500, 320, 300, 500, 320, 580);
            g.addColorStop(0, 'rgba(255,206,0,0)'); g.addColorStop(1, 'rgba(255,206,0,' + pulse.toFixed(2) + ')');
            ctx.fillStyle = g; ctx.fillRect(0, 0, 1000, 640);
            ctx.font = rcWarFont(13, true); ctx.textAlign = 'center'; ctx.fillStyle = '#FFCE00';
            ctx.fillText('AUFHOLJAGD — NOCH ' + (fb.gapAbove||0) + ' PUNKTE BIS PLATZ ' + (fb.rank-1) + ' (' + shortName(fb.aboveCode).toUpperCase() + ')!', 500, 586);
            ctx.textAlign = 'left';
        }
        // === KINO: Letterbox-Balken + grosses Event-Banner ===
        if (RC_WAR.cam.z > 1.06) {
            const k = Math.min(1, (RC_WAR.cam.z - 1.06) / 0.25);
            ctx.fillStyle = 'rgba(0,0,0,' + (0.82*k).toFixed(2) + ')';
            ctx.fillRect(0, 0, 1000, 30*k); ctx.fillRect(0, 640 - 30*k, 1000, 30*k);
        }
        if (RC_WAR.banner) {
            const bn = RC_WAR.banner;
            const a = bn.t < 0.25 ? bn.t/0.25 : (bn.dur - bn.t < 0.45 ? Math.max(0, (bn.dur - bn.t)/0.45) : 1);
            const sizes = [15, 21, 24], cols = ['#F5F5F5', bn.col, '#FF4444'];
            ctx.globalAlpha = a;
            ctx.font = rcWarFont(21, true);
            const wMax = Math.max(...bn.lines.map((t, i) => { ctx.font = rcWarFont(sizes[i] || 14, true); return ctx.measureText(t).width; })) + 56;
            const bh = 18 + bn.lines.length * 27;
            const bx = 500 - wMax/2, by = 106;
            ctx.fillStyle = 'rgba(13,13,13,0.88)';
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(bx, by, wMax, bh, 6); else ctx.rect(bx, by, wMax, bh);
            ctx.fill();
            ctx.strokeStyle = bn.col; ctx.lineWidth = 2; ctx.stroke();
            ctx.textAlign = 'center';
            bn.lines.forEach((t, i) => {
                ctx.font = rcWarFont(sizes[i] || 14, true);
                ctx.fillStyle = cols[i] || '#F5F5F5';
                ctx.fillText(t, 500, by + 24 + i*27);
            });
            ctx.textAlign = 'left'; ctx.globalAlpha = 1;
        }
        // === STUNDEN-DUELL: grosses Countdown-HUD oben Mitte (>=20px) ===
        if (window.rcWarHud.stundenDuell) {
        const duel = RC_WAR.duel;
        if (duel && duel.active) {
            const remMs = Math.max(0, duel.endAt - Date.now());
            const clock = pad2(Math.floor(remMs/60000)) + ':' + pad2(Math.floor((remMs%60000)/1000));
            const aN = shortName(duel.a).toUpperCase(), bN = shortName(duel.b).toUpperCase();
            const title = 'STUNDEN-KOENIGSJAGD   ' + aN + ' vs ' + bN + '   ' + clock;
            const subT = 'WER HOLT DIE MEISTEN KIP + MOBILFUNK?';
            const scoreTxt = aN + '  ' + duel.scoreA + ' : ' + duel.scoreB + '  ' + bN;
            ctx.textAlign = 'center';
            ctx.font = rcWarFont(23, true); const tw = ctx.measureText(title).width;
            ctx.font = rcWarFont(20, true); const sw = ctx.measureText(scoreTxt).width;
            const boxW = Math.max(tw, sw) + 46, boxH = 74, bx = 500 - boxW/2, by = 72;
            ctx.globalAlpha = 0.97;
            ctx.fillStyle = 'rgba(22,17,3,0.93)';
            ctx.beginPath();
            if (ctx.roundRect) ctx.roundRect(bx, by, boxW, boxH, 8); else ctx.rect(bx, by, boxW, boxH);
            ctx.fill();
            ctx.strokeStyle = 'rgba(255,215,0,' + (0.55 + 0.45*Math.sin(RC_WAR.t*4)).toFixed(2) + ')';
            ctx.lineWidth = 2.5; ctx.stroke();
            ctx.font = rcWarFont(22, true); ctx.fillStyle = '#FFD700';
            ctx.fillText(title, 500, by + 24);
            ctx.font = rcWarFont(10, true); ctx.fillStyle = '#C9A15A';
            ctx.fillText(subT, 500, by + 39);
            ctx.font = rcWarFont(21, true); ctx.fillStyle = '#F5F5F5';
            ctx.fillText(scoreTxt, 500, by + 62);
            const lastTxt = [duel.lastA ? aN + ': ' + duel.lastA : '', duel.lastB ? bN + ': ' + duel.lastB : ''].filter(Boolean).join('   ');
            if (lastTxt) { ctx.font = rcWarFont(11, true); ctx.fillStyle = '#C9B08A'; ctx.fillText('LETZTER KOENIGS-TREFFER — ' + lastTxt, 500, by + boxH + 13); }
            ctx.textAlign = 'left'; ctx.globalAlpha = 1;
        } else {
            // Kleiner Countdown zur naechsten vollen Stunde (immer sichtbar)
            const rem = 60 - new Date().getMinutes();
            ctx.textAlign = 'center';
            ctx.font = rcWarFont(11, true); ctx.globalAlpha = 0.82; ctx.fillStyle = '#C9B08A';
            ctx.fillText('NAECHSTE STUNDEN-KOENIGSJAGD IN ' + rem + ' MIN', 500, 84);
            ctx.textAlign = 'left'; ctx.globalAlpha = 1;
        }
        }
    }

    function rcWarLoop(ts){
        if (!RC_WAR.active) { window.rcWarRaf = null; return; }
        const dt = Math.min(0.05, RC_WAR.lastT ? (ts - RC_WAR.lastT)/1000 : 0.016);
        RC_WAR.lastT = ts;
        // Sales-League-Modus uebernimmt Update+Draw komplett; Burg bleibt unveraendert
        if (window.rcRadarMode === 'league' && window.rcLeagueTick) window.rcLeagueTick(dt);
        else { rcWarUpdate(dt); rcWarDraw(); }
        window.rcWarRaf = requestAnimationFrame(rcWarLoop);
    }

    function rcWarEnsureCanvas(){
        const wrap = document.getElementById('rcRadarSvgWrap');
        if (!wrap || !wrap.querySelector('svg')) return false;
        if (!RC_WAR.canvas || !wrap.contains(RC_WAR.canvas)) {
            const c = document.createElement('canvas');
            c.id = 'rcWarCanvas';
            wrap.appendChild(c);
            RC_WAR.canvas = c; RC_WAR.ctx = c.getContext('2d');
            RC_WAR.view = { s:1, ox:0, oy:0, w:0, h:0, dpr:1 };
            // SVG-Blips ausblenden — die Canvas-Basen uebernehmen Zaehler + Alarm
            ORDER.forEach(code => { const g = document.getElementById('rcBlipG_' + code); if (g) g.style.display = 'none'; });
        }
        return true;
    }

    window.rcWarSetActive = function(on){
        RC_WAR.active = !!on;
        if (on) {
            rcWarEnsureBases();
            if (!rcWarEnsureCanvas()) { RC_WAR.active = false; return; }
            if (window.rcLetzteStats && window.rcWarSync) window.rcWarSync(window.rcLetzteStats.standortStats);
            // Sofort-Show beim Einblenden: 3 Replay-Einsaetze im Schnellstart
            RC_WAR.burst = 3; RC_WAR.rT = Math.min(RC_WAR.rT, 0.5); RC_WAR.bT = Math.min(RC_WAR.bT, 2);
            if (!window.rcWarRaf) { RC_WAR.lastT = 0; window.rcWarRaf = requestAnimationFrame(rcWarLoop); }
        }
    };

    // Debug/Test: einen Simulationsschritt manuell ausfuehren (RAF-unabhaengig,
    // z.B. in verborgenen Tabs, wo requestAnimationFrame nicht feuert)
    window.rcWarStep = function(dt){
        if (window.rcRadarMode === 'league' && window.rcLeagueTick) { window.rcLeagueTick(dt || 0.033); return; }
        rcWarUpdate(dt || 0.033); rcWarDraw();
    };

    // HUD-Toggles anwenden: DOM-Overlays schalten + Canvas neu zeichnen.
    // Canvas-Flags werden zur Zeichenzeit gelesen -> hier genuegt ein Redraw.
    window.rcWarHudApply = function(){
        const h = window.rcWarHud || (window.rcWarHud = Object.assign({}, window.rcWarHudDefaults));
        try { localStorage.setItem('rcWarHud', JSON.stringify(h)); } catch(e){}
        const hero = document.getElementById('rcHeroCall');
        if (hero) {
            hero.style.display = h.heroRuf ? '' : 'none';
            hero.classList.toggle('rc-hero-kompakt', !!h.heroKompakt);
            if (!h.heroRuf) hero.innerHTML = '';
        }
        if (RC_WAR.active && RC_WAR.ctx && window.rcRadarMode !== 'league') { try { rcWarDraw(); } catch(e){} }
    };

    // Vorfuehrmodus: einmal alle Einheitentypen zeigen (Konsole: rcWarDemo())
    window.rcWarDemo = function(){
        const demo = [
            ['AL','Yilmaz Oezlem','Mobilfunk BNT', true],
            ['B','Krause Deniz','KIP BNT', true],
            ['SER','Papadopoulos Eleni','DSL Glasfaser BNT', true],
            ['P','Weber Jonas','Premium TV BNT', true],
            ['SKA','Demir Baran','KIP VVL', false],
            ['E','Schmidt Lena','ENV BNT', true]
        ];
        demo.forEach((d, i) => setTimeout(() => window.rcWarSpawn(d[0], d[1], d[2], d[3]), i*1400));
        rcWarAddFeed('VORFUEHRMODUS GESTARTET', '#9C9C9C');
    };

    // Nationen-Schaufenster (Konsole: rcWarPreviewNations([step])) — friert das
    // Radar ein und stellt die vier Kriegertypen gross nebeneinander zur
    // Sicht-Kontrolle (TR-Maschine · GR-Evzone · DE-Teutone · AT-Spargel).
    window.rcWarPreviewNations = function(stepPhase){
        const ctx = RC_WAR.ctx; if (!ctx) { console.warn('rcWarPreviewNations: kein Canvas'); return; }
        if (window.rcWarRaf) { try { cancelAnimationFrame(window.rcWarRaf); } catch(e){} window.rcWarRaf = null; }
        rcWarResize();
        const v = RC_WAR.view, ph = stepPhase != null ? stepPhase : 1.1;
        const usPrev = RC_WAR.unitScale; RC_WAR.unitScale = 3.4;
        ctx.setTransform(1,0,0,1,0,0);
        ctx.clearRect(0,0,RC_WAR.canvas.width,RC_WAR.canvas.height);
        ctx.setTransform(v.dpr*v.s, 0, 0, v.dpr*v.s, v.dpr*v.ox, v.dpr*v.oy);
        ctx.fillStyle = '#0E0F12'; ctx.fillRect(0,0,1000,640);
        const cases = [
            ['TR','ALANYA · YENICERI-MASCHINE','#E60000',180],
            ['GR','SERRES · EVZONE-GARDE','#FFFFFF',400],
            ['DE','BERLIN · KARTOFFEL-KRIEGER','#FF6666',620],
            ['AT','ZEITWERT · SPARGEL-RITTER','#8C8C8C',840]
        ];
        cases.forEach(c => {
            const nat=c[0], col=c[2], cx=c[3];
            ctx.strokeStyle='rgba(255,255,255,0.06)'; ctx.lineWidth=1; ctx.beginPath(); ctx.moveTo(cx,120); ctx.lineTo(cx,470); ctx.stroke();
            rcWarDrawMan(ctx, cx, 400, { col, face:1, step:ph, arms:'sword', helmet:true, size:1.35, nation:nat });
            ctx.fillStyle=col; ctx.font='bold 15px system-ui,sans-serif'; ctx.textAlign='center';
            ctx.fillText(nat, cx, 150);
            ctx.fillStyle='#DCDCDC'; ctx.font='11px system-ui,sans-serif';
            ctx.fillText(c[1], cx, 168);
        });
        ctx.textAlign='left';
        RC_WAR.unitScale = usPrev;
        return 'Vorschau gezeichnet — Radar neu laden/wechseln zum Fortsetzen';
    };

    // ============================================================
    //  REGIOCOM SALES LEAGUE — Fussball-Broadcast-Modus des Radars
    //  (umschaltbar; der Burg-Modus bleibt vollstaendig erhalten).
    //  Prinzipien (SALES_LEAGUE_PLAN.md):
    //   - Ehrliche Anzeigetafel: jede Tor-Szene = echter ESL-Eintrag
    //   - Glueck NUR als Elfmeter (jede 5. Team-Ansprache), Seed-RNG
    //     aus Datum+Team+Nr -> alle Monitore wuerfeln identisch
    //   - K.-o.-Woche: wer am Tagesende 0 Tore hat (oder die wenigsten,
    //     falls alle getroffen haben), scheidet aus; Rebuild aus
    //     rcEslHistory -> Citrix-Wipe egal
    //   - Trikot = Landesflagge des Standorts, Name UEBER dem Trikot
    //  Alles Vektor-Canvas im 1000x640-Raum, keine Emojis, kein CDN.
    // ============================================================
    const RC_LG = {
        scene:null, queue:[], feed:[], tickerX:1010,
        lastA:null, lastP:null, penDone:{}, penGoals:{}, seen:{},
        weekCache:null, weekAt:0, statsAt:0,
        netRip:0, shake:0, confetti:[], crowd:null, excite:0,
        t:0, rT:4, rIdx:0,
        cam:{ s:1, x:350, y:330, ts:1, tx:350, ty:330 },
        amb:{ players:[], ballAt:0, ballT:0, built:'' },
        st:{ stdRows:[], agents:[], teams:{}, totalTore:0, totalParaden:0 },
        forceEvening:null, cfg:{ elfProAnsp:5, flutlichtAb:16, queueMax:7, replayEvery:10 }
    };
    window.rcLeague = RC_LG;
    window.rcRadarMode = (function(){ try { return localStorage.getItem('rcRadarMode') || 'burg'; } catch(e){ return 'burg'; } })();
    window.rcSetRadarMode = function(m){
        window.rcRadarMode = (m === 'burg') ? 'burg' : 'league';
        try { localStorage.setItem('rcRadarMode', window.rcRadarMode); } catch(e){}
        const btn = document.getElementById('rcRadarModeBtn');
        if (btn) btn.textContent = window.rcRadarMode === 'league' ? 'Klassik (Burg)' : 'Sales League';
        const ttl = document.getElementById('rcRadarMainTitle');
        if (ttl) ttl.textContent = window.rcRadarMode === 'league' ? 'Regiocom Sales League — Live-Uebertragung' : 'Burgeroberung — Schlacht um Europa';
        RC_LG.scene = null; RC_LG.cam = { s:1, x:350, y:330, ts:1, tx:350, ty:330 };
    };

    // ---------- Seed-RNG: gleiche Daten = gleiches Wuerfelergebnis ----------
    function rcLgHash(s){ let h = 2166136261; s = String(s); for (let i=0;i<s.length;i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
    function rcLgRng(seed){ let a = seed >>> 0; return function(){ a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
    const rcLgDayKey = d => { const p = n => String(n).padStart(2,'0'); return d.getFullYear()+'-'+p(d.getMonth()+1)+'-'+p(d.getDate()); };

    // ---------- Spielfeld-Projektion (3/4-Perspektive, Tor oben/fern) ----------
    const RC_LG_ST = { cx:350, yFar:168, yNear:566, farHalf:158, nearHalf:322 };
    function rcLgP(u, v){ // u -1..1 (links..rechts) · v 0 (nah) .. 1 (fern/Tor)
        const t = 1 - Math.pow(1 - v, 1.30);
        const half = RC_LG_ST.nearHalf + (RC_LG_ST.farHalf - RC_LG_ST.nearHalf) * t;
        return { x: RC_LG_ST.cx + u * half, y: RC_LG_ST.yNear + (RC_LG_ST.yFar - RC_LG_ST.yNear) * t, sc: 1 - 0.60 * t };
    }
    const rcLgEase = p => 1 - Math.pow(1 - p, 3);
    const rcLgS = sc => sc*1.5 + 0.35; // Spieler-Groesse aus Tiefenskala (Monitor-Lesbarkeit)

    // ---------- Flagge in beliebiges Rechteck malen (Trikots, Chips) ----------
    function rcLgFlag(ctx, nation, x, y, w, h, r){
        ctx.save();
        ctx.beginPath();
        if (ctx.roundRect) ctx.roundRect(x, y, w, h, r || 1.5); else ctx.rect(x, y, w, h);
        ctx.clip();
        ctx.translate(x, y); ctx.scale(w/12, h/8);
        (RC_FLAGS[nation] || (c => { c.fillStyle = '#8C8C8C'; c.fillRect(0,0,12,8); }))(ctx);
        ctx.restore();
    }
    const rcLgNation = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].nation) || 'DE';
    const rcLgShort = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].short) || code;

    // ---------- Fussballer-Rig: Flaggen-Trikot, Posen, Tiefenskalierung ----------
    // o: { s, face, pose:'run|stand|kick|volley|dive|jubel|keeper', ph, pw, col, nation, skin, rot }
    function rcLgMan(ctx, x, y, o){
        const s = o.s || 1, face = o.face || 1;
        const skin = o.skin || '#E8C39E';
        const pose = o.pose || 'stand', ph = o.ph || 0, pw = Math.max(0, Math.min(1, o.pw == null ? 0 : o.pw));
        ctx.save(); ctx.translate(x, y);
        // Schatten am Boden (vor der Rotation)
        ctx.fillStyle = 'rgba(6,18,10,0.32)';
        ctx.beginPath(); ctx.ellipse(0, 1.5*s, 10*s, 3.1*s, 0, 0, 7); ctx.fill();
        if (o.rot) ctx.rotate(o.rot);
        ctx.scale(s*face, s);
        // Beinstellung je Pose
        let lA = 0, lB = 0, aA = -0.5, aB = 0.5, lean = 0, hop = 0;
        if (pose === 'run')    { lA = Math.sin(ph)*0.85; lB = -Math.sin(ph)*0.85; aA = -Math.sin(ph)*0.8 - 0.2; aB = Math.sin(ph)*0.8 + 0.2; lean = 0.10; hop = Math.abs(Math.sin(ph*2))*0.8; }
        if (pose === 'kick')   { lA = -0.55 + pw*1.95; lB = -0.18; aA = -1.15; aB = 0.9; lean = -0.16; }
        if (pose === 'volley') { lA = 1.5 - pw*2.4; lB = -1.2 + pw*1.6; aA = -2.1; aB = 2.1; }
        if (pose === 'dive')   { lA = 0.45; lB = -0.25; aA = -2.6; aB = -2.9; }
        if (pose === 'jubel')  { lA = 0.22; lB = -0.22; aA = -2.6; aB = 2.6; hop = Math.abs(Math.sin(ph*7))*2.2; }
        if (pose === 'keeper') { lA = 0.34; lB = -0.34; aA = -0.9; aB = 0.9; }
        ctx.translate(0, -hop);
        ctx.rotate(lean);
        const hipY = -12.5, shY = -22.5, legL = 12.5;
        // Beine: Oberschenkel (weisse Hose) + Wade (Stutzen) + Schuh
        const leg = (ang, dx) => {
            const kx = dx + Math.sin(ang)*legL*0.5, ky = hipY + Math.cos(ang)*legL*0.5;
            const fx = dx + Math.sin(ang)*legL,     fy = hipY + Math.cos(ang)*legL;
            ctx.strokeStyle = '#F2F2F2'; ctx.lineWidth = 3.4; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(dx, hipY); ctx.lineTo(kx, ky); ctx.stroke();
            ctx.strokeStyle = o.sock || '#1F2D3D'; ctx.lineWidth = 2.9;
            ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
            ctx.fillStyle = '#141414';
            ctx.beginPath(); ctx.ellipse(fx + 1.2, fy, 2.4, 1.3, 0, 0, 7); ctx.fill();
        };
        leg(lB, -1.6); // hinteres Bein zuerst (Tiefe)
        // Torso: Landesflagge als Trikot + dezente Schattierung
        rcLgFlag(ctx, o.nation, -5.2, shY, 10.4, 10.4, 3);
        ctx.fillStyle = 'rgba(0,0,0,0.16)'; ctx.fillRect(1.2, shY, 4.0, 10.4);
        ctx.strokeStyle = 'rgba(10,10,10,0.55)'; ctx.lineWidth = 0.8;
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(-5.2, shY, 10.4, 10.4, 3); else ctx.rect(-5.2, shY, 10.4, 10.4); ctx.stroke();
        // Arme (Aermel = Flaggen-Grundton via halbtransparentem Weiss)
        const arm = (ang, dx) => {
            ctx.strokeStyle = skin; ctx.lineWidth = 2.5; ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(dx, shY + 2);
            ctx.lineTo(dx + Math.sin(ang)*8.5, shY + 2 + Math.cos(ang)*8.5); ctx.stroke();
        };
        arm(aB, 2.6); leg(lA, 1.6); arm(aA, -2.6);
        // Kopf + Haar
        ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(0, shY - 4.6, 4.4, 0, 7); ctx.fill();
        ctx.fillStyle = o.hair || '#2A2118';
        ctx.beginPath(); ctx.arc(0, shY - 5.6, 4.4, Math.PI*1.05, Math.PI*1.95); ctx.fill();
        ctx.restore();
    }

    // TV-Namensschild UEBER dem Spieler (User-Regel: Name ueber dem Trikot)
    function rcLgTag(ctx, x, y, name, nation, hot){
        if (!name) return;
        const fs = hot ? 11.5 : 10;
        ctx.font = rcWarFont(fs, true);
        const w = ctx.measureText(name).width + 24;
        const h = fs + 7;
        const bx = x - w/2, by = y - h;
        ctx.globalAlpha = 0.96;
        ctx.fillStyle = 'rgba(10,16,24,0.88)';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(bx, by, w, h, 3); else ctx.rect(bx, by, w, h); ctx.fill();
        ctx.strokeStyle = hot ? '#E60000' : 'rgba(255,255,255,0.28)'; ctx.lineWidth = 1; ctx.stroke();
        rcLgFlag(ctx, nation, bx + 4, by + h/2 - 3.2, 9.6, 6.4, 1);
        ctx.fillStyle = '#F5F5F5'; ctx.textAlign = 'left';
        ctx.fillText(name, bx + 17, by + fs + 1.5);
        ctx.globalAlpha = 1;
    }

    function rcLgBall(ctx, x, y, r, rot){
        ctx.save(); ctx.translate(x, y); ctx.rotate(rot || 0);
        ctx.fillStyle = '#F8F8F8'; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill();
        ctx.strokeStyle = '#B9B9B9'; ctx.lineWidth = 0.7; ctx.stroke();
        ctx.fillStyle = '#20242A';
        ctx.beginPath(); ctx.moveTo(0, -r*0.42);
        for (let i=1;i<5;i++) ctx.lineTo(Math.sin(i*1.257)*r*0.42, -Math.cos(i*1.257)*r*0.42);
        ctx.closePath(); ctx.fill();
        ctx.restore();
    }

    // ---------- Tageslicht: Vormittag hell, Nachmittag warm, ab 16 Uhr Flutlicht ----------
    function rcLgPhase(){
        const h = (RC_LG.forceEvening != null) ? (RC_LG.forceEvening ? 18 : 10) : new Date().getHours();
        if (h >= RC_LG.cfg.flutlichtAb || h < 7) return 'nacht';
        if (h >= 13) return 'warm';
        return 'tag';
    }

    function rcLgCrowd(){
        if (RC_LG.crowd) return RC_LG.crowd;
        const rng = rcLgRng(20260716), dots = [];
        const cols = ['#E60000','#2C57D2','#FF4C02','#DCDCDC','#9C9C9C','#F5E9C8','#009864'];
        for (let i=0;i<7;i++){ // Tribuenen-Reihen hinter dem Tor
            const v = i/6;
            const y = 62 + i*13.5;
            const half = 300 - v*40;
            const n = Math.round(half/4.6);
            for (let k=0;k<=n;k++){
                dots.push({ x: RC_LG_ST.cx - half + (2*half)*k/n + (rng()-0.5)*3, y: y + (rng()-0.5)*4,
                    c: cols[Math.floor(rng()*cols.length)], p: rng()*6.283, r: 1.5 + rng()*0.9 });
            }
        }
        RC_LG.crowd = dots; return dots;
    }

    // ---------- Stadion (jeden Frame; Kamera-Transform liegt schon an) ----------
    function rcLgStadium(ctx){
        const ph = rcLgPhase(), night = ph === 'nacht';
        // Himmel / Halle
        const sky = ctx.createLinearGradient(0, 40, 0, 240);
        if (night) { sky.addColorStop(0, '#060D16'); sky.addColorStop(1, '#0E1E30'); }
        else if (ph === 'warm') { sky.addColorStop(0, '#D8A96A'); sky.addColorStop(1, '#E8CFA4'); }
        else { sky.addColorStop(0, '#7FA8CB'); sky.addColorStop(1, '#B9D2E6'); }
        ctx.fillStyle = sky; ctx.fillRect(-40, 30, 780, 220);
        // Tribuene (Bogen) + Menge
        ctx.fillStyle = night ? '#101B28' : '#25313F';
        ctx.beginPath(); ctx.moveTo(6, 172); ctx.quadraticCurveTo(RC_LG_ST.cx, 24, 694, 172);
        ctx.lineTo(694, 60); ctx.quadraticCurveTo(RC_LG_ST.cx, -34, 6, 60); ctx.closePath(); ctx.fill();
        ctx.fillStyle = night ? '#0A1420' : '#1C2733';
        ctx.fillRect(6, 52, 688, 8);
        const dots = rcLgCrowd(), ex = RC_LG.excite;
        dots.forEach(d => {
            const jump = ex > 0.05 ? Math.abs(Math.sin(RC_LG.t*9 + d.p)) * 3.2 * ex : Math.sin(RC_LG.t*1.1 + d.p) * 0.5;
            ctx.fillStyle = d.c; ctx.globalAlpha = night ? 0.85 : 0.75;
            ctx.fillRect(d.x, d.y - jump, d.r, d.r*1.35);
        });
        ctx.globalAlpha = 1;
        // Flutlicht-Masten + Lichtkegel
        const mast = (mx) => {
            ctx.strokeStyle = night ? '#3A4A5E' : '#5A6878'; ctx.lineWidth = 3;
            ctx.beginPath(); ctx.moveTo(mx, 138); ctx.lineTo(mx, 44); ctx.stroke();
            ctx.fillStyle = night ? '#FFF3CE' : '#C9D3DC';
            for (let i=0;i<3;i++) for (let j=0;j<2;j++) ctx.fillRect(mx - 10 + i*7, 34 + j*6, 5, 4);
            if (night) {
                const lg = ctx.createLinearGradient(mx, 40, RC_LG_ST.cx, 430);
                lg.addColorStop(0, 'rgba(255,240,190,0.16)'); lg.addColorStop(1, 'rgba(255,240,190,0)');
                ctx.fillStyle = lg;
                ctx.beginPath(); ctx.moveTo(mx - 10, 42); ctx.lineTo(mx + 10, 42);
                ctx.lineTo(RC_LG_ST.cx + (mx < RC_LG_ST.cx ? 190 : -190), 430);
                ctx.lineTo(RC_LG_ST.cx + (mx < RC_LG_ST.cx ? -60 : 60), 430); ctx.closePath(); ctx.fill();
            }
        };
        mast(52); mast(648);
        // Rasen mit Maehstreifen (Perspektiv-Baender)
        for (let i=0;i<9;i++){
            const v0 = i/9, v1 = (i+1)/9;
            const a = rcLgP(-1.06, v0), b = rcLgP(1.06, v0), c = rcLgP(1.06, v1), d = rcLgP(-1.06, v1);
            ctx.fillStyle = (i % 2) ? (night ? '#17693F' : '#2A8A52') : (night ? '#125C36' : '#238049');
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.lineTo(c.x, c.y); ctx.lineTo(d.x, d.y); ctx.closePath(); ctx.fill();
        }
        // Banden entlang der Fernlinie + Seiten
        const bl = rcLgP(-1.1, 1), br = rcLgP(1.1, 1);
        ctx.fillStyle = '#101820'; ctx.fillRect(bl.x, bl.y - 24, br.x - bl.x, 12);
        ctx.font = rcWarFont(8, true); ctx.textAlign = 'center';
        const ads = ['REGIOCOM', 'SALES LEAGUE', 'ESL LIVE-ARENA', 'REGIOCOM', 'SALES LEAGUE'];
        ads.forEach((txt, i) => {
            const seg = (br.x - bl.x)/ads.length, sx = bl.x + seg*i;
            ctx.fillStyle = i % 2 ? '#E60000' : '#16202C'; ctx.fillRect(sx + 1, bl.y - 23, seg - 2, 10);
            ctx.fillStyle = i % 2 ? '#FFFFFF' : '#8FA3B8'; ctx.fillText(txt, sx + seg/2, bl.y - 15.5);
        });
        ctx.textAlign = 'left';
        // Linien
        ctx.strokeStyle = 'rgba(245,250,245,0.88)'; ctx.lineWidth = 1.6;
        const seg = (uA,vA,uB,vB) => { const p1 = rcLgP(uA,vA), p2 = rcLgP(uB,vB); ctx.beginPath(); ctx.moveTo(p1.x,p1.y); ctx.lineTo(p2.x,p2.y); ctx.stroke(); };
        seg(-1,0.01,1,0.01); seg(-1,1,-1,0.01); seg(1,1,1,0.01); seg(-1,1,1,1);
        seg(-1,0.5,1,0.5); // Mittellinie
        const cc = rcLgP(0, 0.5);
        ctx.beginPath(); ctx.ellipse(cc.x, cc.y, 62*cc.sc + 18, 20*cc.sc + 6, 0, 0, 7); ctx.stroke();
        // Strafraum + Fuenfer + Punkt (am fernen Tor)
        seg(-0.52,1,-0.52,0.78); seg(0.52,1,0.52,0.78); seg(-0.52,0.78,0.52,0.78);
        seg(-0.24,1,-0.24,0.90); seg(0.24,1,0.24,0.90); seg(-0.24,0.90,0.24,0.90);
        const pp = rcLgP(0, 0.845);
        ctx.fillStyle = 'rgba(245,250,245,0.9)'; ctx.beginPath(); ctx.arc(pp.x, pp.y, 1.6, 0, 7); ctx.fill();
        ctx.beginPath(); ctx.ellipse(pp.x, rcLgP(0,0.78).y + 4, 26, 7, 0, 0.15*Math.PI, 0.85*Math.PI); ctx.stroke();
        // Tor + Netz (mit Einschlags-Welle)
        rcLgGoal(ctx);
    }

    function rcLgGoal(ctx){
        const gl = rcLgP(-0.20, 1), gr = rcLgP(0.20, 1);
        const gh = 40, gy = gl.y - gh;
        const rip = RC_LG.netRip;
        ctx.strokeStyle = 'rgba(220,228,236,0.75)'; ctx.lineWidth = 0.55;
        for (let i=0;i<=10;i++){ // vertikale Netzfaeden mit Welle
            const x = gl.x + (gr.x - gl.x)*i/10;
            const bow = Math.sin(RC_LG.t*14 + i) * rip * 3.2;
            ctx.beginPath(); ctx.moveTo(x, gy + 2);
            ctx.quadraticCurveTo(x + bow + 3, gy + gh*0.55, x + bow*0.4, gl.y);
            ctx.stroke();
        }
        for (let j=1;j<6;j++){
            const y = gy + gh*j/6;
            ctx.beginPath(); ctx.moveTo(gl.x, y + Math.sin(RC_LG.t*14)*rip*2);
            ctx.lineTo(gr.x, y + Math.sin(RC_LG.t*14 + 2)*rip*2); ctx.stroke();
        }
        ctx.strokeStyle = '#F8FAFC'; ctx.lineWidth = 3; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(gl.x, gl.y); ctx.lineTo(gl.x, gy); ctx.lineTo(gr.x, gy); ctx.lineTo(gr.x, gr.y); ctx.stroke();
    }

    // ---------- Statistiken aus den ECHTEN Zaehlern ziehen ----------
    function rcLgAgentGoals(a){
        const traum = (a.kip||0) + (a.mob||0);
        const rest = (a.env||0) + (a.fibDsl||0) + (a.ptv||0) + (a.sonstBnt||0);
        return { traum, rest, tore: traum*2 + rest, paraden: (a.kipVvl||0) + (a.mobVvl||0) + (a.fibVvl||0) };
    }
    window.rcLeagueSync = function(){
        const S = window.rcLetzteStats; if (!S) return;
        const agents = [];
        Object.values(S.agentStats || {}).forEach(a => {
            const g = rcLgAgentGoals(a);
            agents.push({ vo:a.vo, name:a.name, code:a.standort, nation: rcLgNation(a.standort),
                team:a.team, tore:g.tore, traum:g.traum, paraden:g.paraden, ansp:a.ansprachen||0 });
        });
        agents.sort((x,y) => (y.tore - x.tore) || (y.ansp - x.ansp));
        const stdRows = [];
        let totalTore = 0, totalParaden = 0;
        Object.keys(S.standortStats || {}).forEach(code => {
            const g = rcLgAgentGoals(S.standortStats[code]);
            const pen = RC_LG.penGoals[code] || 0;
            totalTore += g.tore + pen; totalParaden += g.paraden;
            stdRows.push({ code, short: rcLgShort(code), nation: rcLgNation(code), tore: g.tore + pen, traum: g.traum, paraden: g.paraden });
        });
        stdRows.sort((x,y) => y.tore - x.tore);
        RC_LG.st = { stdRows, agents, teams: S.teamStats || {}, totalTore, totalParaden };
        // ---- Deltas -> Szenen (Erstlauf nur Baseline, kein Rueckstau-Feuerwerk) ----
        const base = RC_LG.lastA == null;
        const A = {}, seen = RC_LG.seen;
        agents.forEach(a => { A[a.vo] = a.ansp; });
        if (!base) {
            let chances = 0, arrivals = 0;
            agents.forEach(a => {
                if (!seen[a.vo]) { seen[a.vo] = true;
                    if (arrivals < 2 && a.ansp > 0) { arrivals++; rcLgQueue({ type:'einlauf', name:a.name, code:a.code, nation:a.nation }); } return; }
                const dA = a.ansp - (RC_LG.lastA[a.vo] || 0);
                const dT = a.tore - ((RC_LG.lastT_ && RC_LG.lastT_[a.vo]) || 0);
                if (dA > 0 && dT <= 0 && chances < 2) { chances++;
                    rcLgQueue({ type:'chance', name:a.name, code:a.code, nation:a.nation, ansp:a.ansp }); }
            });
        } else { agents.forEach(a => { seen[a.vo] = true; }); }
        RC_LG.lastA = A;
        RC_LG.lastT_ = {}; agents.forEach(a => { RC_LG.lastT_[a.vo] = a.tore; });
        // ---- Elfmeter: jede 5. TEAM-Ansprache, Seed = Datum|Team|Nr ----
        const dk = rcLgDayKey(new Date());
        Object.values(RC_LG.st.teams).forEach(tm => {
            const n = Math.floor((tm.pitches || 0) / RC_LG.cfg.elfProAnsp);
            const done = RC_LG.penDone[tm.code];
            if (done == null) { RC_LG.penDone[tm.code] = n; return; } // Baseline
            if (n > done) {
                RC_LG.penDone[tm.code] = n;
                const rng = rcLgRng(rcLgHash(dk + '|' + tm.code + '|' + n));
                // Underdog (2/3) = wenigste Wochen-Tore im Feld; sonst 1/3
                const wk = rcLgWeek();
                const underdog = wk.underTeam === tm.code;
                const schuss = Math.floor(rng()*3), keeper = underdog ? ((schuss + 1 + Math.floor(rng()*2)) % 3) : Math.floor(rng()*3);
                const shooter = agents.filter(a => a.team === tm.code).sort((x,y) => y.ansp - x.ansp)[0];
                rcLgQueue({ type:'elfmeter', name: shooter ? shooter.name : ('Team ' + tm.code), code: shooter ? shooter.code : (tm.standort||'B'),
                    nation: rcLgNation(shooter ? shooter.code : (tm.standort||'B')), team: tm.code,
                    schuss, keeper, tor: schuss !== keeper, underdog });
            }
        });
        rcLgTickerBuild();
    };

    // ---------- K.-o.-Woche: reine Funktion aus rcEslHistory (Citrix-fest) ----------
    function rcLgWeek(){
        const now = Date.now();
        if (RC_LG.weekCache && now - RC_LG.weekAt < 45000) return RC_LG.weekCache;
        const hist = window.rcEslHistory || {};
        const today = new Date(); const wd = (today.getDay() + 6) % 7; // 0 = Montag
        const days = [];
        for (let i = wd; i > 0; i--) { const d = new Date(today); d.setDate(today.getDate() - i); days.push(rcLgDayKey(d)); }
        const cum = {}, names = {}, codes = {}, alive = new Set(), outAll = [];
        let spieltag = 1, yesterday = null;
        days.forEach(dk => {
            const day = hist[dk]; if (!day || !day.byAgent) return;
            const gToday = {};
            Object.keys(day.byAgent).forEach(vo => {
                const a = day.byAgent[vo], g = 2*((a.mob||0)+(a.kip||0)) + Math.max(0, (a.bnt||0) - (a.mob||0) - (a.kip||0));
                gToday[vo] = g; cum[vo] = (cum[vo]||0) + g;
                if (a.nm) names[vo] = a.nm;
                if (!alive.has(vo) && !outAll.some(o => o.vo === vo)) alive.add(vo);
            });
            // Tagesende: 0 Tore raus; haben ALLE getroffen, fliegt das Minimum
            let cut = [...alive].filter(vo => !(gToday[vo] > 0));
            if (!cut.length && alive.size > 2) {
                const min = Math.min(...[...alive].map(vo => gToday[vo] || 0));
                cut = [...alive].filter(vo => (gToday[vo]||0) === min);
            }
            cut.forEach(vo => { alive.delete(vo); outAll.push({ vo, tag: spieltag, tore: cum[vo]||0 }); });
            yesterday = { dk, spieltag, cut: cut.length,
                top: Object.keys(gToday).sort((x,y) => gToday[y]-gToday[x]).slice(0,3)
                    .map(vo => ({ vo, name: names[vo] || vo, tore: gToday[vo] })) };
            spieltag++;
        });
        // Underdog-Team (fuer Elfmeter-Bonus): Team mit wenigsten Toren HEUTE — morgens fixiert waere
        // besser, aber ohne Vortags-Teamdaten nehmen wir das schwaechste Team des Standes (stabil je Sync)
        let underTeam = null, uMin = Infinity;
        Object.values(RC_LG.st.teams || {}).forEach(tm => {
            const g = rcLgAgentGoals(tm).tore;
            if (g < uMin && (tm.pitches||0) > 0) { uMin = g; underTeam = tm.code; }
        });
        // Fehlende Namen (Historie ohne nm) aus den heutigen Live-Stammdaten ergaenzen
        const liveByVo = {};
        (RC_LG.st.agents || []).forEach(a => { liveByVo[a.vo] = a.name; });
        if (yesterday) yesterday.top.forEach(t => { if (t.name === t.vo && liveByVo[t.vo]) t.name = liveByVo[t.vo]; });
        RC_LG.weekCache = { spieltag, alive, out: outAll, cum, names, yesterday, underTeam };
        RC_LG.weekAt = now;
        return RC_LG.weekCache;
    }

    // ---------- Szenen-Queue ----------
    function rcLgQueue(ev){
        if (RC_LG.queue.length >= RC_LG.cfg.queueMax) RC_LG.queue.shift();
        RC_LG.queue.push(ev);
    }
    window.rcLeagueSpawn = function(code, name, prod, isBcr, time){
        const cls = classify((prod||'').toString());
        const nation = rcLgNation(code);
        if (cls.isVvl) { rcLgQueue({ type:'parade', name, code, nation, prod }); return; }
        if (!cls.cat) return;
        const map = { kip:'volley', mob:'freistoss', env:'flach', ptv:'schlenzer', fibDsl:'abstauber', sonstBnt:'flach' };
        rcLgQueue({ type: map[cls.cat] || 'flach', name, code, nation, prod, cat: cls.cat, time });
    };

    // ---------- Szene starten: Choreografie mit Phasen ----------
    const RC_LG_LABEL = {
        volley:    { word:'TRAUMTOR', sub:'KIP-BNT — Fallrueckzieher, zaehlt doppelt', tor:true, traum:true },
        freistoss: { word:'TRAUMTOR', sub:'Mobilfunk-BNT — Freistoss, zaehlt doppelt', tor:true, traum:true },
        flach:     { word:'TOR',      sub:'ENV-BNT — harter Flachschuss', tor:true },
        schlenzer: { word:'TOR',      sub:'Premium-TV — Schlenzer in den Winkel', tor:true },
        abstauber: { word:'TOR',      sub:'GIGA/DSL-BNT — Abstauber', tor:true },
        parade:    { word:'PARADE',   sub:'VVL gesichert — der Bestand haelt', tor:false },
        chance:    { word:'CHANCE',   sub:'Ansprache — der Keeper haelt, weiter so', tor:false },
        einlauf:   { word:'EINLAUF',  sub:'Erste Ansprache — willkommen im Turnier', tor:false },
        elfmeter:  { word:'ELFMETER', sub:'5 Team-Ansprachen — verdiente Chance', tor:false }
    };
    function rcLgStart(ev){
        const L = RC_LG_LABEL[ev.type] || RC_LG_LABEL.flach;
        const sc = { ev, t:0, phase:0, type:ev.type, trail:[],
            shooter:{ u: ev.type==='abstauber' ? 0.16 : (ev.type==='freistoss' ? -0.06 : -0.26), v: ev.type==='abstauber' ? 0.86 : (ev.type==='volley' ? 0.72 : (ev.type==='freistoss' ? 0.60 : 0.64)) },
            corner: (rcLgHash((ev.name||'') + (ev.time||'') + RC_LG.t.toFixed(0)) % 2) ? 0.13 : -0.13,
            label:L, done:false };
        if (ev.type === 'elfmeter') { sc.shooter = { u:0, v:0.74 }; sc.corner = (ev.schuss - 1) * 0.13; }
        if (ev.type === 'einlauf')  sc.shooter = { u:0.95, v:0.30 };
        sc.cine = ev.type !== 'einlauf'; // Torszenen laufen als Kino-Nahaufnahme (TV-Schnitt)
        sc.wipeT = 0; sc.ctr = [];
        RC_LG.scene = sc;
        // Kamera auf den Strafraum
        const foc = rcLgP(0, 0.8);
        RC_LG.cam.ts = ev.type === 'einlauf' ? 1.06 : 1.30;
        RC_LG.cam.tx = foc.x; RC_LG.cam.ty = foc.y + 40;
        // Banner-Feed
        const who = heroName(ev.name || '');
        if (L.tor) rcLgFeed((L.traum ? 'TRAUMTOR! ' : 'TOR! ') + who + ' (' + rcLgShort(ev.code) + ') — ' + L.sub);
        else if (ev.type === 'elfmeter') rcLgFeed('ELFMETER fuer Team ' + (ev.team||'') + ' — Schuetze ' + who + (ev.underdog ? ' (Underdog-Bonus 2/3)' : ''));
        else if (ev.type === 'parade') rcLgFeed('PARADE! ' + who + ' sichert eine VVL fuer ' + rcLgShort(ev.code));
    }

    const RC_LG_PH = { // Phasendauern je Typ (Sekunden)
        volley:[0.9,1.0,0.9,1.0,1.6], freistoss:[0.9,1.0,0.75,0.9,1.5],
        flach:[0.8,0.9,0.5,0.8,1.3], schlenzer:[0.8,0.9,0.6,0.8,1.3], abstauber:[0.8,0.7,0.35,0.8,1.3],
        parade:[0.9,0.8,0.55,0.9,1.3], chance:[0.7,0.8,0.5,0.7,1.0],
        einlauf:[0.6,1.6,0.01,0.01,1.0], elfmeter:[1.2,1.0,0.55,0.9,1.6]
    };

    function rcLgSceneTick(dt){
        const sc = RC_LG.scene; if (!sc) return;
        const durs = RC_LG_PH[sc.type] || RC_LG_PH.flach;
        // Zeitlupe beim Traumtor-Abschluss; bei vollem Andrang spielen Szenen schneller ab
        const slow = (sc.label.traum && sc.phase === 2) ? 0.45 : 1;
        const rush = RC_LG.queue.length >= 4 ? 1.8 : (RC_LG.queue.length >= 2 ? 1.3 : 1);
        sc.t += dt * slow * rush;
        if (sc.t >= durs[sc.phase]) {
            sc.t = 0; sc.phase++;
            if (sc.cine && (sc.phase === 1 || sc.phase === 4)) sc.wipeT = 0.26; // TV-Schnitt-Blende
            if (sc.phase === 3) rcLgImpact(sc);
            if (sc.phase === 4 && sc.cine) RC_LG.confetti.length = 0; // Kino-Konfetti nicht in die Totale schleppen
            if (sc.phase >= durs.length) { RC_LG.scene = null; RC_LG.cam.ts = 1; RC_LG.cam.tx = 350; RC_LG.cam.ty = 330; }
        }
        if (sc.wipeT > 0) sc.wipeT = Math.max(0, sc.wipeT - dt);
    }
    function rcLgImpact(sc){
        const L = sc.label;
        if (L.tor || (sc.type === 'elfmeter' && sc.ev.tor)) {
            RC_LG.netRip = 1; RC_LG.excite = 1;
            const cp = sc.cine ? { x: 614, y: sc.cineTargetY || 340 } : rcLgP(sc.corner, 1);
            if (L.traum) { RC_LG.shake = 7; rcLgConfetti(cp); }
            else if (sc.cine) rcLgConfetti(cp);
            if (sc.type === 'elfmeter') {
                RC_LG.penGoals[sc.ev.code] = (RC_LG.penGoals[sc.ev.code] || 0) + 1;
                rcLgFeed('ELFMETER VERWANDELT — ' + heroName(sc.ev.name) + ' trifft fuer Team ' + (sc.ev.team||''));
            }
        } else if (sc.type === 'elfmeter') {
            RC_LG.excite = 0.5;
            rcLgFeed('GEHALTEN — der Keeper ahnt die Ecke. Naechste 5 Ansprachen, naechste Chance');
        } else { RC_LG.excite = 0.35; }
    }
    function rcLgConfetti(p){
        const rng = rcLgRng(rcLgHash('konfetti' + RC_LG.t.toFixed(2)));
        const cols = ['#E60000','#FF4C02','#2C57D2','#F5E9C8','#FFFFFF'];
        for (let i=0;i<120;i++) RC_LG.confetti.push({ x:p.x + (rng()-0.5)*60, y:p.y - 30,
            vx:(rng()-0.5)*190, vy:-70 - rng()*170, c: cols[Math.floor(rng()*cols.length)], t:0, dur: 1.7 + rng()*1.0, w: 3+rng()*3 });
    }

    // ---------- Szene zeichnen ----------
    function rcLgSceneDraw(ctx){
        const sc = RC_LG.scene; if (!sc) return;
        const ev = sc.ev, durs = RC_LG_PH[sc.type], p = Math.min(1, sc.t / durs[sc.phase]);
        const gp = rcLgP(sc.corner, 1);            // Ball-Ziel (Torecke)
        const gy = gp.y - 26;                       // Einschlagshoehe
        const sp = rcLgP(sc.shooter.u, sc.shooter.v);
        const keeperP = rcLgP(0, 0.94);
        const who = heroName(ev.name || '');
        const TY = 34 * rcLgS(sp.sc) + 12; // Namensschild-Abstand skaliert mit Spielergroesse
        const isTor = sc.label.tor || (sc.type === 'elfmeter' && ev.tor);
        // Gegner-Keeper (neutral dunkel) — bei Parade traegt ER unsere Flagge
        const keeperNation = sc.type === 'parade' ? ev.nation : null;
        const drawKeeper = (pose, face, lean) => {
            const o = { s: 0.95, face: face||1, pose: pose, ph: RC_LG.t*6, nation: keeperNation || 'XX',
                skin:'#D9A87C', sock:'#101820', rot: lean||0 };
            if (!keeperNation) { // neutrales Keeper-Trikot dunkel zeichnen: Flagge 'XX' faellt auf grau zurueck
            }
            rcLgMan(ctx, keeperP.x + (sc._kx||0), keeperP.y, o);
        };
        // Phase 0: Auftritt + Banner faehrt ein — Spieler joggt zur Position
        if (sc.phase === 0) {
            if (sc.type === 'einlauf') {
                const from = rcLgP(1.15, 0.3);
                const cur = { x: from.x + (sp.x-from.x)*rcLgEase(p), y: from.y + (sp.y-from.y)*rcLgEase(p) };
                rcLgMan(ctx, cur.x, cur.y, { s: rcLgS(rcLgP(0,sc.shooter.v).sc), face:-1, pose:'run', ph: RC_LG.t*10, nation: ev.nation });
                rcLgTag(ctx, cur.x, cur.y - TY, who, ev.nation, true);
            } else {
                drawKeeper('keeper', 1);
                const from = rcLgP(sc.shooter.u - 0.3, Math.max(0, sc.shooter.v - 0.25));
                const cur = { x: from.x + (sp.x-from.x)*rcLgEase(p), y: from.y + (sp.y-from.y)*rcLgEase(p) };
                rcLgMan(ctx, cur.x, cur.y, { s: rcLgS(sp.sc), face:1, pose:'run', ph: RC_LG.t*10, nation: ev.nation });
                rcLgTag(ctx, cur.x, cur.y - TY, who, ev.nation, true);
                if (sc.type !== 'volley') rcLgBall(ctx, sp.x + 12, sp.y + 2, 4.2*sp.sc + 1.6, RC_LG.t*3);
                if (sc.type === 'freistoss') { // Mauer
                    [ -0.05, 0.03 ].forEach((u,i) => { const w = rcLgP(u, 0.80);
                        rcLgMan(ctx, w.x, w.y, { s: rcLgS(w.sc)*0.85, face:-1, pose:'stand', nation:'XX', skin:'#C9946B' }); });
                }
            }
        }
        // Phase 1: Aktion — Anlauf/Flanke/Anlauf-Elfmeter
        else if (sc.phase === 1) {
            drawKeeper('keeper', 1);
            if (sc.type === 'volley') {
                // Flanke fliegt zum Schuetzen
                const from = rcLgP(-0.95, 0.75);
                const bx = from.x + (sp.x - from.x)*p, by = from.y + (sp.y - from.y)*p - Math.sin(Math.PI*p)*58;
                sc.trail.push({x:bx,y:by}); if (sc.trail.length > 9) sc.trail.shift();
                rcLgTrail(ctx, sc.trail);
                rcLgBall(ctx, bx, by, 4.4*sp.sc + 1.4, RC_LG.t*9);
                rcLgMan(ctx, sp.x, sp.y, { s: rcLgS(sp.sc), face:1, pose:'stand', nation: ev.nation });
                rcLgTag(ctx, sp.x, sp.y - TY, who, ev.nation, true);
            } else {
                const cur = { x: sp.x + (p * 9), y: sp.y };
                rcLgMan(ctx, cur.x, cur.y, { s: rcLgS(sp.sc), face:1, pose:'run', ph: RC_LG.t*12, nation: ev.nation });
                rcLgTag(ctx, cur.x, cur.y - TY, who, ev.nation, true);
                rcLgBall(ctx, sp.x + 13, sp.y + 2, 4.2*sp.sc + 1.6, 0);
                if (sc.type === 'freistoss') [ -0.05, 0.03 ].forEach(u => { const w = rcLgP(u, 0.80);
                    rcLgMan(ctx, w.x, w.y, { s: rcLgS(w.sc)*0.85, face:-1, pose:'stand', nation:'XX', skin:'#C9946B' }); });
            }
        }
        // Phase 2: Schuss — Ballflug (Zeitlupe bei Traumtoren)
        else if (sc.phase === 2) {
            const kickP = Math.min(1, p*2);
            if (sc.type === 'volley') {
                const rot = -p * 4.4;
                rcLgMan(ctx, sp.x, sp.y - Math.sin(Math.PI*Math.min(1,p*1.4))*16, { s: rcLgS(sp.sc), face:1, pose:'volley', pw:p, rot, nation: ev.nation });
            } else {
                rcLgMan(ctx, sp.x + 9, sp.y, { s: rcLgS(sp.sc), face:1, pose:'kick', pw:kickP, nation: ev.nation });
            }
            rcLgTag(ctx, sp.x, sp.y - TY, who, ev.nation, true);
            // Keeper hechtet: bei Tor in die falsche, sonst in die Ball-Ecke
            const dir = sc.type === 'elfmeter' ? (ev.keeper - 1) : (isTor ? -Math.sign(sc.corner||0.1) : Math.sign(sc.corner||0.1));
            sc._kx = dir * 26 * rcLgEase(p);
            drawKeeper('dive', dir >= 0 ? 1 : -1, dir * 0.9 * rcLgEase(p));
            // Ballflug: Bezier vom Fuss in die Ecke — ohne Tor landet er beim Keeper
            const bp = rcLgEase(p);
            const tx2 = isTor ? gp.x : keeperP.x + Math.sign(sc.corner || 0.1) * 26;
            const ty2 = isTor ? gy : keeperP.y - 14;
            const c1 = { x: sp.x + 30 + (sc.type==='schlenzer' ? 55 : 0), y: sp.y - 90 };
            const q = 1 - bp;
            const bx = q*q*(sp.x+12) + 2*q*bp*c1.x + bp*bp*tx2;
            const by = q*q*(sp.y) + 2*q*bp*c1.y + bp*bp*ty2;
            sc.trail.push({x:bx,y:by}); if (sc.trail.length > 12) sc.trail.shift();
            rcLgTrail(ctx, sc.trail);
            rcLgBall(ctx, bx, by, 6.4 - bp*2.6, RC_LG.t*12);
        }
        // Phase 3: Einschlag — Netz bebt / Parade / Pfosten
        else if (sc.phase === 3) {
            if (isTor) {
                rcLgMan(ctx, sp.x + 9, sp.y, { s: rcLgS(sp.sc), face:1, pose:'jubel', ph: RC_LG.t, nation: ev.nation });
                rcLgTag(ctx, sp.x + 9, sp.y - TY, who, ev.nation, true);
                drawKeeper('dive', 1, 1.2);
                rcLgBall(ctx, gp.x, gy + 8, 2.8, 0);
                // TOR-Schriftzug
                ctx.font = rcWarFont(sc.label.traum ? 42 : 32, true); ctx.textAlign = 'center';
                ctx.globalAlpha = Math.min(1, sc.t*4) * (1 - Math.max(0, sc.t - 0.55)/0.35);
                ctx.strokeStyle = 'rgba(8,12,18,0.85)'; ctx.lineWidth = 6; ctx.lineJoin = 'round';
                ctx.strokeText(sc.label.word + '!', 350, 300);
                ctx.fillStyle = sc.label.traum ? '#FFD34D' : '#FFFFFF';
                ctx.fillText(sc.label.word + '!', 350, 300);
                ctx.globalAlpha = 1; ctx.textAlign = 'left';
            } else {
                // Keeper haelt (Chance/Parade/gehaltener Elfer)
                const dir = sc.type === 'elfmeter' ? (ev.keeper - 1) : Math.sign(sc.corner||0.1);
                sc._kx = dir * 26;
                drawKeeper('dive', dir >= 0 ? 1 : -1, dir * 0.9);
                rcLgBall(ctx, keeperP.x + dir*26, keeperP.y - 14, 3.0, 0);
                rcLgMan(ctx, sp.x + 9, sp.y, { s: rcLgS(sp.sc), face:1, pose:'stand', nation: ev.nation });
                rcLgTag(ctx, sp.x + 9, sp.y - TY, who, ev.nation, true);
            }
        }
        // Phase 4: Ausklang — Jubel/Applaus, Banner bleibt
        else {
            if (sc.type === 'einlauf') {
                rcLgMan(ctx, sp.x, sp.y, { s: rcLgS(sp.sc), face:-1, pose:'jubel', ph: RC_LG.t, nation: ev.nation });
                rcLgTag(ctx, sp.x, sp.y - TY, who, ev.nation, true);
            } else if (isTor) {
                rcLgMan(ctx, sp.x + 20, sp.y + 8, { s: rcLgS(sp.sc), face:1, pose:'jubel', ph: RC_LG.t, nation: ev.nation });
                rcLgTag(ctx, sp.x + 20, sp.y - TY, who, ev.nation, true);
            } else {
                drawKeeper('keeper', 1);
                rcLgMan(ctx, sp.x, sp.y, { s: rcLgS(sp.sc), face:1, pose:'stand', nation: ev.nation });
                rcLgTag(ctx, sp.x, sp.y - TY, who, ev.nation, true);
            }
        }
        rcLgBanner(ctx, sc);
    }
    function rcLgTrail(ctx, tr){
        for (let i=0;i<tr.length;i++){
            ctx.globalAlpha = 0.4 * i / tr.length;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(tr[i].x, tr[i].y, 1.4 + 2.4 * i / tr.length, 0, 7); ctx.fill();
        }
        ctx.globalAlpha = 1;
    }
    // Bauchbinde (Lower Third) im TV-Stil
    function rcLgBanner(ctx, sc){
        const durs = RC_LG_PH[sc.type];
        const total = durs.reduce((a,b)=>a+b,0);
        let el = sc.t; for (let i=0;i<sc.phase;i++) el += durs[i];
        const inP = Math.min(1, el / 0.4);
        const outP = Math.max(0, (el - (total - 0.4)) / 0.4);
        const slide = (1 - rcLgEase(inP)) * -320 + rcLgEase(outP) * -320;
        const y = 586;
        const word = sc.type === 'elfmeter' ? (sc.phase >= 3 ? (sc.ev.tor ? 'TOR!' : 'GEHALTEN') : 'ELFMETER') : sc.label.word;
        ctx.save(); ctx.translate(slide, 0);
        ctx.font = rcWarFont(13, true);
        const wordW = ctx.measureText(word).width + 22;
        ctx.fillStyle = sc.label.traum ? '#E60000' : (sc.label.tor ? '#C1121C' : '#16202C');
        ctx.fillRect(24, y - 20, wordW, 26);
        ctx.fillStyle = '#FFFFFF'; ctx.fillText(word, 35, y - 2);
        const name = heroName(sc.ev.name || '') + '  ·  ' + rcLgShort(sc.ev.code);
        ctx.font = rcWarFont(12, true);
        const nW = Math.max(ctx.measureText(name).width, ctx.measureText(sc.label.sub).width * 0.86) + 34;
        ctx.fillStyle = 'rgba(10,16,24,0.92)'; ctx.fillRect(24 + wordW, y - 20, nW, 26);
        rcLgFlag(ctx, sc.ev.nation, 24 + wordW + 8, y - 14.5, 12, 8, 1);
        ctx.fillStyle = '#F5F5F5'; ctx.fillText(name, 24 + wordW + 26, y - 9);
        ctx.font = rcWarFont(9);
        ctx.fillStyle = '#8FA3B8'; ctx.fillText(sc.label.sub, 24 + wordW + 26, y + 1.5);
        ctx.restore();
    }

    // ---------- Ambiente: Aufwaermen der Top-Torjaeger, Ball wandert ----------
    function rcLgAmbient(ctx, dt){
        const list = RC_LG.st.agents.filter(a => a.ansp > 0).slice(0, 5);
        const key = list.map(a => a.vo).join(',');
        if (RC_LG.amb.built !== key) {
            RC_LG.amb.built = key;
            RC_LG.amb.players = list.map((a, i) => ({ a, u: -0.62 + 0.31*i, v: 0.32 + 0.22*((i%3)/2), du: 0, dv: 0, ph: i*1.7 }));
            RC_LG.amb.ballAt = 0; RC_LG.amb.ballT = 0;
        }
        const ps = RC_LG.amb.players;
        ps.forEach(pl => {
            pl.ph += dt;
            pl.u += Math.sin(pl.ph*0.7) * dt * 0.045;
            pl.v += Math.cos(pl.ph*0.5) * dt * 0.03;
        });
        // Passspiel
        if (ps.length > 1) {
            RC_LG.amb.ballT += dt;
            if (RC_LG.amb.ballT > 2.2) { RC_LG.amb.ballT = 0; RC_LG.amb.ballFrom = RC_LG.amb.ballAt; RC_LG.amb.ballAt = (RC_LG.amb.ballAt + 1) % ps.length; }
        }
        ps.slice().sort((x,y) => x.v - y.v).reverse().forEach(pl => {
            const P = rcLgP(pl.u, pl.v);
            rcLgMan(ctx, P.x, P.y, { s: rcLgS(P.sc)*0.9, face: Math.sin(pl.ph*0.7) >= 0 ? 1 : -1, pose:'run', ph: pl.ph*6.5, nation: pl.a.nation });
            rcLgTag(ctx, P.x, P.y - 56, heroName(pl.a.name) + '  ' + pl.a.tore + ' T', pl.a.nation, false);
        });
        if (ps.length > 1) {
            const A = rcLgP(ps[RC_LG.amb.ballFrom||0].u, ps[RC_LG.amb.ballFrom||0].v);
            const B = rcLgP(ps[RC_LG.amb.ballAt].u, ps[RC_LG.amb.ballAt].v);
            const bp = Math.min(1, RC_LG.amb.ballT / 0.7);
            rcLgBall(ctx, A.x + (B.x-A.x)*bp + 10, A.y + (B.y-A.y)*bp + 3, 4, RC_LG.t*6);
        }
        if (!ps.length) {
            ctx.font = rcWarFont(13, true); ctx.textAlign = 'center';
            ctx.fillStyle = 'rgba(245,245,245,0.75)';
            ctx.fillText('DAS STADION WARTET — die erste getrackte Ansprache eroeffnet das Spiel', 350, 380);
            ctx.textAlign = 'left';
        }
    }

    // ---------- Ticker + Feed ----------
    function rcLgFeed(txt){
        RC_LG.feed.unshift({ txt, time: new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}) });
        if (RC_LG.feed.length > 8) RC_LG.feed.pop();
        rcLgTickerBuild();
    }
    function rcLgTickerBuild(){
        const wk = RC_LG.weekCache, parts = [];
        RC_LG.feed.slice(0, 4).forEach(f => parts.push(f.time + ' ' + f.txt));
        if (wk) {
            parts.push('K.-o.-TURNIER: ' + (wk.alive.size || RC_LG.st.agents.filter(a=>a.ansp>0).length) + ' im Feld · ' + wk.out.length + ' ausgeschieden');
            if (wk.yesterday && wk.yesterday.top.length) parts.push('GESTERN: ' + wk.yesterday.top.map(t => heroName(t.name) + ' ' + t.tore + ' Tore').join(' · '));
        }
        // Naechster Elfmeter
        let best = null;
        Object.values(RC_LG.st.teams || {}).forEach(tm => {
            const rest = RC_LG.cfg.elfProAnsp - ((tm.pitches||0) % RC_LG.cfg.elfProAnsp);
            if (rest < RC_LG.cfg.elfProAnsp && (!best || rest < best.rest)) best = { code: tm.code, rest };
        });
        if (best) parts.push('Noch ' + best.rest + ' Ansprache' + (best.rest>1?'n':'') + ' bis zum ELFMETER — Team ' + best.code);
        if (RC_LG.st.stdRows.length) parts.push('TABELLE: ' + RC_LG.st.stdRows.slice(0,3).map((r,i) => (i+1)+'. '+r.short+' '+r.tore).join('  ·  '));
        RC_LG.tickerTxt = parts.join('   +++   ') || 'REGIOCOM SALES LEAGUE — Warte auf Daten';
    }

    // ---------- UI-Rahmen: Anzeigetafel, Panels, Ticker ----------
    function rcLgPanel(ctx, x, y, w, h, title){
        ctx.fillStyle = 'rgba(13,20,29,0.94)';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, 7); else ctx.rect(x, y, w, h); ctx.fill();
        ctx.strokeStyle = 'rgba(255,255,255,0.10)'; ctx.lineWidth = 1;
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x+0.5, y+0.5, w-1, h-1, 7); else ctx.rect(x, y, w, h); ctx.stroke();
        if (title) { ctx.font = rcWarFont(9, true); ctx.fillStyle = '#8FA3B8'; ctx.fillText(title.toUpperCase(), x + 10, y + 15); }
    }
    function rcLgFrame(ctx){
        const wk = rcLgWeek();
        // ---- Anzeigetafel oben ----
        rcLgPanel(ctx, 10, 8, 980, 40, '');
        ctx.fillStyle = '#E60000'; ctx.fillRect(22, 18, 46, 20);
        ctx.font = rcWarFont(11, true); ctx.fillStyle = '#FFFFFF'; ctx.fillText('LIVE', 30, 32);
        ctx.font = rcWarFont(15, true); ctx.fillStyle = '#F5F5F5';
        ctx.fillText('REGIOCOM SALES LEAGUE', 80, 33);
        ctx.font = rcWarFont(10); ctx.fillStyle = '#8FA3B8';
        ctx.fillText('SPIELTAG ' + wk.spieltag + '  ·  K.-o.-Woche  ·  Schlusspfiff 18:00', 296, 32);
        ctx.font = rcWarFont(13, true); ctx.fillStyle = '#FFD34D';
        ctx.fillText(RC_LG.st.totalTore + ' TORE HEUTE', 560, 33);
        ctx.fillStyle = '#7FC5A2'; ctx.fillText(RC_LG.st.totalParaden + ' PARADEN', 700, 33);
        ctx.font = rcWarFont(11, true); ctx.fillStyle = '#DCDCDC'; ctx.textAlign = 'right';
        ctx.fillText(new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}) + ' UHR', 978, 33);
        ctx.textAlign = 'left';
        // ---- Rechte Spalte ----
        const X = 706, W = 284;
        // Tabelle (Standorte, Flaggen-Trikots)
        rcLgPanel(ctx, X, 56, W, 168, 'Tabelle · Tore heute (Traumtor = 2)');
        RC_LG.st.stdRows.slice(0, 7).forEach((r, i) => {
            const ry = 90 + i*19;
            if (i === 0) { ctx.fillStyle = 'rgba(255,211,77,0.10)'; ctx.fillRect(X+4, ry - 12, W-8, 18); }
            ctx.font = rcWarFont(10.5, i === 0); ctx.fillStyle = i === 0 ? '#FFD34D' : '#DCDCDC';
            ctx.fillText(String(i+1), X + 12, ry);
            rcLgFlag(ctx, r.nation, X + 26, ry - 8.5, 15, 10, 1.5);
            ctx.fillText(r.short, X + 48, ry);
            ctx.textAlign = 'right';
            ctx.fillText(String(r.tore), X + W - 46, ry);
            ctx.fillStyle = '#7FC5A2'; ctx.fillText(String(r.paraden) + ' P', X + W - 12, ry);
            ctx.textAlign = 'left';
        });
        // Torjaeger heute
        rcLgPanel(ctx, X, 232, W, 150, 'Torjaeger heute');
        const tj = RC_LG.st.agents.filter(a => a.tore > 0).slice(0, 6);
        if (!tj.length) { ctx.font = rcWarFont(10); ctx.fillStyle = '#5F7186'; ctx.fillText('Noch kein Tor — die Jagd laeuft', X + 10, 272); }
        tj.forEach((a, i) => {
            const ry = 266 + i*19;
            ctx.font = rcWarFont(10.5, i === 0); ctx.fillStyle = i === 0 ? '#FFD34D' : '#DCDCDC';
            rcLgFlag(ctx, a.nation, X + 10, ry - 8.5, 15, 10, 1.5);
            ctx.fillText(heroName(a.name), X + 32, ry);
            ctx.textAlign = 'right';
            ctx.fillText(a.tore + ' T', X + W - 12, ry);
            if (a.traum > 0) { ctx.fillStyle = '#E60000'; ctx.fillText(a.traum + ' TT', X + W - 48, ry); }
            ctx.textAlign = 'left';
        });
        // K.-o.-Stand + Gefaehrdet
        rcLgPanel(ctx, X, 390, W, 118, 'K.-o.-Turnier · Cut um 18:00');
        const feld = RC_LG.st.agents.filter(a => a.ansp > 0 || a.tore > 0);
        const gef = feld.filter(a => a.tore === 0);
        ctx.font = rcWarFont(20, true); ctx.fillStyle = '#F5F5F5'; ctx.fillText(String(feld.length), X + 14, 434);
        ctx.font = rcWarFont(9); ctx.fillStyle = '#8FA3B8'; ctx.fillText('IM FELD', X + 14, 446);
        ctx.font = rcWarFont(20, true); ctx.fillStyle = '#FF7A6B'; ctx.fillText(String(gef.length), X + 96, 434);
        ctx.font = rcWarFont(9); ctx.fillStyle = '#8FA3B8'; ctx.fillText('OHNE TOR', X + 96, 446);
        ctx.font = rcWarFont(20, true); ctx.fillStyle = '#9C9C9C'; ctx.fillText(String(wk.out.length), X + 182, 434);
        ctx.font = rcWarFont(9); ctx.fillStyle = '#8FA3B8'; ctx.fillText('AUSGESCHIEDEN', X + 182, 446);
        ctx.font = rcWarFont(9.5); ctx.fillStyle = '#FF9A8E';
        const gefN = gef.slice(0, 3).map(a => heroName(a.name)).join(' · ');
        if (gefN) ctx.fillText('Gefaehrdet: ' + gefN + (gef.length > 3 ? ' +' + (gef.length-3) : ''), X + 14, 468);
        ctx.fillStyle = '#5F7186'; ctx.fillText('Wer heute ohne Tor bleibt, scheidet aus dem Wochen-K.-o. aus.', X + 14, 484);
        ctx.fillText('Sales zaehlen fuer den Standort trotzdem weiter.', X + 14, 496);
        // Vortag
        rcLgPanel(ctx, X, 516, W, 88, 'Rueckblick Spieltag ' + Math.max(1, wk.spieltag - 1));
        if (wk.yesterday && wk.yesterday.top.length) {
            wk.yesterday.top.forEach((t, i) => {
                const ry = 548 + i*15;
                ctx.font = rcWarFont(10, i === 0); ctx.fillStyle = i === 0 ? '#FFD34D' : '#DCDCDC';
                ctx.fillText((i+1) + '. ' + heroName(t.name), X + 12, ry);
                ctx.textAlign = 'right'; ctx.fillText(t.tore + ' Tore', X + W - 12, ry); ctx.textAlign = 'left';
            });
            ctx.font = rcWarFont(9); ctx.fillStyle = '#8FA3B8';
            ctx.fillText(wk.yesterday.cut + ' Agenten ausgeschieden', X + 12, 596);
        } else {
            ctx.font = rcWarFont(10); ctx.fillStyle = '#5F7186';
            ctx.fillText('Noch keine Vortags-Daten in dieser Woche', X + 12, 545);
        }
        // ---- Ticker unten ----
        rcLgPanel(ctx, 10, 610, 980, 26, '');
        ctx.fillStyle = '#E60000'; ctx.fillRect(18, 615, 58, 16);
        ctx.font = rcWarFont(9.5, true); ctx.fillStyle = '#FFFFFF'; ctx.fillText('TICKER', 26, 626.5);
        ctx.save(); ctx.beginPath(); ctx.rect(84, 610, 898, 26); ctx.clip();
        ctx.font = rcWarFont(11); ctx.fillStyle = '#DCDCDC';
        const tw = ctx.measureText(RC_LG.tickerTxt || '').width;
        if (RC_LG.tickerX < -tw) RC_LG.tickerX = 990;
        ctx.fillText(RC_LG.tickerTxt || '', RC_LG.tickerX, 627);
        ctx.restore();
    }

    // ============================================================
    //  KINO-BUEHNE — TV-Nahaufnahme der Torszenen (Seitenansicht).
    //  Bei jeder Szene schneidet die Regie von der Totalen (Stadion)
    //  auf eine bildschirmfuellende Kamera: grosse Spieler-Rigs mit
    //  Flaggen-Trikot, grosses Tor mit Netz, Bokeh-Tribuene, Zeitlupe.
    // ============================================================
    const RC_CINE = { GY: 512, goalX: 614, goalTop: 300, netX: 692, keeperX: 572, horizon: 402 };
    const rcLgJersey = { TR:'#E30A17', GR:'#0D5EAF', DE:'#1F1F1F', AT:'#ED2939', XX:'#5A6470' };
    const rcLgSock   = { TR:'#8E0A10', GR:'#093F75', DE:'#111111', AT:'#9E1B24', XX:'#39424E' };
    const rcLgSkins  = ['#F0C8A0','#E3B188','#C98F62','#A96B41','#8A5230'];
    const rcLgHairs  = ['#1D1712','#3A2A18','#6B4A26','#0E0E10','#4A4A4A'];

    // Grosser Seitenansicht-Spieler. o: { h, dir, nation, name (Haar/Haut-Varianz),
    // pose: stand|run|walk|set|kick|volley|dive|slide|frust|jubel, ph, pw, rot, keeper }
    function rcLgBigMan(ctx, x, y, o){
        const H = o.h || 190, u = H/8, dir = o.dir || 1;
        const hsh = rcLgHash(o.name || 'x');
        const skin = o.skin || rcLgSkins[hsh % rcLgSkins.length];
        const hair = rcLgHairs[(hsh >> 3) % rcLgHairs.length];
        const nation = o.nation || 'XX';
        const base = o.keeper && nation === 'XX' ? '#31414F' : (rcLgJersey[nation] || rcLgJersey.XX);
        const sock = rcLgSock[nation] || rcLgSock.XX;
        const OL = 'rgba(9,13,19,0.5)';
        const ph = o.ph || 0, pw = Math.max(0, Math.min(1, o.pw == null ? 0 : o.pw));
        // Gelenkwinkel (0 = senkrecht nach unten, positiv = nach vorn)
        let tA = 0.06, l1 = 0.15, k1 = 0.12, l2 = -0.15, k2 = 0.35,
            a1 = 0.45, e1 = 0.55, a2 = -0.45, e2 = 0.55, hop = 0;
        if (o.pose === 'run' || o.pose === 'walk') {
            const sp = o.pose === 'walk' ? 0.5 : 1;
            const s1 = Math.sin(ph), s2 = -s1;
            l1 = s1*0.85*sp; k1 = Math.max(0, -s1)*1.3*sp + 0.14;
            l2 = s2*0.85*sp; k2 = Math.max(0, -s2)*1.3*sp + 0.14;
            a1 = s2*0.75*sp; e1 = 0.95; a2 = s1*0.75*sp; e2 = 0.95;
            tA = 0.15*sp; hop = Math.abs(Math.sin(ph))*u*0.26;
        } else if (o.pose === 'set') {
            l1 = 0.36; k1 = 0.9; l2 = -0.32; k2 = 0.9; tA = 0.32;
            a1 = 0.7; e1 = -1.1; a2 = -0.65; e2 = -1.1; hop = -u*0.55;
        } else if (o.pose === 'kick') {
            const w = pw < 0.38 ? pw/0.38 : 0, sw = pw < 0.38 ? 0 : rcLgEase((pw - 0.38)/0.62);
            l1 = -1.1*w + 2.1*sw - 0.18; k1 = 1.35*w*(1 - sw) + 0.12;
            l2 = 0.12 - 0.22*sw; k2 = 0.16;
            tA = -0.16 + 0.32*sw;
            a1 = 0.95 - 1.5*sw; e1 = 0.5; a2 = -0.85 + 1.3*sw; e2 = 0.5;
        } else if (o.pose === 'volley') {
            l1 = 2.5*pw - 0.4; k1 = 0.14;
            l2 = -1.0*pw + 0.2; k2 = 0.95;
            tA = 0; a1 = -1.7; e1 = 0.4; a2 = -2.3; e2 = 0.3;
        } else if (o.pose === 'dive') {
            l1 = 0.55; k1 = 0.3; l2 = -0.3; k2 = 0.6; tA = 0.12;
            a1 = -2.55; e1 = 0.12; a2 = -2.8; e2 = 0.08;
        } else if (o.pose === 'slide') {
            l1 = 1.3; k1 = 2.2; l2 = 1.05; k2 = 2.3; tA = -0.15;
            a1 = -2.5; e1 = -0.3; a2 = -2.2; e2 = -0.3; hop = -u*1.6;
        } else if (o.pose === 'frust') {
            a1 = -2.95; e1 = -1.95; a2 = -2.8; e2 = -1.95; tA = -0.06;
        } else if (o.pose === 'wall') { // Mauer: Arme vor dem Koerper verschraenkt
            a1 = 0.55; e1 = -1.75; a2 = -0.55; e2 = 1.75; tA = 0.03;
            l1 = 0.08; k1 = 0.08; l2 = -0.08; k2 = 0.1;
        } else if (o.pose === 'jubel') {
            a1 = -2.7; e1 = -0.3; a2 = -2.95; e2 = -0.2; tA = -0.1;
            hop = Math.abs(Math.sin(ph*7))*u*0.5;
        }
        ctx.save(); ctx.translate(x, y);
        ctx.fillStyle = 'rgba(4,14,8,0.36)';
        ctx.beginPath(); ctx.ellipse(0, 0, u*2.2, u*0.5, 0, 0, 7); ctx.fill();
        ctx.translate(0, -hop); ctx.scale(dir, 1);
        if (o.rot) ctx.rotate(o.rot);
        const hipY = -3.55*u, shY = -6.15*u;
        const TH = 1.95*u, CA = 1.85*u, UA = 1.35*u, FA = 1.25*u;
        // Gliedmasse: 2 Segmente mit Outline; foot = Schuh, hand = Hand/Handschuh
        const limb = (ox, oy, len1, ang1, len2, angRel, w1, w2, c1, c2, opt) => {
            const kx = ox + Math.sin(ang1)*len1, ky = oy + Math.cos(ang1)*len1;
            const ab = ang1 + angRel;
            const fx = kx + Math.sin(ab)*len2, fy = ky + Math.cos(ab)*len2;
            ctx.lineCap = 'round';
            ctx.strokeStyle = OL; ctx.lineWidth = w1 + u*0.18;
            ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(kx, ky); ctx.stroke();
            ctx.strokeStyle = c1; ctx.lineWidth = w1;
            ctx.beginPath(); ctx.moveTo(ox, oy); ctx.lineTo(kx, ky); ctx.stroke();
            ctx.strokeStyle = OL; ctx.lineWidth = w2 + u*0.18;
            ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
            ctx.strokeStyle = c2; ctx.lineWidth = w2;
            ctx.beginPath(); ctx.moveTo(kx, ky); ctx.lineTo(fx, fy); ctx.stroke();
            if (opt === 'foot') {
                ctx.save(); ctx.translate(fx, fy); ctx.rotate(ab);
                ctx.fillStyle = '#141920';
                ctx.beginPath();
                if (ctx.roundRect) ctx.roundRect(-u*0.2, -u*0.16, u*0.98, u*0.44, u*0.2); else ctx.rect(-u*0.2, -u*0.16, u*0.98, u*0.44);
                ctx.fill();
                ctx.fillStyle = '#EDEDED'; ctx.fillRect(-u*0.2, u*0.2, u*0.98, u*0.09);
                ctx.restore();
            } else if (opt === 'hand' || opt === 'glove') {
                ctx.fillStyle = opt === 'glove' ? '#EFEFEF' : skin;
                ctx.beginPath(); ctx.arc(fx, fy, u*0.26, 0, 7); ctx.fill();
            }
        };
        const handOpt = o.keeper ? 'glove' : 'hand';
        // Hinterer Arm + hinteres Bein
        limb(-0.2*u, shY + 0.3*u, UA, a2, FA, e2, u*0.5, u*0.42, base, skin, handOpt);
        limb(-0.16*u, hipY, TH, l2, CA, k2, u*0.72, u*0.6, skin, sock, 'foot');
        // Torso mit Flaggen-Trikot (um die Huefte geneigt)
        ctx.save(); ctx.translate(0, hipY); ctx.rotate(tA); ctx.translate(0, -hipY);
        const tw = 2.55*u, tx0 = -tw/2, ty0 = shY - 0.5*u, thh = (hipY - shY) + 1.15*u;
        if (o.keeper && nation === 'XX') {
            ctx.fillStyle = base;
            ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(tx0, ty0, tw, thh, u*0.7); else ctx.rect(tx0, ty0, tw, thh); ctx.fill();
        } else {
            rcLgFlag(ctx, nation, tx0, ty0, tw, thh, u*0.7);
        }
        ctx.fillStyle = 'rgba(0,0,0,0.16)';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(0, ty0, tw/2, thh, u*0.7); else ctx.rect(0, ty0, tw/2, thh); ctx.fill();
        ctx.strokeStyle = OL; ctx.lineWidth = u*0.14;
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(tx0, ty0, tw, thh, u*0.7); else ctx.rect(tx0, ty0, tw, thh); ctx.stroke();
        // Hose
        ctx.fillStyle = o.keeper ? '#1B242E' : '#F4F4F4';
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(tx0 + u*0.08, hipY - u*0.35, tw - u*0.16, u*1.15, u*0.35); else ctx.rect(tx0 + u*0.08, hipY - u*0.35, tw - u*0.16, u*1.15); ctx.fill();
        ctx.strokeStyle = OL; ctx.lineWidth = u*0.12;
        ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(tx0 + u*0.08, hipY - u*0.35, tw - u*0.16, u*1.15, u*0.35); else ctx.rect(tx0 + u*0.08, hipY - u*0.35, tw - u*0.16, u*1.15); ctx.stroke();
        // Kopf + Haar + Ohr (leicht nach vorn versetzt)
        const hx = 0.3*u, hy = shY - 0.95*u, hr = 0.85*u;
        ctx.fillStyle = skin; ctx.beginPath(); ctx.arc(hx, hy, hr, 0, 7); ctx.fill();
        ctx.strokeStyle = OL; ctx.lineWidth = u*0.12; ctx.stroke();
        ctx.fillStyle = hair;
        ctx.beginPath(); ctx.arc(hx, hy - u*0.08, hr + u*0.02, Math.PI*1.02, Math.PI*1.92); ctx.fill();
        ctx.fillStyle = 'rgba(0,0,0,0.15)';
        ctx.beginPath(); ctx.arc(hx - hr*0.45, hy + u*0.05, u*0.16, 0, 7); ctx.fill();
        // Auge in Blickrichtung — macht die Figur sofort lesbar
        ctx.fillStyle = '#1A1F26';
        ctx.beginPath(); ctx.arc(hx + hr*0.5, hy - u*0.06, u*0.11, 0, 7); ctx.fill();
        ctx.restore();
        // Vorderes Bein + vorderer Arm
        limb(0.16*u, hipY, TH, l1, CA, k1, u*0.72, u*0.6, skin, sock, 'foot');
        limb(0.2*u, shY + 0.3*u, UA, a1, FA, e1, u*0.5, u*0.42, base, skin, handOpt);
        ctx.restore();
    }

    function rcLgBigBall(ctx, x, y, r, rot, speedy){
        if (speedy) { // Tempolinien hinter dem Ball
            ctx.strokeStyle = 'rgba(255,255,255,0.30)'; ctx.lineWidth = 2;
            for (let i=0;i<3;i++){ ctx.beginPath(); ctx.moveTo(x - speedy.x*(14 + i*10), y - speedy.y*(14 + i*10) + (i-1)*4);
                ctx.lineTo(x - speedy.x*(30 + i*12), y - speedy.y*(30 + i*12) + (i-1)*4); ctx.stroke(); }
        }
        ctx.save(); ctx.translate(x, y); ctx.rotate(rot || 0);
        ctx.fillStyle = '#FAFAFA'; ctx.beginPath(); ctx.arc(0, 0, r, 0, 7); ctx.fill();
        ctx.strokeStyle = 'rgba(9,13,19,0.5)'; ctx.lineWidth = Math.max(1, r*0.1); ctx.stroke();
        ctx.fillStyle = '#20242A';
        ctx.beginPath(); ctx.moveTo(0, -r*0.4);
        for (let i=1;i<5;i++) ctx.lineTo(Math.sin(i*1.257)*r*0.4, -Math.cos(i*1.257)*r*0.4);
        ctx.closePath(); ctx.fill();
        for (let i=0;i<5;i++){ const a = i*1.257 - Math.PI/2;
            ctx.strokeStyle = 'rgba(32,36,42,0.7)'; ctx.lineWidth = r*0.08;
            ctx.beginPath(); ctx.moveTo(Math.cos(a)*r*0.42, Math.sin(a)*r*0.42);
            ctx.lineTo(Math.cos(a)*r*0.86, Math.sin(a)*r*0.86); ctx.stroke(); }
        ctx.fillStyle = 'rgba(0,0,0,0.14)';
        ctx.beginPath(); ctx.arc(r*0.28, r*0.3, r*0.82, -0.4, 1.8); ctx.fill();
        ctx.restore();
    }

    let RC_CINE_BOKEH = null;
    function rcLgCineBg(ctx){
        const G = RC_CINE;
        const g1 = ctx.createLinearGradient(0, 54, 0, G.horizon);
        g1.addColorStop(0, '#07101B'); g1.addColorStop(1, '#14293E');
        ctx.fillStyle = g1; ctx.fillRect(10, 54, 688, G.horizon - 54);
        if (!RC_CINE_BOKEH) {
            const rng = rcLgRng(4711); RC_CINE_BOKEH = [];
            const cols = ['#E60000','#2C57D2','#FF4C02','#F5E9C8','#FFFFFF','#8FA3B8'];
            for (let i=0;i<120;i++) RC_CINE_BOKEH.push({ x: 12 + rng()*684, y: 60 + rng()*320,
                r: 3 + rng()*10, c: cols[Math.floor(rng()*cols.length)], a: 0.05 + rng()*0.10, p: rng()*6.28 });
        }
        RC_CINE_BOKEH.forEach(b => {
            ctx.globalAlpha = Math.max(0.02, b.a + RC_LG.excite*0.12 + Math.sin(RC_LG.t*1.4 + b.p)*0.02);
            ctx.fillStyle = b.c; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 7); ctx.fill();
        });
        ctx.globalAlpha = 1;
        const beam = (bx, dir) => {
            const lg = ctx.createLinearGradient(bx, 54, bx + dir*200, G.horizon + 60);
            lg.addColorStop(0, 'rgba(255,240,190,0.12)'); lg.addColorStop(1, 'rgba(255,240,190,0)');
            ctx.fillStyle = lg;
            ctx.beginPath(); ctx.moveTo(bx - 26, 54); ctx.lineTo(bx + 26, 54);
            ctx.lineTo(bx + dir*250, G.horizon + 70); ctx.lineTo(bx + dir*130, G.horizon + 70);
            ctx.closePath(); ctx.fill();
        };
        beam(140, 1); beam(570, -1);
        // Werbebande am Horizont
        ctx.fillStyle = '#0C141F'; ctx.fillRect(10, G.horizon - 30, 688, 30);
        ctx.font = rcWarFont(11, true); ctx.textAlign = 'center';
        for (let i=0;i<4;i++){
            ctx.fillStyle = i % 2 ? '#E60000' : '#182430';
            ctx.fillRect(14 + i*171, G.horizon - 26, 167, 22);
            ctx.fillStyle = i % 2 ? '#FFFFFF' : '#7E93A8';
            ctx.fillText(i % 2 ? 'SALES LEAGUE' : 'REGIOCOM', 14 + i*171 + 83, G.horizon - 11);
        }
        ctx.textAlign = 'left';
        // Rasen mit Maehstreifen
        const g2 = ctx.createLinearGradient(0, G.horizon, 0, 604);
        g2.addColorStop(0, '#26834E'); g2.addColorStop(1, '#175F38');
        ctx.fillStyle = g2; ctx.fillRect(10, G.horizon, 688, 604 - G.horizon);
        for (let i=0;i<4;i++){ ctx.fillStyle = 'rgba(255,255,255,0.05)'; ctx.fillRect(10, G.horizon + 22 + i*46, 688, 23); }
        // Strafraum-Andeutung + Elfmeterpunkt + Torlinie
        ctx.strokeStyle = 'rgba(245,250,245,0.55)'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(348, G.horizon + 10); ctx.lineTo(318, 604); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(G.goalX, G.horizon + 4); ctx.lineTo(G.goalX, 604); ctx.stroke();
        ctx.fillStyle = 'rgba(245,250,245,0.8)';
        ctx.beginPath(); ctx.ellipse(430, G.GY + 6, 5, 2.4, 0, 0, 7); ctx.fill();
    }

    function rcLgCineGoal(ctx){
        const G = RC_CINE, rip = RC_LG.netRip;
        const backTop = G.goalTop + 26;
        ctx.strokeStyle = 'rgba(226,236,244,0.5)'; ctx.lineWidth = 1;
        for (let i=0;i<=8;i++){ const t = i/8;
            const x1 = G.goalX + (G.netX - G.goalX)*t;
            const y1 = G.goalTop + (backTop - G.goalTop)*t + Math.sin(RC_LG.t*13 + i)*rip*5;
            ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(Math.min(G.netX, x1 + 8), G.GY - t*10); ctx.stroke();
        }
        for (let j=1;j<=6;j++){ const t = j/6;
            const yl = G.goalTop + (G.GY - G.goalTop)*t + Math.sin(RC_LG.t*13 + j)*rip*4;
            const yr = backTop + (G.GY - 10 - backTop)*t;
            ctx.beginPath(); ctx.moveTo(G.goalX + 2, yl); ctx.lineTo(G.netX, yr); ctx.stroke();
        }
        ctx.strokeStyle = '#F8FAFC'; ctx.lineWidth = 6; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(G.goalX, G.GY + 2); ctx.lineTo(G.goalX, G.goalTop); ctx.lineTo(G.netX, backTop); ctx.stroke();
        ctx.lineWidth = 3.5;
        ctx.beginPath(); ctx.moveTo(G.netX, backTop); ctx.lineTo(G.netX, G.GY - 8); ctx.stroke();
    }

    // Choreografie der Nahaufnahme (Phasen 1-3 einer Szene)
    function rcLgCineDraw(ctx){
        const sc = RC_LG.scene, ev = sc.ev, G = RC_CINE, GY = G.GY;
        const durs = RC_LG_PH[sc.type], p = Math.min(1, sc.t / durs[sc.phase]);
        const who = heroName(ev.name || '');
        const isTor = sc.label.tor || (sc.type === 'elfmeter' && ev.tor);
        rcLgCineBg(ctx);
        rcLgCineGoal(ctx);
        const CFG = {
            flach:     { sx:140, bx:388, hi:false, run:true },
            schlenzer: { sx:140, bx:388, hi:true,  run:true, curve:true },
            abstauber: { sx:396, bx:486, hi:false, run:true },
            freistoss: { sx:322, bx:366, hi:true,  wall:true, curve:true },
            volley:    { sx:392, bx:392, hi:true,  cross:true },
            elfmeter:  { sx:318, bx:430, pen:true },
            parade:    { sx:140, bx:388, hi:true,  run:true, vvl:true },
            chance:    { sx:160, bx:388, hi:false, run:true }
        };
        const C = CFG[sc.type] || CFG.flach;
        const H = 200;
        let targetY = C.hi ? G.goalTop + 42 : GY - 40;
        if (C.pen) targetY = [GY - 40, (G.goalTop + GY)/2, G.goalTop + 42][ev.schuss] || GY - 40;
        sc.cineTargetY = targetY;
        const tHigh = targetY < 400;
        const ballRest = { x: C.bx + 20, y: GY - 13, r: 14 };
        const shotEnd = isTor ? { x: G.goalX + 10, y: targetY } : { x: G.keeperX - 30, y: GY - 96 };
        const ctrl = C.curve ? { x: (C.bx + shotEnd.x)/2 + 30, y: G.goalTop - 110 }
                             : { x: (C.bx + shotEnd.x)/2, y: Math.min(ballRest.y, shotEnd.y) - (C.hi ? 60 : 26) };
        const kickAt = C.cross ? 0.42 : (C.pen ? 0.52 : (C.wall ? 0.5 : 0.38));
        // Rollen: bei VVL ist der AGENT der Keeper, der Schuetze ist neutral
        const shooterNation = C.vvl ? 'XX' : ev.nation;
        const keeperNation  = C.vvl ? ev.nation : 'XX';
        // ---------- Keeper ----------
        let kx = G.keeperX, ky = GY, kRot = 0, kPose = 'set';
        let diveY = targetY;
        if (C.pen) diveY = [GY - 40, (G.goalTop + GY)/2, G.goalTop + 42][ev.keeper] || GY - 40;
        else if (isTor) diveY = tHigh ? GY - 46 : G.goalTop + 90; // Tor: falsche Ecke
        const dHigh = diveY < 400;
        let dp = 0;
        if (sc.phase === 2 && p > kickAt + 0.03) dp = rcLgEase((p - kickAt - 0.03)/(1 - kickAt - 0.03));
        if (sc.phase >= 3) dp = 1;
        if (dp > 0.02) {
            kPose = 'dive';
            kx = G.keeperX + dp*18; // hechtet zur Linie/Ecke, nicht ins Feld
            ky = GY - dp * (dHigh ? 132 : 34);
            kRot = dp * (dHigh ? 1.0 : 1.35);
            if (sc.phase >= 3) ky = Math.max(ky, GY - (dHigh ? 60 : 16)); // liegt am Boden
        }
        rcLgBigMan(ctx, kx, ky, { h: H*0.98, dir:-1, nation: keeperNation, keeper:true,
            name: (ev.name||'') + 'GK', pose: kPose, rot: kRot, ph: RC_LG.t*5,
            pw: 0, skin: C.vvl ? undefined : '#D9A87C' });
        if (C.vvl) rcLgTag(ctx, kx, ky - H - 22, who, ev.nation, true);
        // ---------- Mauer (Freistoss) ----------
        if (C.wall) [470, 504].forEach((wx, i) => {
            rcLgBigMan(ctx, wx, GY + 4, { h: 176, dir:-1, nation:'XX', name:'wall' + i, pose:'wall', ph: RC_LG.t*2 + i });
        });
        // ---------- Schuetze + Ball ----------
        let shX = C.bx - 34, shPose = 'kick', shPw = 0, shDir = 1, shRot = 0, shY2 = GY, tagY = GY - H - 24;
        let ball = { x: ballRest.x, y: ballRest.y, r: ballRest.r, rot: RC_LG.t*2, speedy: null };
        if (sc.phase === 1) {
            if (C.run) { shX = C.sx + (C.bx - 34 - C.sx) * rcLgEase(p); shPose = 'run'; shPw = 0; }
            else if (C.pen) { shX = C.sx - 40 + 40*rcLgEase(p); shPose = 'walk'; }
            else if (C.cross) {
                shX = C.bx - 6; shPose = 'set';
                const cb = rcLgEase(p);
                const q = 1 - cb;
                ball.x = q*q*36 + 2*q*cb*210 + cb*cb*(C.bx + 30);
                ball.y = q*q*262 + 2*q*cb*120 + cb*cb*318;
                ball.rot = RC_LG.t*9;
                sc.ctr.push({ x: ball.x, y: ball.y }); if (sc.ctr.length > 10) sc.ctr.shift();
            }
            else { shX = C.bx - 52; shPose = 'stand'; } // Freistoss: Anlauf-Position
            if (shPose === 'run') shPw = 0;
        } else if (sc.phase === 2) {
            if (C.cross) { // Fallrueckzieher: Sprung + Rotation
                const jp = Math.min(1, p*1.05);
                shY2 = GY - Math.sin(Math.PI*jp)*150;
                shRot = -rcLgEase(Math.min(1, p*1.1)) * 3.7;
                shX = C.bx; shPose = 'volley'; shPw = p;
                tagY = shY2 - H - 10;
                if (p <= kickAt) { ball.x = C.bx + 30; ball.y = 318 + p*26; }
            } else if (C.pen) {
                const rp = Math.min(1, p/0.5);
                shX = C.sx + (C.bx - 34 - C.sx) * rcLgEase(rp);
                shPose = rp < 1 ? 'run' : 'kick'; shPw = rp < 1 ? 0 : Math.min(1, (p - 0.5)*3.4);
            } else if (C.wall) {
                const rp = Math.min(1, p/0.42);
                shX = C.bx - 52 + 18*rcLgEase(rp);
                shPose = rp < 1 ? 'run' : 'kick'; shPw = rp < 1 ? 0 : Math.min(1, (p - 0.42)*3);
            } else { shPose = 'kick'; shPw = Math.min(1, p*1.9); }
            // Ballflug
            if (p > kickAt) {
                const bp = rcLgEase((p - kickAt)/(1 - kickAt));
                const q = 1 - bp;
                const sx0 = C.cross ? C.bx + 30 : ballRest.x, sy0 = C.cross ? 322 : ballRest.y - 4;
                ball.x = q*q*sx0 + 2*q*bp*ctrl.x + bp*bp*shotEnd.x;
                ball.y = q*q*sy0 + 2*q*bp*ctrl.y + bp*bp*shotEnd.y;
                ball.r = 14 - bp*3; ball.rot = RC_LG.t*16;
                const dxv = (shotEnd.x - sx0), dyv = (shotEnd.y - sy0), L = Math.hypot(dxv, dyv) || 1;
                ball.speedy = { x: dxv/L, y: dyv/L };
                sc.ctr.push({ x: ball.x, y: ball.y }); if (sc.ctr.length > 12) sc.ctr.shift();
                if (p - kickAt < 0.1) { // Abschuss-Blitz
                    ctx.fillStyle = 'rgba(255,255,255,' + (0.5*(1 - (p - kickAt)*10)).toFixed(2) + ')';
                    ctx.beginPath(); ctx.arc(sx0, sy0, 26, 0, 7); ctx.fill();
                }
            }
        } else { // Phase 3: Ergebnis
            if (isTor) {
                shPose = 'slide'; shDir = -1;
                shX = C.bx - 30 - rcLgEase(Math.min(1, sc.t/0.9))*170;
                tagY = GY - H*0.46 - 18;
                ball = { x: G.goalX + 30, y: targetY + 10, r: 11, rot: 0, speedy: null };
                // Grasfontaene hinter dem Rutscher
                for (let i=0;i<5;i++){
                    ctx.fillStyle = 'rgba(30,90,55,' + (0.5*Math.random()).toFixed(2) + ')';
                    ctx.fillRect(shX + 30 + Math.random()*40, GY - 8 - Math.random()*22, 3, 3);
                }
            } else {
                shPose = 'frust'; shX = C.bx - 34;
                ball = { x: kx - 34, y: ky - 26, r: 12, rot: 0, speedy: null }; // Ball sicher beim Keeper
            }
        }
        // Ball-Trail + Ball
        for (let i=0;i<sc.ctr.length;i++){
            ctx.globalAlpha = 0.35 * i / sc.ctr.length;
            ctx.fillStyle = '#FFFFFF';
            ctx.beginPath(); ctx.arc(sc.ctr[i].x, sc.ctr[i].y, 2 + 4*i/sc.ctr.length, 0, 7); ctx.fill();
        }
        ctx.globalAlpha = 1;
        rcLgBigMan(ctx, shX, shY2, { h: H, dir: shDir, nation: shooterNation,
            name: C.vvl ? 'neutral' : (ev.name || 'x'), pose: shPose, pw: shPw, rot: shRot, ph: RC_LG.t*11 });
        if (!C.vvl) rcLgTag(ctx, shX, Math.min(tagY, shY2 - H - 10), who, ev.nation, true);
        rcLgBigBall(ctx, ball.x, ball.y, ball.r, ball.rot, ball.speedy);
        // ---------- Wort-Punch ----------
        if (sc.phase === 3) {
            const word = isTor ? (sc.label.traum ? 'TRAUMTOR!' : 'TOR!') : (sc.type === 'parade' ? 'PARADE!' : 'GEHALTEN!');
            const tp = Math.min(1, sc.t / 0.35);
            const scl = 2.4 - 1.4*rcLgEase(tp);
            const al = Math.min(1, sc.t*6) * (1 - Math.max(0, sc.t - (durs[3] - 0.25))/0.25);
            if (al > 0) {
                ctx.save(); ctx.translate(330, 214); ctx.scale(scl, scl);
                ctx.globalAlpha = Math.max(0, Math.min(1, al));
                ctx.font = rcWarFont(isTor ? (sc.label.traum ? 56 : 48) : 38, true);
                ctx.textAlign = 'center'; ctx.lineJoin = 'round';
                ctx.strokeStyle = 'rgba(6,10,16,0.9)'; ctx.lineWidth = 10;
                ctx.strokeText(word, 0, 0);
                ctx.fillStyle = isTor ? (sc.label.traum ? '#FFD34D' : '#FFFFFF') : '#BFD3E6';
                ctx.fillText(word, 0, 0);
                ctx.fillStyle = '#E60000'; ctx.globalAlpha = Math.max(0, al*0.9);
                ctx.fillRect(-120*rcLgEase(tp), 14, 240*rcLgEase(tp), 6);
                ctx.restore(); ctx.globalAlpha = 1; ctx.textAlign = 'left';
            }
        }
        rcLgBanner(ctx, sc);
    }

    // ---------- Haupt-Tick des League-Modus ----------
    window.rcLeagueTick = function(dt){
        const ctx = RC_WAR.ctx; if (!ctx) return;
        rcWarResize();
        RC_LG.t += dt;
        RC_LG.tickerX -= dt * 55;
        RC_LG.netRip = Math.max(0, RC_LG.netRip - dt*1.4);
        RC_LG.excite = Math.max(0, RC_LG.excite - dt*0.35);
        RC_LG.shake = Math.max(0, RC_LG.shake - dt*14);
        // Kamera weich nachfuehren
        const cam = RC_LG.cam;
        cam.s += (cam.ts - cam.s) * Math.min(1, dt*3.2);
        cam.x += (cam.tx - cam.x) * Math.min(1, dt*3.2);
        cam.y += (cam.ty - cam.y) * Math.min(1, dt*3.2);
        // Szenen-Nachschub: Queue -> sonst Wiederholung des Tages
        if (!RC_LG.scene && RC_LG.queue.length) rcLgStart(RC_LG.queue.shift());
        else if (!RC_LG.scene) {
            RC_LG.rT -= dt;
            if (RC_LG.rT <= 0 && window.rcAllSales && window.rcAllSales.length) {
                RC_LG.rT = RC_LG.cfg.replayEvery;
                const list = window.rcAllSales;
                const s = list[RC_LG.rIdx % list.length]; RC_LG.rIdx++;
                const cls = classify((s.prod||'').toString());
                const map = { kip:'volley', mob:'freistoss', env:'flach', ptv:'schlenzer', fibDsl:'abstauber', sonstBnt:'flach' };
                rcLgStart({ type: cls.isVvl ? 'parade' : (map[cls.cat] || 'flach'), name: s.name, code: s.standort,
                    nation: rcLgNation(s.standort), prod: s.prod, time: s.timeStr, replay:true });
            }
        }
        if (RC_LG.scene) rcLgSceneTick(dt);
        // Konfetti-Physik
        RC_LG.confetti = RC_LG.confetti.filter(c => (c.t += dt) < c.dur);
        RC_LG.confetti.forEach(c => { c.vy += 150*dt; c.x += c.vx*dt; c.y += c.vy*dt; });
        // ---- Zeichnen ----
        const v = RC_WAR.view;
        ctx.setTransform(1,0,0,1,0,0);
        ctx.clearRect(0, 0, RC_WAR.canvas.width, RC_WAR.canvas.height);
        const shx = (Math.random()-0.5)*RC_LG.shake, shy = (Math.random()-0.5)*RC_LG.shake;
        ctx.setTransform(v.dpr*v.s, 0, 0, v.dpr*v.s, v.dpr*(v.ox + shx*v.s), v.dpr*(v.oy + shy*v.s));
        // Studio-Hintergrund
        ctx.fillStyle = '#0B141E'; ctx.fillRect(-8, -8, 1016, 656);
        // Stadion-Ausschnitt mit Kamera-Zoom (Clip haelt die Panels sauber)
        ctx.save();
        ctx.beginPath(); ctx.rect(10, 54, 688, 550); ctx.clip();
        const scN = RC_LG.scene;
        const cine = scN && scN.cine && scN.phase >= 1 && scN.phase <= 3;
        if (cine) {
            // TV-Schnitt: bildschirmfuellende Nahaufnahme (ohne Kamera-Zoom der Totalen)
            rcLgCineDraw(ctx);
        } else {
            ctx.translate(354, 330); ctx.scale(cam.s, cam.s); ctx.translate(-cam.x, -cam.y);
            rcLgStadium(ctx);
            if (scN) rcLgSceneDraw(ctx); else rcLgAmbient(ctx, dt);
        }
        RC_LG.confetti.forEach(c => { ctx.globalAlpha = 1 - c.t/c.dur; ctx.fillStyle = c.c; ctx.fillRect(c.x, c.y, c.w, c.w*1.6); });
        ctx.globalAlpha = 1;
        // Blenden-Wisch beim Kamerawechsel Totale <-> Nahaufnahme
        if (scN && scN.wipeT > 0) {
            ctx.setTransform(v.dpr*v.s, 0, 0, v.dpr*v.s, v.dpr*v.ox, v.dpr*v.oy);
            ctx.fillStyle = 'rgba(255,255,255,' + (0.85 * scN.wipeT / 0.26).toFixed(2) + ')';
            ctx.fillRect(10, 54, 688, 550);
        }
        ctx.restore();
        rcLgFrame(ctx);
    };

    // ---------- Vorfuehrmodus: alle Szenen einmal (Konsole: rcLeagueDemo()) ----------
    window.rcLeagueDemo = function(){
        RC_LG.forceEvening = true;
        const seq = [
            { type:'einlauf',   name:'Yilmaz Oezlem',        code:'AL' },
            { type:'chance',    name:'Kaya Emre',            code:'AL' },
            { type:'flach',     name:'Schmidt Lena',         code:'E'  },
            { type:'abstauber', name:'Papadopoulos Eleni',   code:'SER'},
            { type:'schlenzer', name:'Weber Jonas',          code:'P'  },
            { type:'freistoss', name:'Krause Deniz',         code:'B'  },
            { type:'volley',    name:'Demir Baran',          code:'SKA'},
            { type:'parade',    name:'Koutsou Maria',        code:'ADP'},
            { type:'elfmeter',  name:'Aslan Mert',           code:'AL', team:'21105083', schuss:2, keeper:0, tor:true, underdog:true }
        ];
        RC_LG.queue.length = 0;
        seq.forEach(ev => { ev.nation = rcLgNation(ev.code); rcLgQueue(ev); });
        rcLgFeed('VORFUEHRMODUS — alle Szenen der Sales League im Durchlauf');
    };

    // ============================================================
    //  SEITE 4: COCKPIT — Steuerung fuer Manager und Teamleiter
    // ============================================================
    const stdFullName = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].name) || code;
    const crPct = (z, n) => n > 0 ? +(z / n * 100).toFixed(1) : 0;
    const crTxt = (z, n) => n > 0 ? (z / n * 100).toFixed(1).replace('.', ',') + ' %' : '—';

    // ============================================================
    //  VERTRIEBS-BLOCKER-ANALYSE — welche Qualitaets-Kennzahl bremst
    //  gerade den Verkauf? Nutzt ALLE Ligalisten-Werte (WQ, ACW, AQ,
    //  FQ, CS, AHT) und verknuepft sie mit den ESL-Vertriebszahlen zu
    //  konkreten Ursache-Wirkungs-Befunden.
    // ============================================================
    window.rcBuildInsights = function(){
        const out = [];
        const kpis = Object.values(window.rcKpiData || {});
        if (!kpis.length) return out;
        const anspByCcs = {}, anspByName = {};
        if (window.rcLetzteStats) Object.values(window.rcLetzteStats.agentStats).forEach(a => {
            if (a.ccsId) anspByCcs[a.ccsId] = a.ansprachen || 0;
            anspByName[window.rcNormName(a.name)] = a.ansprachen || 0;
        });
        const anspOf = k => (k.ccsId && anspByCcs[k.ccsId] != null) ? anspByCcs[k.ccsId]
                          : (anspByName[window.rcNormName(k.agentName)] != null ? anspByName[window.rcNormName(k.agentName)] : null);
        const nm = k => heroName(k.agentName) + ' (' + normalizeStandort(k.standort) + ')';
        const pct0 = v => v.toFixed(1).replace('.', ',');
        kpis.forEach(k => {
            const calls = k.callCount || 0; if (calls < 10) return;
            const ansp = anspOf(k);
            // Weiterleitungsquote: jedes abgegebene Gespraech ist eine verlorene Verkaufschance
            if (k.wq != null && k.wq > 10) out.push({ p: 40 + k.wq, cat:'WEITERLEITUNG',
                txt: nm(k) + ' leitet ' + pct0(k.wq) + ' % weiter — ca. ' + Math.round(calls*k.wq/100) + ' Gespraeche heute ohne eigene Abschlusschance abgegeben. Erst Anliegen loesen, dann ansprechen, dann weiterleiten.' });
            // AHT unter 8 Min: keine Zeit fuer Beduerfnisanalyse UND Ansprache
            if (k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 480) out.push({ p: 62, cat:'AHT',
                txt: nm(k) + ': Ø ' + fmtAht(k.ahtSec) + ' Min pro Gespraech — zu kurz fuer Loesung UND Ansprache. Folge: FF7-Risiko + Cross-Selling faellt aus.' });
            // ACW frisst Netto-Telefonzeit
            if (k.acwSec != null && k.acwSec > 150 && k.ahtSec) out.push({ p: 28 + k.acwSec/10, cat:'NACHARBEIT',
                txt: nm(k) + ': ' + fmtAht(k.acwSec) + ' Min Nacharbeit je Call — das kostet ca. ' + Math.max(1, Math.round(calls*(k.acwSec-90)/(k.ahtSec+k.acwSec))) + ' moegliche Gespraeche am Tag.' });
            // Vertrauen da, Abschluss fehlt: CS hoch, Ansprache niedrig
            if (k.cs != null && k.cs >= 90 && ansp != null && calls >= 15 && ansp/calls < 0.3) out.push({ p: 72, cat:'POTENZIAL',
                txt: nm(k) + ': CS ' + pct0(k.cs) + ' % — die Kunden vertrauen. Aber nur ' + Math.round(ansp/calls*100) + ' % Ansprache: hier liegt der Abschluss schon bereit, er wird nur nicht abgeholt.' });
            // Auflegerquote: Kunden brechen ab, bevor eine Ansprache moeglich ist
            if (k.auflegerquote != null && k.auflegerquote < 75) out.push({ p: 95 - k.auflegerquote, cat:'AUFLEGER',
                txt: nm(k) + ': Auflegerquote ' + pct0(k.auflegerquote) + ' % — jeder vierte Kunde ist vor Gespraechsende weg. Dort stirbt jede Verkaufschance zuerst.' });
            // TNPS stark, aber kaum Feedback: gute Arbeit bleibt unsichtbar
            if (k.fq != null && k.fq < 15 && k.tnps != null && k.tnps >= 70) out.push({ p: 24, cat:'FEEDBACK',
                txt: nm(k) + ': TNPS ' + pct0(k.tnps) + ' % stark, aber nur ' + pct0(k.fq) + ' % Feedbackquote — aktiv um Bewertung bitten, sonst zaehlt die gute Arbeit nicht.' });
        });
        out.sort((a,b) => b.p - a.p);
        return out.slice(0, 14);
    };

    // Kritische Agenten: Sales-Blocker + Qualitaets-Risiken kombiniert
    function collectCritical(){
        const out = [];
        if (!window.rcLetzteStats) return out;
        Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
            const kpi = window.rcKpiForAgent(ag) || {};
            const probs = [];
            const calls = kpi.callCount || 0, anspr = ag.ansprachen || 0;
            if (calls >= 5 && anspr === 0) probs.push(['KEINE ANSPRACHE', 'rot']);
            else if (calls >= 10 && anspr / calls < 0.2) probs.push(['WENIG ANSPRACHEN', 'gelb']);
            // ESL-Tracking-Auffaelligkeiten: Liga zaehlt Calls, aber im ESL fehlen die Kontakte
            const kont = ag.kontakte || 0;
            if (calls >= 10 && kont > 0 && kont < calls * 0.4)
                probs.push(['ESL-TRACKING ' + Math.round(kont / calls * 100) + ' %', kont < calls * 0.2 ? 'rot' : 'gelb']);
            // "Trackt nur Erfolge": jeder getrackte Kontakt ist Ansprache UND fast alles Abschluss
            if (kont >= 5 && anspr >= kont && (ag.total || 0) >= kont * 0.7)
                probs.push(['TRACKT NUR ERFOLGE', 'rot']);
            if (kpi.ahtSec != null && kpi.ahtSec > 0 && kpi.ahtSec < 480 && calls >= 5) probs.push([kpi.ahtSec < 390 ? 'FF7-RISIKO ' + fmtAht(kpi.ahtSec) + ' MIN' : 'AHT UNTER 8 MIN', kpi.ahtSec < 390 ? 'rot' : 'gelb']);
            if (kpi.tnps != null && kpi.tnps < 0 && calls >= 5) probs.push(['TNPS NEGATIV', 'rot']);
            if (kpi.cs != null && kpi.cs < 50 && calls >= 5) probs.push(['CS KRITISCH', 'rot']);
            if ((kpi.det || 0) >= 2) probs.push([kpi.det + ' DETRAKTOREN', 'rot']);
            else if ((kpi.det || 0) === 1) probs.push(['1 DETRAKTOR', 'gelb']);
            if (probs.length) out.push({ ag, kpi, probs, score: probs.filter(p => p[1] === 'rot').length * 2 + probs.length });
        });
        out.sort((a, b) => b.score - a.score);
        return out;
    }

    // Outlook-Vorlage je Agent (mailto oeffnet den Standard-Mail-Client mit fertigem Text)
    function agentMailHref(x){
        const ag = x.ag, kpi = x.kpi;
        const subject = `ESL Live-Arena — Handlungsbedarf: ${ag.name} (${stdFullName(ag.standort)}, Team ${ag.team || '-'})`;
        const lines = [
            'Hallo,', '',
            `im ESL Live-Dashboard sind heute kritische Werte fuer ${ag.name} aufgefallen:`, '',
            `Standort: ${stdFullName(ag.standort)} | Team: ${ag.team || '-'}` + (ag.stack ? ` | Stack: ${ag.stack}` : ''),
            `ESL: ${ag.kontakte || 0} Kontakte | ${ag.ansprachen || 0} Ansprachen | ${ag.bnt || 0} BNT | ${ag.vvl || 0} VVL`,
        ];
        if (kpi.callCount != null) {
            let l = `Ligaliste: ${kpi.callCount} Calls`;
            if (kpi.ahtSec != null) l += ` | AHT ${fmtAht(kpi.ahtSec)} Min`;
            if (kpi.cs != null) l += ` | CS ${kpi.cs.toFixed(1).replace('.', ',')} %`;
            if (kpi.tnps != null) l += ` | TNPS ${kpi.tnps.toFixed(1).replace('.', ',')} %`;
            lines.push(l);
        }
        lines.push('', 'Auffaelligkeiten:');
        x.probs.forEach(p => lines.push('- ' + p[0]));
        lines.push('', 'Bitte zeitnah mit dem Agenten sprechen und kurz Rueckmeldung geben.', '', 'Viele Gruesse');
        return 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\r\n'));
    }

    function summaryMailHref(crit, teams){
        const subject = 'ESL Live-Arena — Tagesueberblick kritische Werte (' + new Date().toLocaleDateString('de-DE') + ')';
        const lines = ['Hallo zusammen,', '', 'Ueberblick der kritischen Punkte aus dem Live-Dashboard:', ''];
        crit.slice(0, 12).forEach(x => lines.push(`- ${x.ag.name} (${stdFullName(x.ag.standort)}, Team ${x.ag.team || '-'}): ${x.probs.map(p => p[0]).join(', ')}`));
        if (!crit.length) lines.push('- Keine kritischen Agenten — starker Tag.');
        lines.push('', 'Schwaechste Teams nach BCR-BNT (Liga-Call-Basis):');
        const ligaM = window.rcLigaAgg ? window.rcLigaAgg() : { byTeam:{} };
        teams.slice(0, 5).forEach(t => { const lcM = ligaM.byTeam[t.name] || 0;
            lines.push(`- Team ${t.name} (${stdFullName(t.standort)}): BCR-BNT ${lcM>0?crTxt(t.bnt, lcM):'—'} | BCR-VVL ${lcM>0?crTxt(t.vvl, lcM):'—'} | ${t.pitches} Ansprachen bei ${lcM>0?lcM+' Liga-Calls':t.calls+' ESL-Kontakten'}`); });
        lines.push('', 'Details im Dashboard (Seite Cockpit) oder im Excel-Export.', '', 'Viele Gruesse');
        return 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\r\n'));
    }

    window.renderCockpit = function(){
        if (!window.rcLetzteStats) return;
        const { agentStats, standortStats, teamStats } = window.rcLetzteStats;
        const stds = Object.values(standortStats).filter(s => s.calls > 0);
        const sum = k => stds.reduce((s, x) => s + (x[k] || 0), 0);
        const kont = sum('calls'), ansp = sum('pitches'), bnt = sum('bnt'), vvl = sum('vvl');
        // BCR-BNT / BCR-VVL IMMER auf Liga-Call-Basis — ESL-Kontakte sind als Nenner
        // unbrauchbar (Agenten tracken unvollstaendig; ohne Liga-Daten '—' statt Muell)
        const liga = window.rcLigaAgg ? window.rcLigaAgg() : { byStd:{}, byTeam:{}, total:0 };
        const setV = (id, html) => { const e = document.getElementById(id); if (e) e.innerHTML = html; };
        setV('ckKontakte', kont.toLocaleString('de-DE'));
        setV('ckAnspr', `${ansp}<small>${liga.total ? crTxt(ansp, liga.total) + ' der Liga-Calls' : crTxt(ansp, kont)}</small>`);
        setV('ckBnt', `${bnt}<small>${liga.total ? 'BCR-BNT ' + crTxt(bnt, liga.total) : '— Liga-Quelle fehlt'}</small>`);
        setV('ckVvl', `${vvl}<small>${liga.total ? 'BCR-VVL ' + crTxt(vvl, liga.total) : crTxt(vvl, kont)}</small>`);

        const crit = collectCritical();
        setV('ckKrit', crit.length);

        // BNT-Pace: lineare Hochrechnung des Tages (ab 8 Uhr) auf 18 Uhr
        const pc = window.rcPace;
        if (pc) {
            const base = pc.bnt != null ? pc.bnt : pc.bcr;
            const elapsed = (pc.nowH + pc.nowMin/60) - 8;
            const proj = (elapsed >= 1 && pc.nowH < 18) ? Math.round(base / elapsed * 10) : null;
            setV('ckPace', proj != null ? `${proj}<small>bei aktuellem Tempo</small>` : (pc.nowH >= 18 ? `${base}<small>Endstand</small>` : '—'));
        }

        // Ablehnungsgruende-Pareto: die haeufigsten Einwaende = direktester Coaching-Hebel
        const reasonsEl = document.getElementById('rcCkReasons');
        if (reasonsEl) {
            const rr = Object.entries(window.rcRejReasons || {}).sort((a,b) => b[1]-a[1]).slice(0,6);
            const rMax = rr.length ? rr[0][1] : 1;
            reasonsEl.innerHTML = rr.length ? rr.map(([grund,cnt], i) => `<div style="margin-bottom:7px;">
                    <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:2px;">
                        <span style="font-weight:700; color:#F5F5F5; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:78%;" title="${grund}">${i+1}. ${grund}</span>
                        <span class="rc-mono" style="color:${i===0?'#E60000':'#4A4D4E'};">${cnt}x</span>
                    </div>
                    <div class="rc-bar-track"><div class="rc-bar-fill" style="background:${i===0?'#E60000':'#8C8C8C'}; width:${Math.max(5,cnt/rMax*100)}%;"></div></div>
                </div>`).join('') : `<div style="padding:10px; color:#9C9C9C; font-size:11px;">Keine Ablehnungsgruende erfasst</div>`;
        }
        // Vertriebs-Blocker: die Ligalisten-Kennzahlen erklaeren die Vertriebsquote
        const insEl = document.getElementById('rcCkInsights');
        if (insEl) {
            const CAT_COL = { WEITERLEITUNG:'#FF6666', AHT:'#E60000', NACHARBEIT:'#FF6666', POTENZIAL:'#F5F5F5', AUFLEGER:'#E60000', FEEDBACK:'#9C9C9C' };
            const ins = window.rcBuildInsights ? window.rcBuildInsights() : [];
            insEl.innerHTML = ins.length ? ins.map(x => `<div style="padding:7px 10px; margin-bottom:5px; background:#232323; border-left:3px solid ${CAT_COL[x.cat]||'#9C9C9C'}; border-radius:4px;">
                    <div style="font-size:8.5px; font-weight:700; letter-spacing:0.5px; color:${CAT_COL[x.cat]||'#9C9C9C'};">${x.cat}</div>
                    <div style="font-size:11px; color:#DCDCDC; line-height:1.35;">${x.txt}</div>
                </div>`).join('')
                : `<div style="padding:10px; color:#9C9C9C; font-size:11px;">Keine Blocker erkannt — oder KPI-Quelle noch nicht verbunden</div>`;
        }
        const kritEl = document.getElementById('rcCkKrit');
        if (kritEl) kritEl.innerHTML = crit.length ? crit.slice(0, 25).map(x => `<div class="rc-warn-item${x.probs.some(p => p[1] === 'rot') ? ' hart' : ''}" data-rc-vo="${rcAttr(x.ag.vo)}" data-rc-name="${rcAttr(x.ag.name)}" style="flex-wrap:wrap;">
                <span class="nm">${getFlagSvg(x.ag.standort, 'small')} ${x.ag.name} <span class="rc-mono" style="color:#9A9A9A; font-size:9px; font-weight:400;">${x.ag.team || ''}</span></span>
                <a class="rc-mailbtn" href="${agentMailHref(x)}">Mail</a>
                <div style="width:100%; margin-top:3px;">${x.probs.map(p => `<span class="rc-chip ${p[1]}">${p[0]}</span>`).join('')}</div>
            </div>`).join('') : `<div style="padding:10px; color:#F5F5F5; font-weight:700; font-size:11px;">Keine kritischen Agenten — starker Tag</div>`;

        // Team-Vergleich: alle Teams mit Vertrieb + Qualitaet, frei sortierbar.
        // Ohne Liga-Zuordnung (Mapping fehlt) werden Quoten als '—' gezeigt (nie falsche ESL-Quote).
        const teamLiga = t => liga.byTeam[t.name] || 0;
        const teamRows = Object.values(teamStats).filter(t => t.calls > 0).map(t => {
            const lc = teamLiga(t);
            const q = rcTeamQualiAgg(t.code) || {};
            return { t, code:t.code, name:t.name, standort:t.standort, stack:t.stack, lc,
                calls: lc > 0 ? lc : t.calls,
                anspr: lc > 0 ? (t.pitches / lc * 100) : null,
                bnt: t.bnt || 0,
                bcrBnt: lc > 0 ? ((t.bnt || 0) / lc * 100) : null,
                vvl: t.vvl || 0,
                bcrVvl: lc > 0 ? ((t.vvl || 0) / lc * 100) : null,
                cs: (q.cs != null ? q.cs : null),
                tnps: (q.tnps != null ? q.tnps : null) };
        });
        const sort = window.rcCkTeamSort || { key:'bcrBnt', dir:'asc' };  // Default: schwaechste BCR-BNT zuerst
        teamRows.sort((a,b) => {
            if (sort.key === 'name') return sort.dir==='asc' ? String(a.name).localeCompare(String(b.name)) : String(b.name).localeCompare(String(a.name));
            let av=a[sort.key], bv=b[sort.key];
            if (av==null && bv==null) return 0;
            if (av==null) return 1; if (bv==null) return -1;   // fehlende Werte immer ans Ende
            return sort.dir==='asc' ? av-bv : bv-av;
        });
        const pct0 = v => v!=null ? v.toFixed(1).replace('.',',')+'%' : '—';
        const tmEl = document.getElementById('rcCkTeams');
        if (tmEl) tmEl.innerHTML = teamRows.map(r => `<tr data-rc-team="${rcAttr(r.code)}" title="Klick: Team-Details">
                <td><b style="font-size:11px;">Team ${r.name}</b><div class="rc-mono" style="color:#9A9A9A; font-size:8.5px; font-weight:400;">${shortName(r.standort)}${r.stack ? ' · ' + r.stack : ''}</div></td>
                <td style="text-align:center;" class="rc-mono">${r.calls}</td>
                <td style="text-align:center; color:${zielColor(r.anspr, {min:40})};" class="rc-mono">${pct0(r.anspr)}</td>
                <td style="text-align:center; color:#F5F5F5; font-weight:700;" class="rc-mono">${r.bnt}</td>
                <td style="text-align:center;" class="rc-mono">${pct0(r.bcrBnt)}</td>
                <td style="text-align:center; color:#9C9C9C;" class="rc-mono">${r.vvl}</td>
                <td style="text-align:center;" class="rc-mono">${pct0(r.bcrVvl)}</td>
                <td style="text-align:center; color:${zielColor(r.cs, RC_ZIELE.cs)};" class="rc-mono">${r.cs!=null?r.cs.toFixed(0)+'%':'—'}</td>
                <td style="text-align:center; color:${zielColor(r.tnps, RC_ZIELE.tnps)};" class="rc-mono">${r.tnps!=null?r.tnps.toFixed(0)+'%':'—'}</td>
            </tr>`).join('') || `<tr><td colspan="9" style="text-align:center; padding:18px; color:#9C9C9C;">Keine Team-Daten</td></tr>`;
        // Sortier-Pfeil im aktiven Spaltenkopf
        document.querySelectorAll('.rc-ck-teamtable thead th[data-ck-sort]').forEach(th => {
            const base = th.dataset.ckLabel || (th.dataset.ckLabel = th.textContent.replace(/[▲▼]/g,'').trim());
            th.textContent = base + (th.dataset.ckSort === sort.key ? (sort.dir==='asc'?' ▲':' ▼') : '');
        });

        const stdEl = document.getElementById('rcCkStd');
        if (stdEl) stdEl.innerHTML = stds.slice().sort((a, b) => b.total - a.total).map(s => { const lc = liga.byStd[s.code] || 0; return `<tr data-rc-std="${rcAttr(s.code)}" title="Klick: Standort-Details">
                <td><b style="font-size:11px;">${getFlagSvg(s.code, 'small')} ${shortName(s.code)}</b></td>
                <td style="text-align:center;" class="rc-mono">${lc > 0 ? lc : s.calls}</td>
                <td style="text-align:center; color:#F5F5F5;" class="rc-mono">${s.bnt || 0}</td>
                <td style="text-align:center;" class="rc-mono">${lc > 0 ? crTxt(s.bnt || 0, lc) : '—'}</td>
                <td style="text-align:center; color:#9C9C9C;" class="rc-mono">${s.vvl}</td>
                <td style="text-align:center;" class="rc-mono">${lc > 0 ? crTxt(s.vvl, lc) : '—'}</td>
            </tr>`; }).join('') || `<tr><td colspan="6" style="text-align:center; padding:18px; color:#9C9C9C;">Keine Daten</td></tr>`;

        const mailAll = document.getElementById('ckBtnMailAll');
        if (mailAll) mailAll.href = summaryMailHref(crit, teamRows.map(r => r.t));
        if (window.renderTrendHist) window.renderTrendHist();
        if (window.rcRenderCkExtra) window.rcRenderCkExtra();
    };

    // ============================================================
    //  COCKPIT v2 — Management-Statistik: Produktklassen, Matrix, Charts, Cross-Selling
    //  Panels lesen aus den (bereits nach Standort/Team/Stack gefilterten) Live-Stats.
    //  Historie-Trends wenden den Filter selbst an (byAgent -> Scope via Mapping/Live).
    // ============================================================
    // Validierte, dunkle Produktklassen-Palette (Dataviz-geprueft) + feste Stapel-Reihenfolge.
    // 'vvl' aggregiert kipVvl+mobVvl+fibVvl (Historie kennt nur die VVL-Summe).
    const RC_CK_CLASSES = [
        { key:'kip',      label:'KIP-BNT',       short:'KIP',  col:'#C98500' },
        { key:'mob',      label:'Mobilfunk-BNT', short:'MOB',  col:'#3987E5' },
        { key:'env',      label:'ENV-BNT',       short:'ENV',  col:'#008300' },
        { key:'fibDsl',   label:'DSL/FIB-BNT',   short:'DSL',  col:'#199E70' },
        { key:'ptv',      label:'PTV',           short:'PTV',  col:'#9085E9' },
        { key:'sonstBnt', label:'sonst BNT',     short:'BNT',  col:'#D95926' },
        { key:'vvl',      label:'VVL',           short:'VVL',  col:'#D55181' }
    ];
    function rcCkVal(o, key){ if (!o) return 0; if (key === 'vvl') return (o.kipVvl||0)+(o.mobVvl||0)+(o.fibVvl||0); return o[key]||0; }
    function rcCkBntSum(o){ return o ? (o.kip||0)+(o.mob||0)+(o.env||0)+(o.fibDsl||0)+(o.ptv||0)+(o.sonstBnt||0) : 0; }
    function rcCkGesamt(o){ return rcCkBntSum(o) + rcCkVal(o,'vvl'); }
    function rcCkFilters(){ return {
        std:  ((document.getElementById('rcStandortFilter')||{}).value) || 'ALL',
        team: ((document.getElementById('rcTeamFilter')||{}).value) || 'ALL',
        stack:((document.getElementById('rcStackFilter')||{}).value) || 'ALL' }; }

    // STUFE 1 — Produktklassen-KPIs. Summiert die (gefilterten) Standort-Stats je Klasse.
    function renderCkClassKpis(){
        const box = document.getElementById('rcCkClassKpis'); if (!box) return;
        const st = window.rcLetzteStats;
        const stds = st ? Object.values(st.standortStats).filter(s => s.calls > 0) : [];
        const tot = {}; RC_CK_CLASSES.forEach(c => { tot[c.key] = 0; });
        stds.forEach(s => RC_CK_CLASSES.forEach(c => { tot[c.key] += rcCkVal(s, c.key); }));
        const bntSum = RC_CK_CLASSES.reduce((a,c) => a + (c.key!=='vvl' ? tot[c.key] : 0), 0);
        box.innerHTML = RC_CK_CLASSES.map(c => {
            const v = tot[c.key];
            const sub = (c.key === 'vvl') ? 'Vertragsverlaeng.' : (bntSum > 0 ? Math.round(v/bntSum*100) + ' % der BNT' : '&mdash;');
            return `<div class="rc-ck-clstile" style="border-top-color:${c.col};">
                <div class="l"><i class="rc-ck-dot" style="background:${c.col};"></i>${c.label}</div>
                <div class="v" style="color:${v>0?c.col:'#5A5A5A'};">${v}</div>
                <div class="s">${sub}</div>
            </div>`;
        }).join('');
    }

    // STUFE 2/3/4 — in den folgenden Stufen implementiert (Stubs halten die Datei lauffaehig)
    // STUFE 2 — Produktklassen-Matrix: Standort -> (Klick) Teams -> (Klick) Agenten.
    // Alle Ebenen lesen aus den bereits gefilterten Live-Stats; Spalten sind sortierbar.
    function renderCkMatrix(){
        const body = document.getElementById('rcCkMatrix'); if (!body) return;
        const head = document.getElementById('rcCkMatrixHead');
        const st = window.rcLetzteStats;
        const stds = st ? Object.values(st.standortStats).filter(s => s.calls > 0) : [];
        const sort = window.rcCkMatrixSort || { key:'gesamt', dir:'desc' };
        const arrow = k => sort.key === k ? (sort.dir === 'asc' ? ' ▲' : ' ▼') : '';
        if (head) head.innerHTML = `<tr>
            <th data-ck-msort="name">Standort / Team / Agent${arrow('name')}</th>
            ${RC_CK_CLASSES.map(c => `<th data-ck-msort="${c.key}" title="${c.label}"><span style="display:inline-flex; align-items:center; gap:4px; justify-content:center;"><i class="rc-ck-dot" style="background:${c.col};"></i>${c.short}</span>${arrow(c.key)}</th>`).join('')}
            <th data-ck-msort="gesamt">Gesamt${arrow('gesamt')}</th>
        </tr>`;
        const span = RC_CK_CLASSES.length + 2;
        if (!stds.length) { body.innerHTML = `<tr><td colspan="${span}" style="padding:16px; color:#9C9C9C; text-align:left;">Keine Daten &mdash; warte auf Daten</td></tr>`; return; }

        const sortVal = o => sort.key === 'gesamt' ? rcCkGesamt(o) : rcCkVal(o, sort.key);
        const cmp = (a, b, na, nb) => {
            if (sort.key === 'name') return sort.dir === 'asc' ? String(na).localeCompare(String(nb)) : String(nb).localeCompare(String(na));
            const av = sortVal(a), bv = sortVal(b);
            return sort.dir === 'asc' ? av - bv : bv - av;
        };
        const cells = o => RC_CK_CLASSES.map(c => { const v = rcCkVal(o, c.key); return `<td class="${v > 0 ? '' : 'rc-ck-zero'}">${v}</td>`; }).join('') + `<td class="rc-ck-gcell">${rcCkGesamt(o)}</td>`;
        const teamStats = st.teamStats || {}, agentStats = st.agentStats || {};

        const rows = [];
        stds.slice().sort((a, b) => cmp(a, b, shortName(a.code), shortName(b.code))).forEach(s => {
            const openS = window.rcCkExpStd.has(s.code);
            rows.push(`<tr class="rc-ckm-std" data-ck-toggle="std:${rcAttr(s.code)}" title="Klick: Teams ein-/ausklappen">
                <td><span class="rc-ckm-caret">${openS ? '▼' : '▶'}</span>${getFlagSvg(s.code, 'small')} ${stdFullName(s.code)}</td>${cells(s)}</tr>`);
            if (!openS) return;
            const teams = Object.values(teamStats).filter(t => t.standort === s.code && (t.calls > 0 || rcCkGesamt(t) > 0));
            if (!teams.length) rows.push(`<tr class="rc-ckm-team"><td>keine Teams</td>${RC_CK_CLASSES.map(() => '<td>&mdash;</td>').join('')}<td>&mdash;</td></tr>`);
            teams.slice().sort((a, b) => cmp(a, b, a.name, b.name)).forEach(t => {
                const tkey = s.code + '|' + t.code;
                const openT = window.rcCkExpTeam.has(tkey);
                rows.push(`<tr class="rc-ckm-team" data-ck-toggle="team:${rcAttr(tkey)}" title="Klick: Agenten ein-/ausklappen">
                    <td><span class="rc-ckm-caret">${openT ? '▼' : '▶'}</span>Team ${rcAttr(t.name)}</td>${cells(t)}</tr>`);
                if (!openT) return;
                const agents = Object.values(agentStats).filter(a => (a.team || '') === t.code && a.standort === s.code);
                if (!agents.length) { rows.push(`<tr class="rc-ckm-agent"><td>keine Agenten erfasst</td>${RC_CK_CLASSES.map(() => '<td>&mdash;</td>').join('')}<td>&mdash;</td></tr>`); return; }
                agents.slice().sort((a, b) => cmp(a, b, a.name, b.name)).forEach(a => {
                    rows.push(`<tr class="rc-ckm-agent" data-rc-vo="${rcAttr(a.vo)}" data-rc-name="${rcAttr(a.name)}" title="Klick: Agenten-Details">
                        <td>${a.name}</td>${cells(a)}</tr>`);
                });
            });
        });
        body.innerHTML = rows.join('');
    }
    // STUFE 3a — Produktmix je Standort: ein horizontaler, gestapelter Balken pro Standort.
    // Segmente in fester Palette-Reihenfolge, 2px-Luecke (Border in Kartenfarbe), Legende darunter.
    function renderCkMix(){
        const ctx = document.getElementById('rcCkMix');
        const legend = document.getElementById('rcCkMixLegend');
        if (!ctx || !window.Chart) return;
        const st = window.rcLetzteStats;
        const stds = (st ? Object.values(st.standortStats).filter(s => s.calls > 0) : []).slice()
            .sort((a, b) => rcCkGesamt(b) - rcCkGesamt(a));
        if (legend) legend.innerHTML = RC_CK_CLASSES.map(c => `<span><i class="rc-ck-dot" style="background:${c.col};"></i>${c.label}</span>`).join('');
        if (window.rcCkMixChart) { try { window.rcCkMixChart.destroy(); } catch(e){} window.rcCkMixChart = null; }
        if (!stds.length) return;
        const labels = stds.map(s => shortName(s.code));
        const datasets = RC_CK_CLASSES.map(c => ({
            label: c.label,
            data: stds.map(s => rcCkVal(s, c.key)),
            backgroundColor: c.col,
            borderColor: '#1D1D1D',
            borderWidth: { top: 0, bottom: 0, left: 2, right: 2 },
            borderSkipped: false,
            stack: 'mix'
        }));
        window.rcCkMixChart = new Chart(ctx, {
            type: 'bar',
            data: { labels, datasets },
            options: { indexAxis: 'y', responsive: true, maintainAspectRatio: false, animation: { duration: 600 },
                plugins: { legend: { display: false },
                    tooltip: { backgroundColor: '#1D1D1D', titleColor: '#F5F5F5', bodyColor: '#C9C9C9', borderColor: '#3E3E3E', borderWidth: 1,
                        callbacks: { label: it => ' ' + it.dataset.label + ': ' + it.parsed.x } } },
                scales: {
                    x: { stacked: true, grid: { color: 'rgba(255,255,255,0.06)' }, ticks: { color: '#9C9C9C', font: { size: 9 }, precision: 0 }, beginAtZero: true },
                    y: { stacked: true, grid: { display: false }, ticks: { color: '#C9C9C9', font: { size: 10, weight: '700' } } } } }
        });
    }
    // STUFE 3b — Trend ueber 7 Vortage + heute. Umschaltbar: BNT gesamt / KIP-BNT / Mobilfunk-BNT / VVL.
    // (Nur diese 4, weil die ESL-Historie pro Agent genau kip/mob/bnt/vvl fuehrt.)
    // Filter wird respektiert: byAgent-Werte werden ueber vo->Standort/Team/Stack gefiltert.
    function renderCkTrend(){
        const ctx = document.getElementById('rcCkTrend'); if (!ctx || !window.Chart) return;
        const metric = window.rcCkTrendMetric || 'bnt';
        const META = { bnt:{label:'BNT gesamt', col:'#E60000'}, kip:{label:'KIP-BNT', col:'#C98500'}, mob:{label:'Mobilfunk-BNT', col:'#3987E5'}, vvl:{label:'VVL', col:'#D55181'} };
        const m = META[metric] || META.bnt;
        const f = rcCkFilters();
        const filterActive = !(f.std === 'ALL' && f.team === 'ALL' && f.stack === 'ALL');
        const voMap = (window.rcWcaMapping && window.rcWcaMapping.voMap) || {};
        const stackMap = (window.rcWcaMapping && window.rcWcaMapping.stackMap) || {};
        const liveAg = (window.rcLetzteStats && window.rcLetzteStats.agentStats) || {};
        const scopeOf = vo => {
            const mm = voMap[vo] || {}, la = liveAg[vo] || {};
            const std = normalizeStandort(mm.standort || la.standort || '');
            const team = ((mm.team || la.team || '') + '').trim();
            const stack = (mm.team && stackMap[mm.team]) || la.stack || (window.rcStackOf ? window.rcStackOf(team) : '') || '';
            return { std, team, stack };
        };
        const inScope = vo => {
            if (!filterActive) return true;
            const sc = scopeOf(vo);
            if (f.std !== 'ALL' && sc.std !== f.std) return false;
            if (f.team !== 'ALL' && sc.team !== f.team) return false;
            if (f.stack !== 'ALL' && sc.stack !== f.stack) return false;
            return true;
        };
        const mVal = e => metric === 'bnt' ? (e.bnt || 0) : metric === 'vvl' ? (e.vvl || 0) : metric === 'kip' ? (e.kip || 0) : (e.mob || 0);
        const hist = window.rcEslHistory || (typeof rcLoadEslHistory === 'function' ? rcLoadEslHistory() : {}) || {};
        const WD = ['So','Mo','Di','Mi','Do','Fr','Sa'];
        const labels = [], data = [];
        for (let d = 7; d >= 1; d--) {
            const dt = new Date(Date.now() - d * 86400000);
            const key = dt.getFullYear() + '-' + pad2(dt.getMonth() + 1) + '-' + pad2(dt.getDate());
            labels.push(WD[dt.getDay()] + ' ' + pad2(dt.getDate()) + '.' + pad2(dt.getMonth() + 1) + '.');
            const h = hist[key];
            if (!h) { data.push(null); continue; }
            let val;
            if ((metric === 'bnt' || metric === 'vvl') && !filterActive) {
                val = (h[metric] != null) ? h[metric] : 0;
            } else if (h.byAgent) {
                val = 0; Object.keys(h.byAgent).forEach(vo => { if (inScope(vo)) val += mVal(h.byAgent[vo]); });
            } else {
                val = (metric === 'bnt' || metric === 'vvl') ? (filterActive ? 0 : (h[metric] || 0)) : null;
            }
            data.push(val);
        }
        // Heute aus den (gefilterten) Live-Standort-Stats
        const stds = (window.rcLetzteStats) ? Object.values(window.rcLetzteStats.standortStats).filter(s => s.calls > 0) : [];
        const todayVal = stds.reduce((a, s) => a + (metric === 'bnt' ? rcCkBntSum(s) : metric === 'vvl' ? rcCkVal(s, 'vvl') : rcCkVal(s, metric)), 0);
        labels.push('Heute'); data.push(todayVal);
        const pts = data.map((v, i) => i === data.length - 1 ? '#F5F5F5' : m.col);
        if (window.rcCkTrendChart) { try { window.rcCkTrendChart.destroy(); } catch(e){} window.rcCkTrendChart = null; }
        window.rcCkTrendChart = new Chart(ctx, {
            type: 'line',
            data: { labels, datasets: [{ label: m.label, data, borderColor: m.col, backgroundColor: m.col,
                pointBackgroundColor: pts, pointBorderColor: pts, pointRadius: 3, pointHoverRadius: 5,
                borderWidth: 2.6, tension: 0.25, spanGaps: true, fill: false }] },
            options: { responsive: true, maintainAspectRatio: false, animation: { duration: 600 },
                plugins: { legend: { display: false },
                    tooltip: { backgroundColor: '#1D1D1D', titleColor: '#F5F5F5', bodyColor: '#C9C9C9', borderColor: '#3E3E3E', borderWidth: 1,
                        callbacks: { label: it => ' ' + m.label + ': ' + (it.parsed.y == null ? '—' : it.parsed.y) } } },
                scales: { x: { grid: { display: false }, ticks: { color: '#9C9C9C', font: { size: 9 } } },
                    y: { grid: { color: 'rgba(255,255,255,0.07)' }, ticks: { color: '#9C9C9C', font: { size: 9 }, precision: 0 }, beginAtZero: true } } }
        });
    }
    // STUFE 4 — Cross-Selling KIP x Mobilfunk. Coaching-Ziel: wer verkauft beide Welten,
    // wer bleibt einseitig. Team-Zeile = KIP/MOB-Summe + Luecken-Tag; Klick -> Agenten mit
    // gruener Zahl (hat) bzw. rotem "–" (Luecke = kein Cross-Selling).
    function renderCkCross(){
        const box = document.getElementById('rcCkCross'); if (!box) return;
        const st = window.rcLetzteStats;
        if (!st) { box.innerHTML = '<div style="padding:14px; color:#9C9C9C; font-size:11px;">Warte auf Daten</div>'; return; }
        const teams = Object.values(st.teamStats).filter(t => t.calls > 0 || rcCkGesamt(t) > 0);
        if (!teams.length) { box.innerHTML = '<div style="padding:14px; color:#9C9C9C; font-size:11px;">Keine Team-Daten</div>'; return; }
        const agentStats = st.agentStats || {};
        const OK = '#4FB552', GAP = '#EB9700', BAD = '#E60000', NEU = '#7E7E7E';
        const pill = v => v > 0
            ? `<span style="background:rgba(63,150,66,0.16); color:#4FB552; border:1px solid rgba(63,150,66,0.5); border-radius:9999px; padding:1px 9px; font-weight:700; font-variant-numeric:tabular-nums;">${v}</span>`
            : `<span style="background:rgba(230,0,0,0.12); color:#FF6B6B; border:1px solid rgba(230,0,0,0.45); border-radius:9999px; padding:1px 10px; font-weight:700;">–</span>`;
        const info = teams.map(t => {
            const ags = Object.values(agentStats).filter(a => (a.team || '') === t.code && a.standort === t.standort);
            let both = 0, onlyKip = 0, onlyMob = 0, none = 0;
            ags.forEach(a => { const k = (a.kip || 0) > 0, m = (a.mob || 0) > 0; if (k && m) both++; else if (k) onlyKip++; else if (m) onlyMob++; else none++; });
            return { t, ags, kip: t.kip || 0, mob: t.mob || 0, both, onlyKip, onlyMob, none, sellers: both + onlyKip + onlyMob };
        });
        // Coaching-Prioritaet: die einseitigsten Teams zuerst
        info.sort((a, b) => (b.onlyKip + b.onlyMob) - (a.onlyKip + a.onlyMob) || rcCkGesamt(b.t) - rcCkGesamt(a.t));
        box.innerHTML = info.map(ti => {
            const t = ti.t;
            let tag, col;
            if (ti.kip > 0 && ti.mob > 0) {
                if (ti.onlyKip + ti.onlyMob === 0) { tag = 'Cross aktiv'; col = OK; }
                else { tag = (ti.onlyKip + ti.onlyMob) + ' einseitig'; col = GAP; }
            } else if (ti.mob > 0 && ti.kip === 0) { tag = 'Mobilfunk ohne KIP'; col = BAD; }
            else if (ti.kip > 0 && ti.mob === 0) { tag = 'KIP ohne Mobilfunk'; col = GAP; }
            else { tag = 'kein KIP/MOB'; col = NEU; }
            const open = window.rcCkExpCross.has(t.code);
            let html = `<div class="rc-ck-crossrow" data-ck-cross="${rcAttr(t.code)}" style="border-left-color:${col};" title="Klick: Agenten ein-/ausklappen">
                <span class="rc-ckm-caret">${open ? '▼' : '▶'}</span>
                <span class="nm" style="flex:1;">${getFlagSvg(t.standort, 'small')} Team ${rcAttr(t.name)} <span style="color:#9C9C9C; font-weight:400; font-size:9px;">${shortName(t.standort)}${t.stack ? ' · ' + t.stack : ''}</span></span>
                <span style="width:78px; text-align:right;"><span style="color:#C98500; font-size:9px; font-weight:700;">KIP</span> <b class="rc-ck-num" style="color:${ti.kip > 0 ? '#C98500' : '#5A5A5A'};">${ti.kip}</b></span>
                <span style="width:78px; text-align:right;"><span style="color:#3987E5; font-size:9px; font-weight:700;">MOB</span> <b class="rc-ck-num" style="color:${ti.mob > 0 ? '#3987E5' : '#5A5A5A'};">${ti.mob}</b></span>
                <span style="width:96px; text-align:center; font-size:9px; color:#9C9C9C;">${ti.both}/${ti.sellers || 0} machen beides</span>
                <span class="rc-ck-crosstag" style="background:${col === NEU ? 'rgba(126,126,126,0.15)' : (col === OK ? 'rgba(63,150,66,0.16)' : (col === GAP ? 'rgba(235,151,0,0.16)' : 'rgba(230,0,0,0.16)'))}; color:${col === OK ? '#4FB552' : col}; border:1px solid ${col};">${tag}</span>
            </div>`;
            if (open) {
                const ags = ti.ags.slice().sort((a, b) => rcCkGesamt(b) - rcCkGesamt(a));
                if (!ags.length) html += `<div class="rc-ck-agentrow">keine Agenten erfasst</div>`;
                ags.forEach(a => {
                    const k = a.kip || 0, m = a.mob || 0;
                    html += `<div class="rc-ck-agentrow" data-rc-vo="${rcAttr(a.vo)}" data-rc-name="${rcAttr(a.name)}" title="Klick: Agenten-Details">
                        <span style="flex:1;">${a.name}</span>
                        <span style="width:80px; text-align:right;"><span style="color:#C98500; font-size:9px; font-weight:700;">KIP</span> ${pill(k)}</span>
                        <span style="width:90px; text-align:right;"><span style="color:#3987E5; font-size:9px; font-weight:700;">MOB</span> ${pill(m)}</span>
                    </div>`;
                });
            }
            return html;
        }).join('');
    }

    // Dispatcher: jedes Panel isoliert (ein Fehler darf die anderen nicht mitreissen)
    window.rcRenderCkExtra = function(){
        const safe = (fn, tag) => { try { fn(); } catch(e){ try { rcLog.log('cockpit/' + tag, e && e.message); } catch(_){} } };
        safe(renderCkClassKpis, 'classkpis');
        safe(renderCkMatrix, 'matrix');
        safe(renderCkMix, 'mix');
        safe(renderCkTrend, 'trend');
        safe(renderCkCross, 'cross');
    };

    // ============================================================
    //  EXCEL-EXPORT — regiocom CD, 6 Blaetter, berechnete CR%
    //  Styling via xlsx-js-style (Drop-in-Fork); Fallback: normale SheetJS ohne Farben
    // ============================================================
    function rcLoadStyledXlsx(cb){
        if (window.rcXLSXS) return cb(window.rcXLSXS);
        const prev = window.XLSX;
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js';
        s.onload = function(){
            const x = window.XLSX || prev;
            x.__styled = (x !== prev);          // Fork geladen -> Styling verfuegbar
            window.XLSX = prev;                  // Original-Instanz fuer den Import unangetastet lassen
            window.rcXLSXS = x; cb(x);
        };
        s.onerror = function(){
            const fb = prev || window.XLSX;
            if (!fb) { alert('XLSX-Bibliothek nicht verfuegbar.'); return; }
            fb.__styled = false; window.rcXLSXS = fb;
            rcLog.log('Styling-CDN blockiert -> Export ohne Farben (Daten korrekt)');
            cb(fb);
        };
        document.head.appendChild(s);
    }

    // Ein Agent/eine Zeile "hat Daten", wenn IRGENDEIN Signal vorliegt: Liga-Calls,
    // ESL-Kontakte, Ansprache, Abschluss (BNT/VVL/KIP/MOB) ODER eine gemessene
    // Qualitaets-Kennzahl (CS/TNPS/AHT/...). Nur komplett leere Zeilen (0 Calls,
    // 0 Kontakte, keine Kennzahl) fliegen aus dem Export — sonst landen z.B.
    // Liga-Agenten mit 0 Calls als reine Leerzeilen im Bericht.
    function rcStandRowHasData(r){
        if ((r.calls||0) > 0 || (r.ansp||0) > 0) return true;
        if ((r.bnt||0) > 0 || (r.vvl||0) > 0 || (r.mob||0) > 0 || (r.kip||0) > 0) return true;
        if ((r.ahtSec != null && r.ahtSec > 0) || (r.detr != null && r.detr > 0)) return true;
        return [r.aq, r.cs, r.tnps, r.fq, r.dds, r.ftf].some(o => o && o.v != null);
    }

    // ============================================================
    //  "AKTUELLER STAND" — Datenbeschaffung fuer beliebige Tage.
    //  live (dayKey null/heute): rcKpiData + agentStats;
    //  Vortag: rcLigaHistory.byAgent (inkl. Zaehler/FTF ab Crawler v3.6)
    //          + rcEslHistory.byAgent (inkl. mob/kip ab v22-Update).
    //  Scope = aktive Dashboard-Filter (Standort/Team/Stack).
    // ============================================================
    function rcStandRows(dayKey, scope){
        const tKey = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date());
        const live = !dayKey || dayKey === tKey;
        // Scope wahlweise uebergeben (Zeitraum-Modal mit eigenem Standort) ODER aus den Dashboard-Filtern
        const fvE = (scope && scope.std   != null) ? scope.std   : ((document.getElementById('rcStandortFilter') || {}).value || 'ALL');
        const tSelE = document.getElementById('rcTeamFilter');
        const ftE = (scope && scope.team  != null) ? scope.team  : ((fvE !== 'ALL' && tSelE) ? (tSelE.value || 'ALL') : 'ALL');
        const sSelE = document.getElementById('rcStackFilter');
        const fsE = (scope && scope.stack != null) ? scope.stack : (sSelE ? (sSelE.value || 'ALL') : 'ALL');
        const mapM = window.rcWcaMapping || {};
        const ccsMapE = mapM.ccsMap || {}, stackMapE = mapM.stackMap || {}, voMapE = mapM.voMap || {};
        const useKey = live ? tKey : dayKey;
        const label = useKey.slice(8) + '.' + useKey.slice(5,7) + '.' + useKey.slice(0,4);
        const rows = [];

        if (live) {
            let ligaList = Object.values(window.rcKpiData || {});
            const teamOfK = k => (((ccsMapE[k.ccsId] && ccsMapE[k.ccsId].team) || k.team || '') + '').trim();
            if (fvE !== 'ALL') ligaList = ligaList.filter(k => window.rcLigaMeta(k).std === fvE);
            if (ftE !== 'ALL') ligaList = ligaList.filter(k => teamOfK(k) === ftE);
            if (fsE !== 'ALL') ligaList = ligaList.filter(k => { const tm = teamOfK(k); return tm && (stackMapE[tm] || '') === fsE; });
            const agentsAll2 = window.rcLetzteStats ? Object.values(window.rcLetzteStats.agentStats) : [];
            const eslByCcs = {}, eslByName = {};
            agentsAll2.forEach(a => { if (a.ccsId) eslByCcs[a.ccsId] = a; eslByName[window.rcNormName(a.name)] = a; });
            ligaList.forEach(k => {
                const ag = (k.ccsId && eslByCcs[k.ccsId]) || eslByName[window.rcNormName(k.agentName)] || null;
                const calls = k.callCount || 0;
                const csN = (k.promCs != null || k.detCs != null || k.neutCs != null) ? (k.promCs||0)+(k.detCs||0)+(k.neutCs||0) : null;
                const tnN = (k.promTnps != null || k.detTnps != null || k.neutTnps != null) ? (k.promTnps||0)+(k.detTnps||0)+(k.neutTnps||0) : null;
                rows.push({
                    team: teamOfK(k), name: k.agentName, calls, ahtSec: k.ahtSec,
                    aq:   { z: k.aqZ   != null ? k.aqZ   : null, v: (k.auflegerquote != null && calls > 0) ? k.auflegerquote : null },
                    cs:   { z: k.csZ   != null ? k.csZ   : null, v: (k.cs   != null && (csN == null || csN > 0)) ? k.cs   : null },
                    tnps: { z: k.tnpsZ != null ? k.tnpsZ : null, v: (k.tnps != null && (tnN == null || tnN > 0)) ? k.tnps : null },
                    fq:   { z: k.fqZ   != null ? k.fqZ   : null, v: (k.fq   != null && calls > 0) ? k.fq : null },
                    dds:  { z: k.ddsZ  != null ? k.ddsZ  : null, v: (k.dds  != null && (tnN == null || tnN > 0)) ? k.dds : null },
                    detr: (k.det != null ? k.det : 0),   // TNPS-Detraktoren (ANZAHL, nicht %)
                    ftf:  { z: k.ftfZ  != null ? k.ftfZ  : null, v: (k.ftf  != null && calls > 0 && (k.ftf > 0 || k.ftfZ != null)) ? k.ftf : null },
                    hasEsl: !!ag, ansp: ag ? (ag.ansprachen || 0) : 0,
                    mob: ag ? (ag.mob||0) : null, kip: ag ? (ag.kip||0) : null,
                    bnt: ag ? (ag.bnt||0) : null, vvl: ag ? (ag.vvl||0) : null
                });
            });
            // ESL-Agenten OHNE Liga-Praesenz ergaenzen — sonst fehlen ihre Abschluesse in
            // der GESAMT-Summe (das Blatt iteriert oben nur Liga-Agenten). Qualitaet=Keine.
            const coveredCcs = new Set(), coveredNm = new Set();
            ligaList.forEach(k => { if (k.ccsId) coveredCcs.add(String(k.ccsId)); if (k.agentName) coveredNm.add(window.rcNormName(k.agentName)); });
            agentsAll2.forEach(a => {
                if ((a.bnt||0)+(a.vvl||0)+(a.ansprachen||0) === 0) return; // nur wer etwas getrackt hat
                const nm = window.rcNormName(a.name);
                if ((a.ccsId && coveredCcs.has(String(a.ccsId))) || coveredNm.has(nm)) return; // schon als Liga-Zeile
                if (fvE !== 'ALL' && a.standort !== fvE) return;
                if (ftE !== 'ALL' && (a.team||'') !== ftE) return;
                if (fsE !== 'ALL' && (a.stack||'') !== fsE) return;
                rows.push({ team: a.team||'', name: a.name, calls: 0, ahtSec: null,
                    aq:{z:null,v:null}, cs:{z:null,v:null}, tnps:{z:null,v:null}, fq:{z:null,v:null}, dds:{z:null,v:null}, detr:null, ftf:{z:null,v:null},
                    hasEsl: true, ansp: a.ansprachen||0, mob: a.mob||0, kip: a.kip||0, bnt: a.bnt||0, vvl: a.vvl||0 });
                coveredNm.add(nm);
            });
        } else {
            const lig = (window.rcLigaHistory || {})[dayKey];
            const eslH = window.rcEslHistory || rcLoadEslHistory() || {};
            const esl = eslH[dayKey];
            if (!lig || !lig.byAgent || !Object.keys(lig.byAgent).length) {
                return { rows: [], label, today:false, fehlt: 'Fuer ' + label + ' liegen keine Ligalisten-Agenten in der Historie. KPI-Crawler (v3.6) laufen lassen oder den Tag ueber den Zeitraum-Button laden.' };
            }
            // ESL-Vortagsdaten (per VO) fuer den Join vorbereiten. Robust: CCS/Name kommen
            // primaer aus dem Aggregat selbst (rcFinalizeAgg speichert ccs/nm mit),
            // dann aus dem Mapping, dann aus den Live-agentStats — so klappt der Join
            // auch bei unvollstaendigem Mapping zur Export-Zeit.
            const eslBy = (esl && esl.byAgent) || {};
            const liveAg = (window.rcLetzteStats && window.rcLetzteStats.agentStats) || {};
            const eslByCcs = {}, eslByName = {};
            Object.keys(eslBy).forEach(vo => {
                const e = eslBy[vo], m = voMapE[vo] || {}, la = liveAg[vo] || {};
                // Die ESL-Spalte "vo_nummer" IST bei manchen Portal-Exporten bereits die
                // CCS-ID (kein separater VO-Code). Fehlt die VO im voMap, aber existiert
                // sie direkt als CCS-ID im ccsMap, wird sie als CCS-ID genutzt — sonst
                // scheitert der Vortags-Join zu 100% und BNT/VVL/Ansprache bleiben leer.
                const ccs = e.ccs || m.ccsId || la.ccsId || (ccsMapE[vo] ? String(vo) : '');
                const nm  = e.nm  || m.name  || la.name  || (ccsMapE[vo] ? ccsMapE[vo].name : '') || vo;
                const rec = { ansp: e.a || 0,
                    mob: e.mob != null ? e.mob : null, kip: e.kip != null ? e.kip : null,
                    bnt: e.bnt != null ? e.bnt : (e.bcr || 0), vvl: e.vvl || 0 };
                if (ccs) eslByCcs[ccs + ''] = rec;
                if (window.rcNormName && nm) eslByName[window.rcNormName(nm)] = rec;
            });
            Object.keys(lig.byAgent).forEach(id => {
                const v = lig.byAgent[id];
                const meta = ccsMapE[id] || {};
                const team = ((meta.team || '') + '').trim();
                const std = normalizeStandort(meta.standort || '');
                if (fvE !== 'ALL' && std !== fvE) return;
                if (ftE !== 'ALL' && team !== ftE) return;
                if (fsE !== 'ALL' && (!team || (stackMapE[team] || '') !== fsE)) return;
                const nm = meta.name || (window.rcKpiData && window.rcKpiData[id] && window.rcKpiData[id].agentName) || ('CCS ' + id);
                const ag = eslByCcs[id] || (window.rcNormName ? eslByName[window.rcNormName(nm)] : null) || null;
                rows.push({
                    team, name: nm, calls: v.c || 0, ahtSec: v.aht != null ? v.aht : null,
                    aq:   { z: v.za != null ? v.za : null, v: v.aq  != null ? v.aq  : null },
                    cs:   { z: v.zc != null ? v.zc : null, v: v.cs  != null ? v.cs  : null },
                    tnps: { z: v.zt != null ? v.zt : null, v: v.tn  != null ? v.tn  : null },
                    fq:   { z: v.zf != null ? v.zf : null, v: v.fq  != null ? v.fq  : null },
                    dds:  { z: v.zd != null ? v.zd : null, v: v.dds != null ? v.dds : null },
                    detr: (v.det != null ? v.det : 0),   // TNPS-Detraktoren (ANZAHL, nicht %)
                    ftf:  { z: v.zx != null ? v.zx : null, v: (v.ftf != null && (v.ftf > 0 || v.zx != null)) ? v.ftf : null },
                    hasEsl: !!ag, ansp: ag ? ag.ansp : 0,
                    mob: ag ? ag.mob : null, kip: ag ? ag.kip : null,
                    bnt: ag ? ag.bnt : null, vvl: ag ? ag.vvl : null
                });
            });
            // ESL-Vortags-Agenten OHNE Liga-Match ergaenzen (sonst fehlen ihre
            // Abschluesse in der GESAMT-Summe des Vortags-Stands). Qualitaet=Keine.
            const ligaCcs = new Set(Object.keys(lig.byAgent).map(String));
            const ligaNm = new Set();
            Object.keys(lig.byAgent).forEach(id => { const meta = ccsMapE[id] || {}; const nm = meta.name || (window.rcKpiData && window.rcKpiData[id] && window.rcKpiData[id].agentName) || ('CCS ' + id); if (window.rcNormName) ligaNm.add(window.rcNormName(nm)); });
            Object.keys(eslBy).forEach(vo => {
                const e = eslBy[vo], m = voMapE[vo] || {}, la = liveAg[vo] || {};
                const cm = ccsMapE[vo] || null;   // vo IST teils direkt die CCS-ID
                const bntV = e.bnt != null ? e.bnt : (e.bcr || 0);
                if ((bntV || 0) + (e.vvl || 0) + (e.a || 0) === 0) return;
                const ccs = e.ccs || m.ccsId || la.ccsId || (cm ? String(vo) : '');
                const nm  = e.nm  || m.name  || la.name  || (cm ? cm.name : '') || vo;
                if (ccs && ligaCcs.has(String(ccs))) return;
                if (window.rcNormName && ligaNm.has(window.rcNormName(nm))) return;
                const team = ((m.team || la.team || (cm && cm.team) || '') + '').trim();
                const std = normalizeStandort(m.standort || la.standort || (cm && cm.standort) || '');
                if (fvE !== 'ALL' && std !== fvE) return;
                if (ftE !== 'ALL' && team !== ftE) return;
                if (fsE !== 'ALL' && (!team || (stackMapE[team] || '') !== fsE)) return;
                rows.push({ team, name: nm, calls: 0, ahtSec: null,
                    aq:{z:null,v:null}, cs:{z:null,v:null}, tnps:{z:null,v:null}, fq:{z:null,v:null}, dds:{z:null,v:null}, detr:null, ftf:{z:null,v:null},
                    hasEsl: true, ansp: e.a || 0, mob: e.mob != null ? e.mob : null, kip: e.kip != null ? e.kip : null, bnt: bntV, vvl: e.vvl || 0 });
            });
        }
        // Datenlose Agenten (0 Calls, 0 Kontakte, keine Kennzahl) draussen lassen
        const cleanRows = rows.filter(rcStandRowHasData);
        cleanRows.sort((a,b) => (a.team + '').localeCompare(b.team + '') || a.name.localeCompare(b.name));
        // eslFehlt: kein einziger Agent hat ESL-Vertriebsdaten -> Ansprache/BNT waeren
        // komplett leer. Der Export warnt dann, statt still leere Spalten zu liefern.
        const eslFehlt = cleanRows.length > 0 && !cleanRows.some(r => r.hasEsl);
        return { rows: cleanRows, label, today: live, eslFehlt };
    }

    // ============================================================
    //  "AKTUELLER STAND"-BLATT (1:1 Vorlage) + Bewertungslogik —
    //  eigenstaendig, damit auch VORTAGE exportierbar sind.
    //  NEU ggue. Vorlage: Zaehler-Spalten (statt leerer Nenner),
    //  V-Ansprache-Ampel (Ziel >= 50 %), DDS faerbt auch 0 (Bestwert),
    //  "Keine" bei fehlender Bewertung.
    // ============================================================
    function rcBuildStandSheets(XL, wb, styled, data, opts){
        opts = opts || {};
        const FILL = c => ({ patternType:'solid', fgColor:{ rgb:c } });
        const M = (r1,c1,r2,c2) => ({ s:{r:r1,c:c1}, e:{r:r2,c:c2} });
        const w = (...a2) => a2.map(x => ({ wch:x }));
        // Original-Palette (aus styles.xml der Vorlage)
        const C_ORANGE = 'FFFF4C02', C_BLAU = 'FF2C57D2', C_DUNKEL = 'FF1F2D3D',
              C_TXT = 'FF35414C', C_ZEBRA = 'FFF4F6FA', C_PINK = 'FFFF679B',
              C_GRUEN = 'FF009864', C_ROT = 'FFE2241A';
        const AMPEL     = { DG:'FF00684A', G:'FF009864', O:'FFFF4C02', R:'FFE2241A' };
        const AMPEL_FTF = { DG:'FF005C39', G:'FF00A65A', O:'FFFF5500', R:'FFE52213' };
        const PASTELL   = { DG:'FFCDEAD9', G:'FFEDF7ED', O:'FFFFE0CC', R:'FFFBD8D5' };
        const P_FONT    = { DG:'FF00684A', G:'FF009864', O:'FFFF4C02', R:'FFE2241A' };
        const PCT1 = '0.0" %"'; // exakt das Original-Zahlenformat
        const BD_A = (function(){ const b = { style:'thin', color:{ rgb:'FFD7DEE8' } }; return { top:b, bottom:b, left:b, right:b }; })();
        // CF-Skalen: AQ >=90/85/80,1 · CS >=95/90/85,1 · TNPS >=80/70/60,1 · FQ >30/25/20
        // DDS: 0 ist BESTWERT -> auch 0 wird gefaerbt (<=2 DG / <=3 G / <5 O / >=5 R)
        // V-Ansprache: Ziel >= 50 % (DG >=65 / G >=50 / O >=35 / R darunter)
        const gh = (v, dg, g, o) => (v == null || v < 1) ? null : (v >= dg ? 'DG' : v >= g ? 'G' : v > o ? 'O' : 'R');
        const SCALES = {
            aq:   v => gh(v, 90, 85, 80),
            cs:   v => gh(v, 95, 90, 85),
            tnps: v => gh(v, 80, 70, 60),
            fq:   v => gh(v, 30.1, 25.1, 20),
            dds:  v => v == null ? null : (v <= 2 ? 'DG' : v <= 3 ? 'G' : v < 5 ? 'O' : 'R'),
            // Detraktoren = ANZAHL (0 ist Bestwert): 0 gruen, 1 orange, >=2 rot
            detr: v => v == null ? null : (v <= 0 ? 'DG' : v <= 1 ? 'O' : 'R'),
            ftf:  v => gh(v, 80, 70, 60),
            vansp: v => v == null ? null : (v >= 65 ? 'DG' : v >= 50 ? 'G' : v >= 35 ? 'O' : 'R')
        };
        // Zellen-Fabrik: jedes s-Objekt frisch (Leak-sicher); Fonts wie Original
        const cell = (v, o) => {
            o = o || {};
            const c = { v: (v === '' || v == null) ? '' : v, t: (typeof v === 'number' ? 'n' : 's') };
            if (o.nf && c.t === 'n') c.z = o.nf;
            if (styled) c.s = {
                fill: FILL(o.bg || 'FFFFFFFF'),
                font: { sz: o.sz || 9.5, bold: !!o.b, color: { rgb: o.fc || C_TXT }, name: o.fn || 'Roboto' },
                alignment: { horizontal: o.al || 'center', vertical: 'center', wrapText: !!o.wrap },
                border: o.nb ? undefined : BD_A,
                numFmt: (c.t === 'n' && o.nf) ? o.nf : 'General'
            };
            return c;
        };
        function sheetFromCells(rows2){
            const ws = {};
            let maxC = 0;
            rows2.forEach((row, R) => { row.forEach((cl, C) => { if (cl != null) ws[XL.utils.encode_cell({ r:R, c:C })] = cl; if (C > maxC) maxC = C; }); });
            ws['!ref'] = XL.utils.encode_range({ s:{ r:0, c:0 }, e:{ r: rows2.length - 1, c: maxC } });
            return ws;
        }

        // ---------- Blatt A: Stand (Spalten A..V, Inhalt ab B) ----------
        const NC = 22;
        const rows2 = [], rowH = [];
        const span = (row, c1, c2, mk) => { for (let c = c1; c <= c2; c++) row[c] = mk(c === c1); };
        const blank = () => { const r = []; r[0] = cell('', { nb:true }); return r; };
        // r0: weisser Abstand · r1: orange Topline (B:V)
        rows2.push(blank()); rowH.push({ hpt:16.5 });
        const rTop = blank(); span(rTop, 1, NC-1, () => cell('', { bg:C_ORANGE, nb:true }));
        rows2.push(rTop); rowH.push({ hpt:5.1 });
        // r2..r4: blauer Titelblock — B:L Titel (Poppins 18) + M:V "regiocom Türkei"
        const standTitel = data.today ? 'Aktueller  Stand' : 'Stand  ' + data.label;
        for (let i = 0; i < 3; i++) {
            const r = blank();
            span(r, 1, 11, first => first && i === 0 ? cell(standTitel, { bg:C_BLAU, fc:'FFFFFFFF', b:true, sz:18, al:'left', fn:'Poppins', nb:true }) : cell('', { bg:C_BLAU, nb:true }));
            span(r, 12, NC-1, first => first && i === 0 ? cell('regiocom Türkei', { bg:C_BLAU, fc:'FFFFFFFF', b:true, sz:14, al:'right', fn:'Poppins', nb:true }) : cell('', { bg:C_BLAU, nb:true }));
            rows2.push(r); rowH.push({ hpt: i === 1 ? 25.5 : 21.95 });
        }
        // r5: Zeitraum (B:E) + QUALITAET (F:Q) + VERTRIEB (R:V) — alles 1F2D3D
        const r5 = blank();
        span(r5, 1, 4,  f => f ? cell('Zeitraum: ' + data.label + ' bis ' + data.label, { bg:C_DUNKEL, fc:'FFFFFFFF', al:'left', sz:9, fn:'Roboto' }) : cell('', { bg:C_DUNKEL }));
        span(r5, 5, 16, f => f ? cell('QUALITÄT', { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, sz:9.5, fn:'Poppins' }) : cell('', { bg:C_DUNKEL }));
        span(r5, 17, NC-1, f => f ? cell('VERTRIEB', { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, sz:9.5, fn:'Poppins' }) : cell('', { bg:C_DUNKEL }));
        rows2.push(r5); rowH.push({ hpt:20.25 });
        // r6: KPI-Gruppen — Blau; V-Ansprache Rot; BNT/VVL Orange (Original-Farben)
        const r6 = blank();
        const GRP = [ [1,4,'DATEN &  AHT / VOLUMEN',C_BLAU], [5,6,'AuflegerQuote',C_BLAU], [7,8,'CS  / Freundlich.',C_BLAU],
            [9,10,'TNPS',C_BLAU], [11,12,'FeedbackQuote',C_BLAU], [13,14,'Detraktoren',C_BLAU], [15,16,'First-Time-Fix',C_BLAU],
            [17,17,'V-Ansprache',C_ROT], [18,20,'BNT',C_ORANGE], [21,21,'VVL',C_ORANGE] ];
        GRP.forEach(([c1,c2,txt,bg]) => span(r6, c1, c2, f => f ? cell(txt, { bg, fc:'FFFFFFFF', b:true, sz:9, fn:'Poppins' }) : cell('', { bg })));
        rows2.push(r6); rowH.push({ hpt:20.25 });
        // r7: Sub-Header (1F2D3D, 8.5pt) — ZAEHLER statt Nenner (Nutzer-Vorgabe)
        const sub2 = ['Team','Agent','Calls','Ø Min.','Zähler','IST %','Zähler','IST %','Zähler','IST %','Zähler','IST %','','Anzahl','Zähler','IST %','IST %','MOB','KIP','BNT GES.','VVL GES.'];
        const r7 = blank();
        sub2.forEach((t, i) => { r7[i+1] = cell(t, { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, sz:8.5, fn:'Roboto' }); });
        rows2.push(r7); rowH.push({ hpt:18 });
        // Datenzeilen: Werte ROH in Prozent (88,5 -> "88,5 %"), Ampeln nach SCALES;
        // ohne Bewertung steht "Keine" (grau). Zebra wie Original.
        const KEINE = zeb => cell('Keine', { bg: zeb, fc:'FF8C959E', sz:8 });
        const mkAmp = (v, grade, pal, zeb) => v == null ? KEINE(zeb) :
            cell(+v.toFixed(1), grade ? { nf:PCT1, bg:pal[grade], fc:'FFFFFFFF', b:true } : { nf:PCT1, b:true, bg: zeb });
        const sum = { calls:0, ahtW:0, mob:0, kip:0, bnt:0, vvl:0, ansp:0, detrSum:0,
            z: { aq:null, cs:null, tnps:null, fq:null, ftf:null },
            q: { aq:[], cs:[], tnps:[], fq:[], ftf:[] } };
        data.rows.forEach((row, li) => {
            const zeb = (li % 2 === 1) ? C_ZEBRA : 'FFFFFFFF';
            const calls = row.calls || 0;
            const vq = (row.hasEsl && calls > 0) ? (row.ansp / calls * 100) : null;
            sum.calls += calls; if (row.ahtSec) sum.ahtW += row.ahtSec * calls;
            sum.ansp += row.hasEsl ? row.ansp : 0;
            if (row.hasEsl) { sum.mob += row.mob||0; sum.kip += row.kip||0; sum.bnt += row.bnt||0; sum.vvl += row.vvl||0; }
            ['aq','cs','tnps','fq','ftf'].forEach(s2 => {
                const kv = row[s2];
                if (kv.v != null) sum.q[s2].push(kv.v);
                if (kv.z != null) sum.z[s2] = (sum.z[s2] || 0) + kv.z;
            });
            if (row.detr != null) sum.detrSum += row.detr;
            const r = blank();
            const dz = (v, o) => cell(v, Object.assign({ bg: zeb }, o || {}));
            const zZ = z => dz(z != null ? z : '', {});
            r[1] = dz(row.team || '', { b:true });
            r[2] = dz(heroName(row.name), { al:'left' });
            r[3] = dz(calls, {});
            r[4] = dz(row.ahtSec != null ? ('0' + fmtAht(row.ahtSec)).slice(-5) : '', {});
            r[5]  = zZ(row.aq.z);   r[6]  = mkAmp(row.aq.v,   SCALES.aq(row.aq.v), AMPEL, zeb);
            r[7]  = zZ(row.cs.z);   r[8]  = mkAmp(row.cs.v,   SCALES.cs(row.cs.v), AMPEL, zeb);
            r[9]  = zZ(row.tnps.z); r[10] = mkAmp(row.tnps.v, SCALES.tnps(row.tnps.v), AMPEL, zeb);
            r[11] = zZ(row.fq.z);   r[12] = mkAmp(row.fq.v,   SCALES.fq(row.fq.v), AMPEL, zeb);
            // Detraktoren = ANZAHL (kein %): Spalte 13 leer, Spalte 14 = Anzahl mit Ampel (0 gruen)
            r[13] = dz('', {});
            r[14] = (row.detr == null) ? KEINE(zeb) : cell(row.detr, { bg:AMPEL[SCALES.detr(row.detr)], fc:'FFFFFFFF', b:true });
            r[15] = zZ(row.ftf.z);  r[16] = mkAmp(row.ftf.v,  SCALES.ftf(row.ftf.v), AMPEL_FTF, zeb);
            // V-Ansprache: Ampel (Ziel >= 50 %); ohne ESL-Tracking "Keine"
            r[17] = vq != null
                ? cell(+vq.toFixed(1), { nf:PCT1, bg:AMPEL[SCALES.vansp(vq)], fc:'FFFFFFFF', b:true })
                : KEINE(zeb);
            r[18] = dz(row.mob != null ? row.mob : '', {});
            r[19] = dz(row.kip != null ? row.kip : '', {});
            r[20] = dz(row.bnt != null ? row.bnt : '', { b:true });
            r[21] = dz(row.vvl != null ? row.vvl : '', { b:true });
            rows2.push(r); rowH.push({ hpt:15.75 });
        });
        // GESAMT-Zeile: Zaehler-Summen + Ampeln (V-Ansprache mit eigener Skala)
        const mean2 = a => a.length ? a.reduce((s2,x)=>s2+x,0)/a.length : null;
        const gr2 = blank();
        gr2[1] = cell('GESAMT', { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, al:'left', fn:'Poppins', sz:9 });
        gr2[2] = cell('', { bg:C_DUNKEL });
        gr2[3] = cell(sum.calls, { bg:C_ZEBRA, b:true });
        gr2[4] = cell(sum.calls > 0 && sum.ahtW ? ('0' + fmtAht(sum.ahtW / sum.calls)).slice(-5) : '', { bg:C_ZEBRA, b:true });
        const gAmp = (key, pal) => { const v = mean2(sum.q[key]); const gr = v != null ? SCALES[key](v) : null;
            return v == null ? cell('Keine', { bg:C_ZEBRA, fc:'FF8C959E', sz:8 }) : cell(+v.toFixed(1), gr ? { nf:PCT1, bg:pal[gr], fc:'FFFFFFFF', b:true } : { nf:PCT1, bg:C_ZEBRA, b:true }); };
        const gZ = key => cell(sum.z[key] != null ? sum.z[key] : '', { bg:C_ZEBRA, b:true });
        gr2[5] = gZ('aq');   gr2[6]  = gAmp('aq', AMPEL);
        gr2[7] = gZ('cs');   gr2[8]  = gAmp('cs', AMPEL);
        gr2[9] = gZ('tnps'); gr2[10] = gAmp('tnps', AMPEL);
        gr2[11] = gZ('fq');  gr2[12] = gAmp('fq', AMPEL);
        gr2[13] = cell('', { bg:C_ZEBRA }); gr2[14] = cell(sum.detrSum || 0, { bg:C_ZEBRA, b:true }); // Detraktoren gesamt (Summe, neutral)
        gr2[15] = gZ('ftf'); gr2[16] = gAmp('ftf', AMPEL_FTF);
        const gvq = sum.calls > 0 ? sum.ansp / sum.calls * 100 : null;
        gr2[17] = gvq != null
            ? cell(+gvq.toFixed(1), { nf:PCT1, bg:AMPEL[SCALES.vansp(gvq)], fc:'FFFFFFFF', b:true })
            : cell('', { bg:C_ZEBRA });
        gr2[18] = cell(sum.mob, { bg:C_ZEBRA, b:true }); gr2[19] = cell(sum.kip, { bg:C_ZEBRA, b:true });
        gr2[20] = cell(sum.bnt, { bg:C_ZEBRA, b:true }); gr2[21] = cell(sum.vvl, { bg:C_ZEBRA, b:true });
        rows2.push(gr2); rowH.push({ hpt:20.25 });

        const wsA = sheetFromCells(rows2);
        const gesR = rows2.length - 1;
        wsA['!merges'] = [ M(1,1,1,NC-1), M(2,1,4,11), M(2,12,4,NC-1),
            M(5,1,5,4), M(5,5,5,16), M(5,17,5,NC-1), M(gesR,1,gesR,2) ]
            .concat(GRP.filter(g => g[1] > g[0]).map(g => M(6,g[0],6,g[1])));
        // Original-Spaltenbreiten
        wsA['!cols'] = w(1.4, 9.57, 23.14, 8.43, 8.43, 6.43, 7.29, 5.43, 7.29, 5.43, 7.29, 6.29, 7.29, 5.43, 7.29, 6.43, 7.29, 12.43, 8.43, 8.43, 9.43, 9.14);
        wsA['!rows'] = rowH;
        XL.utils.book_append_sheet(wb, wsA, data.today ? 'Aktueller Stand' : ('Stand ' + data.label.replace(/\./g, '-')).slice(0, 31));

        // Bei Mehrtages-Export (rcExportStandRange) die Bewertungslogik nur EINMAL anhaengen.
        if (opts.skipBewertung) return;

        // ---------- Blatt B: Bewertungslogik (A..E, dunkler Aussenrahmen) ----------
        const rowsB = [], rowHB = [], mergesB = [];
        const frameRow = (mid) => { const r = []; r[0] = cell('', { bg:C_DUNKEL, nb:true }); for (let c=1;c<=3;c++) r[c] = mid(c); r[4] = cell('', { bg:C_DUNKEL, nb:true }); return r; };
        const pushB = (mid, hpt, mergeBD) => { const R = rowsB.length; rowsB.push(frameRow(mid)); rowHB.push({ hpt }); if (mergeBD) mergesB.push(M(R,1,R,mergeBD === 'BC' ? 2 : 3)); return R; };
        pushB(() => cell('', { bg:C_DUNKEL, nb:true }), 5.1);
        const tR = pushB(c => c === 1 ? cell('BEWERTUNGSLOGIK', { bg:C_BLAU, fc:'FFFFFFFF', b:true, sz:14, fn:'Poppins' }) : cell('', { bg:C_BLAU }), 11.25, 'BD');
        pushB(c => cell('', { bg:C_BLAU }), 11.25);
        mergesB[mergesB.length-1] = M(tR,1,tR+1,3); // Titel ueber 2 Zeilen
        pushB(c => c === 1 ? cell('Vier KPI . vier Ebenen . gewichtete Gesamtbewertung', { bg:C_DUNKEL, fc:'FFFFFFFF', sz:9.5, fn:'Roboto' }) : cell('', { bg:C_DUNKEL }), 21.95, 'BD');
        const sektion = (titel, bg, zeilen) => {
            pushB(() => cell('', {}), 14.25); // Abstand
            pushB(c => c === 1 ? cell(titel, { bg, fc:'FFFFFFFF', b:true, sz:9.5, fn:'Poppins' }) : cell('', { bg }), 20.1, 'BD');
            pushB(c => c <= 2 ? (c === 1 ? cell('Bereich', { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, sz:9 }) : cell('', { bg:C_DUNKEL })) : cell('Farbe', { bg:C_DUNKEL, fc:'FFFFFFFF', b:true, sz:9 }), 14.25, 'BC');
            zeilen.forEach(([txt, gr]) => pushB(c => c <= 2
                ? (c === 1 ? cell(txt, { bg:PASTELL[gr], fc:P_FONT[gr], b:true, al:'left', sz:10 }) : cell('', { bg:PASTELL[gr] }))
                : cell('', { bg:AMPEL[gr] }), 20.1, 'BC'));
        };
        sektion('BNT . Neuvertraege   .   Gewichtung 40 %', C_BLAU, [
            ['ab 5,60 %','DG'], ['4,80 - 5,59 %','G'], ['4,00 - 4,79 %','O'], ['unter 4,00 %','R'] ]);
        sektion('FF7 . Final Fix   .   Gewichtung 35 %', C_GRUEN, [
            ['ab 86,74 %','DG'], ['78,50 - 86,73 %','G'], ['72,22 - 78,49 %','O'], ['unter 72,22 %','R'] ]);
        sektion('CS . Zufriedenheit   .   Gewichtung 15 %', C_ORANGE, [
            ['ab 95,00 %','DG'], ['90,00 - 94,99 %','G'], ['82,80 - 89,99 %','O'], ['unter 82,80 %','R'] ]);
        sektion('VVL . Vertragsverlaengerung   .   Gewichtung 10 %', C_PINK, [
            ['ab 5,00 %','DG'], ['4,20 - 4,99 %','G'], ['3,40 - 4,19 %','O'], ['unter 3,40 %','R'] ]);
        pushB(() => cell('', {}), 14.25);
        pushB(() => cell('', { bg:C_DUNKEL, nb:true }), 11);
        const wsB = sheetFromCells(rowsB);
        wsB['!merges'] = mergesB;
        wsB['!cols'] = w(1.43, 19.29, 19.29, 19.29, 1.43);
        wsB['!rows'] = rowHB;
        XL.utils.book_append_sheet(wb, wsB, 'Bewertungslogik');
    }

    // "Stand"-Blatt fuer einen beliebigen Tag als eigene Datei exportieren
    // (fuer die Team-Mail: gestern waehlen -> Excel -> anhaengen).
    // scope optional (Standort/Team/Stack) — sonst gelten die Dashboard-Filter.
    window.rcExportStandTag = function(dayKey, scope){
        const data = rcStandRows(dayKey, scope);
        if (data.fehlt) { alert(data.fehlt); return; }
        if (!data.rows.length) { alert('Keine Agenten fuer ' + data.label + ' im gewaehlten Filter gefunden.'); return; }
        if (data.eslFehlt && !data.today) {
            if (!confirm('Fuer ' + data.label + ' liegen KEINE ESL-Vertriebsdaten vor — die Spalten V-Ansprache, BNT und VVL bleiben leer (Qualitaet ist vorhanden).\n\nDie ESL-Vortagsdaten zuerst ueber "Zeitraum" -> "Daten laden (ESL + Liga)" holen. Trotzdem jetzt exportieren?')) return;
        }
        rcLoadStyledXlsx(function(XL){
            const wb = XL.utils.book_new();
            rcBuildStandSheets(XL, wb, !!XL.__styled, data);
            const g = (id, sk) => (scope && scope[sk] != null) ? (scope[sk] !== 'ALL' ? scope[sk] : null) : (() => { const el = document.getElementById(id); return (el && el.value !== 'ALL') ? el.value : null; })();
            const parts = [g('rcStandortFilter','std'), g('rcStackFilter','stack'), g('rcTeamFilter','team') ? 'Team' + g('rcTeamFilter','team') : null].filter(Boolean);
            const fn = 'regiocom_Stand_' + (data.today ? 'heute' : dayKey) + (parts.length ? '_' + parts.join('_').replace(/[^A-Za-z0-9_-]+/g, '') : '') + '.xlsx';
            XL.writeFile(wb, fn);
            rcLog.log('Stand-Export ' + data.label + ' (' + data.rows.length + ' Agenten): ' + fn);
        });
    };

    // "Aktueller Stand"-BLATT je Tag ueber einen ganzen ZEITRAUM (ein Blatt pro Tag,
    // Bewertungslogik einmal am Ende) — genau das gewohnte Layout, nur rueckwirkend.
    window.rcExportStandRange = function(from, to, std){
        if (!from || !to || from > to) { alert('Bitte gueltigen Zeitraum waehlen (Von <= Bis).'); return; }
        const eslHist = window.rcEslHistory || rcLoadEslHistory() || {};
        const ligaHist = window.rcLigaHistory || {};
        const tk = rcTodayKey();
        const scope = { std: std || 'ALL', team: 'ALL', stack: 'ALL' };
        const days = [...new Set([].concat(Object.keys(eslHist), Object.keys(ligaHist), [tk]))]
            .filter(k => k >= from && k <= to).sort();
        if (!days.length) { alert('Fuer ' + from + ' bis ' + to + ' liegen keine Tage in der Historie. Zuerst "Daten laden (ESL + Liga)" ausfuehren.'); return; }
        const datas = [];
        days.forEach(k => { const d = rcStandRows(k, scope); if (d.rows && d.rows.length) datas.push(d); });
        if (!datas.length) { alert('Fuer den gewaehlten Zeitraum/Standort wurden keine Agenten gefunden.'); return; }
        rcLoadStyledXlsx(function(XL){
            const wb = XL.utils.book_new();
            datas.forEach((d, i) => rcBuildStandSheets(XL, wb, !!XL.__styled, d, { skipBewertung: i < datas.length - 1 }));
            const stdPart = (std && std !== 'ALL') ? '_' + std : '';
            const fn = 'regiocom_Stand_' + from + '_bis_' + to + stdPart + '.xlsx';
            XL.writeFile(wb, fn);
            rcLog.log('Stand-Zeitraum-Export ' + from + '..' + to + ' (' + datas.length + ' Tage): ' + fn);
        });
    };

    // Tages-Auswahl fuer den Stand-Export (Cockpit-Button "Stand-Export (Tag)")
    window.rcOpenStandExport = function(){
        const eslHist = window.rcEslHistory || rcLoadEslHistory() || {};
        const ligaHist = window.rcLigaHistory || {};
        const tk = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date());
        const dayKeys = [...new Set([].concat(Object.keys(ligaHist), Object.keys(eslHist), [tk]))].sort().reverse();
        const fmtD = k => (k === tk ? 'Heute (' + k + ')' : k) + ((k !== tk && !(ligaHist[k] && ligaHist[k].byAgent)) ? ' — ohne Liga-Daten' : '');
        rcShowDetail(`
            <div class="rc-detail-head"><div>
                <h3>Stand-Export — Tag waehlen</h3>
                <div class="rc-detail-sub">Das Vorlagen-Blatt (Qualitaet + Vertrieb je Agent) fuer einen beliebigen Tag exportieren — z.B. GESTERN fuer die Team-Mail. Aktive Filter (Standort/Team/Stack) gelten auch hier.</div>
            </div></div>
            <div class="rc-cmp-controls">
                <select id="rcStdExpDay" class="rc-select">${dayKeys.map((k, i) => `<option value="${k}"${(dayKeys.length > 1 && i === 1) ? ' selected' : ''}>${fmtD(k)}</option>`).join('')}</select>
                <button class="rc-btn rc-btn-blue" id="rcStdExpGo">Als Excel exportieren</button>
            </div>
            <div class="rc-detail-hint">Vortage brauchen die Liga-Historie des KPI-Crawlers. Tage mit dem Vermerk "ohne Liga-Daten" zuerst ueber den Zeitraum-Button laden. Zaehler-Spalten fuellen sich fuer alle Tage, die der Crawler ab v3.6 geholt hat.</div>
        `);
        document.getElementById('rcStdExpGo').addEventListener('click', () => {
            window.rcExportStandTag(document.getElementById('rcStdExpDay').value);
        });
    };

    window.rcExportReport = function(){
        if (!window.rcLetzteStats) { alert('Noch keine Daten geladen.'); return; }
        rcLoadStyledXlsx(function(XL){
            const styled = !!XL.__styled;
            const { agentStats, standortStats, teamStats } = window.rcLetzteStats;
            const wb = XL.utils.book_new();

            const nd = new Date();
            const dstr = pad2(nd.getDate()) + '.' + pad2(nd.getMonth()+1) + '.' + String(nd.getFullYear()).slice(-2);
            const titel = 'Vodafone      ESL PERFORMANCE TRACKING  |  Zeitraum: ' + dstr + ' - ' + dstr;
            const PCT = '0.0%';
            const crF = (z,n) => n > 0 ? +(z/n).toFixed(4) : 0;   // Bruch fuer echtes Excel-%-Format

            // --- Style-Bausteine (nur wirksam, wenn der Styling-Fork geladen wurde) ---
            const bd = { style:'thin', color:{ rgb:'FFD9D9D9' } };
            const BORDER = { top:bd, bottom:bd, left:bd, right:bd };
            const FILL = c => ({ patternType:'solid', fgColor:{ rgb:c } });
            const S_TITLE = { fill:FILL('FFE60000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:13 }, alignment:{ horizontal:'left', vertical:'center' } };
            const S_HDR   = bg => ({ fill:FILL(bg), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ horizontal:'center', vertical:'center', wrapText:true }, border:BORDER });
            const S_CELL  = al => ({ font:{ sz:10 }, alignment:{ horizontal:al||'center', vertical:'center' }, border:BORDER });
            const S_GROUP = { fill:FILL('FFE60000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ vertical:'center' }, border:BORDER };
            // Hierarchie-Ebenen fuer die Struktur-Uebersicht (Standort/Stack/Team)
            const S_LVL_STANDORT = { fill:FILL('FFE60000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:11 }, alignment:{ vertical:'center' }, border:BORDER };
            const S_LVL_STACK    = { fill:FILL('FF820000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ vertical:'center' }, border:BORDER };
            const S_LVL_TEAM     = { fill:FILL('FF4A4D4E'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ vertical:'center' }, border:BORDER };

            const M = (r1,c1,r2,c2) => ({ s:{r:r1,c:c1}, e:{r:r2,c:c2} });

            // Generischer Styler: legt fehlende Zellen an, faerbt Titel/Header/Daten, setzt %-Format.
            // levelRows = { rowIndex: styleObjekt } fuer mehrstufige Hierarchie-Zeilen.
            function decorate(ws, o){
                const rng = XL.utils.decode_range(ws['!ref']);
                for (let R=rng.s.r; R<=rng.e.r; R++){
                    for (let C=rng.s.c; C<=rng.e.c; C++){
                        const addr = XL.utils.encode_cell({ r:R, c:C });
                        if (!ws[addr]) ws[addr] = { t:'s', v:'' };
                        let st;
                        if (o.titleRows && o.titleRows.indexOf(R)!==-1) st = S_TITLE;
                        else if (o.headerRows && o.headerRows.indexOf(R)!==-1) st = S_HDR(o.hdrBg);
                        else {
                            // %-Format NUR fuer die definierten Prozent-Spalten
                            if (o.pctCols && o.pctCols.has(C) && ws[addr].t==='n') ws[addr].z = PCT;
                            if (o.levelRows && o.levelRows[R]) st = o.levelRows[R];
                            else if (o.groupRows && o.groupRows.has(R)) st = S_GROUP;
                            else st = S_CELL(C===0 ? 'left' : 'center');
                        }
                        if (styled) {
                            // KRITISCH: Style-Objekt pro Zelle KLONEN. xlsx-js-style haengt
                            // beim Schreiben das Zahlenformat an cell.s an (Mutation!) —
                            // geteilte Style-Referenzen liessen das %-Format auf Stueckzahlen
                            // "leaken" (Bug: 101 wurde als "10100,0%" angezeigt).
                            const own = Object.assign({}, st);
                            own.numFmt = (ws[addr].t === 'n' && ws[addr].z) ? ws[addr].z : 'General';
                            ws[addr].s = own;
                        }
                    }
                }
                if (o.cols)   ws['!cols']   = o.cols;
                if (o.merges) ws['!merges'] = (ws['!merges']||[]).concat(o.merges);
            }

            // ---------- Flache Blaetter (Standorte/Stacks/Teams/Agenten) ----------
            function flatSheet(name, hdrBg, header, dataRows, pctCols, widths){
                const aoa = [ [titel], header ].concat(dataRows);
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1], hdrBg:hdrBg,
                    pctCols:new Set(pctCols), merges:[ M(0,0,0,header.length-1) ], cols:widths });
                XL.utils.book_append_sheet(wb, ws, name);
            }

            const stds  = Object.values(standortStats).filter(s => s.calls > 0).sort((a,b) => b.total - a.total);
            const teams = Object.values(teamStats).filter(t => t.calls > 0).sort((a,b) => b.total - a.total);
            // Nur Agenten MIT Daten ins Agenten-Blatt: Kontakte, Ansprache, Abschluss
            // oder Liga-Calls. Reine Karteileichen (alles 0) bleiben draussen.
            const agentsAll = Object.values(agentStats).filter(a => {
                if ((a.kontakte||0) > 0 || (a.total||0) > 0 || (a.ansprachen||0) > 0) return true;
                const kpi = window.rcKpiForAgent ? window.rcKpiForAgent(a) : null;
                return !!(kpi && (kpi.callCount||0) > 0);
            });
            const w = (...a) => a.map(x => ({ wch:x }));

            // Liga-Calls je Standort/Team — der einzig gueltige BCR-Nenner (ESL-Kontakte
            // sind unvollstaendig getrackt; Befund 12.07.: nur ~12 % der Calls im ESL).
            const liga = window.rcLigaAgg ? window.rcLigaAgg() : { byStd:{}, byTeam:{}, total:0 };

            // ============================================================
            // Blatt A: AKTUELLER STAND + Blatt B: BEWERTUNGSLOGIK
            // 1:1-Nachbau der Nutzer-Vorlage PIX_Dashaaaboard_VKD_TEC2.xlsm —
            // Farben, Skalen, Merges, Spaltenbreiten und Zeilenhoehen wurden
            // direkt aus der Original-Datei extrahiert (styles.xml + CF-Regeln).
            // Alle Zellen bekommen EIGENE Style-Objekte (kein numFmt-Leak).
            // ============================================================
            rcBuildStandSheets(XL, wb, styled, rcStandRows(null));

            // Blatt 0: STRUKTUR — Hierarchie Standort -> Stack -> Team (ohne Einzelagenten).
            // Je Ebene: Liga-Calls, ESL-Kontakte, Tracking-Quote (deckt "trackt nur
            // Erfolge" auf), BNT/VVL-Stueck, BCR-Relevanz, BCR-BNT/BCR-VVL auf Liga-Basis.
            (function(){
                const header = ['Standort / Stack / Team','Liga-Calls','ESL-Kontakte','Tracking %','Anspr.','BNT','VVL','BCR-rel.','n. BCR-rel.','Gesamt','BCR-BNT (Liga)','BCR-VVL (Liga)'];
                const aoa = [ [titel], header ];
                const levelRows = {};
                const rowLvl = (label, ligaCalls, o) => [ label,
                    ligaCalls > 0 ? ligaCalls : '', o.calls || 0,
                    ligaCalls > 0 ? crF(o.calls || 0, ligaCalls) : '',
                    o.pitches || 0, o.bnt || 0, o.vvl || 0, bcrOf(o), nonBcrOf(o), o.total || 0,
                    ligaCalls > 0 ? crF(o.bnt || 0, ligaCalls) : '',
                    ligaCalls > 0 ? crF(o.vvl || 0, ligaCalls) : '' ];
                stds.forEach(s => {
                    levelRows[aoa.length] = S_LVL_STANDORT;
                    aoa.push(rowLvl(stdFullName(s.code), liga.byStd[s.code] || 0, s));
                    const stdTeams = teams.filter(t => t.standort === s.code);
                    const stacks = [...new Set(stdTeams.map(t => t.stack || '—'))].sort();
                    stacks.forEach(stk => {
                        const stkTeams = stdTeams.filter(t => (t.stack || '—') === stk);
                        const agg = stkTeams.reduce((o,t) => { ['calls','pitches','bcr','nonBcr','bnt','vvl','total'].forEach(k => o[k]=(o[k]||0)+(t[k]||0)); return o; }, {});
                        const stkLiga = stkTeams.reduce((s2,t) => s2 + (liga.byTeam[t.name] || 0), 0);
                        levelRows[aoa.length] = S_LVL_STACK;
                        aoa.push(rowLvl('   Stack: ' + stk, stkLiga, agg));
                        stkTeams.sort((a,b) => b.total - a.total).forEach(t => {
                            levelRows[aoa.length] = S_LVL_TEAM;
                            aoa.push(rowLvl('      Team ' + t.name, liga.byTeam[t.name] || 0, t));
                        });
                    });
                });
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1], hdrBg:'FFE60000', levelRows:levelRows,
                    pctCols:new Set([3, 10, 11]), merges:[ M(0,0,0,header.length-1) ],
                    cols:w(34,10,12,10,8,8,8,9,9,8,12,12) });
                XL.utils.book_append_sheet(wb, ws, 'Struktur');
            })();

            // Blattfarben = Vodafone-Palette: Liga-Blaetter Electric Red, Rest Datenviz-Segmentierung
            // Blatt 1: Liga Standorte — Calls und ALLE CR% auf LIGA-Call-Basis
            // (ESL-Kontakte sind als Nenner unbrauchbar: unvollstaendig getrackt)
            (function(){
                const grp = ['Standort','Liga-Calls','ENV BNT','','DSL / FIB BNT','','KIP BNT','','MOB BNT','','BNT GES.','','Mobilfunk VVL','','KIP VVL','','VVL','','Kumuliert',''];
                const sub = ['','IST','IST','CR%','IST','CR%','IST','CR%','IST','CR%','GES. IST','CR%','IST','CR%','IST','CR%','GES. IST','CR%','GES. IST','CR%'];
                const aoa = [ [titel], grp, sub ];
                stds.forEach(s => { const lc = liga.byStd[s.code] || 0;
                    const cr = v => lc > 0 ? crF(v, lc) : '';
                    aoa.push([ stdFullName(s.code), lc > 0 ? lc : '',
                        s.env, cr(s.env), s.fibDsl, cr(s.fibDsl), s.kip, cr(s.kip), s.mob, cr(s.mob),
                        s.bnt, cr(s.bnt), s.mobVvl, cr(s.mobVvl), s.kipVvl, cr(s.kipVvl),
                        s.vvl, cr(s.vvl), s.total, cr(s.total) ]); });
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1,2], hdrBg:'FFE60000', pctCols:new Set([3,5,7,9,11,13,15,17,19]),
                    merges:[ M(0,0,0,19), M(1,0,2,0), M(1,1,2,1), M(1,2,1,3), M(1,4,1,5), M(1,6,1,7), M(1,8,1,9), M(1,10,1,11), M(1,12,1,13), M(1,14,1,15), M(1,16,1,17), M(1,18,1,19) ],
                    cols:w(18,7,7,7,10,7,7,7,7,7,9,7,10,7,8,7,7,7,9,7) });
                XL.utils.book_append_sheet(wb, ws, 'Liga Standorte');
            })();

            // Blatt 2: Liga Teams — Calls und ALLE CR% auf LIGA-Call-Basis je Team/Standort
            (function(){
                const grp = ['Standort / Team','Liga-Calls','ENV BNT','','PTV BNT','','KIP BNT','','Mobilfunk BNT','','BNT','','','Mobilfunk VVL','','KIP VVL','','VVL','','','Kumuliert','',''];
                const sub = ['','IST','Stück','CR%','Stück','CR%','Stück','CR%','Stück','CR%','IST Stück','CR%','Ziel','Stück','CR%','Stück','CR%','IST Stück','CR%','Ziel','IST Stück','CR%','Ziel'];
                const aoa = [ [titel], grp, sub ];
                const groupRows = new Set();
                const rowOf = (o, lc) => { const cr = v => lc > 0 ? crF(v, lc) : '';
                    return [ '', lc > 0 ? lc : '', o.env, cr(o.env), o.ptv, cr(o.ptv), o.kip, cr(o.kip),
                    o.mob, cr(o.mob), o.bnt, cr(o.bnt), '', o.mobVvl, cr(o.mobVvl), o.kipVvl, cr(o.kipVvl),
                    o.vvl, cr(o.vvl), '', o.total, cr(o.total), '' ]; };
                stds.forEach(s => {
                    const gr = rowOf(s, liga.byStd[s.code] || 0); gr[0] = stdFullName(s.code);
                    groupRows.add(aoa.length); aoa.push(gr);
                    teams.filter(t => t.standort === s.code).sort((a,b) => b.total - a.total).forEach(t => {
                        const r = rowOf(t, liga.byTeam[t.name] || 0); r[0] = t.name; aoa.push(r);
                    });
                });
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1,2], hdrBg:'FFE60000', groupRows:groupRows,
                    pctCols:new Set([3,5,7,9,11,14,16,18,21]),
                    merges:[ M(0,0,0,22), M(1,0,2,0), M(1,1,2,1), M(1,2,1,3), M(1,4,1,5), M(1,6,1,7), M(1,8,1,9), M(1,10,1,12), M(1,13,1,14), M(1,15,1,16), M(1,17,1,19), M(1,20,1,22) ],
                    cols:w(18,7,7,7,7,7,7,7,9,7,8,7,6,10,7,7,7,7,7,6,9,7,6) });
                XL.utils.book_append_sheet(wb, ws, 'Liga Teams');
            })();

            // Blatt 3: Standorte (aggregiert; BCR-Quoten auf Liga-Call-Basis)
            flatSheet('Standorte', 'FF4A4D4E',
                ['Standort','KIP BNT','MOB BNT','FIB/DSL BNT','ENV BNT','BNT GES.','VVL GES.','BCR-rel.','n. BCR-rel.','Ansprachen','Liga-Calls','ESL-Kontakte','Tracking %','BCR-BNT (Liga)','BCR-VVL (Liga)','Gesamt'],
                stds.map(s => { const lc = liga.byStd[s.code] || 0; return [ stdFullName(s.code), s.kip, s.mob, s.fibDsl, s.env, s.bnt, s.vvl, bcrOf(s), nonBcrOf(s), s.pitches,
                    lc > 0 ? lc : '', s.calls, lc > 0 ? crF(s.calls, lc) : '', lc > 0 ? crF(s.bnt, lc) : '', lc > 0 ? crF(s.vvl, lc) : '', s.total ]; }),
                [12,13,14], w(18,8,8,10,8,9,9,8,8,10,9,11,10,12,12,8));

            // Blatt 4: Stacks (nach Standort + Stack aggregiert)
            (function(){
                const agg = {};
                Object.values(teamStats).forEach(t => {
                    const key = t.standort + '|' + (t.stack || '');
                    const o = agg[key] || (agg[key] = { standort:t.standort, stack:t.stack||'', kip:0,mob:0,fibDsl:0,env:0,bnt:0,vvl:0,bcr:0,nonBcr:0,pitches:0,calls:0,total:0 });
                    ['kip','mob','fibDsl','env','bnt','vvl','bcr','nonBcr','pitches','calls','total'].forEach(k => o[k] += (t[k]||0));
                });
                // Liga-Calls je Stack = Summe der zugeordneten Teams
                const stackLiga = {};
                Object.values(teamStats).forEach(t => {
                    const key = t.standort + '|' + (t.stack || '');
                    stackLiga[key] = (stackLiga[key] || 0) + (liga.byTeam[t.name] || 0);
                });
                flatSheet('Stacks', 'FF820000',
                    ['Standort','Stack','KIP','MOB','FIB/DSL','ENV','BNT gesamt','VVL','BCR-rel.','n. BCR-rel.','Ansprachen','Liga-Calls','ESL-Kontakte','BCR-BNT (Liga)','BCR-VVL (Liga)','Gesamt'],
                    Object.values(agg).filter(o => o.calls > 0).sort((a,b) => b.total - a.total).map(o => {
                        const lc = stackLiga[o.standort + '|' + o.stack] || 0;
                        return [ stdFullName(o.standort), o.stack, o.kip, o.mob, o.fibDsl, o.env, o.bnt, o.vvl, o.bcr||0, o.nonBcr||0, o.pitches,
                          lc > 0 ? lc : '', o.calls, lc > 0 ? crF(o.bnt||0, lc) : '', lc > 0 ? crF(o.vvl||0, lc) : '', o.total ]; }),
                    [13,14], w(16,14,7,7,9,7,9,7,8,8,9,9,11,12,12,8));
            })();

            // Blatt 5: Teams (BCR-Quoten auf Liga-Call-Basis)
            flatSheet('Teams', 'FF4A4D4E',
                ['Standort','Team','Stack','KIP','MOB','FIB/DSL','ENV','BNT gesamt','VVL','BCR-rel.','n. BCR-rel.','Liga-Calls','ESL-Kontakte','Tracking %','BCR-BNT (Liga)','BCR-VVL (Liga)','Ansprachen'],
                teams.map(t => { const lc = liga.byTeam[t.name] || 0; return [ stdFullName(t.standort), t.name, t.stack || '', t.kip, t.mob, t.fibDsl, t.env, t.bnt, t.vvl, bcrOf(t), nonBcrOf(t),
                    lc > 0 ? lc : '', t.calls, lc > 0 ? crF(t.calls, lc) : '', lc > 0 ? crF(t.bnt, lc) : '', lc > 0 ? crF(t.vvl, lc) : '', t.pitches ]; }),
                [13,14,15], w(16,10,12,6,6,8,6,9,7,8,8,9,11,10,12,12,9));

            // Blatt 6: Agenten (mit CCS-ID, Liga-Calls, Tracking-Quote, BCR-BNT/BCR-VVL auf Liga-Basis)
            flatSheet('Agenten', 'FF262626',
                ['Standort','Agent','CCS-ID','Team','KIP','MOB','FIB/DSL','ENV','BNT','VVL','BCR-rel.','n. BCR-rel.','Anspr.','Liga-Calls','ESL-Kontakte','Tracking %','BCR-BNT (Liga)','BCR-VVL (Liga)','Gesamt'],
                agentsAll.sort((a,b) => b.total - a.total).map(a => {
                    const kpi = window.rcKpiForAgent ? window.rcKpiForAgent(a) : null;
                    const lc = kpi ? (kpi.callCount || 0) : 0;
                    return [ stdFullName(a.standort), a.name, a.ccsId || (kpi ? kpi.ccsId : '') || '', a.team || '', a.kip, a.mob, a.fibDsl, a.env, a.bnt, a.vvl, bcrOf(a), nonBcrOf(a), a.ansprachen,
                        lc > 0 ? lc : '', a.kontakte || 0, lc > 0 ? crF(a.kontakte || 0, lc) : '', lc > 0 ? crF(a.bnt, lc) : '', lc > 0 ? crF(a.vvl, lc) : '', a.total ]; }),
                [15,16,17], w(16,18,10,10,5,5,7,5,5,5,7,7,7,8,10,9,11,11,7));

            // Blatt 7: ENTWICKLUNG — Tages-Trend rueckwirkend, im AKTIVEN Dashboard-Scope
            // (Standort-/Team-/Stack-Filter wirken auch auf dieses Blatt)
            (function(){
                if (!window.rcCollectTrend) return;
                const gv = id => { const el = document.getElementById(id); return el ? el.value : 'ALL'; };
                const tr = window.rcCollectTrend({ std: gv('rcStandortFilter'), team: gv('rcTeamFilter'), stack: gv('rcStackFilter') });
                if (!tr.days.length) return;
                const pctAvg = (s,n) => n > 0 ? +((s/n)/100).toFixed(4) : '';
                flatSheet('Entwicklung (' + tr.scopeLabel.slice(0, 16) + ')', 'FF2C57D2',
                    ['Tag','ESL-Kontakte','Ansprachen','BNT','VVL','Liga-Calls','BCR-BNT (Liga)','BCR-VVL (Liga)','CS Ø','TNPS Ø'],
                    tr.days.map(d => [ d.key + (d.today ? ' (heute)' : ''), d.esl.k, d.esl.a, d.esl.bnt, d.esl.vvl, d.liga.calls || '',
                        d.liga.calls > 0 ? crF(d.esl.bnt, d.liga.calls) : '', d.liga.calls > 0 ? crF(d.esl.vvl, d.liga.calls) : '',
                        pctAvg(d.liga.csS, d.liga.csN), pctAvg(d.liga.tnS, d.liga.tnN) ]),
                    [6,7,8,9], w(17,12,11,8,8,10,13,13,9,9));
            })();

            const fn = `regiocom_ESL_Report_${nd.getFullYear()}-${pad2(nd.getMonth()+1)}-${pad2(nd.getDate())}_${pad2(nd.getHours())}${pad2(nd.getMinutes())}.xlsx`;
            XL.writeFile(wb, fn);
            rcLog.log('Report exportiert (' + (styled ? 'mit' : 'ohne') + ' Styling): ' + fn);
        });
    };

    // KIP / MOB Liga — zeigt nur die (bereits gefilterten) Agenten.
    // Namen gross (vom Agenten-Monitor lesbar); jede Zeile hinter Platz 1
    // sagt konkret, wie viele Abschluesse zur Spitze fehlen.
    function renderLiga(elId, agentsArr, key, color, filterVal){
        const list = agentsArr.filter(a => a[key] > 0).sort((a,b) => b[key]-a[key]).slice(0,10);
        if (!list.length) { document.getElementById(elId).innerHTML = `<div style="padding:10px; color:#9C9C9C;">Noch keine Abschluesse — Platz 1 ist FREI: der erste Treffer holt die Krone!</div>`; return; }
        const top = list[0][key];
        let html = '';
        list.forEach((ag, i) => {
            const gap = top - ag[key];
            const chase = i === 0
                ? `<span style="font-size:9px; color:#FFD700; font-weight:700; letter-spacing:0.4px;">DIE KRONE GEHOERT DIR — VERTEIDIGE SIE!</span>`
                : `<span style="font-size:9px; color:#9C9C9C;">noch <b style="color:${color};">${gap + 1}</b> bis zur Krone</span>`;
            html += `<div class="rc-list-item" data-rc-vo="${rcAttr(ag.vo)}" data-rc-name="${rcAttr(ag.name)}" data-rc-std="${rcAttr(ag.standort)}" style="padding:7px 10px;">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;"><b style="font-size:14px;">${getFlagSvg(ag.standort,'small')} ${ag.name} <span class="rc-mono" style="color:#9C9C9C; font-size:10px; font-weight:400;">(${ag.standort})</span></b><br>${chase}</div>
                <div class="rc-mono" style="color:${color}; font-size:19px;">${ag[key]}</div>
            </div>`;
        });
        document.getElementById(elId).innerHTML = html;
    }

    // Unten rechts: erst die STILLEN KANONEN namentlich (Calls da, keine
    // Ansprache — die holen wir persoenlich rein), darunter kompakt die
    // Standorte ohne KIP/MOB. Respektiert den Standort-Filter.
    window.renderZeroSellers = function(standortStats) {
        const el = document.getElementById('rcRadarZeroSellers');
        if (!el) return;
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fCode = (fv && fv !== 'ALL') ? fv : null;
        let html = '';
        const stille = rcWarKrieger(fCode).filter(k => k.type === 'still').slice(0, 6);
        if (stille.length) {
            html += `<div style="font-size:9.5px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:#FF9E9E; margin-bottom:5px;">Wir vermissen euch an der Front — meldet euch!</div>`;
            html += stille.map(k => `<div class="rc-xl-item" data-rc-vo="${rcAttr(k.vo||'')}" data-rc-name="${rcAttr(k.name)}" data-rc-std="${rcAttr(k.std)}" style="border-left-color:#FF9E9E; padding:6px 10px;">
                <div style="flex:1;"><b style="font-size:14px;">${getFlagSvg(k.std,'small')} ${k.name}</b><br>
                    <span class="rc-xl-sub">${k.calls} Calls · 0 Ansprachen — du gehoerst zu uns, kaempf mit!</span></div>
                <div class="rc-xl-ask" style="color:#FF9E9E; font-size:10.5px;">DEIN 1. ANGRIFF<br>WARTET</div>
            </div>`).join('');
        }
        const list = ORDER.filter(code => {
            if (fCode && code !== fCode) return false;
            const s = standortStats[code] || {};
            return (!s.kip || s.kip === 0) && (!s.mob || s.mob === 0);
        });
        if (!list.length && !stille.length) {
            el.innerHTML = '<div style="padding:15px; color:#9C9C9C; text-align:center;">Alle Standorte haben getroffen — die Front steht!</div>';
            return;
        }
        if (list.length) {
            html += `<div style="font-size:9.5px; font-weight:700; letter-spacing:0.8px; text-transform:uppercase; color:#9C9C9C; margin:${stille.length ? 7 : 0}px 0 5px;">Standorte ohne KIP/MOB heute</div>`;
            list.forEach(code => {
                const m = STANDORT_METADATA[code] || {};
                html += `<div class="rc-list-item" data-rc-std="${rcAttr(code)}" style="padding:4px 10px; margin-bottom:4px;">
                    <div style="flex:1;"><b>${getFlagSvg(code,'small')} ${m.name || code}</b></div>
                    <div class="rc-mono" style="color:#FF6666; font-size:11px;">0 KIP / 0 MOB</div>
                </div>`;
            });
        }
        el.innerHTML = html;
    };

    // ============================================================
    //  LOW-PERFORMER-MODUL (Radar links unten) — rotiert alle 30 s
    //  zwischen Agentenbasis und Teambasis. Zeigt, wer heute noch
    //  KEIN Premium (KIP/MOB) auf dem Konto hat, aber aktiv ist
    //  (Ansprachen/Kontakte). Gegenstueck zu den Ligen darueber.
    //  Respektiert den Standort-Filter. Namen gross + klickbar.
    // ============================================================
    window.rcLowPerfMode = 0; // 0 = Agenten, 1 = Teams
    window.renderLowPerformer = function(){
        const el = document.getElementById('rcLowPerf'); if (!el) return;
        const st = window.rcLetzteStats;
        const ttl = document.getElementById('rcLowPerfTitle');
        const sub = document.getElementById('rcLowPerfSub');
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fCode = (fv && fv !== 'ALL') ? fv : null;
        if (!st) { el.innerHTML = '<div style="padding:14px; color:#9C9C9C; text-align:center; font-size:11px;">Warte auf Daten</div>'; return; }

        if (window.rcLowPerfMode === 1) {
            // ---------- TEAMBASIS ----------
            if (ttl) ttl.textContent = 'Teams ohne Premium-BNT';
            if (sub) sub.textContent = 'Teambasis';
            let teams = Object.values(st.teamStats || {}).filter(t => {
                if (fCode && t.standort !== fCode) return false;
                return (t.pitches || 0) > 0 || (t.calls || 0) > 0; // nur aktive Teams
            });
            let zero = teams.filter(t => (t.kip||0) === 0 && (t.mob||0) === 0);
            // Kein reines Null-Team? Dann die schwaechsten (wenigste KIP+MOB) zeigen.
            const rest = zero.length ? zero : teams.slice();
            rest.sort((a,b) => ((a.kip||0)+(a.mob||0)) - ((b.kip||0)+(b.mob||0))
                || (b.pitches||0) - (a.pitches||0) || (b.calls||0) - (a.calls||0));
            const list = rest.slice(0, 10);
            if (!list.length) { el.innerHTML = '<div style="padding:16px; color:#9C9C9C; text-align:center;">Alle aktiven Teams haben Premium gemacht — stark!</div>'; return; }
            el.innerHTML = list.map(t => {
                const km = (t.kip||0) + (t.mob||0);
                const isZero = km === 0;
                const col = isZero ? '#FF6666' : '#FFB020';
                return `<div class="rc-xl-item" data-rc-team="${rcAttr(t.code)}" data-rc-std="${rcAttr(t.standort)}" style="border-left-color:${col};">
                    <div style="flex:1;"><b>${getFlagSvg(t.standort,'small')} Team ${t.name}</b>
                        <span class="rc-xl-chip" style="background:${col};">${isZero ? '0 PREMIUM' : km + ' PREMIUM'}</span><br>
                        <span class="rc-xl-sub">${shortName(t.standort)} · ${t.pitches||0} Anspr · ${t.calls||0} Kont${(t.kip||0)||(t.mob||0) ? ' · ' + (t.kip||0) + ' KIP / ' + (t.mob||0) + ' MOB' : ''}</span></div>
                    <div class="rc-xl-ask" style="color:${col};">${isZero ? 'NOCH KEIN<br>DURCHBRUCH' : '1 KIP FEHLT<br>ZUR SPITZE'}</div>
                </div>`;
            }).join('');
        } else {
            // ---------- AGENTENBASIS ----------
            if (ttl) ttl.textContent = 'Agenten ohne Premium-BNT';
            if (sub) sub.textContent = 'Agentenbasis';
            let ags = Object.values(st.agentStats || {}).filter(a => {
                if (fCode && a.standort !== fCode) return false;
                if ((a.kip||0) > 0 || (a.mob||0) > 0) return false; // weder KIP noch MOB
                return (a.ansprachen||0) > 0 || (a.kontakte||0) > 0; // aber aktiv
            });
            // Fleissigste zuerst — sie arbeiten hart, nur der Premium-Treffer fehlt
            ags.sort((a,b) => (b.ansprachen||0) - (a.ansprachen||0)
                || (b.kontakte||0) - (a.kontakte||0));
            const list = ags.slice(0, 12);
            if (!list.length) { el.innerHTML = '<div style="padding:16px; color:#9C9C9C; text-align:center;">Alle aktiven Agenten haben Premium (KIP/MOB) — Wahnsinn!</div>'; return; }
            const bal = RC_WAR.balance || { dmgKip: 100, dmgMob: 70 };
            el.innerHTML = list.map(a => {
                return `<div class="rc-xl-item" data-rc-vo="${rcAttr(a.vo||'')}" data-rc-name="${rcAttr(a.name)}" data-rc-std="${rcAttr(a.standort)}" style="border-left-color:#FF6666;">
                    <div style="flex:1;"><b>${getFlagSvg(a.standort,'small')} ${a.name}</b>
                        <span class="rc-xl-chip" style="background:#FF6666;">0 KIP · 0 MOB</span><br>
                        <span class="rc-xl-sub">${shortName(a.standort)}${a.team ? ' · Team ' + a.team : ''} · ${a.ansprachen||0} Anspr · ${a.kontakte||0} Kont</span></div>
                    <div class="rc-xl-ask">1 KIP = +${(RC_WAR.score&&RC_WAR.score.kip)||35}<br>1 MOB = +${(RC_WAR.score&&RC_WAR.score.mob)||30} PKT</div>
                </div>`;
            }).join('');
        }
    };

    // ---------- TAGESBEFEHL (Radar links oben) ----------
    // Mit Standort-Filter: das Radar arbeitet NUR fuer diesen Standort und
    // sagt woertlich, wie viele KIP-/MOB-BNTs noch fehlen — zum Freikauf,
    // zur Eroberung des Ziels, zur Todeszonen-Rettung, zur naechsten
    // Ausbaustufe. Ohne Filter: kompakte Frontlage aller Burgen.
    window.renderRadarMission = function(){
        const el = document.getElementById('rcRadarMission'); if (!el) return;
        rcWarEnsureBases();
        const bal = RC_WAR.balance;
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fCode = (fv && fv !== 'ALL' && RC_WAR.bases[fv]) ? fv : null;
        const ttl = document.getElementById('rcRadarMissionTitle');
        const block = (col, head, body) => `<div style="background:rgba(255,255,255,0.03); border-left:3px solid ${col}; padding:7px 9px; margin:0 0 6px;">
            <div style="color:${col}; font-weight:700; font-size:12px;">${head}</div>
            <div style="color:#DCDCDC; font-size:11px; line-height:1.45;">${body}</div></div>`;

        if (!fCode) {
            if (ttl) ttl.textContent = 'Frontlage (alle Standorte)';
            const ranked = ORDER.map(c => RC_WAR.bases[c]).filter(b => b && RC_WAR_POS[b.code])
                .sort((a,b) => ((b.score||0)-(a.score||0)) || ((b.total||0)-(a.total||0)));
            const rows = ranked.map((b, i) => {
                const gapTxt = i === 0 ? '<span style="color:#FFCE00; font-weight:700;">FUEHRT</span>'
                    : 'noch <b style="color:'+((b.gapAbove||0)<=20?'#66DD88':'#C9B08A')+';">'+(b.gapAbove||0)+'</b> bis Platz '+i;
                return `<div class="rc-list-item" data-rc-std="${rcAttr(b.code)}">
                    <div style="flex:1;"><b>${i+1}. ${getFlagSvg(b.code,'small')} ${shortName(b.code)}</b> <span class="rc-mono" style="font-size:9px; color:#9C9C9C;">${Math.round(b.score||0)} PKT</span></div>
                    <div class="rc-mono" style="font-size:10px; color:${i===0?'#FFCE00':'#C9B08A'};">${gapTxt}</div></div>`;
            }).join('');
            el.innerHTML = rows + `<div style="font-size:9.5px; color:#6E6E6E; padding:6px 2px;">Standort-Filter oben setzen — dann arbeitet die ganze Karte fuer euren Standort und zeigt euren Tagesbefehl.</div>`;
            return;
        }

        const b = RC_WAR.bases[fCode];
        if (ttl) ttl.textContent = 'Tagesbefehl ' + shortName(fCode);
        const kipW = (RC_WAR.score && RC_WAR.score.kip) || 35;
        let html = '';
        // 1) EIN Ziel: der Rang direkt ueber uns (Nordstern)
        if ((b.rank||1) === 1 || !b.aboveCode) {
            const rk = ORDER.map(c => RC_WAR.bases[c]).filter(Boolean).sort((a,c)=>((c.score||0)-(a.score||0)));
            const chaser = rk[1];
            html += block('#FFCE00', 'PLATZ 1 — DIE KRONE IST UNSER',
                chaser ? `Vorsprung auf ${shortName(chaser.code)}: <b style="color:#FFCE00; font-size:14px;">${Math.max(0,Math.round((b.score||0)-(chaser.score||0)))} Punkte</b>. Jeder Abschluss baut den Vorsprung aus — die Jaeger schlafen nicht!`
                    : 'Alleinige Spitze.');
        } else {
            const above = RC_WAR.bases[b.aboveCode];
            html += block('#57D0E0', 'AUFHOLJAGD: PLATZ ' + b.rank + ' — JAGE ' + shortName(b.aboveCode).toUpperCase(),
                `Noch <b style="color:#FFCE00; font-size:14px;">${b.gapAbove||0} Punkte</b> bis Platz ${b.rank-1} (${shortName(b.aboveCode)} hat ${Math.round((above&&above.score)||0)}). Ein KIP-BNT = +${kipW} — ueberhole ihn und ihr tauscht die Plaetze!`);
        }
        // 2) Ausbau der eigenen Burg — Wert baut Mauern (Score-Stufen)
        const stufen = [[20,'STEINBURG'],[60,'FESTUNG'],[120,'ZITADELLE'],[200,'IMPERIUM']];
        const nextStufe = stufen.find(s => s[0] > (b.score||0));
        if (nextStufe) {
            html += block('#C9B08A', 'BURG-AUSBAU: noch ' + Math.round(nextStufe[0]-(b.score||0)) + ' Punkte bis ' + nextStufe[1],
                `Jede Ausbaustufe macht die Burg groesser und sichtbarer auf der Karte — Wert baut Mauern.`);
        }
        
        // 5) Ansprache-Chance (aus den echten Liga-Calls)
        if (b.ligaCalls >= 30) {
            const q = b.ansp / b.ligaCalls;
            if (q < 0.35) {
                const offen = Math.max(1, Math.round(b.ligaCalls * 0.4 - b.ansp));
                html += block('#FF6666', 'MUNITION LIEGT AUF DER STRASSE',
                    `Nur ${Math.round(q*100)}% Ansprache bei ${b.ligaCalls} Calls — <b>${offen} Chancen</b> heute noch nicht genutzt. Jede Ansprache ist ein moeglicher Angriff!`);
            }
        }
        el.innerHTML = html || '<div style="padding:10px; color:#9C9C9C; font-size:11px;">Warte auf Daten...</div>';
    };

    // ---------- KRIEGER VOR DEM DURCHBRUCH (Radar rechts) ----------
    // Wer macht Ansprachen oder liefert Top-Qualitaet, hat aber noch KEINEN
    // Abschluss? Diese Leute werden namentlich gerufen — der erste Treffer
    // ist der Durchbruch. Kandidaten auch fuer den Lagebericht auf der Karte.
    // Kategorisierte Kandidaten (alle mit type):
    //  'durchbruch' — Ansprachen da, noch KEIN Abschluss (der erste Treffer fehlt)
    //  'quali'      — CS >= 90, aber heute weder KIP noch MOB (Qualitaets-Ass ohne Krone;
    //                 darf andere Abschluesse haben — genau der "VeyseL"-Fall)
    //  'still'      — Calls da, aber KEINE Ansprache (stille Kanonen, wir holen sie rein)
    function rcWarKrieger(fCode){
        const st = window.rcLetzteStats; if (!st) return [];
        const out = [];
        const usedKpi = new Set();
        // Stack-/Team-Filter zusaetzlich zum Standort respektieren: sonst tauchen
        // Liga-Agenten AUS ANDEREN STACKS (z.B. MF_Care/VUM in Alanya) im
        // Helden-Ruf auf, obwohl der User VKD_Tech gewaehlt hat. Die agentStats
        // sind bereits stack-gefiltert (processDataStream), die rcKpiData NICHT.
        const fStack = (document.getElementById('rcStackFilter')||{}).value || 'ALL';
        const fTeam  = (document.getElementById('rcTeamFilter')||{}).value || 'ALL';
        const mp = window.rcWcaMapping || {};
        const ccsMapK = mp.ccsMap || {}, stackMapK = mp.stackMap || {};
        Object.values(st.agentStats || {}).forEach(a => {
            if (fCode && a.standort !== fCode) return;
            if (fStack !== 'ALL' && (a.stack || stackMapK[a.team] || '') !== fStack) return;
            if (fTeam !== 'ALL' && (a.team || '') !== fTeam) return;
            const sales = (a.bnt||0) + (a.vvl||0);
            const ansp = a.ansprachen || 0;
            const kpi = window.rcKpiForAgent ? window.rcKpiForAgent(a) : null;
            if (kpi) usedKpi.add(kpi);
            const cs = (kpi && kpi.cs != null) ? kpi.cs : null;
            const calls = kpi ? (kpi.callCount || 0) : 0;
            const topQ = cs != null && cs >= 90 && calls >= 5;
            const kipMob = (a.kip||0) + (a.mob||0);
            if (sales === 0 && ansp > 0) {
                out.push({ vo: a.vo, name: a.name, std: a.standort, ansp, cs, calls, type:'durchbruch',
                    score: 40 + ansp*10 + (topQ ? 15 : 0) + Math.min(calls, 20)*0.2 });
            } else if (sales === 0 && topQ) {
                out.push({ vo: a.vo, name: a.name, std: a.standort, ansp, cs, calls, type:'quali',
                    score: 30 + cs*0.2 + Math.min(calls, 20)*0.2 });
            } else if (sales > 0 && kipMob === 0 && topQ) {
                // Verkauft zwar, aber ohne KIP/MOB — mit Spitzen-Qualitaet: nur der Koenigsschuss fehlt
                out.push({ vo: a.vo, name: a.name, std: a.standort, ansp, cs, calls, type:'quali',
                    sales, score: 25 + cs*0.2 });
            } else if (sales === 0 && ansp === 0 && calls >= 10) {
                out.push({ vo: a.vo, name: a.name, std: a.standort, ansp: 0, cs, calls, type:'still',
                    score: 10 + Math.min(calls, 40)*0.3 });
            }
        });
        // Liga-Agenten OHNE ESL-Zeile heute: telefonieren, aber tauchen im
        // Verkaufs-Export nicht auf -> stille Kanonen, namentlich reinholen.
        // WICHTIG: Team/Stack aus dem Mapping herleiten und mitfiltern — sonst
        // erscheinen fremde Stacks (MF_Care/VUM/...) unter einem VKD-Filter.
        Object.values(window.rcKpiData || {}).forEach(k => {
            if (usedKpi.has(k)) return;
            const code = (typeof normalizeStandort === 'function') ? normalizeStandort(k.standort) : k.standort;
            if (!code || !STANDORT_METADATA[code]) return;
            if (fCode && code !== fCode) return;
            const meta = ccsMapK[k.ccsId] || {};
            const team = ((meta.team || k.team || '') + '').trim();
            const stack = stackMapK[team] || meta.stack || '';
            // Ohne Mapping-Zuordnung (kein Team/Stack bekannt) NICHT unter einem
            // aktiven Stack-/Team-Filter zeigen — wir wissen nicht, ob sie dazugehoeren.
            if (fStack !== 'ALL' && stack !== fStack) return;
            if (fTeam  !== 'ALL' && team  !== fTeam)  return;
            const calls = k.callCount || 0;
            if (calls < 10) return;
            out.push({ vo: null, name: k.agentName || ('CCS ' + k.ccsId), std: code, ansp: 0,
                cs: k.cs != null ? k.cs : null, calls, type:'still', score: 8 + Math.min(calls, 40)*0.3 });
        });
        return out.sort((x,y) => y.score - x.score);
    }

    // Chip-Farben + Beschriftung je Kandidaten-Typ (auch vom Helden-Ruf genutzt)
    const RC_KRIEGER_TYPE = {
        durchbruch: { chip:'VOR DEM DURCHBRUCH', col:'#FFCE00' },
        quali:      { chip:'QUALITAETS-ASS',     col:'#88CCFF' },
        still:      { chip:'STILLE KANONE',      col:'#FF9E9E' }
    };
    window.renderRadarKrieger = function(){
        const el = document.getElementById('rcRadarKrieger'); if (!el) return;
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fCode = (fv && fv !== 'ALL') ? fv : null;
        const list = rcWarKrieger(fCode).slice(0, 12);
        if (!list.length) {
            el.innerHTML = '<div style="padding:12px; color:#9C9C9C; font-size:11px; text-align:center;">Keine offenen Kandidaten — alle aktiven Kaempfer haben schon getroffen.</div>';
            return;
        }
        el.innerHTML = list.map(k => {
            const ty = RC_KRIEGER_TYPE[k.type] || RC_KRIEGER_TYPE.durchbruch;
            const zeile2 = k.type === 'quali'
                ? `CS ${k.cs != null ? k.cs.toFixed(0) : '?'}%${k.calls ? ' bei ' + k.calls + ' Calls' : ''} — nur der Koenigsschuss fehlt`
                : k.type === 'still'
                ? `${k.calls} Calls, noch keine Ansprache — wir holen dich rein!`
                : `${k.ansp} Ansprache${k.ansp===1?'':'n'}${k.cs != null ? ' · CS ' + k.cs.toFixed(0) + '%' : ''}${k.calls ? ' · ' + k.calls + ' Calls' : ''} — erster Treffer fehlt`;
            const ask = k.type === 'still'
                ? `<div class="rc-xl-ask" style="color:${ty.col};">1 ANSPRACHE<br>= 1 ANGRIFF</div>`
                : `<div class="rc-xl-ask">1 KIP =<br>+${(RC_WAR.score&&RC_WAR.score.kip)||35} PKT</div>`;
            return `<div class="rc-xl-item" data-rc-vo="${rcAttr(k.vo||'')}" data-rc-name="${rcAttr(k.name)}" data-rc-std="${rcAttr(k.std)}" style="border-left-color:${ty.col};">
                <div style="flex:1;"><b>${getFlagSvg(k.std,'small')} ${k.name}</b>
                    <span class="rc-xl-chip" style="background:${ty.col};">${ty.chip}</span><br>
                    <span class="rc-xl-sub">${zeile2}</span></div>
                ${ask}
            </div>`;
        }).join('');
    };

    // ============================================================
    //  HELDEN-RUF — die riesige persoenliche Ansprache ueber der Karte.
    //  Rotiert alle 11 s durch ALLE Mitarbeiter (Helden zuerst gelobt,
    //  dann Durchbruch-Kandidaten, Qualitaets-Asse, stille Kanonen):
    //  Name in 40px — lesbar vom anderen Ende des Grossraums — plus
    //  konkrete Zahl, was SEIN naechster Schritt fuer die Nation bewirkt.
    //  Respektiert den Standort-Filter. Keine Emojis, ae/oe/ue.
    // ============================================================
    const RC_HERO_SLOGAN = {
        TR: ['GANZ ALANYA STEHT HINTER DIR', 'DIE TUERKEI IST STOLZ AUF DICH', 'DU KAEMPFST FUER DEN HALBMOND'],
        GR: ['GANZ HELLAS JUBELT DIR ZU', 'SPARTA WAERE STOLZ AUF DICH', 'DU KAEMPFST FUER GRIECHENLAND'],
        DE: ['DEUTSCHLAND ZAEHLT AUF DICH', 'DIE HEIMAT SCHAUT AUF DICH', 'DU KAEMPFST FUER DAS REICH DER BURGEN'],
        AT: ['GANZ OESTERREICH VERTRAUT DIR', 'DIE ALPEN GRUESSEN IHREN HELDEN']
    };
    const RC_HERO_STRIPES = {
        TR: ['#E30A17','#FFFFFF','#E30A17'], GR: ['#0D5EAF','#FFFFFF','#0D5EAF'],
        DE: ['#161616','#DD0000','#FFCE00'], AT: ['#ED2939','#FFFFFF','#ED2939']
    };
    window.rcHeroIdx = 0;
    // Rotations-Liste: Helden (Lob) + alle Kandidaten-Typen, rundgemischt,
    // damit nacheinander verschiedene Kategorien erscheinen
    function rcHeroCallList(fCode){
        const st = window.rcLetzteStats; if (!st) return [];
        const byType = { held: [], durchbruch: [], quali: [], still: [] };
        Object.values(st.agentStats || {}).forEach(a => {
            if (fCode && a.standort !== fCode) return;
            if ((a.kip||0) + (a.mob||0) > 0)
                byType.held.push({ name: a.name, vo: a.vo, std: a.standort, type:'held', kip: a.kip||0, mob: a.mob||0 });
        });
        byType.held.sort((x,y) => (y.kip + y.mob) - (x.kip + x.mob));
        rcWarKrieger(fCode).forEach(k => { if (byType[k.type]) byType[k.type].push(k); });
        const order = ['held','durchbruch','quali','still'], out = [];
        for (let i = 0; out.length < 60; i++) {
            let added = false;
            order.forEach(t => { if (byType[t][i]) { out.push(byType[t][i]); added = true; } });
            if (!added) break;
        }
        return out;
    }
    function rcHeroCallEl(){
        let el = document.getElementById('rcHeroCall');
        if (!el) {
            const wrap = document.getElementById('rcRadarSvgWrap');
            if (!wrap || !wrap.parentElement) return null;
            el = document.createElement('div');
            el.id = 'rcHeroCall'; el.className = 'rc-herocall';
            wrap.parentElement.appendChild(el);
        }
        return el;
    }
    window.rcHeroCallTick = function(){
        if (window.rcActivePage !== 'radar' || window.rcRadarMode === 'league') return;
        if (window.rcWarHud && !window.rcWarHud.heroRuf) { const _e = document.getElementById('rcHeroCall'); if (_e) { _e.style.display = 'none'; _e.innerHTML = ''; } return; }
        const el = rcHeroCallEl(); if (!el) return;
        el.style.display = '';
        const _heroKompakt = !!(window.rcWarHud && window.rcWarHud.heroKompakt);
        el.classList.toggle('rc-hero-kompakt', _heroKompakt);
        // Bei aktivem Stunden-Duell (zentrales Top-HUD) weicht der Helden-Ruf nach unten aus.
        try { el.classList.toggle('rc-duel', !!(RC_WAR.duel && RC_WAR.duel.active)); } catch(e){}
        const fv = (document.getElementById('rcStandortFilter')||{}).value;
        const fCode = (fv && fv !== 'ALL' && STANDORT_METADATA[fv]) ? fv : null;
        const list = rcHeroCallList(fCode);
        if (!list.length) { el.innerHTML = ''; return; }
        const k = list[window.rcHeroIdx % list.length];
        window.rcHeroIdx++;
        const nation = (STANDORT_METADATA[k.std] || {}).nation || '';
        const slogans = RC_HERO_SLOGAN[nation] || ['DEINE BURG BRAUCHT DICH'];
        const slogan = slogans[window.rcHeroIdx % slogans.length];
        const scw = (window.rcWar && window.rcWar.score) || { kip:35, mob:30 };
        const myBaseH = RC_WAR.bases[k.std];
        const plN = (myBaseH && myBaseH.rank) ? ('Platz ' + myBaseH.rank) : '';
        let kicker, kcol, msg;
        if (k.type === 'held') {
            kicker = 'HELD DES TAGES — ' + shortName(k.std).toUpperCase(); kcol = '#FFD700';
            // Persoenlicher Ziel-Fortschritt (echte Zahlen aus agentStats: k.kip/k.mob)
            const _z = (window.rcWar && window.rcWar.ziele) || {}, _kz = _z.kipProAgent||1, _mz = _z.mobProAgent||2;
            const _kh = k.kip||0, _mh = k.mob||0, _rk = Math.max(0, _kz - _kh), _rm = Math.max(0, _mz - _mh);
            let _ziel;
            if (_rk === 0 && _rm === 0) _ziel = 'TAGESZIEL ERFUELLT — JETZT DRAUFLEGEN, DU HELD!';
            else { const _p = []; if (_rk > 0) _p.push('noch ' + _rk + ' KIP'); if (_rm > 0) _p.push('noch ' + _rm + ' Mobilfunk'); _ziel = _p.join(' · ') + ' bis zum Tagesziel!'; }
            msg = `<b>${_kh}/${_kz} KIP · ${_mh}/${_mz} Mobilfunk</b> — ${_ziel} DEINE Hand baut die Burg.`;
        } else if (k.type === 'quali') {
            kicker = 'QUALITAETS-ASS — ' + shortName(k.std).toUpperCase(); kcol = '#88CCFF';
            msg = `CS <b>${k.cs != null ? k.cs.toFixed(0) : '?'}%</b> — deine Qualitaet ist eine Festung. Jetzt fehlt nur DEIN Koenigsschuss: <b>1 KIP = +${scw.kip||35} Punkte</b>!`;
        } else if (k.type === 'still') {
            kicker = 'DIE FRONT RUFT DICH — ' + shortName(k.std).toUpperCase(); kcol = '#FF9E9E';
            msg = `<b>${k.calls} Calls</b> — jeder Kunde ist eine Chance. Deine ERSTE Ansprache ist der Angriff. Du gehoerst zu uns!`;
        } else {
            kicker = 'KURZ VOR DEM DURCHBRUCH — ' + shortName(k.std).toUpperCase(); kcol = '#FFCE00';
            msg = `<b>${k.ansp} Ansprache${k.ansp===1?'':'n'}</b>${k.cs != null ? ', CS ' + k.cs.toFixed(0) + '%' : ''} — dein erster Treffer klettert die Rangliste: <b>1 KIP = +${scw.kip||35} Punkte</b>!`;
        }
        // Team-Kontext: was bewirkt SEIN Abschluss fuer den Rang?
        let teamLine = slogan;
        try {
            const myB = RC_WAR.bases[k.std];
            if (myB && (myB.rank||9) > 1 && myB.aboveCode) teamLine = slogan + ' — NOCH ' + (myB.gapAbove||0) + ' PUNKTE BIS PLATZ ' + (myB.rank-1) + ' (' + shortName(myB.aboveCode).toUpperCase() + ')';
            else if (myB && myB.rank === 1) teamLine = slogan + ' — ' + shortName(k.std).toUpperCase() + ' FUEHRT DIE WERTUNG, VORSPRUNG HALTEN!';
        } catch(e){}
        const stripes = (RC_HERO_STRIPES[nation] || ['#E60000','#FFFFFF','#E60000'])
            .map(c => `<i style="background:${c};"></i>`).join('');
        const card = document.createElement('div');
        card.className = 'rc-herocall-card';
        card.style.borderColor = kcol;
        card.innerHTML = `
            <div class="rc-herocall-kicker" style="color:${kcol};">${kicker}</div>
            <div class="rc-herocall-name">${getFlagSvg(k.std,'xl',true)}${rcAttr(k.name)}</div>
            <div class="rc-herocall-msg">${msg}</div>
            <div class="rc-herocall-sub">${teamLine}</div>
            <div class="rc-herocall-stripes">${stripes}</div>`;
        const old = el.firstElementChild;
        if (old) { old.classList.add('out'); setTimeout(() => { el.innerHTML = ''; el.appendChild(card); }, 380); }
        else el.appendChild(card);
        // Kompakt: kuerzere Standzeit — nach 6s ausblenden, damit die Mitte frei wird.
        if (window._rcHeroHideTO) { clearTimeout(window._rcHeroHideTO); window._rcHeroHideTO = null; }
        if (_heroKompakt) { window._rcHeroHideTO = setTimeout(function(){ const c = el.firstElementChild; if (c) c.classList.add('out'); }, 6000); }
    };

    function renderSide(agentsArr, filterVal){
        const tab = window.rcActiveSideTab;
        const key = tab==='ansp' ? 'ansprachen' : (tab==='offers' ? 'offers' : 'vvl');
        const color = tab==='ansp' ? '#FF6666' : (tab==='offers' ? '#FF9E9E' : '#B4B4B4');
        let arr = agentsArr.filter(a => a[key] > 0).sort((a,b) => b[key]-a[key]).slice(0,10);
        let html = '';
        arr.forEach((ag, i) => {
            html += `<div class="rc-list-item" data-rc-vo="${rcAttr(ag.vo)}" data-rc-name="${rcAttr(ag.name)}">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;"><b>${getFlagSvg(ag.standort,'small')} ${ag.name} <span class="rc-mono" style="color:#9C9C9C; font-size:10px; font-weight:400;">(${ag.standort})</span></b>${tab==='offers' ? '<div style="font-size:9px; color:#FF6666; font-weight:700; letter-spacing:0.4px;">JETZT NACHFASSEN — ANGEBOT LIEGT BEIM KUNDEN</div>' : ''}</div>
                <div class="rc-mono" style="color:${color}; font-size:15px;">${ag[key]}</div>
            </div>`;
        });
        const emptyMsg = tab==='offers' ? 'Keine offenen Angebote — alles nachgefasst' : 'Noch keine Daten';
        document.getElementById('rcSideLeaderboard').innerHTML = html || `<div style="padding:10px; color:#9C9C9C;">${emptyMsg}</div>`;
    }

    function renderStandorte(statsObj, isTeam){
        const el = document.getElementById('rcStandortBattleList');
        const arr = Object.values(statsObj);
        // Team-Modus: kein Flaggen-SVG (Team-ID hat keine Flagge), neutrale Farbe
        const flag = (s) => isTeam ? '' : (getFlagSvg(s.code,'small') + ' ');
        const label = (s) => isTeam ? ('Team ' + s.name) : shortName(s.code);
        const emptyTxt = isTeam ? 'Keine Team-Daten' : 'Keine Standort-Daten';
        if (window.rcActiveStandortTab === 'rates') {
            const rows = arr.filter(s => s.calls > 0).map(s => ({...s,
                pitchRate: s.calls>0?Math.round(s.pitches/s.calls*100):0,
                bntRate:   s.calls>0?Math.round(s.bnt/s.calls*100):0,
                rejRate:   s.calls>0?Math.round(s.rejections/s.calls*100):0
            })).sort((a,b) => b.bntRate-a.bntRate);
            let html = '';
            rows.forEach(s => {
                const col = s.bntRate>=15?'#F5F5F5':(s.bntRate>=8?'#FF6666':'#E60000');
                html += `<div style="margin-bottom:9px; padding:2px 4px;" ${isTeam?`data-rc-team="${rcAttr(s.code)}"`:`data-rc-std="${rcAttr(s.code)}"`}>
                    <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px;">
                        <span>${flag(s)}<b>${label(s)}</b></span>
                        <span class="rc-mono" style="font-size:10px; color:#9C9C9C; font-weight:400;">Abschl <b style="color:${col};">${s.bntRate}%</b> · Ansp ${s.pitchRate}% · Abl ${s.rejRate}%</span>
                    </div>
                    <div class="rc-bar-track"><div class="rc-bar-fill" style="background:${col}; width:${Math.min(s.bntRate*3,100)}%;"></div></div>
                </div>`;
            });
            el.innerHTML = html || `<div style="padding:10px; color:#9C9C9C;">${emptyTxt}</div>`;
        } else {
            const rows = arr.filter(s => s.total > 0).sort((a,b) => b.total-a.total);
            const max = rows.length ? rows[0].total : 1;
            let html = '';
            rows.forEach(s => {
                const meta = STANDORT_METADATA[s.code], col = isTeam ? '#BD0000' : (meta?meta.color:'#9C9C9C');
                html += `<div style="margin-bottom:9px; padding:2px 4px;" ${isTeam?`data-rc-team="${rcAttr(s.code)}"`:`data-rc-std="${rcAttr(s.code)}"`}>
                    <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px;">
                        <span>${flag(s)}<b>${label(s)}</b> <span class="rc-mono" style="font-size:9px; color:#9C9C9C; font-weight:400;">KIP ${s.kip} · MOB ${s.mob}</span></span>
                        <span class="rc-mono" style="color:#F5F5F5;"><b>${s.bnt}</b> BNT · ${s.vvl} VVL</span>
                    </div>
                    <div class="rc-bar-track"><div class="rc-bar-fill" style="background:${col}; width:${Math.max(3,s.total/max*100)}%;"></div></div>
                </div>`;
            });
            el.innerHTML = html || `<div style="padding:10px; color:#9C9C9C;">${emptyTxt}</div>`;
        }
    }

    // Team-Dropdown fuer den gewaehlten Standort befuellen (nur sichtbar wenn ein Standort gewaehlt ist).
    // teamInfo: Map(team -> {esl, liga}) mit der Datenlage je Team; ein blankes Set
    // wird weiterhin akzeptiert (dann ohne Datenlage-Hinweis).
    function updateTeamFilter(std, teamInfo){
        const sel = document.getElementById('rcTeamFilter');
        if (!sel) return;
        sel.style.display = '';   // Team-Filter IMMER sichtbar (zeigt, dass es ihn gibt)
        if (std === 'ALL' || !teamInfo || !teamInfo.size) {
            if (sel.dataset.sig !== 'none') { sel.innerHTML = '<option value="ALL">Team (erst Standort waehlen)</option>'; sel.dataset.sig = 'none'; }
            sel.value = 'ALL'; sel.disabled = true;   // sichtbar aber deaktiviert
            if (window.rcMarkFilters) rcMarkFilters();
            return;
        }
        const cur = sel.value;
        const infoOf = t => (typeof teamInfo.get === 'function' ? (teamInfo.get(t) || {}) : {});
        // Sortierung nach Datenlage: erst Teams mit ESL-Verkaufsdaten, dann
        // Liga-only-Teams (Qualitaet vorhanden), zuletzt die leeren. Sonst stehen
        // rein alphabetisch die Karteileichen vorn und das Dashboard wirkt kaputt.
        const rang = t => { const i = infoOf(t); return i.esl ? 0 : (i.liga ? 1 : 2); };
        const teams = [...(teamInfo.keys ? teamInfo.keys() : teamInfo)]
            .sort((a, b) => (rang(a) - rang(b)) || a.localeCompare(b));
        const label = t => {
            const i = infoOf(t);
            if (i.esl)  return `Team ${t} (${i.esl} Agent${i.esl === 1 ? '' : 'en'}${i.liga ? ' · Liga' : ''})`;
            if (i.liga) return `Team ${t} (nur Qualitaet, ${i.liga} Liga-Agent${i.liga === 1 ? '' : 'en'})`;
            return `Team ${t} — keine Daten heute`;
        };
        // Signatur nur ueber Team-Liste + Datenlage-KLASSE: die Zahlen wachsen den
        // Tag ueber staendig; ein innerHTML-Neubau bei jedem Poll wuerde ein offenes
        // Dropdown zuklappen. Aendern sich nur die Zahlen, werden die Labels an Ort
        // und Stelle nachgezogen.
        const sig = std + '|' + teams.map(t => t + ':' + rang(t)).join(',');
        if (sel.dataset.sig !== sig) {
            sel.innerHTML = '<option value="ALL">Alle Teams</option>'
                + teams.map(t => `<option value="${rcAttr(t)}">${label(t)}</option>`).join('');
            sel.dataset.sig = sig;
            sel.value = (cur && teams.includes(cur)) ? cur : 'ALL';
        } else {
            [...sel.options].forEach(o => { if (o.value !== 'ALL') { const nt = label(o.value); if (o.textContent !== nt) o.textContent = nt; } });
        }
        sel.disabled = false;
        if (window.rcMarkFilters) rcMarkFilters();
    }

    // Team-Battle: Teams des gewaehlten Standorts als Wettbewerber (bei Standort-Filter)
    function renderTeamBattle(teamStats, filterStd, filterTeam){
        const el = document.getElementById('rcNationBattleList');
        document.getElementById('rcBattleTitle').textContent = 'Team-Battle';
        document.getElementById('rcStandorteTitle').textContent = 'Teams';
        document.getElementById('rcBattleHint').textContent = STANDORT_METADATA[filterStd] ? STANDORT_METADATA[filterStd].name : filterStd;
        document.getElementById('rcNationPicker').style.display = 'none';
        const stdCol = (STANDORT_METADATA[filterStd] || {}).color || '#BD0000';

        let arr = Object.values(teamStats).filter(t => t.total > 0).sort((a,b) => b.total-a.total);
        if (!arr.length) { el.innerHTML = `<div style="padding:10px; color:#9C9C9C;">Noch keine Team-Abschluesse in ${filterStd}</div>`; return; }

        // Genau 2 Teams -> Duell (Gewinner: roter Rahmen + Speechmark-Radius)
        if (arr.length === 2) {
            const [A,B] = arr, tot = Math.max(A.total+B.total,1);
            const aPct = Math.round(A.total/tot*100), bPct = 100-aPct;
            const win = A.total===B.total ? null : (A.total>B.total?A.code:B.code);
            const side = (s, isWin) => `<div class="rc-duel-side" data-rc-team="${rcAttr(s.code)}" style="${isWin?'border:2px solid #E60000; border-radius:6px 18px 6px 6px; background:#2A2A2A;':''}">
                <div style="font-weight:700; font-size:12.5px; color:#F5F5F5;">Team ${s.name}</div>
                <div class="rc-mono" style="font-size:24px; color:${stdCol};">${s.total}</div>
                <div class="rc-mono" style="font-size:9px; color:#9C9C9C; font-weight:400;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
            </div>`;
            el.innerHTML = `<div class="rc-duel">${side(A,win===A.code)}<div class="rc-duel-vs">VS</div>${side(B,win===B.code)}</div>
                <div class="rc-tug"><div style="width:${aPct}%; background:${stdCol};"></div><div style="width:${bPct}%; background:#8C8C8C;"></div></div>
                <div style="display:flex; justify-content:space-between; font-size:10px; color:#9C9C9C; margin-top:5px;" class="rc-mono"><span>${aPct}%</span><span>Vorsprung: ${Math.abs(A.total-B.total)}</span><span>${bPct}%</span></div>`;
            return;
        }
        // Ranking
        let html = '';
        arr.forEach((t, i) => {
            const hi = (filterTeam !== 'ALL' && t.code === filterTeam);
            html += `<div class="rc-list-item" data-rc-team="${rcAttr(t.code)}" style="padding:7px 10px; border-left:3px solid ${hi?stdCol:'#3E3E3E'}; ${i===0?'background:rgba(254,203,0,0.08);':''}">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;">
                    <div style="font-weight:700; font-size:12.5px; color:#F5F5F5;">Team ${t.name}</div>
                    <div class="rc-mono" style="font-size:9px; color:#9C9C9C; font-weight:400;">KIP ${t.kip} · MOB ${t.mob} · VVL ${t.vvl}</div>
                </div>
                <div class="rc-mono" style="font-size:17px; color:${stdCol};">${t.total}</div>
            </div>`;
        });
        el.innerHTML = html;
    }

    // Standort-Battle: jeder Standort ist ein Wettbewerber (Flagge + Standortname).
    // Ein Land kann mehrere Standorte haben (GR = Serres + Alexandroupolis), daher NICHT nach Nation gruppieren.
    function renderStandortBattle(standortStats){
        const el = document.getElementById('rcNationBattleList');
        // Titel/Picker aus evtl. Team-Modus zuruecksetzen
        document.getElementById('rcBattleTitle').textContent = 'Standort-Battle';
        document.getElementById('rcStandorteTitle').textContent = 'Standorte';
        document.getElementById('rcBattleHint').textContent = 'Flaggen antippen';
        document.getElementById('rcNationPicker').style.display = '';
        const sel = window.rcSelectedStandorte;
        const arr = ORDER.filter(c => sel.has(c) && standortStats[c] && standortStats[c].total > 0)
                         .map(c => standortStats[c]).sort((a,b) => b.total-a.total);
        if (!arr.length) { el.innerHTML = `<div style="padding:10px; color:#9C9C9C;">Keine Daten fuer die gewaehlten Standorte</div>`; return; }
        const colOf = c => (STANDORT_METADATA[c] || {}).color || '#7E7E7E';

        // Duell-Ansicht bei genau 2 aktiven Standorten (Gewinner: roter Speechmark-Rahmen).
        // Duell-Farben fest Rot vs. Schwarz — die Flaggen identifizieren die Standorte.
        if (arr.length === 2) {
            const [A,B] = arr, tot = Math.max(A.total+B.total,1);
            const aPct = Math.round(A.total/tot*100), bPct = 100-aPct;
            const colA = '#E60000', colB = '#FFFFFF';
            const win = A.total===B.total ? null : (A.total>B.total?A.code:B.code);
            const side = (s, col, isWin) => `<div class="rc-duel-side" data-rc-std="${rcAttr(s.code)}" style="${isWin?'border:2px solid #E60000; border-radius:6px 18px 6px 6px; background:#2A2A2A;':''}">
                <div>${getFlagSvg(s.code,'large',isWin)}</div>
                <div style="font-weight:700; font-size:13px; color:#F5F5F5; margin-top:4px; letter-spacing:0.3px;">${shortName(s.code)}</div>
                <div class="rc-mono" style="font-size:24px; color:${col};">${s.total}</div>
                <div class="rc-mono" style="font-size:9px; color:#9C9C9C; font-weight:400;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
            </div>`;
            el.innerHTML = `<div class="rc-duel">${side(A,colA,win===A.code)}<div class="rc-duel-vs">VS</div>${side(B,colB,win===B.code)}</div>
                <div class="rc-tug"><div style="width:${aPct}%; background:${colA}; transition:width 0.9s;"></div><div style="width:${bPct}%; background:${colB}; transition:width 0.9s;"></div></div>
                <div style="display:flex; justify-content:space-between; font-size:10px; color:#9C9C9C; margin-top:5px;" class="rc-mono"><span>${aPct}%</span><span>Vorsprung: ${Math.abs(A.total-B.total)}</span><span>${bPct}%</span></div>`;
            return;
        }
        // Ranking-Ansicht
        let html = '';
        arr.forEach((s, i) => {
            const col = colOf(s.code);
            html += `<div class="rc-list-item" data-rc-std="${rcAttr(s.code)}" style="padding:7px 10px; border-left:3px solid ${col}; ${i===0?'background:rgba(254,203,0,0.08);':''}">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="display:flex; align-items:center;">${getFlagSvg(s.code,'small',i===0)}</div>
                <div style="flex:1; margin-left:4px;">
                    <div style="font-weight:700; font-size:12.5px; color:#F5F5F5;">${shortName(s.code)}</div>
                    <div class="rc-mono" style="font-size:9px; color:#9C9C9C; font-weight:400;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
                </div>
                <div class="rc-mono" style="font-size:17px; color:${col};">${s.total}</div>
            </div>`;
        });
        el.innerHTML = html;
    }

    function renderProducts(sheetData, idx){
        const counts = {};
        for (let i=1;i<sheetData.length;i++){ const r=sheetData[i]; if(!r) continue;
            const pg=(r[idx.prod]||'').toString().trim(), anz=parseInt(r[idx.anz])||0, erg=(r[idx.erg]||'').toString().toLowerCase();
            if (anz>0 && erg.includes('angenommen') && pg) counts[pg]=(counts[pg]||0)+anz; // nur echte Abschluesse
        }
        const top = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0,6);
        const max = top.length ? top[0][1] : 1;
        let html = '';
        top.forEach(([name,cnt], i) => {
            html += `<div style="margin-bottom:7px;">
                <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:2px;">
                    <span style="font-weight:700; color:#F5F5F5; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:78%;" title="${name}">${i+1}. ${name}</span>
                    <span class="rc-mono" style="color:#F5F5F5;">${cnt}x</span>
                </div>
                <div class="rc-bar-track"><div class="rc-bar-fill" style="background:#BD0000; width:${Math.max(4,cnt/max*100)}%;"></div></div>
            </div>`;
        });
        const el = document.getElementById('rcTopProductsList');
        el.innerHTML = html || `<div style="color:#9C9C9C; font-size:11px;">Keine Daten</div>`;
    }

    // Gemeinsame EKG-Monitor-Optik fuer die beiden Verlaufscharts
    const RC_EKG_OPTS = (yTitle) => ({ responsive:true, maintainAspectRatio:false, interaction:{mode:'index',intersect:false},
        animation:{ duration:800, easing:'linear' },
        plugins:{ legend:{ position:'top', labels:{ color:'#C9C9C9', boxWidth:9, usePointStyle:true, font:{size:9.5} } },
            tooltip:{ backgroundColor:'#1D1D1D', titleColor:'#F5F5F5', bodyColor:'#C9C9C9', borderColor:'#3E3E3E', borderWidth:1 } },
        scales:{
            x:{ grid:{color:'rgba(255,255,255,0.05)'}, ticks:{color:'#9C9C9C', font:{size:8.5}} },
            y:{ position:'left', grid:{color:'rgba(255,255,255,0.08)'}, ticks:{color:'#9C9C9C', font:{size:8.5}, precision:0},
                title:{display:!!yTitle, text:yTitle||'', color:'#9C9C9C', font:{size:8.5}} }
        } });

    function renderTrend(hourLabels, trendByStd, anspTrend){
        // Abschluesse je STANDORT (kumulierte Linien) + Ansprachen/h als Balken.
        // Bei aktivem Filter enthaelt trendByStd nur die gefilterten Standorte.
        const cum = a => a.reduce((acc,v,i) => { acc.push((acc[i-1]||0)+v); return acc; }, []);
        const ctx = document.getElementById('rcTrendChart');
        if (!ctx || !window.Chart) return;
        const codes = ORDER.filter(c => trendByStd[c] && trendByStd[c].some(v => v > 0));
        const ds = [{ type:'bar', label:'Ansprachen/h', data:(anspTrend||[]), backgroundColor:'rgba(180,180,180,0.28)',
                      borderRadius:2, yAxisID:'y1', order:5 }];
        codes.forEach(c => {
            const m = STANDORT_METADATA[c];
            ds.push({ type:'line', label:shortName(c), data:cum(trendByStd[c]), borderColor:m.color, borderDash:(m.dash||[]),
                backgroundColor:m.color+'22', fill:'origin', borderWidth:2.5, tension:0.25, pointRadius:0, pointHoverRadius:4, yAxisID:'y', order:1 });
        });
        if (window.rcChartInstance && (window.rcChartInstance.canvas !== ctx || window.rcChartInstance.data.datasets.length !== ds.length)) {
            try { window.rcChartInstance.destroy(); } catch(e){}
            window.rcChartInstance = null;
        }
        if (window.rcChartInstance) {
            window.rcChartInstance.data.labels = hourLabels;
            window.rcChartInstance.data.datasets.forEach((d,i) => { d.data = ds[i].data; d.label = ds[i].label; if (ds[i].borderColor) d.borderColor = ds[i].borderColor; });
            window.rcChartInstance.update();
        } else {
            const opts = RC_EKG_OPTS('Abschluesse (kum.)');
            opts.scales.y.beginAtZero = true;
            opts.scales.y1 = { position:'right', grid:{display:false}, ticks:{color:'#9C9C9C', font:{size:8.5}, precision:0}, beginAtZero:true };
            window.rcChartInstance = new Chart(ctx, { data:{ labels:hourLabels, datasets:ds }, options:opts });
        }
    }

    // TNPS-Historie: bei jedem KPI-Batch ein Snapshot je Standort (max 72 Punkte = 6 Std)
    window.rcTnpsHistory = window.rcTnpsHistory || [];
    window.rcCaptureTnpsSnapshot = function(){
        const list = Object.values(window.rcKpiData || {});
        if (!list.length) return;
        const per = {};
        list.forEach(k => {
            if (k.tnps == null) return;
            const c = normalizeStandort(k.standort);
            (per[c] || (per[c] = [])).push(k.tnps);
        });
        const snap = { t: new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}), v: {} };
        Object.entries(per).forEach(([c, arr]) => snap.v[c] = +(arr.reduce((s,x)=>s+x,0)/arr.length).toFixed(1));
        const last = window.rcTnpsHistory[window.rcTnpsHistory.length-1];
        if (last && last.t === snap.t) window.rcTnpsHistory[window.rcTnpsHistory.length-1] = snap;
        else window.rcTnpsHistory.push(snap);
        if (window.rcTnpsHistory.length > 72) window.rcTnpsHistory.shift();
    };

    window.renderTnpsChart = function(){
        const ctx = document.getElementById('rcTnpsChart');
        if (!ctx || !window.Chart) return;
        const hist = window.rcTnpsHistory;
        const filterVal = document.getElementById('rcStandortFilter').value;
        const labels = hist.map(h => h.t);
        let codes = ORDER.filter(c => hist.some(h => h.v[c] != null));
        if (filterVal !== 'ALL') codes = codes.filter(c => c === filterVal); // Filter -> nur dieser Standort
        const pr = hist.length < 3 ? 3 : 0; // bei wenigen Snapshots Punkte zeigen, sonst waere nichts sichtbar
        const ds = codes.map(c => ({ type:'line', label:shortName(c), data:hist.map(h => h.v[c] != null ? h.v[c] : null),
            borderColor:STANDORT_METADATA[c].color, borderDash:(STANDORT_METADATA[c].dash||[]), backgroundColor:STANDORT_METADATA[c].color+'1C', fill:'origin', borderWidth:2.5, tension:0.25,
            pointRadius:pr, pointHoverRadius:4, spanGaps:true }));
        if (window.rcTnpsChartInstance && (window.rcTnpsChartInstance.canvas !== ctx || window.rcTnpsChartInstance.data.datasets.length !== ds.length)) {
            try { window.rcTnpsChartInstance.destroy(); } catch(e){}
            window.rcTnpsChartInstance = null;
        }
        if (!ds.length) return;
        if (window.rcTnpsChartInstance) {
            window.rcTnpsChartInstance.data.labels = labels;
            window.rcTnpsChartInstance.data.datasets.forEach((d,i) => { d.data = ds[i].data; d.label = ds[i].label; d.borderColor = ds[i].borderColor; });
            window.rcTnpsChartInstance.update();
        } else {
            const opts = RC_EKG_OPTS('TNPS %');
            opts.scales.y.suggestedMin = -20; opts.scales.y.suggestedMax = 100;
            window.rcTnpsChartInstance = new Chart(ctx, { data:{ labels, datasets:ds }, options:opts });
        }
    };

    function addTicker(code, name, prod, time, saleNo, isBcr){
        const t = document.getElementById('rcTickerList'); if (!t) return;
        if (t.innerText.includes('Lade') || t.innerText.includes('Warte')) t.innerHTML = '';
        const item = document.createElement('div');
        item.className = 'rc-list-item';
        // BCR-Abschluss = rote Kante, Nicht-BCR (VVL) = graue Kante + dezentes Tag
        item.style.borderLeft = isBcr ? '3px solid #E60000' : '3px solid #6E6E6E';
        const streakChip = isBcr ? (saleNo >= 3 ? ' <span class="rc-chip rot">HATTRICK</span>' : (saleNo === 2 ? ' <span class="rc-chip rot">DOPPELPACK</span>' : '')) : '';
        const nonBcrTag = isBcr ? '' : ' <span class="rc-chip" style="background:#2E2E2E; color:#9C9C9C; border:1px solid #3E3E3E;">NICHT BCR</span>';
        item.innerHTML = `<span class="rc-mono" style="color:#9C9C9C; font-weight:400;">[${time}]</span>
            <span><b>${getFlagSvg(code,'small')} ${name} <span class="rc-mono" style="color:#9C9C9C; font-size:10px; font-weight:400;">(${code})</span></b> · <span style="color:#C9C9C9;">${prod}</span>${streakChip}${nonBcrTag}</span>`;
        t.insertBefore(item, t.firstChild);
        while (t.children.length > 25) t.removeChild(t.lastElementChild);
        // Zugzwang-Timer im Header: Zeitpunkt des letzten Abschlusses merken
        let ts = Date.now();
        const m = (time||'').match(/^(\d{1,2}):(\d{2})$/);
        if (m) { const d = new Date(); d.setHours(+m[1], +m[2], 0, 0); if (d.getTime() <= Date.now()) ts = d.getTime(); }
        if (!window.rcLastSaleTs || ts > window.rcLastSaleTs) window.rcLastSaleTs = ts;
    }

    // Laufband: ZUERST die Ansprachen-Alarme (wer telefoniert, aber nicht anspricht), dann Ablehnungsgruende
    function renderMarquee(){
        const el = document.getElementById('rcNewsMarquee');
        if (!el) return;
        const items = [];

        // 1) Ansprachen-Alarme (Calls aus Ligaliste vs. ESL-Ansprachen)
        if (window.rcLetzteStats) {
            const alarme = [];
            Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
                const kpi = window.rcKpiForAgent(ag);
                if (!kpi || !kpi.callCount || kpi.callCount < 5) return;
                const anspr = ag.ansprachen || 0;
                const q = anspr / kpi.callCount;
                if (anspr === 0) alarme.push({ ag, kpi, anspr, q, hart: true });
                else if (kpi.callCount >= 10 && q < 0.2) alarme.push({ ag, kpi, anspr, q, hart: false });
            });
            alarme.sort((a,b) => a.q - b.q);
            alarme.slice(0, 8).forEach(x => {
                const txt = x.hart
                    ? `<span class="rc-mq-alarm">&#9650; <b>${x.ag.name}</b> (${x.ag.standort}) — ${x.kpi.callCount} Calls, noch keine Ansprache — jetzt proaktiv ansprechen</span>`
                    : `<span class="rc-mq-alarm">&#9650; <b>${x.ag.name}</b> (${x.ag.standort}) — nur ${Math.round(x.q*100)} % Ansprachequote bei ${x.kpi.callCount} Calls</span>`;
                items.push(txt);
            });
        }

        // 2) FF7-Schutz: zu kurze Gespraeche gefaehrden die 7-Tage-Loesungsquote
        const ffAlarme = Object.values(window.rcKpiData || {})
            .filter(k => k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 480 && (k.callCount || 0) >= 5)
            .sort((a,b) => a.ahtSec - b.ahtSec).slice(0, 6);
        ffAlarme.forEach(k => items.push(
            `<span class="rc-mq-alarm">&#9650; FF7-SCHUTZ: <b>${k.agentName}</b> (${normalizeStandort(k.standort)}) — Ø ${fmtAht(k.ahtSec)} Min — Kundenanliegen zu Ende loesen</span>`));

        // 2b) ESL-Tracking-Alarme: die Ligaliste zaehlt Calls, aber im ESL fehlen die
        //     Kontakte -> ohne vollstaendiges Tracking stimmt keine Quote.
        if (window.rcLetzteStats) {
            const tr = [];
            const matched = new Set();
            Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
                const kpi = window.rcKpiForAgent(ag);
                if (!kpi) return;
                matched.add(kpi.ccsId);
                if ((kpi.callCount || 0) < 10) return;
                const kont = ag.kontakte || 0;
                if (kont < kpi.callCount * 0.4) tr.push({ name: ag.name, std: ag.standort, kont, calls: kpi.callCount });
            });
            // Agenten, die in der Ligaliste telefonieren, aber im ESL GAR NICHT auftauchen
            Object.values(window.rcKpiData || {}).forEach(k => {
                if (!matched.has(k.ccsId) && (k.callCount || 0) >= 15)
                    tr.push({ name: k.agentName, std: normalizeStandort(k.standort), kont: 0, calls: k.callCount });
            });
            tr.sort((a,b) => (a.kont/a.calls) - (b.kont/b.calls)).slice(0, 6).forEach(x => items.push(
                `<span class="rc-mq-alarm">&#9650; ESL-TRACKING: <b>${x.name}</b> (${x.std}) — nur ${x.kont} von ${x.calls} Calls im ESL — bitte JEDEN Call eintragen</span>`));
        }

        // 2c) Vertriebs-Blocker aus der Liga-Analyse (WQ, ACW, Aufleger, Potenzial)
        if (window.rcBuildInsights) {
            window.rcBuildInsights().slice(0, 5).forEach(x => items.push(
                `<span class="rc-mq-alarm">&#9650; ${x.cat}: ${x.txt}</span>`));
        }

        // 2d) Croco-Alarme: ueberfaellige Auftraege (>7 Tage) + Storno trotz ESL-Verkauf
        try {
            const cv = window.rcCrocoView ? window.rcCrocoView() : null;
            if (cv && cv.ready) {
                (cv.overdue || []).slice(0, 6).forEach(o => items.push(
                    `<span class="rc-mq-alarm">&#9650; CROCO: Auftrag <b>${o.auftrag||o.vo||'?'}</b> (${o.standort}${o.agent?', '+o.agent:''}) seit <b>${o.ageDays} Tagen</b> offen — nachfassen</span>`));
                (cv.recon && cv.recon.stornoTrotzEsl || []).slice(0, 5).forEach(o => items.push(
                    `<span class="rc-mq-alarm">&#9650; STORNO-ALARM: <b>${o.agent||'?'}</b> (${o.standort}) — im ESL gebucht, in Croco storniert (VO ${o.vo||'?'}${o.produkt?', '+o.produkt:''})</span>`));
            }
        } catch(e){}

        // 3) Ablehnungsgruende (bestehender Buffer)
        window.rcMarqueeBuffer.forEach(b => items.push(b));

        if (!items.length) return;
        const txt = items.join(' <span class="rc-mq-sep">+++</span> ');
        el.innerHTML = '<span class="rc-mq-sep">+++</span> ' + txt + ' <span class="rc-mq-sep">+++</span>';
        el.style.animationDuration = Math.max(70, Math.round(txt.replace(/<[^>]+>/g,'').length*0.14)) + 's';
    }
    window.renderMarquee = renderMarquee;

    function buildDynamicMoti(agentsArr, standortStats){
        const m = [];
        // ON FIRE: wer in der letzten Stunde 2+ Abschluesse gemacht hat, brennt gerade
        try {
            const nowD = new Date(), fire = {};
            (window.rcAllSales || []).forEach(s => {
                if (!s.timeStr) return;
                const tm = s.timeStr.match(/^(\d{1,2}):(\d{2})$/); if (!tm) return;
                const d = new Date(); d.setHours(+tm[1], +tm[2], 0, 0);
                if (nowD - d >= 0 && nowD - d <= 3600000) fire[s.name] = (fire[s.name]||0) + 1;
            });
            Object.entries(fire).filter(([,n]) => n >= 2).sort((a,b) => b[1]-a[1]).slice(0,2)
                .forEach(([nm,n]) => m.push(`ON FIRE: <b>${nm}</b> — <b>${n}</b> Abschluesse in der letzten Stunde. Weiter so!`));
        } catch(e){}
        const top = agentsArr[0];
        if (top && top.total>0) m.push(`<b>${top.name}</b> fuehrt die Arena mit <b>${top.total}</b> Sales an`);
        const kipL = agentsArr.slice().sort((a,b)=>b.kip-a.kip)[0];
        if (kipL && kipL.kip>0) m.push(`KIP-Koenig: <b>${kipL.name}</b> mit <b>${kipL.kip}</b> KIP-BNT`);
        const mobL = agentsArr.slice().sort((a,b)=>b.mob-a.mob)[0];
        if (mobL && mobL.mob>0) m.push(`Mobilfunk-Held: <b>${mobL.name}</b> mit <b>${mobL.mob}</b> Abschluessen`);
        const stds = Object.values(standortStats).sort((a,b)=>b.bnt-a.bnt);
        if (stds[0] && stds[0].bnt>0) m.push(`Standort-Spitze: <b>${stds[0].name}</b> mit <b>${stds[0].bnt}</b> BNT`);

        // Qualitaets-Stars mit wenig Abschluessen: gute CS/TNPS = Vertrauen ist da -> zur Ansprache ermutigen
        const qualiTemplates = [
            (n, kv) => `<b>${n}</b>, ${kv} — deine Kunden vertrauen dir. Genau jetzt ist der Moment fuer den Abschluss!`,
            (n, kv) => `<b>${n}</b>, ${kv} — so eine Beratung verdient einen Abschluss. Trau dich, mach die Ansprache!`,
            (n, kv) => `Respekt, <b>${n}</b>: ${kv}. Wer so ueberzeugt, verkauft auch — der naechste Call gehoert dir!`,
            (n, kv) => `<b>${n}</b>, deine Gespraechsqualitaet ist top (${kv}). Der Abschluss ist nur noch einen Satz entfernt!`
        ];
        let qi = 0;
        agentsArr.forEach(ag => {
            if (qi >= 3 || (ag.total || 0) > 1) return;
            const kpi = window.rcKpiForAgent(ag);
            if (!kpi || !kpi.callCount || kpi.callCount < 8) return;
            const parts = [];
            if (kpi.cs != null && kpi.cs >= 85) parts.push(`CS <b>${kpi.cs.toFixed(0)} %</b>`);
            if (kpi.tnps != null && kpi.tnps >= 60) parts.push(`TNPS <b>${kpi.tnps.toFixed(0)} %</b>`);
            if (!parts.length) return;
            m.push(qualiTemplates[qi % qualiTemplates.length](ag.name, parts.join(' und ')));
            qi++;
        });
        window.rcDynamicMoti = m;
    }

    // ============================================================
    //  DATEN-PIPELINE (unveraendert bewaehrt aus v20)
    // ============================================================
    function verarbeiteExcelBuffer(arrayBuffer){
        if (!window.XLSX) { rcLog.error('XLSX nicht geladen.'); return; }
        try {
            const wb = XLSX.read(new Uint8Array(arrayBuffer), { type:'array' });
            const sn = wb.SheetNames[0]; if (!sn) return;
            const ws = wb.Sheets[sn]; if (!ws) return;
            const data = XLSX.utils.sheet_to_json(ws, { header:1 });
            if (!data || !data.length) return;
            window.processDataStream(data);
        } catch(e){ rcLog.error('Excel-Verarbeitung fehlgeschlagen:', e); }
    }

    async function holeExcelVomServer(){
        if (window.rcHarvestBusy) return; // Historien-Harvester laeuft — keine konkurrierenden POSTs
        rcLog.log('--- Aktualisierungszyklus (20s) ---');
        try {
            const form = document.getElementById('filterForm');
            if (!form) {
                rcLog.error("Formular 'filterForm' nicht gefunden.");
                const s = document.getElementById('rcFetchStatus'); if (s) s.textContent = 'kein Datenformular gefunden';
                showWarn('Kein "filterForm" auf dieser Seite — bitte das Script auf der ESL-Seite "Projektergebnisse" (mit von/bis und Excel-Export) einfuegen.');
                return;
            }
            const buttons = Array.from(form.querySelectorAll('button[type="submit"], input[type="submit"]'));

            // 1. Suche/Filter ausloesen, um Backend-DataModel zu erneuern
            const searchBtn = buttons.find(b => /suchen|aktualisieren|filtern|anzeigen/.test((b.innerText||b.value||'').toLowerCase()));
            if (searchBtn) {
                const sid = searchBtn.id || searchBtn.name;
                if (sid) {
                    const sd = new FormData(form);
                    sd.append(sid, sid);
                    sd.append('javax.faces.partial.ajax','true');
                    sd.append('javax.faces.source', sid);
                    sd.append('javax.faces.partial.execute','filterForm data');
                    sd.append('javax.faces.partial.render','filterForm data');
                    try {
                        const resp = await fetch(form.action || window.location.href, { method:'POST', body:sd,
                            headers:{ 'Faces-Request':'partial/ajax', 'X-Requested-With':'XMLHttpRequest' } });
                        const txt = await resp.text();
                        // Server-seitige ViewExpiredException schon hier abfangen — sie kommt
                        // als partial-response mit viewExpiredDialog/ViewExpiredException-eval.
                        if (/ViewExpiredException|viewExpiredDialog/.test(txt)) {
                            rcSessionLost('ViewExpiredException in Such-Antwort');
                            return;
                        }
                        const vs = txt.match(/<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[(.*?)\]\]><\/update>/) ||
                                   txt.match(/name="javax\.faces\.ViewState".*?value="([^"]+)"/);
                        // WICHTIG gegen ViewExpired: das frische Token in ALLE Formulare schreiben
                        // (frmPoll, frmMainMenu, ...), nicht nur filterForm. JSF/Mojarra haelt nur
                        // die letzten ~15 ViewState-Staende pro Ansicht; unser 20-s-Poll macht in
                        // 5 min ~15 Postbacks -> sonst faellt das 5-min-alte Token von globalPoll
                        // aus dem Puffer und dessen naechster Poll wirft ViewExpiredException.
                        if (vs && vs[1]) {
                            document.querySelectorAll('input[name="javax.faces.ViewState"]').forEach(function(inp){ inp.value = vs[1]; });
                        }
                    } catch(e){ rcLog.error('Fehler bei Such-Aktualisierung:', e); }
                }
            }

            // 2. Excel-Export ausloesen (mit aktualisiertem ViewState)
            const formData = new FormData(form);
            const exportBtn = buttons.find(b => { const t=(b.innerText||b.value||'').toLowerCase(); return t.includes('excel')||t.includes('export')||(b.innerHTML||'').toLowerCase().includes('excel'); });
            const btnId = exportBtn ? (exportBtn.id || exportBtn.name) : 'filterForm:j_idt517';
            if (btnId) formData.append(btnId, btnId);

            const response = await fetch(form.action || window.location.href, { method:'POST', body:formData });
            if (response.ok) {
                // Logout-Erkennung: eine abgelaufene Session liefert statt der xlsx die
                // Login-/ViewExpired-HTML-Seite mit HTTP 200 -> nicht still als Excel parsen.
                // ACHTUNG: der echte xlsx-MIME-Type "...openxmlformats-officedocument.spreadsheetml.sheet"
                // enthaelt den Teilstring "xml" -> NICHT auf "xml" pruefen, sonst Fehlalarm bei jedem Export.
                const ct = (response.headers.get('content-type') || '').toLowerCase();
                // text/html ist NICHT per se Session-Tod: ein noch nicht gefundener/falscher
                // Export-Button, ein PrimeFaces-Re-Render oder eine kurz nicht bereite Seite
                // liefern ebenfalls HTML mit HTTP 200. Frueher hat schon der reine text/html-
                // Content-Type rcSessionLost() ausgeloest -> der Live-Abruf wurde beim ERSTEN
                // Poll direkt nach dem Login dauerhaft abgeschaltet (Fehlalarm). Deshalb hier
                // den Body pruefen: NUR bei echten Login-/ViewExpired-Markern die Session fuer
                // tot erklaeren, sonst diesen Zyklus ueberspringen und in 20s erneut versuchen.
                const urlHint = /login|anmeld|expired/i.test(response.url || '');
                if (ct.includes('text/html') || urlHint) {
                    let body = '';
                    try { body = await response.text(); } catch(e){}
                    const echterLogout = urlHint || /ViewExpiredException|viewExpiredDialog|j_username|id="loginForm"|name="username"|type="password"|angemeldet\s+bleiben|>\s*Anmelden\s*</i.test(body);
                    if (echterLogout) {
                        rcSessionLost('Export lieferte HTML/Login statt Excel');
                    } else {
                        rcLog.warn('Excel-Export lieferte HTML ohne Login-/ViewExpired-Marker (Content-Type ' + ct + ') — Zyklus uebersprungen, neuer Versuch in 20s. Kein Session-Verlust.');
                        const s = document.getElementById('rcFetchStatus'); if (s) s.textContent = 'Export nicht bereit — neuer Versuch in 20s';
                    }
                    return;
                }
                verarbeiteExcelBuffer(await response.arrayBuffer());
            }
            else if (response.status === 401 || response.status === 403) rcSessionLost('HTTP ' + response.status + ' beim Excel-Abruf');
            else rcLog.error('Server-Fehler beim Excel-Abruf. HTTP', response.status);
        } catch(e){ rcLog.error('Kritischer Fehler beim Datenabruf:', e); }
    }

    // ============================================================
    //  ESL-TAGESHISTORIE — automatischer 7-Tage-Harvester
    //  Zieht fehlende Vortage ueber dasselbe filterForm: das Datum wird NUR im
    //  POST ueberschrieben (die sichtbaren Felder bleiben unberuehrt), danach
    //  stellt ein normaler Live-Abruf den Heute-Zustand im Backend wieder her.
    //  Ergebnis in localStorage 'rcEslHistory' je Tag: BCR/VVL/Ansprachen/
    //  Kontakte gesamt + je Standort -> Grundlage fuer die Trend-Charts.
    // ============================================================
    const RC_HIST_DAYS = 7;
    function rcLoadEslHistory(){
        try { return JSON.parse(localStorage.getItem('rcEslHistory') || '{}'); } catch(e){ return {}; }
    }

    // Kompakte Tages-Aggregation eines Export-Buffers (ohne UI/Feiern/State).
    // expectedKey ('JJJJ-MM-TT'): ueber die Datumsspalte wird verifiziert, dass der
    // Export WIRKLICH den angefragten Tag enthaelt. Liefert das Portal stattdessen
    // die Heute-Daten (Datums-Override nicht uebernommen), steht in srcDay der
    // tatsaechliche Tag und der Harvester verwirft das Ergebnis — das war der Bug
    // "alle Vortage identisch (35 BCR, 114 Kontakte)".
    // Zusaetzlich: byAgent (VO -> kompakte Tageszahlen) fuer die Agenten-Wochentrends.
    // Leeres Tages-Aggregat mit internen Eindeutig-Sets (werden beim Finalisieren entfernt)
    function rcNewAgg(){
        return { rows:0, kontakte:0, ansp:0, bcr:0, nonBcr:0, bnt:0, vvl:0, byStd:{}, byAgent:{}, srcDay:null,
                 _k:new Set(), _a:new Set(), _kSt:{}, _aSt:{}, _kAg:{}, _aAg:{} };
    }
    // Eine Export-Zeile in ein Aggregat einrechnen (BCR/BNT/VVL, Kontakte, Ansprachen)
    function rcAccumRow(agg, r, ix, i){
        const code = normalizeStandort((r[ix.standort]||'').toString());
        const vo = ix.vo!==-1 ? (r[ix.vo]||'').toString().trim() : '';
        const erg = (r[ix.erg]||'').toString().toLowerCase();
        const anz = parseInt(r[ix.anz]) || 0;
        const mm = ix.merkmal!==-1 ? (r[ix.merkmal]||'').toString().toLowerCase() : '';
        const bcrRel = !/nicht\s*bcr/.test(mm);
        const ang = ix.ansp!==-1 ? (r[ix.ansp]||'').toString().toLowerCase().trim() : '';
        const rid = (ix.id!==-1 && r[ix.id]) ? r[ix.id].toString() : (code + '_' + vo + '_' + i);
        agg.rows++;
        const s = agg.byStd[code] || (agg.byStd[code] = { kontakte:0, ansp:0, bcr:0, nonBcr:0, bnt:0, vvl:0 });
        const agE = vo ? (agg.byAgent[vo] || (agg.byAgent[vo] = { k:0, a:0, bcr:0, bnt:0, vvl:0, mob:0, kip:0 })) : null;
        agg._k.add(rid); (agg._kSt[code] || (agg._kSt[code] = new Set())).add(rid);
        if (vo) (agg._kAg[vo] || (agg._kAg[vo] = new Set())).add(rid);
        const istAnsp = (ang === 'ja') || (ang === '' && (erg.includes('angenommen') || erg.includes('angebot') || erg.includes('abgelehnt')));
        if (istAnsp) {
            agg._a.add(rid); (agg._aSt[code] || (agg._aSt[code] = new Set())).add(rid);
            if (vo) (agg._aAg[vo] || (agg._aAg[vo] = new Set())).add(rid);
        }
        if (anz > 0 && erg.includes('angenommen')) {
            const { cat, isBnt, isVvl } = classify((r[ix.prod]||'').toString());
            if (cat) {
                if (bcrRel) { agg.bcr += anz; s.bcr += anz; if (agE) agE.bcr += anz; } else { agg.nonBcr += anz; s.nonBcr += anz; }
                if (isBnt) { agg.bnt += anz; s.bnt += anz; if (agE) agE.bnt += anz; }
                if (isVvl) { agg.vvl += anz; s.vvl += anz; if (agE) agE.vvl += anz; }
                if (agE && cat === 'mob') agE.mob += anz;
                if (agE && cat === 'kip') agE.kip += anz;
            }
        }
    }
    // Eindeutig-Sets in Zahlen aufloesen und interne Felder entfernen
    function rcFinalizeAgg(agg, srcDay){
        agg.kontakte = agg._k.size; agg.ansp = agg._a.size;
        Object.keys(agg.byStd).forEach(c => { agg.byStd[c].kontakte = agg._kSt[c] ? agg._kSt[c].size : 0; agg.byStd[c].ansp = agg._aSt[c] ? agg._aSt[c].size : 0; });
        // CCS-ID + Name direkt aus dem Mapping mitspeichern -> der Vortags-Stand-Export
        // joint spaeter mapping-UNABHAENGIG (VO<->CCS), auch wenn das Mapping wechselt.
        const voMap = (window.rcWcaMapping && window.rcWcaMapping.voMap) || {};
        const ccsMap = (window.rcWcaMapping && window.rcWcaMapping.ccsMap) || {};
        Object.keys(agg.byAgent).forEach(v => {
            agg.byAgent[v].k = agg._kAg[v] ? agg._kAg[v].size : 0;
            agg.byAgent[v].a = agg._aAg[v] ? agg._aAg[v].size : 0;
            const m = voMap[v];
            if (m) { if (m.ccsId) agg.byAgent[v].ccs = String(m.ccsId); if (m.name) agg.byAgent[v].nm = m.name; }
            // Fallback: die ESL-vo_nummer ist bei manchen Exporten bereits die CCS-ID.
            else if (ccsMap[v]) { agg.byAgent[v].ccs = String(v); if (ccsMap[v].name) agg.byAgent[v].nm = ccsMap[v].name; }
        });
        agg.srcDay = srcDay || null;
        delete agg._k; delete agg._a; delete agg._kSt; delete agg._aSt; delete agg._kAg; delete agg._aAg;
        return agg;
    }
    // BEREITS archivierte ESL-Historie nachtraeglich mit CCS-ID/Name aus dem AKTUELLEN
    // Mapping verknuepfen. Noetig, wenn Vortage mit unvollstaendigem Mapping (leere voMap)
    // archiviert wurden: ohne ccs/nm findet der Vortags-Stand-Export keinen Agenten und
    // schreibt ueberall "Keine". Laeuft automatisch nach jedem Mapping-Import.
    window.rcRepairEslHistory = function(){
        const voMap = (window.rcWcaMapping && window.rcWcaMapping.voMap) || {};
        const ccsMap = (window.rcWcaMapping && window.rcWcaMapping.ccsMap) || {};
        if (!Object.keys(voMap).length && !Object.keys(ccsMap).length) return 0;
        const hist = window.rcEslHistory || rcLoadEslHistory() || {};
        let fixed = 0, tage = 0;
        Object.keys(hist).forEach(dk => {
            const ba = hist[dk] && hist[dk].byAgent; if (!ba) return;
            let t = 0;
            Object.keys(ba).forEach(vo => {
                const m = voMap[vo];
                if (m) {
                    if (!ba[vo].ccs && m.ccsId) { ba[vo].ccs = String(m.ccsId); t++; }
                    if (!ba[vo].nm && m.name) ba[vo].nm = m.name;
                } else if (ccsMap[vo]) {   // vo IST bereits die CCS-ID
                    if (!ba[vo].ccs) { ba[vo].ccs = String(vo); t++; }
                    if (!ba[vo].nm && ccsMap[vo].name) ba[vo].nm = ccsMap[vo].name;
                }
            });
            if (t) { fixed += t; tage++; }
        });
        if (fixed) {
            try { localStorage.setItem('rcEslHistory', JSON.stringify(hist)); } catch(e){}
            window.rcEslHistory = hist;
            rcLog.log('ESL-Historie nachgeruestet: ' + fixed + ' Agenten an ' + tage + ' Tag(en) mit CCS-ID verknuepft — Vortags-Stand-Export zeigt jetzt Ansprache/BNT/VVL.');
        }
        return fixed;
    };
    function rcReadSheet(arrayBuffer){
        if (!window.XLSX) return null;
        const wb = XLSX.read(new Uint8Array(arrayBuffer), { type:'array' });
        const ws = wb.Sheets[wb.SheetNames[0]]; if (!ws) return null;
        const data = XLSX.utils.sheet_to_json(ws, { header:1 });
        if (!data || data.length < 2) return { data:null, ix:null };
        const ix = { datum:0, standort:1, vo:3, prod:5, merkmal:6, erg:8, anz:9, ansp:-1, id:-1 };
        const h = data[0].map(x => (x||'').toString().toLowerCase().trim());
        const set = (key, ...names) => { for (const nm of names){ const i = h.indexOf(nm); if (i!==-1){ ix[key]=i; return; } } };
        set('datum','datum'); set('standort','standort'); set('vo','vo_nummer','vo-nummer','vo');
        set('prod','produktgruppe','produktgrupe'); set('merkmal','produktmerkmal','merkmal');
        set('erg','ergebnis','status'); set('anz','anzahl','anz'); set('ansp','sis_angesprochen','angesprochen'); set('id','id');
        return { data, ix };
    }
    // Datum einer Zeile -> 'YYYY-MM-DD'. Deutsche Formate (DD.MM.YYYY, mit/ohne
    // Uhrzeit), ISO (YYYY-MM-DD / YYYY/MM/DD) und Excel-Serial werden explizit
    // erkannt — parseDateTime allein ist bei reinen Datumsstrings unzuverlaessig.
    function rcRowDayKey(r, ix){
        if (ix.datum === -1) return null;
        const raw = r[ix.datum];
        if (raw == null || raw === '') return null;
        if (typeof raw === 'number') { const d = new Date(Math.round((raw-25569)*86400*1000)); return isNaN(d)?null:d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); }
        const t = raw.toString().trim();
        let m = t.match(/^(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{4})/);       // DD.MM.YYYY [ hh:mm]
        if (m) return m[3] + '-' + pad2(m[2]) + '-' + pad2(m[1]);
        m = t.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})/);          // YYYY-MM-DD / YYYY/MM/DD
        if (m) return m[1] + '-' + pad2(m[2]) + '-' + pad2(m[3]);
        const dv = parseDateTime(raw);
        return (dv && dv.date && !isNaN(dv.date)) ? dv.date.getFullYear()+'-'+pad2(dv.date.getMonth()+1)+'-'+pad2(dv.date.getDate()) : null;
    }

    // Ein-Tages-Aggregat (mit srcDay-Verifikation ueber die Datumsspalte)
    function rcAggregateDayBuffer(arrayBuffer, expectedKey){
        const { data, ix } = rcReadSheet(arrayBuffer) || {};
        if (!data) return { rows:0, kontakte:0, ansp:0, bcr:0, nonBcr:0, bnt:0, vvl:0, byStd:{}, byAgent:{}, srcDay:null };
        const agg = rcNewAgg(); const dayCount = {};
        for (let i=1; i<data.length; i++){
            const r = data[i]; if (!r || r[ix.standort] == null) continue;
            const dk = rcRowDayKey(r, ix); if (dk) dayCount[dk] = (dayCount[dk]||0)+1;
            rcAccumRow(agg, r, ix, i);
        }
        const dEntries = Object.entries(dayCount).sort((a,b) => b[1]-a[1]);
        return rcFinalizeAgg(agg, dEntries.length ? dEntries[0][0] : null);
    }

    // MEHRTAGES-Aggregat: EIN Export mit Datumsbereich (von..bis) wird ueber die
    // echte Datumsspalte je Tag getrennt. Das umgeht den unzuverlaessigen
    // Ein-Tages-Override komplett -> { 'JJJJ-MM-TT': agg, ... }
    function rcAggregateMultiDayBuffer(arrayBuffer){
        const { data, ix } = rcReadSheet(arrayBuffer) || {};
        if (!data || ix.datum === -1) return {};
        const byDay = {};
        for (let i=1; i<data.length; i++){
            const r = data[i]; if (!r || r[ix.standort] == null) continue;
            const dk = rcRowDayKey(r, ix); if (!dk) continue; // ohne verifiziertes Datum ignorieren
            (byDay[dk] || (byDay[dk] = rcNewAgg()))._pending = true;
            rcAccumRow(byDay[dk], r, ix, i);
        }
        const out = {};
        Object.keys(byDay).forEach(dk => { out[dk] = rcFinalizeAgg(byDay[dk], dk); });
        return out;
    }

    // Export fuer einen Datumsbereich (von..bis) abrufen — von/bis werden im
    // FormData ueberschrieben. fromStr==toStr = EIN Tag; unterschiedlich = Bereich
    // (ein Export ueber mehrere Tage, spaeter per Datumsspalte getrennt).
    // fullMode=true: Suche als VOLLER Formular-Submit statt Partial-AJAX.
    async function rcFetchRangeBuffer(fromStr, toStr, fullMode){
        const form = document.getElementById('filterForm'); if (!form) return null;
        // Datumsfelder robust finden: Datepicker-Klasse, PrimeFaces-Kalender oder
        // Inputs, deren Wert wie ein Datum aussieht. OHNE gefundene Felder wird
        // abgebrochen — sonst liefert der Export stumm die Heute-Daten.
        let dateInputs = Array.from(form.querySelectorAll('input.hasDatepicker, .ui-calendar input')).filter(i => i.name);
        if (!dateInputs.length) {
            dateInputs = Array.from(form.querySelectorAll('input')).filter(i =>
                i.name && /^\d{1,2}\.\d{1,2}\.\d{2,4}$/.test((i.value||'').trim()));
        }
        if (!dateInputs.length) { rcLog.warn('Historie: keine Datumsfelder im filterForm gefunden — Zeitraum kann nicht angefragt werden.'); return null; }
        const n0 = dateInputs[0].name;
        const n1 = dateInputs[1] ? dateInputs[1].name : n0;
        const buttons = Array.from(form.querySelectorAll('button[type="submit"], input[type="submit"]'));
        const searchBtn = buttons.find(b => /suchen|aktualisieren|filtern|anzeigen|liste aktualisieren/.test((b.innerText||b.value||b.title||'').toLowerCase()));
        // 1) Suche mit Datum-Override -> Backend-DataModel auf den Zeitraum stellen
        const sid = searchBtn ? (searchBtn.id || searchBtn.name) : null;
        if (sid) {
            const sd = new FormData(form);
            sd.set(n0, fromStr); sd.set(n1, toStr);
            sd.append(sid, sid);
            let txt = '';
            if (fullMode) {
                // Voller Submit — verhaelt sich wie ein echter Klick auf "Liste aktualisieren"
                const resp = await fetch(form.action || window.location.href, { method:'POST', body:sd });
                txt = await resp.text();
            } else {
                sd.append('javax.faces.partial.ajax','true');
                sd.append('javax.faces.source', sid);
                sd.append('javax.faces.partial.execute','filterForm data');
                sd.append('javax.faces.partial.render','filterForm data');
                const resp = await fetch(form.action || window.location.href, { method:'POST', body:sd,
                    headers:{ 'Faces-Request':'partial/ajax', 'X-Requested-With':'XMLHttpRequest' } });
                txt = await resp.text();
            }
            const vs = txt.match(/<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[(.*?)\]\]><\/update>/) ||
                       txt.match(/name="javax\.faces\.ViewState".*?value="([^"]+)"/);
            if (vs && vs[1]) { const old = form.querySelector('input[name="javax.faces.ViewState"]'); if (old) old.value = vs[1]; }
        }
        // 2) Export mit Datum-Override
        const fd = new FormData(form);
        fd.set(n0, fromStr); fd.set(n1, toStr);
        const exportBtn = buttons.find(b => { const t=(b.innerText||b.value||b.title||'').toLowerCase(); return t.includes('excel')||t.includes('export')||(b.innerHTML||'').toLowerCase().includes('excel'); });
        const btnId = exportBtn ? (exportBtn.id || exportBtn.name) : 'filterForm:j_idt640';
        fd.append(btnId, btnId);
        const response = await fetch(form.action || window.location.href, { method:'POST', body:fd });
        if (!response.ok) return null;
        return await response.arrayBuffer();
    }
    // Rueckwaerts-kompatibel: EIN Tag
    async function rcFetchDayBuffer(dateStr, fullMode){ return rcFetchRangeBuffer(dateStr, dateStr, fullMode); }

    // ZUVERLAESSIGSTER Bereichs-Export: treibt die ECHTEN DOM-Felder + den echten
    // "Liste aktualisieren"-Button an (PrimeFaces committet den Zeitraum korrekt in
    // das Servermodell), exportiert danach per fetch und stellt den Ur-Zustand
    // wieder her. So respektiert der Export den Datumsbereich zuverlaessig.
    async function rcFetchRangeViaUI(fromStr, toStr){
        const form = document.getElementById('filterForm'); if (!form) return null;
        const dateInputs = Array.from(form.querySelectorAll('input.hasDatepicker, .ui-calendar input')).filter(i => i.name);
        if (dateInputs.length < 2) { rcLog.warn('Historie(UI): keine zwei Datumsfelder gefunden.'); return null; }
        const vonI = dateInputs[0], bisI = dateInputs[1];
        const oVon = vonI.value, oBis = bisI.value;
        const setVal = (el, v) => { el.value = v; el.dispatchEvent(new Event('input', {bubbles:true})); el.dispatchEvent(new Event('change', {bubbles:true})); };
        setVal(vonI, fromStr); setVal(bisI, toStr);
        // echten "Liste aktualisieren"-Button klicken -> Server-Commit ueber PrimeFaces
        const buttons = Array.from(form.querySelectorAll('button, input[type="submit"]'));
        const updBtn = buttons.find(b => /aktualisieren|liste aktualisieren/i.test((b.title||b.innerText||b.value||'')) || /refresh/i.test(b.innerHTML||''));
        if (updBtn) { try { updBtn.click(); } catch(e){} }
        await new Promise(r => setTimeout(r, 6000)); // auf PrimeFaces-Ajax + Neuaufbau warten
        // Export per fetch — DOM hat jetzt Bereich + aktualisierten ViewState
        let buf = null;
        try {
            const fd = new FormData(form);
            fd.set(vonI.name, fromStr); fd.set(bisI.name, toStr);
            const expBtn = buttons.find(b => { const t=(b.title||b.innerText||b.value||'').toLowerCase(); return t.includes('export')||t.includes('excel')||(b.innerHTML||'').toLowerCase().includes('excel'); });
            const btnId = expBtn ? (expBtn.id || expBtn.name) : 'filterForm:j_idt640';
            fd.append(btnId, btnId);
            const resp = await fetch(form.action || window.location.href, { method:'POST', body:fd });
            if (resp.ok) buf = await resp.arrayBuffer();
        } catch(e){ rcLog.warn('Historie(UI): Export-Fetch fehlgeschlagen:', e); }
        // KRITISCH: Zeitraum per ECHTEM Klick auf HEUTE zurueckstellen — sonst bleibt
        // das SERVER-Modell auf dem Bereich stehen und jeder folgende Live-Poll
        // liefert Wochensummen als "heute" (genau das war der 5000er-TX-Bug).
        const heuteStr = (d => pad2(d.getDate())+'.'+pad2(d.getMonth()+1)+'.'+d.getFullYear())(new Date());
        setVal(vonI, heuteStr); setVal(bisI, heuteStr);
        if (updBtn) { try { updBtn.click(); } catch(e){} }
        await new Promise(r => setTimeout(r, 4000));
        // falls die Ur-Werte nicht heute waren (unwahrscheinlich), DOM angleichen
        if (oVon !== heuteStr || oBis !== heuteStr) { setVal(vonI, heuteStr); setVal(bisI, heuteStr); }
        rcLog.log('Historie(UI): Zeitraum per Klick auf HEUTE (' + heuteStr + ') zurueckgestellt.');
        return buf;
    }

    // DIAGNOSE (Konsole): rcEslDebugRange('01.07.2026','13.07.2026')
    // Zeigt, ob der Export den Bereich respektiert — Zeilen, erkannte Tage, Beispiele.
    window.rcEslDebugRange = async function(fromStr, toStr){
        const nowD = new Date();
        fromStr = fromStr || (d => pad2(d.getDate())+'.'+pad2(d.getMonth()+1)+'.'+d.getFullYear())(new Date(Date.now()-7*86400000));
        toStr = toStr || pad2(nowD.getDate())+'.'+pad2(nowD.getMonth()+1)+'.'+nowD.getFullYear();
        rcLog.log('DEBUG Bereichs-Export ' + fromStr + ' – ' + toStr + ' via echten UI-Ablauf...');
        const buf = await rcFetchRangeViaUI(fromStr, toStr);
        if (!buf) { rcLog.warn('DEBUG: kein Export erhalten.'); holeExcelVomServer(); return; }
        const sheet = rcReadSheet(buf);
        const perDay = rcAggregateMultiDayBuffer(buf);
        const days = Object.keys(perDay).sort();
        rcLog.log('DEBUG: Zeilen=' + (sheet && sheet.data ? sheet.data.length-1 : '?') +
            ' · erkannte Tage=' + days.length + ' -> ' + (days.join(', ') || 'KEINE'));
        days.forEach(k => rcLog.log('   ' + k + ': ' + (perDay[k].bnt||0) + ' BNT, ' + (perDay[k].vvl||0) + ' VVL, ' + perDay[k].kontakte + ' Kontakte'));
        if (sheet && sheet.data && sheet.data.length > 1) {
            rcLog.log('DEBUG Datum-Spalte (Index ' + sheet.ix.datum + '), erste Werte: ' +
                sheet.data.slice(1, 6).map(r => JSON.stringify(r[sheet.ix.datum])).join(' | '));
        }
        holeExcelVomServer(); // Live wiederherstellen
        return { days, perDay };
    };

    async function rcHarvestEslHistory(){
        if (window.rcHarvestBusy) return;
        if (!document.getElementById('filterForm') || !window.XLSX) return;
        const todayKey = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date());
        const hist = rcLoadEslHistory();

        // Einmalige Migration: neuer Harvest-Weg (Bereichs-Export) -> "heute erledigt"-
        // Sperre einmal loesen, damit die Vortage mit der neuen Logik frisch geladen werden.
        const RC_HARV_VER = 'range-v1';
        try { if (localStorage.getItem('rcEslHarvVer') !== RC_HARV_VER) { localStorage.removeItem('rcEslHistCheck'); localStorage.setItem('rcEslHarvVer', RC_HARV_VER); } } catch(e){}

        // Selbstheilung: 3+ Vortage mit EXAKT identischen Werten sind kein Zufall,
        // sondern der alte Harvest-Fehler (Portal lieferte immer die Heute-Daten).
        // Solche Eintraege verwerfen und neu laden.
        (function(){
            const seen = {};
            Object.keys(hist).forEach(k => {
                const t = hist[k]; if (!t || !t.kontakte) return;
                const sig = [t.rows, t.kontakte, t.ansp, t.bcr, t.vvl].join('|');
                (seen[sig] || (seen[sig] = [])).push(k);
            });
            let bad = [];
            Object.values(seen).forEach(keys => { if (keys.length >= 3) bad = bad.concat(keys); });
            if (bad.length) {
                bad.forEach(k => delete hist[k]);
                try { localStorage.removeItem('rcEslHistCheck'); localStorage.setItem('rcEslHistory', JSON.stringify(hist)); } catch(e){}
                rcLog.warn('Historie: ' + bad.length + ' identische Vortage verworfen (alter Harvest-Fehler) — lade korrekt nach.');
            }
        })();

        try { if (localStorage.getItem('rcEslHistCheck') === todayKey) { window.rcEslHistory = hist; return; } } catch(e){}
        const missing = [];
        for (let d = 1; d <= RC_HIST_DAYS; d++) {
            const dt = new Date(Date.now() - d*86400000);
            const key = dt.getFullYear()+'-'+pad2(dt.getMonth()+1)+'-'+pad2(dt.getDate());
            // auch Alt-Eintraege ohne byAgent neu laden (fuer die Agenten-Wochentrends)
            if (!hist[key] || (hist[key].kontakte > 0 && !hist[key].byAgent)) missing.push({ key, dateStr: pad2(dt.getDate())+'.'+pad2(dt.getMonth()+1)+'.'+dt.getFullYear() });
        }
        if (!missing.length) {
            try { localStorage.setItem('rcEslHistCheck', todayKey); } catch(e){}
            window.rcEslHistory = hist; return;
        }
        window.rcHarvestBusy = true;
        rcLog.log('Historie: lade ' + missing.length + ' fehlende Tage nach (' + missing.map(m=>m.key).join(', ') + ')...');
        let got = 0;
        try {
            // SCHRITT 1: EIN breiter Export ueber den ganzen Zeitraum (von aeltestem
            // fehlenden Tag bis heute). Die echte Datumsspalte trennt die Tage —
            // das umgeht den unzuverlaessigen Ein-Tages-Override komplett.
            try {
                const oldest = new Date(Date.now() - RC_HIST_DAYS*86400000);
                const fromStr = pad2(oldest.getDate())+'.'+pad2(oldest.getMonth()+1)+'.'+oldest.getFullYear();
                const nowD = new Date();
                const toStr = pad2(nowD.getDate())+'.'+pad2(nowD.getMonth()+1)+'.'+nowD.getFullYear();
                rcLog.log('Historie: Bereichs-Export ' + fromStr + ' – ' + toStr + ' (echter UI-Ablauf: Aktualisieren -> Export, nach Datum getrennt)...');
                // 1a) Primaerweg: echte DOM-Felder + "Liste aktualisieren"-Klick (Server-Commit)
                let buf = await rcFetchRangeViaUI(fromStr, toStr);
                let perDay = buf ? rcAggregateMultiDayBuffer(buf) : {};
                // 1b) falls nur EIN Tag kam: reine fetch-Varianten als Rueckfall
                if (Object.keys(perDay).length <= 1) {
                    rcLog.log('Historie: UI-Weg lieferte ' + Object.keys(perDay).length + ' Tag(e) — versuche fetch-Varianten...');
                    await new Promise(r => setTimeout(r, 700));
                    buf = await rcFetchRangeBuffer(fromStr, toStr, true);
                    let p2 = buf ? rcAggregateMultiDayBuffer(buf) : {};
                    if (Object.keys(p2).length <= 1) {
                        buf = await rcFetchRangeBuffer(fromStr, toStr, false);
                        const p3 = buf ? rcAggregateMultiDayBuffer(buf) : {};
                        if (Object.keys(p3).length > Object.keys(p2).length) p2 = p3;
                    }
                    if (Object.keys(p2).length > Object.keys(perDay).length) perDay = p2;
                }
                missing.forEach(m => {
                    if (perDay[m.key]) { hist[m.key] = perDay[m.key]; got++; }
                });
                if (got) rcLog.log('Historie: Bereichs-Export lieferte ' + got + ' Vortag(e): ' + Object.keys(perDay).sort().join(', '));
                else rcLog.warn('Historie: Portal ignoriert den Datumsbereich beim Export (nur ' + (Object.keys(perDay).sort().join(',')||'—') + '). Die Historie waechst ab jetzt taeglich per Selbst-Archivierung. Diagnose: rcEslDebugRange() in der Konsole.');
            } catch(e){ rcLog.warn('Historie: Bereichs-Export fehlgeschlagen:', e); }

            // Kein Ein-Tages-Fallback mehr: der Ein-Tages-Override scheitert am selben
            // ViewState-Verhalten wie der Bereich und wuerde nur 7x ~20s hammern.
            // Der UI-Bereichs-Export ist der definitive Weg; fehlt danach ein Tag,
            // ist er echt leer (Wochenende) — die Selbst-Archivierung fuellt vorwaerts.
            Object.keys(hist).sort().slice(0, -40).forEach(k => delete hist[k]);
            try {
                localStorage.setItem('rcEslHistory', JSON.stringify(hist));
                // Ein Harvest-Versuch pro Tag genuegt (der Mechanismus ist deterministisch).
                localStorage.setItem('rcEslHistCheck', todayKey);
            } catch(e){}
            window.rcEslHistory = hist;
            rcLog.log('Historie: ' + Object.keys(hist).filter(k => hist[k] && hist[k].kontakte).length + ' Tage insgesamt im Speicher.');
        } finally {
            window.rcHarvestBusy = false;
            // Backend-Zustand zurueck auf HEUTE stellen (normaler Live-Abruf)
            holeExcelVomServer();
            if (window.renderTrendHist) window.renderTrendHist();
        }
    }

    // Fuer Debugging/manuellen Re-Harvest in der Portal-Konsole:
    //   window.rcHarvestEslHistory()  — fehlende/verworfene Tage sofort nachladen
    //   window.rcAggregateDayBuffer(buf, 'JJJJ-MM-TT') — Buffer pruefen
    window.rcHarvestEslHistory = rcHarvestEslHistory;
    window.rcAggregateDayBuffer = rcAggregateDayBuffer;
    window.rcAggregateMultiDayBuffer = rcAggregateMultiDayBuffer;
    window.rcFetchRangeBuffer = rcFetchRangeBuffer;

    // BCR-Trend-Chart im Cockpit: Vortage grau, heute Electric Red (3 oder 7 Tage)
    window.rcHistDays = 7;
    window.renderTrendHist = function(){
        const ctx = document.getElementById('rcHistChart');
        if (!ctx || !window.Chart) return;
        const hist = window.rcEslHistory || rcLoadEslHistory();
        const days = [];
        const WD = ['So','Mo','Di','Mi','Do','Fr','Sa'];
        for (let d = window.rcHistDays; d >= 1; d--) {
            const dt = new Date(Date.now() - d*86400000);
            const key = dt.getFullYear()+'-'+pad2(dt.getMonth()+1)+'-'+pad2(dt.getDate());
            days.push({ label: WD[dt.getDay()] + ' ' + pad2(dt.getDate()) + '.' + pad2(dt.getMonth()+1) + '.',
                        h: hist[key] || null, today: false });
        }
        // Heute = hoechster Stundenwert aus der (ungefilterten) Tageshistorie rcDayTrend
        // ('b'-Schluessel = BNT; numerische Schluessel = alte BCR-rel.-Werte als Fallback)
        let todayBnt = 0, todayAlt = 0;
        try {
            const store = window.rcDayTrend || JSON.parse(localStorage.getItem('rcDayTrend') || '{}');
            const d = new Date();
            const tk = d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());
            const t = store[tk] || {};
            Object.keys(t).forEach(hk => {
                const v = t[hk] || 0;
                if (String(hk).charAt(0) === 'b') { if (v > todayBnt) todayBnt = v; }
                else if (v > todayAlt) todayAlt = v;
            });
        } catch(e){}
        if (!todayBnt) todayBnt = (window.rcTodayAgg && window.rcTodayAgg.bnt) || todayAlt;
        days.push({ label: 'Heute', h: { bnt: todayBnt }, today: true });
        const labels = days.map(x => x.label);
        const data = days.map(x => x.h ? (x.h.bnt != null ? x.h.bnt : (x.h.bcr || 0)) : null);
        const colors = days.map(x => x.today ? '#E60000' : '#8C8C8C');
        if (window.rcHistChart_i && window.rcHistChart_i.canvas !== ctx) { try { window.rcHistChart_i.destroy(); } catch(e){} window.rcHistChart_i = null; }
        if (window.rcHistChart_i && window.rcHistChart_i.data.labels.length === labels.length) {
            const ch = window.rcHistChart_i;
            ch.data.labels = labels; ch.data.datasets[0].data = data; ch.data.datasets[0].backgroundColor = colors;
            ch.update();
        } else {
            if (window.rcHistChart_i) { try { window.rcHistChart_i.destroy(); } catch(e){} }
            window.rcHistChart_i = new Chart(ctx, { type:'bar',
                data:{ labels, datasets:[{ label:'BNT (Neuvertraege)', data, backgroundColor:colors, borderRadius:4 }] },
                options:{ responsive:true, maintainAspectRatio:false, animation:{ duration:700 },
                    plugins:{ legend:{ display:false },
                        tooltip:{ backgroundColor:'#1D1D1D', titleColor:'#F5F5F5', bodyColor:'#C9C9C9', borderColor:'#3E3E3E', borderWidth:1,
                            callbacks:{ afterBody: (items) => {
                                const x = days[items[0].dataIndex];
                                if (!x || !x.h || x.today) return '';
                                const t = x.h;
                                return ['VVL: ' + (t.vvl||0), 'Ansprachen: ' + (t.ansp||0), 'ESL-Kontakte: ' + (t.kontakte||0)];
                            } } } },
                    scales:{ x:{ grid:{display:false}, ticks:{color:'#9C9C9C', font:{size:9}} },
                             y:{ grid:{color:'rgba(255,255,255,0.07)'}, ticks:{color:'#9C9C9C', font:{size:9}, precision:0}, beginAtZero:true } } } });
        }
    };

    // ============================================================
    //  DETAIL-ANSICHTEN — Klick auf Agent / Team / Standort oeffnet ein Modal
    //  mit Vertriebs- UND Qualitaetswerten inkl. Wochentrend-Charts.
    //  Plus: Tagesvergleich (Vergleich-Button) mit freier Datumswahl.
    // ============================================================
    const detailModal = document.createElement('div');
    detailModal.id = 'rcDetailModal';
    detailModal.innerHTML = `<div class="rc-card rc-detail-card"><button class="rc-detail-close" id="rcDetailClose" title="Schliessen">&#10005;</button><div id="rcDetailBody"></div></div>`;
    document.body.appendChild(detailModal);

    window._rcDetCharts = [];
    function rcCloseDetail(){
        detailModal.style.display = 'none';
        window._rcDetCharts.forEach(c => { try { c.destroy(); } catch(e){} });
        window._rcDetCharts = [];
    }
    function rcShowDetail(html){
        window._rcDetCharts.forEach(c => { try { c.destroy(); } catch(e){} });
        window._rcDetCharts = [];
        document.getElementById('rcDetailBody').innerHTML = html;
        detailModal.style.display = 'flex';
    }
    function rcDetChart(canvasId, cfg){
        const ctx = document.getElementById(canvasId);
        if (!ctx || !window.Chart) return null;
        const ch = new Chart(ctx, cfg);
        window._rcDetCharts.push(ch);
        return ch;
    }
    document.getElementById('rcDetailClose').addEventListener('click', rcCloseDetail);

    const rcTodayKey = () => { const d = new Date(); return d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()); };
    const fmtPct1 = v => v!=null ? v.toFixed(1).replace('.',',')+' %' : '—';
    const kpiTile = (label, val, col, sub) => `<div class="rc-detail-kpi"><div class="l" title="${rcAttr(label)}">${rcAttr(label)}</div><div class="v" style="color:${col||'#F5F5F5'};">${val}${sub?`<small>${sub}</small>`:''}</div></div>`;

    // 7 Vortage + heute als gemeinsame Zeitachse fuer alle Trend-Charts
    function rcDetailDays(){
        const out = [], WD = ['So','Mo','Di','Mi','Do','Fr','Sa'];
        for (let d = 7; d >= 0; d--) {
            const dt = new Date(Date.now() - d*86400000);
            const key = dt.getFullYear()+'-'+pad2(dt.getMonth()+1)+'-'+pad2(dt.getDate());
            out.push({ key, label: d===0 ? 'Heute' : (WD[dt.getDay()]+' '+pad2(dt.getDate())+'.'+pad2(dt.getMonth()+1)+'.'), today: d===0 });
        }
        return out;
    }
    const RC_DET_CHART_OPTS = (extra) => Object.assign({ responsive:true, maintainAspectRatio:false, animation:{ duration:500 },
        plugins:{ legend:{ labels:{ color:'#C9C9C9', boxWidth:9, font:{ size:9.5 } } } },
        scales:{ x:{ grid:{ display:false }, ticks:{ color:'#9C9C9C', font:{ size:9 } } },
                 y:{ grid:{ color:'rgba(255,255,255,0.07)' }, ticks:{ color:'#9C9C9C', font:{ size:9 } }, beginAtZero:true } } }, extra || {});

    // ============================================================
    //  TREND-ENGINE — Entwicklung je Scope (Standort/Team/Stack, optional von/bis)
    //  Sammelt je Tag ESL-Vertrieb (rcEslHistory.byAgent, heute live) und
    //  Liga-Qualitaet (rcLigaHistory.byAgent, heute rcKpiData) plus die
    //  VERURSACHER (Agenten-Summen ueber den Zeitraum, ESL+Liga per CCS gejoint).
    //  Scope-Zuordnung je Agent ueber das Mapping (VO->Team/Standort, Team->Stack).
    // ============================================================
    window.rcCollectTrend = function(scope){
        scope = scope || {};
        const fStd = scope.std || 'ALL', fTeam = scope.team != null ? String(scope.team) : 'ALL', fStack = scope.stack || 'ALL';
        const mapping = window.rcWcaMapping || {};
        const voMap = mapping.voMap || {}, ccsMap = mapping.ccsMap || {}, stackMap = mapping.stackMap || {};
        const agentStats = (window.rcLetzteStats && window.rcLetzteStats.agentStats) || {};
        const tKey = rcTodayKey();

        const voMeta = vo => {
            // Fehlt die VO im voMap, ist sie bei manchen ESL-Exporten bereits die CCS-ID
            // (ccsMap-Fallback) — sonst bleibt ccs leer und der Liga-Join per CCS
            // scheitert (doppelte Verursacher-Zeilen, BCR-BNT/VVL auf falscher Basis).
            const m = voMap[vo], a = agentStats[vo], cm = ccsMap[vo];
            return { name: (m && m.name) || (a && a.name) || (cm && cm.name) || vo,
                     team: ((m && m.team) || (a && a.team) || (cm && cm.team) || '').toString().trim(),
                     std:  normalizeStandort((m && m.standort) || (a && a.standort) || (cm && cm.standort) || ''),
                     ccs:  ((m && m.ccsId) || (a && a.ccsId) || (cm ? vo : '')).toString() };
        };
        const ccsMeta = id => {
            const m = ccsMap[id], k = window.rcKpiData ? window.rcKpiData[id] : null;
            return { name: (m && m.name) || (k && k.agentName) || ('CCS ' + id),
                     team: ((m && m.team) || (k && k.team) || '').toString().trim(),
                     std:  normalizeStandort((m && m.standort) || (k && k.standort) || '') };
        };
        const inScope = meta => (fStd === 'ALL' || meta.std === fStd)
            && (fTeam === 'ALL' || meta.team === fTeam)
            && (fStack === 'ALL' || (meta.team && (stackMap[meta.team] || '') === fStack));

        const eslHist = window.rcEslHistory || rcLoadEslHistory();
        const ligaHist = window.rcLigaHistory || {};
        let keys = [...new Set([].concat(Object.keys(eslHist), Object.keys(ligaHist), [tKey]))].sort();
        if (scope.from) keys = keys.filter(k => k >= scope.from);
        if (scope.to)   keys = keys.filter(k => k <= scope.to);
        keys = keys.slice(-40);

        const agg = {};       // Verursacher ueber den Zeitraum
        const ccsIndex = {};  // CCS-ID -> agg-Eintrag (Liga-Join ohne O(n^2))
        const nameIndex = {}; // Fallback-Join ohne CCS: normalisierter Name (Projektkonvention)
        const ensureAgg = (id, meta, vo) => {
            let g = agg[id];
            if (!g) { g = agg[id] = { vo: vo || '', name: meta.name, team: meta.team, std: meta.std, ccs: (meta.ccs || '').toString(),
                                       k:0, a:0, bnt:0, vvl:0, calls:0, csS:0, csN:0, tnS:0, tnN:0, tage:0 }; }
            return g;
        };

        const days = keys.map(key => {
            let byA = null;
            if (key === tKey && window.rcTodayAgg) byA = window.rcTodayAgg.byAgent;
            else { const t = eslHist[key]; byA = t && t.byAgent; }
            const e = { k:0, a:0, bnt:0, vvl:0, n:0 };
            const dayAgents = scope.detail ? {} : null;
            if (byA) Object.keys(byA).forEach(vo => {
                const meta = voMeta(vo); if (!inScope(meta)) return;
                const v = byA[vo], bntV = (v.bnt != null ? v.bnt : (v.bcr || 0));
                e.n++; e.k += v.k||0; e.a += v.a||0; e.bnt += bntV; e.vvl += v.vvl||0;
                const g = ensureAgg('vo:' + vo, meta, vo);
                g.k += v.k||0; g.a += v.a||0; g.bnt += bntV; g.vvl += v.vvl||0; g.tage++;
                if (meta.ccs && !ccsIndex[meta.ccs]) ccsIndex[meta.ccs] = g;
                if (window.rcNormName) { const nn = window.rcNormName(meta.name); if (nn && !nameIndex[nn]) nameIndex[nn] = g; }
                if (dayAgents) { const d2 = dayAgents[vo] || (dayAgents[vo] = { name:meta.name, team:meta.team, k:0, a:0, bnt:0, vvl:0, calls:0, cs:null, tn:null });
                    d2.k += v.k||0; d2.a += v.a||0; d2.bnt += bntV; d2.vvl += v.vvl||0;
                    if (meta.ccs) d2._ccs = meta.ccs; }
            });
            const l = { calls:0, csS:0, csN:0, tnS:0, tnN:0, ahtS:0, ahtN:0, n:0 };
            const ccsToDay = {}, nameToDay = {};
            if (dayAgents) Object.keys(dayAgents).forEach(vo => { const d2 = dayAgents[vo];
                if (d2._ccs) ccsToDay[d2._ccs] = d2;
                if (window.rcNormName) { const nn = window.rcNormName(d2.name); if (nn && !nameToDay[nn]) nameToDay[nn] = d2; } });
            const addLiga = (id, c, cs, tn, aht) => {
                id = String(id);
                const meta = ccsMeta(id); if (!inScope(meta)) return;
                l.n++; l.calls += c||0;
                if (cs != null) { l.csS += cs; l.csN++; }
                if (tn != null) { l.tnS += tn; l.tnN++; }
                if (aht != null && aht > 0) { l.ahtS += aht; l.ahtN++; }
                let g = ccsIndex[id];
                if (!g && window.rcNormName) g = nameIndex[window.rcNormName(meta.name)] || null;
                if (!g) { g = ensureAgg('ccs:' + id, Object.assign({}, meta, { ccs:id }), ''); ccsIndex[id] = g; }
                g.calls += c||0;
                if (cs != null) { g.csS += cs; g.csN++; }
                if (tn != null) { g.tnS += tn; g.tnN++; }
                if (dayAgents) {
                    let d2 = ccsToDay[id];
                    if (!d2 && window.rcNormName) d2 = nameToDay[window.rcNormName(meta.name)] || null;
                    if (!d2) d2 = dayAgents['ccs:'+id] = dayAgents['ccs:'+id] || { name:meta.name, team:meta.team, k:0, a:0, bnt:0, vvl:0, calls:0, cs:null, tn:null };
                    d2.calls += c||0; if (cs != null) d2.cs = cs; if (tn != null) d2.tn = tn; }
            };
            if (key === tKey) Object.keys(window.rcKpiData || {}).forEach(id => { const k2 = window.rcKpiData[id]; addLiga(id, k2.callCount, k2.cs, k2.tnps, k2.ahtSec); });
            else { const t = ligaHist[key]; if (t && t.byAgent) Object.keys(t.byAgent).forEach(id => { const v = t.byAgent[id]; addLiga(id, v.c, v.cs, v.tn, v.aht); }); }
            return { key, today: key === tKey, esl: e, liga: l, agents: dayAgents };
        });

        // Karteileichen raus: nur Agenten mit ESL-Aktivitaet ODER Liga-Signal (Calls/CS/TNPS)
        const agents = Object.values(agg)
            .filter(g => ((g.k||0)+(g.a||0)+(g.bnt||0)+(g.vvl||0)+(g.calls||0)) > 0 || (g.csN||0) > 0 || (g.tnN||0) > 0)
            .sort((x,y) => (y.bnt - x.bnt) || (y.calls - x.calls));
        const scopeLabel = [ fStd !== 'ALL' ? stdFullName(fStd) : '', fStack !== 'ALL' ? fStack : '', fTeam !== 'ALL' ? 'Team ' + fTeam : '' ]
            .filter(Boolean).join(' · ') || 'Alle Standorte';
        return { days, agents, scopeLabel };
    };

    // ---------- ENTWICKLUNGS-EXPORT (Excel, 3 Blaetter, Scope-gefiltert) ----------
    // Blatt 1: je Tag · Blatt 2: Verursacher (Agenten-Summen) · Blatt 3: Agent x Tag (pivot-faehig)
    window.rcExportTrend = function(scope){
        const data = window.rcCollectTrend(Object.assign({}, scope, { detail:true }));
        if (!data.days.length) { alert('Keine Entwicklungs-Daten vorhanden — Historie baut sich auf (Harvester/KPI-Crawler laufen lassen).'); return; }
        rcLoadStyledXlsx(function(XL){
            const styled = !!XL.__styled;
            const wb = XL.utils.book_new();
            const nd = new Date();
            const titel = 'Vodafone   ESL ENTWICKLUNG  |  ' + data.scopeLabel + '  |  Stand: ' + pad2(nd.getDate()) + '.' + pad2(nd.getMonth()+1) + '.' + nd.getFullYear();
            const PCT = '0.0%';
            const crF = (z,n) => n > 0 ? +((z||0)/n).toFixed(4) : '';
            const pctAvg = (s,n) => n > 0 ? +((s/n)/100).toFixed(4) : ''; // Liga-Werte kommen als 88,5 -> Bruch fuers %-Format
            const bd = { style:'thin', color:{ rgb:'FFD9D9D9' } };
            const BORDER = { top:bd, bottom:bd, left:bd, right:bd };
            const S_TITLE = { fill:{ patternType:'solid', fgColor:{ rgb:'FFE60000' } }, font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:12 }, alignment:{ horizontal:'left', vertical:'center' } };
            const S_HDR   = { fill:{ patternType:'solid', fgColor:{ rgb:'FF4A4D4E' } }, font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ horizontal:'center', vertical:'center', wrapText:true }, border:BORDER };
            const S_SUM   = { fill:{ patternType:'solid', fgColor:{ rgb:'FF1F2D3D' } }, font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ horizontal:'center', vertical:'center' }, border:BORDER };
            const S_CELL  = al => ({ font:{ sz:10 }, alignment:{ horizontal:al, vertical:'center' }, border:BORDER });
            function sheet(name, header, rows, pctCols, widths, sumRow){
                const aoa = [ [titel], header ].concat(rows);
                const sumIdx = sumRow ? aoa.length : -1;
                if (sumRow) aoa.push(sumRow);
                const ws = XL.utils.aoa_to_sheet(aoa);
                const rng = XL.utils.decode_range(ws['!ref']);
                for (let R = rng.s.r; R <= rng.e.r; R++) for (let C = rng.s.c; C <= rng.e.c; C++){
                    const addr = XL.utils.encode_cell({ r:R, c:C });
                    if (!ws[addr]) ws[addr] = { t:'s', v:'' };
                    if (R > 1 && pctCols.has(C) && ws[addr].t === 'n') ws[addr].z = PCT;
                    if (styled) {
                        const base = R === 0 ? S_TITLE : (R === 1 ? S_HDR : (R === sumIdx ? S_SUM : S_CELL(C === 0 ? 'left' : 'center')));
                        // Style pro Zelle klonen + numFmt setzen (xlsx-js-style-Leak!)
                        const own = Object.assign({}, base);
                        own.numFmt = (ws[addr].t === 'n' && ws[addr].z) ? ws[addr].z : 'General';
                        ws[addr].s = own;
                    }
                }
                ws['!merges'] = [ { s:{r:0,c:0}, e:{r:0,c:header.length-1} } ];
                ws['!cols'] = widths.map(x => ({ wch:x }));
                XL.utils.book_append_sheet(wb, ws, name);
            }
            // Blatt 1: Entwicklung je Tag (+ GESAMT)
            const sum = { k:0, a:0, bnt:0, vvl:0, calls:0, csS:0, csN:0, tnS:0, tnN:0 };
            const rows1 = data.days.map(d => { const e = d.esl, l = d.liga;
                sum.k += e.k; sum.a += e.a; sum.bnt += e.bnt; sum.vvl += e.vvl;
                sum.calls += l.calls; sum.csS += l.csS; sum.csN += l.csN; sum.tnS += l.tnS; sum.tnN += l.tnN;
                return [ d.key + (d.today ? ' (heute)' : ''), e.k, e.a, e.bnt, e.vvl, l.calls || '',
                         crF(e.bnt, l.calls), crF(e.vvl, l.calls), pctAvg(l.csS, l.csN), pctAvg(l.tnS, l.tnN) ]; });
            sheet('Entwicklung Tage',
                ['Tag','ESL-Kontakte','Ansprachen','BNT','VVL','Liga-Calls','BCR-BNT','BCR-VVL','CS Ø','TNPS Ø'],
                rows1, new Set([6,7,8,9]), [17,12,11,8,8,10,10,10,9,9],
                ['GESAMT', sum.k, sum.a, sum.bnt, sum.vvl, sum.calls || '', crF(sum.bnt, sum.calls), crF(sum.vvl, sum.calls), pctAvg(sum.csS, sum.csN), pctAvg(sum.tnS, sum.tnN)]);
            // Blatt 2: Verursacher — Agenten-Summen ueber den Zeitraum
            sheet('Agenten (Verursacher)',
                ['Agent','Team','Standort','CCS-ID','Tage m. ESL','Kontakte','Anspr.','BNT','VVL','Liga-Calls','BCR-BNT','BCR-VVL','CS Ø','TNPS Ø'],
                data.agents.map(g => [ g.name, g.team, g.std ? stdFullName(g.std) : '', g.ccs, g.tage, g.k, g.a, g.bnt, g.vvl, g.calls || '',
                    crF(g.bnt, g.calls), crF(g.vvl, g.calls), pctAvg(g.csS, g.csN), pctAvg(g.tnS, g.tnN) ]),
                new Set([10,11,12,13]), [22,11,15,9,9,9,8,7,7,10,10,10,9,9]);
            // Blatt 3: Agent x Tag (langes Format — direkt pivot-faehig)
            const rows3 = [];
            data.days.forEach(d => { if (!d.agents) return;
                Object.keys(d.agents).forEach(kk => { const x = d.agents[kk];
                    // Tageszeile ohne jedes Signal (0 Kontakte/Anspr/BNT/VVL/Calls, keine KPI) weglassen
                    if (((x.k||0)+(x.a||0)+(x.bnt||0)+(x.vvl||0)+(x.calls||0)) === 0 && x.cs == null && x.tn == null) return;
                    rows3.push([ d.key, x.name, x.team, x.k, x.a, x.bnt, x.vvl, x.calls || '',
                        x.cs != null ? +(x.cs/100).toFixed(4) : '', x.tn != null ? +(x.tn/100).toFixed(4) : '' ]); }); });
            sheet('Agenten je Tag',
                ['Tag','Agent','Team','Kontakte','Anspr.','BNT','VVL','Liga-Calls','CS','TNPS'],
                rows3, new Set([8,9]), [12,22,11,9,8,7,7,10,8,8]);
            const slug = data.scopeLabel.replace(/[^A-Za-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40) || 'Alle';
            const fn = `regiocom_ESL_Entwicklung_${slug}_${nd.getFullYear()}-${pad2(nd.getMonth()+1)}-${pad2(nd.getDate())}_${pad2(nd.getHours())}${pad2(nd.getMinutes())}.xlsx`;
            XL.writeFile(wb, fn);
            rcLog.log('Entwicklungs-Export (' + data.scopeLabel + ', ' + data.days.length + ' Tage): ' + fn);
        });
    };

    // ---------- AGENT-DETAIL ----------
    window.rcOpenAgentDetail = function(ref){
        ref = ref || {};
        const stats = window.rcLetzteStats || { agentStats:{} };
        let ag = null;
        if (ref.vo && stats.agentStats[ref.vo]) ag = stats.agentStats[ref.vo];
        if (!ag && ref.ccs) ag = Object.values(stats.agentStats).find(a => a.ccsId === ref.ccs) || null;
        if (!ag && ref.name) { const nn = window.rcNormName(ref.name); ag = Object.values(stats.agentStats).find(a => window.rcNormName(a.name) === nn) || null; }
        let kpi = ag ? window.rcKpiForAgent(ag) : null;
        if (!kpi && ref.ccs && window.rcKpiData[ref.ccs]) kpi = window.rcKpiData[ref.ccs];
        if (!kpi && ref.name) kpi = window.rcKpiByName[window.rcNormName(ref.name)] || null;
        if (!ag && !kpi) return;

        const name = ag ? ag.name : kpi.agentName;
        const code = normalizeStandort(ag ? ag.standort : kpi.standort);
        const team = (ag && ag.team) || (kpi && kpi.team) || '';
        const ccsId = (ag && ag.ccsId) || (kpi && kpi.ccsId) || ref.ccs || '';
        const vo = (ag && ag.vo) || ref.vo || '';
        const ligaCalls = kpi ? (kpi.callCount || 0) : 0;
        const anspQ = (ag && ligaCalls > 0) ? (ag.ansprachen / ligaCalls * 100) : null;

        // Vertrieb heute
        let salesTiles = '';
        if (ag) {
            salesTiles =
                kpiTile('ESL-Kontakte', ag.kontakte||0) +
                kpiTile('Ansprachen', ag.ansprachen||0, '#FF6666') +
                kpiTile('Ansprache-Quote', anspQ!=null?fmtPct1(anspQ):'—', zielColor(anspQ,{min:40}), anspQ!=null?'auf Liga-Calls':'') +
                kpiTile('KIP-BNT', ag.kip||0, (ag.kip||0)>0?'#FF6666':'#F5F5F5') +
                kpiTile('MOBILFUNK-BNT', ag.mob||0, '#FFFFFF') +
                kpiTile('BNT gesamt', ag.bnt||0, '#E60000') +
                kpiTile('FIB/DSL-BNT', ag.fibDsl||0) +
                kpiTile('ENV-BNT', ag.env||0) +
                kpiTile('PTV-BNT', ag.ptv||0) +
                kpiTile('KIP-VVL', ag.kipVvl||0) +
                kpiTile('MOBILFUNK-VVL', ag.mobVvl||0) +
                kpiTile('VVL gesamt', ag.vvl||0) +
                kpiTile('BCR-BNT (Liga)', ligaCalls>0?fmtPct1((ag.bnt||0)/ligaCalls*100):'—', '#E60000', ligaCalls>0?'BNT / Liga-Calls':'') +
                kpiTile('BCR-VVL (Liga)', ligaCalls>0?fmtPct1((ag.vvl||0)/ligaCalls*100):'—', '#FF679B', ligaCalls>0?'VVL / Liga-Calls':'') +
                kpiTile('BCR-relevant', bcrOf(ag), '#E60000', 'zaehlt in die BCR') +
                kpiTile('nicht BCR-rel.', nonBcrOf(ag), '#9C9C9C') +
                kpiTile('Offene Angebote', ag.offers||0, (ag.offers||0)>0?'#FF6666':'#F5F5F5');
        } else {
            salesTiles = `<div class="rc-detail-hint">Keine ESL-Vertriebsdaten fuer diesen Agenten (heute nichts getrackt).</div>`;
        }

        // Qualitaet heute — ALLE Ligalisten-Kennzahlen
        let qualiTiles = '';
        if (kpi) {
            qualiTiles =
                kpiTile('Calls', kpi.callCount!=null?kpi.callCount:'—', zielColor(kpi.callCount, RC_ZIELE.calls)) +
                kpiTile('AHT', fmtAht(kpi.ahtSec), zielColor(kpi.ahtSec!=null?kpi.ahtSec/60:null, RC_ZIELE.ahtMin), 'Min') +
                kpiTile('ACD', fmtAht(kpi.acdSec), '#F5F5F5', 'Min') +
                kpiTile('ACW', fmtAht(kpi.acwSec), '#F5F5F5', 'Min') +
                kpiTile('ACHT', fmtAht(kpi.achtSec), '#F5F5F5', 'Min') +
                kpiTile('Auflegerquote', fmtPct1(kpi.auflegerquote), zielColor(kpi.auflegerquote, RC_ZIELE.aq)) +
                kpiTile('CS', fmtPct1(kpi.cs), zielColor(kpi.cs, RC_ZIELE.cs)) +
                kpiTile('CS Deep Detr.', fmtPct1(kpi.csDds), kpi.csDds!=null&&kpi.csDds>RC_ZIELE.dds.max?'#E60000':'#F5F5F5') +
                kpiTile('TNPS', fmtPct1(kpi.tnps), zielColor(kpi.tnps, RC_ZIELE.tnps)) +
                kpiTile('Feedbackquote', fmtPct1(kpi.fq), zielColor(kpi.fq, RC_ZIELE.fq)) +
                kpiTile('TNPS-DDS', fmtPct1(kpi.dds), zielColor(kpi.dds, RC_ZIELE.dds)) +
                kpiTile('First-Time-Fix', fmtPct1(kpi.ftf)) +
                kpiTile('Total-Fix', fmtPct1(kpi.totalFix)) +
                kpiTile('Final Fix 7', fmtPct1(kpi.ff7), zielColor(kpi.ff7, RC_ZIELE.ff7), '7 Tage verzoegert') +
                kpiTile('Weiterl. Skill<>', fmtPct1(kpi.wq)) +
                kpiTile('Promotoren CS', kpi.promCs!=null?kpi.promCs:'—') +
                kpiTile('Neutrale CS', kpi.neutCs!=null?kpi.neutCs:'—', '#9C9C9C') +
                kpiTile('Detraktoren CS', kpi.detCs!=null?kpi.detCs:'—', (kpi.detCs||0)>0?'#E60000':'#F5F5F5') +
                kpiTile('Promotoren TNPS', kpi.promTnps!=null?kpi.promTnps:'—') +
                kpiTile('Neutrale TNPS', kpi.neutTnps!=null?kpi.neutTnps:'—', '#9C9C9C') +
                kpiTile('Detraktoren TNPS', kpi.detTnps!=null?kpi.detTnps:'—', (kpi.detTnps||0)>0?'#E60000':'#F5F5F5');
        } else {
            qualiTiles = `<div class="rc-detail-hint">Keine Ligalisten-Daten — KPI-Quelle oeffnen (Button oben) oder Agent hat heute keine Calls.</div>`;
        }

        rcShowDetail(`
            <div class="rc-detail-head">${getFlagSvg(code,'large')}<div>
                <h3>${rcAttr(name)}</h3>
                <div class="rc-detail-sub">${stdFullName(code)}${team?' · Team '+rcAttr(team):''}${(ag&&ag.stack)?' · '+rcAttr(ag.stack):''}${vo?' · VO '+rcAttr(vo):''}${ccsId?' · CCS '+rcAttr(ccsId):''}</div>
            </div></div>
            <div class="rc-detail-sec">Vertrieb heute (ESL)</div>
            <div class="rc-detail-kpis">${salesTiles}</div>
            <div class="rc-detail-sec">Qualitaet heute (Ligaliste — alle Kennzahlen)</div>
            <div class="rc-detail-kpis">${qualiTiles}</div>
            <div class="rc-detail-sec">Wochentrend</div>
            <div class="rc-detail-grid2">
                <div><div class="rc-detail-chartwrap"><canvas id="rcDetChSales"></canvas></div><div class="rc-detail-hint">Vertrieb: BNT, VVL und Ansprachen je Tag</div></div>
                <div><div class="rc-detail-chartwrap"><canvas id="rcDetChQuali"></canvas></div><div class="rc-detail-hint">Qualitaet: CS %, TNPS % und Calls je Tag</div></div>
            </div>
            <div class="rc-detail-hint" id="rcDetTrendHint"></div>
        `);

        // Trend-Daten sammeln
        const days = rcDetailDays();
        const eslHist = window.rcEslHistory || rcLoadEslHistory();
        const ligaHist = window.rcLigaHistory || {};
        const tKey = rcTodayKey();
        let histPoints = 0;
        const sBnt = [], sVvl = [], sAnsp = [];
        const qCs = [], qTnps = [], qCalls = [];
        days.forEach(d => {
            let e = null;
            if (d.today) e = (window.rcTodayAgg && vo && window.rcTodayAgg.byAgent[vo]) || null;
            else { const t = eslHist[d.key]; e = (t && t.byAgent && vo && t.byAgent[vo]) || null; }
            if (e && !d.today) histPoints++;
            sBnt.push(e ? (e.bnt!=null?e.bnt:(e.bcr||0)) : null); sVvl.push(e ? (e.vvl||0) : null); sAnsp.push(e ? (e.a||0) : null);
            let q = null;
            if (d.today && kpi) q = { cs:kpi.cs, tn:kpi.tnps, c:kpi.callCount||0 };
            else { const t = ligaHist[d.key]; q = (t && t.byAgent && ccsId && t.byAgent[ccsId]) || null; }
            qCs.push(q && q.cs!=null ? q.cs : null); qTnps.push(q && q.tn!=null ? q.tn : null); qCalls.push(q ? (q.c||0) : null);
        });
        const labels = days.map(d => d.label);
        rcDetChart('rcDetChSales', { type:'bar',
            data:{ labels, datasets:[
                { label:'BNT', data:sBnt, backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 },
                { label:'VVL', data:sVvl, backgroundColor:'rgba(255,255,255,0.55)', borderRadius:3 },
                { label:'Ansprachen', data:sAnsp, type:'line', borderColor:'#FF6666', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
            options: RC_DET_CHART_OPTS() });
        rcDetChart('rcDetChQuali', { type:'bar',
            data:{ labels, datasets:[
                { label:'Calls', data:qCalls, backgroundColor:'rgba(140,140,140,0.4)', borderRadius:3, yAxisID:'y1' },
                { label:'CS %', data:qCs, type:'line', borderColor:'#FFFFFF', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true },
                { label:'TNPS %', data:qTnps, type:'line', borderColor:'#E60000', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
            options: RC_DET_CHART_OPTS({ scales:{ x:{ grid:{ display:false }, ticks:{ color:'#9C9C9C', font:{ size:9 } } },
                y:{ grid:{ color:'rgba(255,255,255,0.07)' }, ticks:{ color:'#9C9C9C', font:{ size:9 } }, suggestedMax:100 },
                y1:{ position:'right', grid:{ display:false }, ticks:{ color:'#6E6E6E', font:{ size:8.5 } }, beginAtZero:true } } }) });
        const hint = document.getElementById('rcDetTrendHint');
        if (hint && histPoints === 0) hint.textContent = 'Hinweis: Die Vortage-Historie baut sich gerade auf — der ESL-Harvester laedt die letzten 7 Tage automatisch nach, die Liga-Historie waechst mit jedem Tag, an dem der KPI-Crawler laeuft.';
    };

    // Quali-Aggregat eines Teams: ueber ESL-Agenten des Teams (CCS-ID, Name-Fallback)
    // + Mapping (CCS -> Team) fuer Agenten ohne ESL-Eintrag
    function rcTeamQualiAgg(teamId){
        const seen = new Set(), kpis = [];
        const add = k => { if (k && k.ccsId && !seen.has(k.ccsId)) { seen.add(k.ccsId); kpis.push(k); } };
        if (window.rcLetzteStats) Object.values(window.rcLetzteStats.agentStats).forEach(a => { if (a.team === teamId) add(window.rcKpiForAgent(a)); });
        const ccsMap = (window.rcWcaMapping && window.rcWcaMapping.ccsMap) || {};
        Object.keys(ccsMap).forEach(id => { if (ccsMap[id] && ccsMap[id].team === teamId) add(window.rcKpiData[id]); });
        if (!kpis.length) return null;
        const mean = key => { const v = kpis.filter(k => k[key] != null); return v.length ? v.reduce((s,k)=>s+k[key],0)/v.length : null; };
        const ahtV = kpis.filter(k => k.ahtSec != null && k.ahtSec > 0);
        return { n:kpis.length, calls:kpis.reduce((s,k)=>s+(k.callCount||0),0), cs:mean('cs'), tnps:mean('tnps'), fq:mean('fq'),
                 aht:ahtV.length?ahtV.reduce((s,k)=>s+k.ahtSec,0)/ahtV.length:null, det:kpis.reduce((s,k)=>s+(k.det||0),0) };
    }

    // ---------- TEAM-DETAIL ----------
    window.rcOpenTeamDetail = function(teamId){
        const stats = window.rcLetzteStats; if (!stats) return;
        const t = stats.teamStats[teamId];
        const agents = Object.values(stats.agentStats).filter(a => a.team === teamId).sort((a,b) => b.total - a.total);
        if (!t && !agents.length) return;
        const code = t ? t.standort : (agents[0] ? agents[0].standort : '');
        const q = rcTeamQualiAgg(teamId);
        const liga = window.rcLigaAgg ? window.rcLigaAgg() : { byTeam:{} };
        const lc = liga.byTeam[teamId] || 0;

        let tiles = '';
        if (t) {
            tiles = kpiTile('ESL-Kontakte', t.calls||0) +
                kpiTile('Ansprachen', t.pitches||0, '#FF6666', lc>0?crTxt(t.pitches, lc)+' der Liga-Calls':'') +
                kpiTile('KIP-BNT', t.kip||0, (t.kip||0)>0?'#FF6666':'#F5F5F5') +
                kpiTile('MOBILFUNK-BNT', t.mob||0, '#FFFFFF') +
                kpiTile('BNT gesamt', t.bnt||0, '#E60000') +
                kpiTile('FIB/DSL-BNT', t.fibDsl||0) +
                kpiTile('ENV-BNT', t.env||0) +
                kpiTile('VVL', t.vvl||0) +
                kpiTile('BCR-BNT (Liga)', lc>0?crTxt(t.bnt||0, lc):'—', '#E60000', lc>0?'BNT / Liga-Calls':'') +
                kpiTile('BCR-VVL (Liga)', lc>0?crTxt(t.vvl||0, lc):'—', '#FF679B', lc>0?'VVL / Liga-Calls':'') +
                kpiTile('Liga-Calls', lc>0?lc:'—') +
                kpiTile('Ablehnungen', t.rejections||0, '#9C9C9C');
        }
        if (q) {
            tiles += kpiTile('CS Ø', fmtPct1(q.cs), zielColor(q.cs, RC_ZIELE.cs)) +
                kpiTile('TNPS Ø', fmtPct1(q.tnps), zielColor(q.tnps, RC_ZIELE.tnps)) +
                kpiTile('AHT Ø', fmtAht(q.aht), zielColor(q.aht!=null?q.aht/60:null, RC_ZIELE.ahtMin), 'Min') +
                kpiTile('FQ Ø', fmtPct1(q.fq), zielColor(q.fq, RC_ZIELE.fq)) +
                kpiTile('Detraktoren', q.det, q.det>0?'#E60000':'#F5F5F5');
        }

        const rows = agents.map(a => {
            const k = window.rcKpiForAgent(a) || {};
            return `<tr data-rc-vo="${rcAttr(a.vo)}" data-rc-name="${rcAttr(a.name)}" title="Klick: Agenten-Details">
                <td><b>${rcAttr(a.name)}</b></td>
                <td style="text-align:center;" class="rc-mono">${a.kontakte||0}</td>
                <td style="text-align:center; color:#FF6666;" class="rc-mono">${a.ansprachen||0}</td>
                <td style="text-align:center; color:${(a.kip||0)>0?'#FF6666':'#9C9C9C'}; font-weight:700;" class="rc-mono">${a.kip||0}</td>
                <td style="text-align:center; color:${(a.mob||0)>0?'#FFFFFF':'#9C9C9C'}; font-weight:700;" class="rc-mono">${a.mob||0}</td>
                <td style="text-align:center; color:#E60000;" class="rc-mono">${a.bnt||0}</td>
                <td style="text-align:center;" class="rc-mono">${a.vvl||0}</td>
                <td style="text-align:center;" class="rc-mono">${k.callCount!=null?k.callCount:'—'}</td>
                <td style="text-align:center; color:${zielColor(k.cs, RC_ZIELE.cs)};" class="rc-mono">${k.cs!=null?k.cs.toFixed(0)+'%':'—'}</td>
                <td style="text-align:center; color:${zielColor(k.tnps, RC_ZIELE.tnps)};" class="rc-mono">${k.tnps!=null?k.tnps.toFixed(0)+'%':'—'}</td>
            </tr>`; }).join('');

        rcShowDetail(`
            <div class="rc-detail-head">${getFlagSvg(code,'large')}<div style="flex:1;">
                <h3>Team ${rcAttr(teamId)}</h3>
                <div class="rc-detail-sub">${stdFullName(code)}${(t&&t.stack)?' · '+rcAttr(t.stack):''} · ${agents.length} Agenten im ESL</div>
            </div><button class="rc-btn rc-btn-blue" id="rcTeamExportBtn" style="margin-left:auto; font-size:11px;" title="Entwicklung + Verursacher dieses Teams als Excel">Team-Export (Excel)</button></div>
            <div class="rc-detail-sec">Team heute — Vertrieb & Qualitaet</div>
            <div class="rc-detail-kpis">${tiles || '<div class="rc-detail-hint">Keine Daten</div>'}</div>
            <div class="rc-detail-sec">Wochentrend Team</div>
            <div class="rc-detail-grid2">
                <div><div class="rc-detail-chartwrap"><canvas id="rcDetChTeamS"></canvas></div><div class="rc-detail-hint">Vertrieb: BNT, VVL und Ansprachen je Tag</div></div>
                <div><div class="rc-detail-chartwrap"><canvas id="rcDetChTeamQ"></canvas></div><div class="rc-detail-hint">Qualitaet: CS %, TNPS % und Liga-Calls je Tag</div></div>
            </div>
            <div class="rc-detail-sec">Verursacher — Agenten-Summen der letzten 7 Tage</div>
            <div id="rcTeamWeekWrap"></div>
            <div class="rc-detail-sec">Agenten des Teams (heute)</div>
            <table class="rc-detail-table"><thead><tr><th>Agent</th><th style="text-align:center;">Kont</th><th style="text-align:center;">Anspr</th><th style="text-align:center; color:#FF6666;">KIP</th><th style="text-align:center;">MOB</th><th style="text-align:center;">BNT</th><th style="text-align:center;">VVL</th><th style="text-align:center;">Calls</th><th style="text-align:center;">CS</th><th style="text-align:center;">TNPS</th></tr></thead>
            <tbody>${rows || '<tr><td colspan="10" style="text-align:center; color:#9C9C9C; padding:14px;">Keine Agenten mit ESL-Daten</td></tr>'}</tbody></table>
        `);

        // Wochentrend + Verursacher aus der Trend-Engine (letzte 8 Tage, Team-Scope)
        const fromIso = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date(Date.now() - 7*86400000));
        const trend = window.rcCollectTrend({ team: teamId, from: fromIso });
        const tds = trend.days;
        const WDT = ['So','Mo','Di','Mi','Do','Fr','Sa'];
        const lblOf = d => { if (d.today) return 'Heute'; const dt = new Date(d.key + 'T00:00:00'); return WDT[dt.getDay()] + ' ' + d.key.slice(8) + '.' + d.key.slice(5,7) + '.'; };
        const labelsT = tds.map(lblOf);
        rcDetChart('rcDetChTeamS', { type:'bar',
            data:{ labels: labelsT, datasets:[
                { label:'BNT', data: tds.map(d => d.esl.n ? d.esl.bnt : null), backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 },
                { label:'VVL', data: tds.map(d => d.esl.n ? d.esl.vvl : null), backgroundColor:'rgba(255,255,255,0.55)', borderRadius:3 },
                { label:'Ansprachen', data: tds.map(d => d.esl.n ? d.esl.a : null), type:'line', borderColor:'#FF6666', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
            options: RC_DET_CHART_OPTS() });
        rcDetChart('rcDetChTeamQ', { type:'bar',
            data:{ labels: labelsT, datasets:[
                { label:'Liga-Calls', data: tds.map(d => d.liga.n ? d.liga.calls : null), backgroundColor:'rgba(140,140,140,0.4)', borderRadius:3, yAxisID:'y1' },
                { label:'CS %', data: tds.map(d => d.liga.csN ? +(d.liga.csS/d.liga.csN).toFixed(1) : null), type:'line', borderColor:'#FFFFFF', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true },
                { label:'TNPS %', data: tds.map(d => d.liga.tnN ? +(d.liga.tnS/d.liga.tnN).toFixed(1) : null), type:'line', borderColor:'#E60000', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
            options: RC_DET_CHART_OPTS({ scales:{ x:{ grid:{ display:false }, ticks:{ color:'#9C9C9C', font:{ size:9 } } },
                y:{ grid:{ color:'rgba(255,255,255,0.07)' }, ticks:{ color:'#9C9C9C', font:{ size:9 } }, suggestedMax:100 },
                y1:{ position:'right', grid:{ display:false }, ticks:{ color:'#6E6E6E', font:{ size:8.5 } }, beginAtZero:true } } }) });
        const wkWrap = document.getElementById('rcTeamWeekWrap');
        if (wkWrap) {
            const pctW = (z,n) => n > 0 ? (z/n*100).toFixed(1).replace('.',',')+' %' : '—';
            wkWrap.innerHTML = trend.agents.length ? `<table class="rc-detail-table">
                <thead><tr><th>Agent</th><th style="text-align:center;">Kontakte</th><th style="text-align:center;">Anspr.</th><th style="text-align:center; color:#FF6666;">BNT</th><th style="text-align:center;">VVL</th><th style="text-align:center;">Liga-Calls</th><th style="text-align:center;">BCR-BNT</th><th style="text-align:center;">BCR-VVL</th><th style="text-align:center;">CS Ø</th><th style="text-align:center;">TNPS Ø</th></tr></thead>
                <tbody>${trend.agents.slice(0, 20).map(g => `<tr${g.vo?` data-rc-vo="${rcAttr(g.vo)}" data-rc-name="${rcAttr(g.name)}" title="Klick: Agenten-Details"`:''}>
                    <td><b>${rcAttr(g.name)}</b></td>
                    <td style="text-align:center;" class="rc-mono">${g.k}</td>
                    <td style="text-align:center; color:#FF6666;" class="rc-mono">${g.a}</td>
                    <td style="text-align:center; color:#E60000; font-weight:700;" class="rc-mono">${g.bnt}</td>
                    <td style="text-align:center;" class="rc-mono">${g.vvl}</td>
                    <td style="text-align:center;" class="rc-mono">${g.calls || '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${pctW(g.bnt, g.calls)}</td>
                    <td style="text-align:center;" class="rc-mono">${pctW(g.vvl, g.calls)}</td>
                    <td style="text-align:center;" class="rc-mono">${g.csN ? (g.csS/g.csN).toFixed(1).replace('.',',')+' %' : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${g.tnN ? (g.tnS/g.tnN).toFixed(1).replace('.',',')+' %' : '—'}</td>
                </tr>`).join('')}</tbody></table>`
                : '<div class="rc-detail-hint">Noch keine Historie fuer dieses Team — Harvester/KPI-Crawler laufen lassen oder Zeitraum-Button nutzen.</div>';
        }
        const expBtn = document.getElementById('rcTeamExportBtn');
        if (expBtn) expBtn.addEventListener('click', () => window.rcExportTrend({ team: teamId }));
    };

    // ---------- STANDORT-DETAIL ----------
    window.rcOpenStandortDetail = function(code){
        const stats = window.rcLetzteStats; if (!stats) return;
        const s = stats.standortStats[code];
        const teams = Object.values(stats.teamStats).filter(t => t.standort === code).sort((a,b) => b.total - a.total);
        const agents = Object.values(stats.agentStats).filter(a => a.standort === code).sort((a,b) => b.total - a.total);
        if (!s && !teams.length && !agents.length) return;
        const liga = window.rcLigaAgg ? window.rcLigaAgg() : { byStd:{}, byTeam:{} };
        const lc = liga.byStd[code] || 0;

        let tiles = '';
        if (s) {
            tiles = kpiTile('ESL-Kontakte', s.calls||0) +
                kpiTile('Ansprachen', s.pitches||0, '#FF6666', lc>0?crTxt(s.pitches, lc)+' der Liga-Calls':'') +
                kpiTile('KIP-BNT', s.kip||0, (s.kip||0)>0?'#FF6666':'#F5F5F5') +
                kpiTile('MOBILFUNK-BNT', s.mob||0, '#FFFFFF') +
                kpiTile('BNT gesamt', s.bnt||0, '#E60000') +
                kpiTile('VVL', s.vvl||0) +
                kpiTile('BCR-BNT (Liga)', lc>0?crTxt(s.bnt||0, lc):'—', '#E60000', lc>0?'BNT / Liga-Calls':'') +
                kpiTile('BCR-VVL (Liga)', lc>0?crTxt(s.vvl||0, lc):'—', '#FF679B', lc>0?'VVL / Liga-Calls':'') +
                kpiTile('Liga-Calls', lc>0?lc:'—') +
                kpiTile('Ablehnungen', s.rejections||0, '#9C9C9C') +
                kpiTile('Offene Angebote', s.offers||0, (s.offers||0)>0?'#FF6666':'#F5F5F5');
        }

        const teamRows = teams.map(t => {
            const q = rcTeamQualiAgg(t.code);
            const tlc = liga.byTeam[t.code] || 0;
            return `<tr data-rc-team="${rcAttr(t.code)}" title="Klick: Team-Details">
                <td><b>Team ${rcAttr(t.name)}</b>${t.stack?`<span class="rc-mono" style="color:#9A9A9A; font-size:9px; margin-left:5px;">${rcAttr(t.stack)}</span>`:''}</td>
                <td style="text-align:center;" class="rc-mono">${t.calls||0}</td>
                <td style="text-align:center; color:#FF6666;" class="rc-mono">${t.pitches||0}</td>
                <td style="text-align:center; color:${(t.kip||0)>0?'#FF6666':'#9C9C9C'}; font-weight:700;" class="rc-mono">${t.kip||0}</td>
                <td style="text-align:center; color:${(t.mob||0)>0?'#FFFFFF':'#9C9C9C'}; font-weight:700;" class="rc-mono">${t.mob||0}</td>
                <td style="text-align:center; color:#E60000;" class="rc-mono">${t.bnt||0}</td>
                <td style="text-align:center;" class="rc-mono">${t.vvl||0}</td>
                <td style="text-align:center;" class="rc-mono">${tlc>0?crTxt(t.bnt||0, tlc):'—'}</td>
                <td style="text-align:center; color:${q?zielColor(q.cs, RC_ZIELE.cs):'#9C9C9C'};" class="rc-mono">${q&&q.cs!=null?q.cs.toFixed(0)+'%':'—'}</td>
                <td style="text-align:center; color:${q?zielColor(q.tnps, RC_ZIELE.tnps):'#9C9C9C'};" class="rc-mono">${q&&q.tnps!=null?q.tnps.toFixed(0)+'%':'—'}</td>
            </tr>`; }).join('');

        const agRows = agents.slice(0,12).map(a => `<tr data-rc-vo="${rcAttr(a.vo)}" data-rc-name="${rcAttr(a.name)}" title="Klick: Agenten-Details">
                <td><b>${rcAttr(a.name)}</b><span class="rc-mono" style="color:#9A9A9A; font-size:9px; margin-left:5px;">${rcAttr(a.team||'')}</span></td>
                <td style="text-align:center; color:#FF6666;" class="rc-mono">${a.ansprachen||0}</td>
                <td style="text-align:center; color:${(a.kip||0)>0?'#FF6666':'#9C9C9C'}; font-weight:700;" class="rc-mono">${a.kip||0}</td>
                <td style="text-align:center; color:${(a.mob||0)>0?'#FFFFFF':'#9C9C9C'}; font-weight:700;" class="rc-mono">${a.mob||0}</td>
                <td style="text-align:center; color:#E60000;" class="rc-mono">${a.bnt||0}</td>
                <td style="text-align:center;" class="rc-mono">${a.vvl||0}</td>
                <td style="text-align:center; font-weight:700;" class="rc-mono">${a.total||0}</td>
            </tr>`).join('');

        rcShowDetail(`
            <div class="rc-detail-head">${getFlagSvg(code,'large')}<div style="flex:1;">
                <h3>${stdFullName(code)}</h3>
                <div class="rc-detail-sub">${teams.length} Teams · ${agents.length} Agenten im ESL heute</div>
            </div><button class="rc-btn rc-btn-blue" id="rcStdExportBtn" style="margin-left:auto; font-size:11px;" title="Entwicklung + Verursacher dieses Standorts als Excel">Standort-Export (Excel)</button></div>
            <div class="rc-detail-sec">Standort heute</div>
            <div class="rc-detail-kpis">${tiles || '<div class="rc-detail-hint">Keine Daten</div>'}</div>
            <div class="rc-detail-grid2" style="margin-top:14px;">
                <div>
                    <div class="rc-detail-sec" style="margin-top:0;">Teams</div>
                    <table class="rc-detail-table"><thead><tr><th>Team</th><th style="text-align:center;">Kont</th><th style="text-align:center;">Anspr</th><th style="text-align:center; color:#FF6666;">KIP</th><th style="text-align:center;">MOB</th><th style="text-align:center;">BNT</th><th style="text-align:center;">VVL</th><th style="text-align:center;">BCR-BNT</th><th style="text-align:center;">CS</th><th style="text-align:center;">TNPS</th></tr></thead>
                    <tbody>${teamRows || '<tr><td colspan="10" style="text-align:center; color:#9C9C9C; padding:14px;">Keine Team-Daten</td></tr>'}</tbody></table>
                    <div class="rc-detail-sec">Top-Agenten</div>
                    <table class="rc-detail-table"><thead><tr><th>Agent</th><th style="text-align:center;">Anspr</th><th style="text-align:center; color:#FF6666;">KIP</th><th style="text-align:center;">MOB</th><th style="text-align:center;">BNT</th><th style="text-align:center;">VVL</th><th style="text-align:center;">Ges.</th></tr></thead>
                    <tbody>${agRows || '<tr><td colspan="7" style="text-align:center; color:#9C9C9C; padding:14px;">Keine Agenten</td></tr>'}</tbody></table>
                </div>
                <div>
                    <div class="rc-detail-sec" style="margin-top:0;">Wochentrend Vertrieb</div>
                    <div class="rc-detail-chartwrap" style="height:240px;"><canvas id="rcDetChStd"></canvas></div>
                    <div class="rc-detail-hint">BNT, VVL und Ansprachen je Tag — Vortage aus der ESL-Historie, heute live</div>
                    <div class="rc-detail-sec">Wochentrend Qualitaet</div>
                    <div class="rc-detail-chartwrap" style="height:200px;"><canvas id="rcDetChStdQ"></canvas></div>
                    <div class="rc-detail-hint">CS %, TNPS % und Liga-Calls je Tag — aus den Liga-Tages-Snapshots</div>
                </div>
            </div>
        `);
        const stdExp = document.getElementById('rcStdExportBtn');
        if (stdExp) stdExp.addEventListener('click', () => window.rcExportTrend({ std: code }));

        const days = rcDetailDays();
        const eslHist = window.rcEslHistory || rcLoadEslHistory();
        const sBnt = [], sVvl = [], sAnsp = [];
        days.forEach(d => {
            let e = null;
            if (d.today) e = (window.rcTodayAgg && window.rcTodayAgg.byStd[code]) || null;
            else { const t = eslHist[d.key]; e = (t && t.byStd && t.byStd[code]) || null; }
            sBnt.push(e ? (e.bnt!=null?e.bnt:(e.bcr||0)) : null); sVvl.push(e ? (e.vvl||0) : null); sAnsp.push(e ? (e.ansp||0) : null);
        });
        rcDetChart('rcDetChStd', { type:'bar',
            data:{ labels: days.map(d => d.label), datasets:[
                { label:'BNT', data:sBnt, backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 },
                { label:'VVL', data:sVvl, backgroundColor:'rgba(255,255,255,0.55)', borderRadius:3 },
                { label:'Ansprachen', data:sAnsp, type:'line', borderColor:'#FF6666', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
            options: RC_DET_CHART_OPTS() });
        // Qualitaets-Wochentrend des Standorts aus der Trend-Engine (Liga-Snapshots)
        (function(){
            const fromIso = (d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate()))(new Date(Date.now() - 7*86400000));
            const tr = window.rcCollectTrend({ std: code, from: fromIso });
            const WDQ = ['So','Mo','Di','Mi','Do','Fr','Sa'];
            const lbl = d => d.today ? 'Heute' : (WDQ[new Date(d.key+'T00:00:00').getDay()] + ' ' + d.key.slice(8) + '.' + d.key.slice(5,7) + '.');
            rcDetChart('rcDetChStdQ', { type:'bar',
                data:{ labels: tr.days.map(lbl), datasets:[
                    { label:'Liga-Calls', data: tr.days.map(d => d.liga.n ? d.liga.calls : null), backgroundColor:'rgba(140,140,140,0.4)', borderRadius:3, yAxisID:'y1' },
                    { label:'CS %', data: tr.days.map(d => d.liga.csN ? +(d.liga.csS/d.liga.csN).toFixed(1) : null), type:'line', borderColor:'#FFFFFF', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true },
                    { label:'TNPS %', data: tr.days.map(d => d.liga.tnN ? +(d.liga.tnS/d.liga.tnN).toFixed(1) : null), type:'line', borderColor:'#E60000', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true } ] },
                options: RC_DET_CHART_OPTS({ scales:{ x:{ grid:{ display:false }, ticks:{ color:'#9C9C9C', font:{ size:9 } } },
                    y:{ grid:{ color:'rgba(255,255,255,0.07)' }, ticks:{ color:'#9C9C9C', font:{ size:9 } }, suggestedMax:100 },
                    y1:{ position:'right', grid:{ display:false }, ticks:{ color:'#6E6E6E', font:{ size:8.5 } }, beginAtZero:true } } }) });
        })();
    };

    // ---------- TAGESVERGLEICH (Vertrieb + Qualitaet, freie Datumswahl) ----------
    window.rcOpenCompare = function(){
        const eslHist = window.rcEslHistory || rcLoadEslHistory();
        const ligaHist = window.rcLigaHistory || {};
        const tKey = rcTodayKey();
        const dayKeys = [...new Set([].concat(Object.keys(eslHist), Object.keys(ligaHist), [tKey]))].sort().reverse();
        if (dayKeys.length < 2) { rcShowDetail('<div class="rc-detail-head"><h3>Tagesvergleich</h3></div><div class="rc-detail-hint">Noch nicht genug Historie — der Harvester laedt die Vortage automatisch. Spaeter erneut oeffnen.</div>'); return; }
        const fmtDay = k => k === tKey ? 'Heute (' + k + ')' : k;
        const opts = sel => dayKeys.map(k => `<option value="${k}"${k===sel?' selected':''}>${fmtDay(k)}</option>`).join('');
        const stdOpts = ['<option value="ALL">Alle Standorte</option>'].concat(ORDER.map(c => `<option value="${c}">${stdFullName(c)}</option>`)).join('');

        rcShowDetail(`
            <div class="rc-detail-head"><div>
                <h3>Tagesvergleich — Vertrieb & Qualitaet</h3>
                <div class="rc-detail-sub">Zwei Tage frei waehlen · ESL-Vertrieb + Ligalisten-Qualitaet nebeneinander</div>
            </div></div>
            <div class="rc-cmp-controls">
                <select id="rcCmpDayA" class="rc-select">${opts(dayKeys[1])}</select>
                <span style="color:#9C9C9C; font-weight:700; font-size:11px;">VS</span>
                <select id="rcCmpDayB" class="rc-select">${opts(dayKeys[0])}</select>
                <select id="rcCmpStd" class="rc-select">${stdOpts}</select>
            </div>
            <div id="rcCmpTableWrap"></div>
            <div class="rc-detail-chartwrap" style="height:210px; margin-top:12px;"><canvas id="rcDetChCmp"></canvas></div>
            <div class="rc-detail-hint">Vertriebswerte aus der ESL-Tageshistorie (verifiziert), Qualitaet aus den Liga-Tages-Snapshots des KPI-Crawlers. Tage ohne Snapshot zeigen "—".</div>
        `);

        function eslOf(key, std){
            const src = key === tKey ? window.rcTodayAgg : eslHist[key];
            if (!src) return null;
            if (std === 'ALL') return { kontakte:src.kontakte, ansp:src.ansp, bcr:src.bcr, bnt:src.bnt, vvl:src.vvl };
            return (src.byStd && src.byStd[std]) || null;
        }
        function ligaOf(key, std){
            let snap = ligaHist[key];
            // Heute-Fallback: live aus den aktuellen KPI-Daten aggregieren
            if (!snap && key === tKey && Object.keys(window.rcKpiData||{}).length) {
                const t = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 };
                Object.values(window.rcKpiData).forEach(k => {
                    if (std !== 'ALL' && window.rcLigaMeta(k).std !== std) return;
                    t.calls += k.callCount||0; t.agents++;
                    if (k.cs!=null){ t.csSum+=k.cs; t.csN++; }
                    if (k.tnps!=null){ t.tnpsSum+=k.tnps; t.tnpsN++; }
                    if (k.ahtSec!=null&&k.ahtSec>0){ t.ahtSum+=k.ahtSec; t.ahtN++; }
                    t.det += k.det||0;
                });
                return t.agents ? t : null;
            }
            if (!snap) return null;
            if (std === 'ALL') return snap.tot || null;
            // byStd-Schluessel sind Liga-Standortnamen -> normalisieren und summieren
            const out = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 };
            let hit = false;
            Object.keys(snap.byStd || {}).forEach(name => {
                if (normalizeStandort(name) !== std) return;
                hit = true; const v = snap.byStd[name];
                ['calls','csSum','csN','tnpsSum','tnpsN','ahtSum','ahtN','det','agents'].forEach(f => out[f] += (v[f]||0));
            });
            return hit ? out : null;
        }
        const mval = (o, f) => o ? o[f] : null;
        const ligaAvg = (o, sumF, nF) => (o && o[nF] > 0) ? o[sumF]/o[nF] : null;

        function renderCmp(){
            const kA = document.getElementById('rcCmpDayA').value;
            const kB = document.getElementById('rcCmpDayB').value;
            const std = document.getElementById('rcCmpStd').value;
            const eA = eslOf(kA, std), eB = eslOf(kB, std);
            const lA = ligaOf(kA, std), lB = ligaOf(kB, std);
            const rateOf = (e, l, f) => (e && l && l.calls > 0) ? (e[f]||0) / l.calls * 100 : null;
            const rows = [
                ['ESL-Kontakte', mval(eA,'kontakte'), mval(eB,'kontakte'), true, v=>v],
                ['Ansprachen', mval(eA,'ansp'), mval(eB,'ansp'), true, v=>v],
                ['BNT (Neuvertraege)', mval(eA,'bnt'), mval(eB,'bnt'), true, v=>v],
                ['VVL', mval(eA,'vvl'), mval(eB,'vvl'), true, v=>v],
                ['BCR-BNT (Liga)', rateOf(eA,lA,'bnt'), rateOf(eB,lB,'bnt'), true, v=>v.toFixed(1).replace('.',',')+' %'],
                ['BCR-VVL (Liga)', rateOf(eA,lA,'vvl'), rateOf(eB,lB,'vvl'), true, v=>v.toFixed(1).replace('.',',')+' %'],
                ['Liga-Calls', mval(lA,'calls'), mval(lB,'calls'), true, v=>v],
                ['CS Ø', ligaAvg(lA,'csSum','csN'), ligaAvg(lB,'csSum','csN'), true, v=>v.toFixed(1).replace('.',',')+' %'],
                ['TNPS Ø', ligaAvg(lA,'tnpsSum','tnpsN'), ligaAvg(lB,'tnpsSum','tnpsN'), true, v=>v.toFixed(1).replace('.',',')+' %'],
                ['AHT Ø', ligaAvg(lA,'ahtSum','ahtN'), ligaAvg(lB,'ahtSum','ahtN'), false, v=>fmtAht(v)+' Min'],
                ['Detraktoren', mval(lA,'det'), mval(lB,'det'), false, v=>v]
            ];
            const trs = rows.map(([label, a, b, upGood, fmt]) => {
                const dTxt = (a!=null && b!=null) ? (() => {
                    const d = b - a;
                    if (Math.abs(d) < 0.05) return '<span class="rc-delta-zero">±0</span>';
                    const good = upGood ? d > 0 : d < 0;
                    const val = Math.abs(d) >= 10 || Number.isInteger(a) && Number.isInteger(b) ? Math.round(Math.abs(d)) : Math.abs(d).toFixed(1).replace('.',',');
                    return `<span class="${good?'rc-delta-up':'rc-delta-down'}">${d>0?'+':'−'}${val}</span>`;
                })() : '<span class="rc-delta-zero">—</span>';
                return `<tr><td><b>${label}</b></td>
                    <td style="text-align:center;" class="rc-mono">${a!=null?fmt(a):'—'}</td>
                    <td style="text-align:center;" class="rc-mono">${b!=null?fmt(b):'—'}</td>
                    <td style="text-align:center;" class="rc-mono">${dTxt}</td></tr>`;
            }).join('');
            document.getElementById('rcCmpTableWrap').innerHTML = `<table class="rc-detail-table">
                <thead><tr><th>Kennzahl</th><th style="text-align:center;">${fmtDay(kA)}</th><th style="text-align:center;">${fmtDay(kB)}</th><th style="text-align:center;">&Delta; (B−A)</th></tr></thead>
                <tbody>${trs}</tbody></table>`;
            // Chart: die 5 wichtigsten Werte als Balkenpaar
            window._rcDetCharts.filter(c => c.canvas && c.canvas.id === 'rcDetChCmp').forEach(c => { try{ c.destroy(); }catch(e){} });
            window._rcDetCharts = window._rcDetCharts.filter(c => !(c.canvas && c.canvas.id === 'rcDetChCmp'));
            const cats = ['BNT', 'VVL', 'Ansprachen', 'CS Ø %', 'TNPS Ø %'];
            const dA = [mval(eA,'bnt'), mval(eA,'vvl'), mval(eA,'ansp'), ligaAvg(lA,'csSum','csN'), ligaAvg(lA,'tnpsSum','tnpsN')];
            const dB = [mval(eB,'bnt'), mval(eB,'vvl'), mval(eB,'ansp'), ligaAvg(lB,'csSum','csN'), ligaAvg(lB,'tnpsSum','tnpsN')];
            rcDetChart('rcDetChCmp', { type:'bar',
                data:{ labels:cats, datasets:[
                    { label:fmtDay(kA), data:dA, backgroundColor:'rgba(140,140,140,0.7)', borderRadius:3 },
                    { label:fmtDay(kB), data:dB, backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 } ] },
                options: RC_DET_CHART_OPTS() });
        }
        ['rcCmpDayA','rcCmpDayB','rcCmpStd'].forEach(id => document.getElementById(id).addEventListener('change', renderCmp));
        renderCmp();
    };

    // ---------- KPI-KACHEL-DRILLDOWN: Klick auf eine Arena-Zahl -> WER dahinter steht ----------
    // Zeigt fuer BNT/KIP/MOB/VVL/Ansprachen/Ablehnungen/Kontakte/Offene die Agenten-Liste
    // (nur im aktuell gewaehlten Filter Standort/Team/Stack). Klick auf eine Zeile
    // oeffnet das komplette Agenten-Profil.
    function rcKpiScopeTxt(){
        const fv=(document.getElementById('rcStandortFilter')||{}).value;
        const ts=document.getElementById('rcTeamFilter');
        const ss=document.getElementById('rcStackFilter');
        const p=[];
        if (ss && ss.value && ss.value!=='ALL') p.push(ss.value);
        if (fv && fv!=='ALL') p.push(stdFullName(fv));
        if (fv && fv!=='ALL' && ts && ts.value!=='ALL') p.push('Team '+ts.value);
        return p.length ? p.join(' · ') : 'Alle Standorte';
    }
    window.rcOpenKpiDetail = function(kind){
        const sales = window.rcAllSales || [];
        const rejs  = window.rcAllRejections || [];
        const agentsArr = Object.values((window.rcLetzteStats||{}).agentStats || {});
        const scopeTxt = rcKpiScopeTxt();
        const agRow = (a, n, col, extra) => `<tr data-rc-vo="${rcAttr(a.vo)}" data-rc-name="${rcAttr(a.name)}" title="Klick: Agenten-Profil" style="cursor:pointer;">
            <td><b>${rcAttr(a.name)}</b> <span class="rc-mono" style="color:#9A9A9A; font-size:9px; font-weight:400;">${a.team?('Team '+rcAttr(a.team)):''}</span></td>
            <td style="text-align:center; color:${col}; font-weight:700;" class="rc-mono">${n}</td>${extra||''}</tr>`;

        // Verkaufs-Kacheln (aus rcAllSales)
        const CFG = {
            bnt: { t:'BNT gesamt — Neuvertraege', filt:s=>s.isBnt,        col:'#E60000' },
            kip: { t:'KIP-BNT',                   filt:s=>s.cat==='kip',  col:'#FF6666' },
            mob: { t:'Mobilfunk-BNT',             filt:s=>s.cat==='mob',  col:'#FFFFFF' },
            vvl: { t:'VVL — Vertragsverlaengerung', filt:s=>s.isVvl,      col:'#FF679B' }
        };
        if (CFG[kind]) {
            const c = CFG[kind];
            const list = sales.filter(c.filt);
            const total = list.reduce((s2,x)=>s2+(x.anzahl||1),0);
            const byAg = {};
            list.forEach(s => { const k=s.vo||s.name; (byAg[k]||(byAg[k]={name:s.name,vo:s.vo,team:s.team,n:0,items:[]})).n+=(s.anzahl||1); byAg[k].items.push(s); });
            const agents = Object.values(byAg).sort((a,b)=>b.n-a.n);
            const rows = agents.length ? agents.map(a => agRow(a, a.n, c.col,
                `<td style="font-size:10px; color:#BDBDBD;">${a.items.slice(0,10).map(it=>rcAttr(it.prod||'')+(it.timeStr?' ('+it.timeStr+')':'')).join(', ')}${a.items.length>10?' …':''}</td>`
            )).join('') : `<tr><td colspan="3" style="text-align:center; color:#9C9C9C; padding:16px;">Keine ${rcAttr(c.t)} im aktuellen Filter.</td></tr>`;
            rcShowDetail(`<div class="rc-detail-head"><div><h3>${rcAttr(c.t)}</h3>
                <div class="rc-detail-sub">${rcAttr(scopeTxt)} · <b style="color:${c.col};">${total}</b> Abschluss/Abschluesse · ${agents.length} Agent(en)</div></div></div>
                <table class="rc-detail-table"><thead><tr><th>Agent</th><th style="text-align:center;">Anzahl</th><th>Produkte (Uhrzeit)</th></tr></thead><tbody>${rows}</tbody></table>
                <div class="rc-detail-hint">Klick auf eine Zeile oeffnet das komplette Agenten-Profil. Es zaehlt nur der aktuell gewaehlte Filter (Standort/Team/Stack).</div>`);
            return;
        }
        // Ablehnungen (aus rcAllRejections)
        if (kind === 'rej') {
            const byAg = {};
            rejs.forEach(rj => { const k=rj.vo||rj.name; (byAg[k]||(byAg[k]={name:rj.name,vo:rj.vo,team:rj.team,n:0,gruende:{}})).n++; byAg[k].gruende[rj.grund]=(byAg[k].gruende[rj.grund]||0)+1; });
            const agents = Object.values(byAg).sort((a,b)=>b.n-a.n);
            const rows = agents.length ? agents.map(a => agRow(a, a.n, '#E60000',
                `<td style="font-size:10px; color:#BDBDBD;">${Object.entries(a.gruende).sort((x,y)=>y[1]-x[1]).slice(0,6).map(([g,n])=>rcAttr(g)+(n>1?' ×'+n:'')).join(', ')}</td>`
            )).join('') : `<tr><td colspan="3" style="text-align:center; color:#9C9C9C; padding:16px;">Keine Ablehnungen im aktuellen Filter.</td></tr>`;
            rcShowDetail(`<div class="rc-detail-head"><div><h3>Ablehnungen &amp; „nicht moeglich"</h3>
                <div class="rc-detail-sub">${rcAttr(scopeTxt)} · <b style="color:#E60000;">${rejs.length}</b> Faelle · ${agents.length} Agent(en)</div></div></div>
                <table class="rc-detail-table"><thead><tr><th>Agent</th><th style="text-align:center;">Anzahl</th><th>Gruende</th></tr></thead><tbody>${rows}</tbody></table>
                <div class="rc-detail-hint">Klick auf eine Zeile oeffnet das Agenten-Profil. Umfasst abgelehnte Angebote UND „nicht moeglich".</div>`);
            return;
        }
        // Ansprachen / Kontakte / Offene Angebote (aus agentStats)
        const cfgAg = {
            pitches: { t:'Ansprachen',       val:a=>a.ansprachen||0, col:'#FF6666' },
            calls:   { t:'Kontakte',         val:a=>a.kontakte||0,   col:'#F5F5F5' },
            offers:  { t:'Offene Angebote',  val:a=>a.offers||0,     col:'#FF6666' }
        }[kind];
        if (cfgAg) {
            const agents = agentsArr.map(a=>({name:a.name,vo:a.vo,team:a.team,n:cfgAg.val(a)})).filter(a=>a.n>0).sort((a,b)=>b.n-a.n);
            const total = agents.reduce((s2,x)=>s2+x.n,0);
            const rows = agents.length ? agents.map(a => agRow(a, a.n, cfgAg.col, '')).join('')
                : `<tr><td colspan="2" style="text-align:center; color:#9C9C9C; padding:16px;">Nichts im aktuellen Filter.</td></tr>`;
            rcShowDetail(`<div class="rc-detail-head"><div><h3>${rcAttr(cfgAg.t)}</h3>
                <div class="rc-detail-sub">${rcAttr(scopeTxt)} · <b style="color:${cfgAg.col==='#F5F5F5'?'#FFFFFF':cfgAg.col};">${total}</b> gesamt · ${agents.length} Agent(en)</div></div></div>
                <table class="rc-detail-table"><thead><tr><th>Agent</th><th style="text-align:center;">${rcAttr(cfgAg.t)}</th></tr></thead><tbody>${rows}</tbody></table>
                <div class="rc-detail-hint">Klick auf eine Zeile oeffnet das komplette Agenten-Profil.</div>`);
            return;
        }
    };

    // ---------- ZEITRAUM — Bereich waehlen, ESL + Ligaliste SYNCHRON laden ----------
    // "Daten laden" stellt den ESL-Export per echtem UI-Ablauf auf von..bis
    // (rcFetchRangeViaUI, danach automatisch zurueck auf heute) und schickt der
    // Ligaliste das Kommando RC_HARVEST_RANGE (Crawler v3.5 holt user_defined
    // via get_data.rb). Ergebnis: Tages-Tabelle ESL-Vertrieb + Liga-Qualitaet.
    window.rcOpenRange = function(){
        const isoOf = d => d.getFullYear()+'-'+pad2(d.getMonth()+1)+'-'+pad2(d.getDate());
        const heute = new Date(), vor7 = new Date(Date.now() - 7*86400000);
        const stdOpts = ['<option value="ALL">Alle Standorte</option>'].concat(ORDER.map(c => `<option value="${c}">${stdFullName(c)}</option>`)).join('');
        rcShowDetail(`
            <div class="rc-detail-head"><div>
                <h3>Zeitraum — ESL &amp; Ligaliste synchron</h3>
                <div class="rc-detail-sub">Bereich waehlen · "Daten laden" stellt ESL-Export UND Ligaliste automatisch auf den Zeitraum und holt jeden Tag einzeln</div>
            </div></div>
            <div class="rc-cmp-controls" style="flex-wrap:wrap;">
                <label style="font-size:11px; color:#9C9C9C; font-weight:700;">Von <input type="date" id="rcRgFrom" class="rc-select" value="${isoOf(vor7)}" max="${isoOf(heute)}"></label>
                <label style="font-size:11px; color:#9C9C9C; font-weight:700;">Bis <input type="date" id="rcRgTo" class="rc-select" value="${isoOf(heute)}" max="${isoOf(heute)}"></label>
                <select id="rcRgStd" class="rc-select">${stdOpts}</select>
                <button class="rc-btn rc-btn-blue" id="rcRgLoad">Daten laden (ESL + Liga)</button>
                <button class="rc-btn rc-btn-blue" id="rcRgStand" title="Das gewohnte 'Aktueller Stand'-Blatt (Qualitaet + Vertrieb je Agent, mit Ampeln) fuer jeden Tag im Zeitraum als Excel">Stand-Blatt exportieren</button>
                <button class="rc-btn rc-btn-ghost" id="rcRgExport" title="Verlauf/Entwicklung als Excel (Tage + Verursacher + Agent x Tag)">Verlauf exportieren</button>
            </div>
            <div id="rcRgStatus" class="rc-detail-hint" style="margin-top:6px;"></div>
            <div id="rcRgTableWrap" style="margin-top:10px;"></div>
            <div class="rc-detail-chartwrap" style="height:220px; margin-top:12px;"><canvas id="rcDetChRange"></canvas></div>
            <div class="rc-detail-hint"><b>Stand-Blatt exportieren</b> = das gewohnte "Aktueller Stand"-Layout (Qualitaet + Vertrieb je Agent, mit Ampeln) fuer jeden Tag im Zeitraum. <b>Verlauf exportieren</b> = Tages-Entwicklung + Verursacher. BCR-BNT / BCR-VVL = BNT bzw. VVL geteilt durch Liga-Calls des Tages. "—" = kein Snapshot fuer den Tag. Liga-Vortage liefert der KPI-Crawler (Ligaliste ueber den KPI-Button geoeffnet lassen); ESL-Vortage kommen aus "Daten laden (ESL + Liga)".</div>
        `);

        const setStatus = (txt, warn) => { const el = document.getElementById('rcRgStatus'); if (el) { el.textContent = txt; el.style.color = warn ? '#E60000' : ''; } };

        function ligaOfDay(key, std){
            const ligaHist = window.rcLigaHistory || {};
            const tKey = rcTodayKey();
            let snap = ligaHist[key];
            if (!snap && key === tKey && Object.keys(window.rcKpiData||{}).length) {
                const t = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 };
                Object.values(window.rcKpiData).forEach(k => {
                    if (std !== 'ALL' && window.rcLigaMeta(k).std !== std) return;
                    t.calls += k.callCount||0; t.agents++;
                    if (k.cs!=null){ t.csSum+=k.cs; t.csN++; }
                    if (k.tnps!=null){ t.tnpsSum+=k.tnps; t.tnpsN++; }
                    if (k.ahtSec!=null&&k.ahtSec>0){ t.ahtSum+=k.ahtSec; t.ahtN++; }
                });
                return t.agents ? t : null;
            }
            if (!snap) return null;
            if (std === 'ALL') return snap.tot || null;
            const out = { calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0, ahtSum:0, ahtN:0, det:0, agents:0 };
            let hit = false;
            Object.keys(snap.byStd || {}).forEach(name => {
                if (normalizeStandort(name) !== std) return;
                hit = true; const v = snap.byStd[name];
                ['calls','csSum','csN','tnpsSum','tnpsN','ahtSum','ahtN','det','agents'].forEach(f => out[f] += (v[f]||0));
            });
            return hit ? out : null;
        }
        function eslOfDay(key, std){
            const tKey = rcTodayKey();
            const eslHist = window.rcEslHistory || rcLoadEslHistory();
            const src = key === tKey ? (window.rcTodayAgg || eslHist[key]) : eslHist[key];
            if (!src) return null;
            if (std === 'ALL') return { kontakte:src.kontakte||0, ansp:src.ansp||0, bnt:src.bnt||0, vvl:src.vvl||0 };
            const v = src.byStd && src.byStd[std];
            return v ? { kontakte:v.kontakte||0, ansp:v.ansp||0, bnt:v.bnt||0, vvl:v.vvl||0 } : null;
        }

        function renderRangeTable(){
            const wrap = document.getElementById('rcRgTableWrap'); if (!wrap) return;
            const from = document.getElementById('rcRgFrom').value, to = document.getElementById('rcRgTo').value;
            const std = document.getElementById('rcRgStd').value;
            if (!from || !to || from > to) { wrap.innerHTML = '<div class="rc-detail-hint">Bitte gueltigen Bereich waehlen (Von &le; Bis).</div>'; return; }
            const days = [];
            const cur = new Date(from + 'T00:00:00');
            while (isoOf(cur) <= to && days.length < 62) { days.push(isoOf(cur)); cur.setDate(cur.getDate() + 1); }
            const tKey = rcTodayKey();
            const sum = { kontakte:0, ansp:0, bnt:0, vvl:0, calls:0, csSum:0, csN:0, tnpsSum:0, tnpsN:0 };
            const pct = (z, n) => n > 0 ? (z / n * 100).toFixed(1).replace('.', ',') + ' %' : '—';
            const rows = days.map(k => {
                const e = eslOfDay(k, std), l = ligaOfDay(k, std);
                if (e) { sum.kontakte += e.kontakte; sum.ansp += e.ansp; sum.bnt += e.bnt; sum.vvl += e.vvl; }
                if (l) { sum.calls += l.calls||0; sum.csSum += l.csSum||0; sum.csN += l.csN||0; sum.tnpsSum += l.tnpsSum||0; sum.tnpsN += l.tnpsN||0; }
                const cs = (l && l.csN > 0) ? (l.csSum/l.csN).toFixed(1).replace('.',',')+' %' : '—';
                const tn = (l && l.tnpsN > 0) ? (l.tnpsSum/l.tnpsN).toFixed(1).replace('.',',')+' %' : '—';
                return `<tr>
                    <td><b>${k === tKey ? 'Heute (' + k + ')' : k}</b></td>
                    <td style="text-align:center;" class="rc-mono">${e ? e.kontakte : '—'}</td>
                    <td style="text-align:center; color:#FF6666;" class="rc-mono">${e ? e.ansp : '—'}</td>
                    <td style="text-align:center; color:#E60000; font-weight:700;" class="rc-mono">${e ? e.bnt : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${e ? e.vvl : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${l ? (l.calls||0) : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${(e && l && l.calls > 0) ? pct(e.bnt, l.calls) : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${(e && l && l.calls > 0) ? pct(e.vvl, l.calls) : '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${cs}</td>
                    <td style="text-align:center;" class="rc-mono">${tn}</td>
                </tr>`; }).join('');
            const sumCs = sum.csN > 0 ? (sum.csSum/sum.csN).toFixed(1).replace('.',',')+' %' : '—';
            const sumTn = sum.tnpsN > 0 ? (sum.tnpsSum/sum.tnpsN).toFixed(1).replace('.',',')+' %' : '—';
            wrap.innerHTML = `<table class="rc-detail-table">
                <thead><tr><th>Tag</th><th style="text-align:center;">Kontakte</th><th style="text-align:center;">Anspr.</th><th style="text-align:center; color:#FF6666;">BNT</th><th style="text-align:center;">VVL</th><th style="text-align:center;">Liga-Calls</th><th style="text-align:center;">BCR-BNT</th><th style="text-align:center;">BCR-VVL</th><th style="text-align:center;">CS &Oslash;</th><th style="text-align:center;">TNPS &Oslash;</th></tr></thead>
                <tbody>${rows}
                <tr style="border-top:2px solid #E60000; font-weight:700;">
                    <td><b>GESAMT</b></td>
                    <td style="text-align:center;" class="rc-mono">${sum.kontakte}</td>
                    <td style="text-align:center;" class="rc-mono">${sum.ansp}</td>
                    <td style="text-align:center; color:#E60000;" class="rc-mono">${sum.bnt}</td>
                    <td style="text-align:center;" class="rc-mono">${sum.vvl}</td>
                    <td style="text-align:center;" class="rc-mono">${sum.calls || '—'}</td>
                    <td style="text-align:center;" class="rc-mono">${pct(sum.bnt, sum.calls)}</td>
                    <td style="text-align:center;" class="rc-mono">${pct(sum.vvl, sum.calls)}</td>
                    <td style="text-align:center;" class="rc-mono">${sumCs}</td>
                    <td style="text-align:center;" class="rc-mono">${sumTn}</td>
                </tr></tbody></table>`;
            // Chart: BNT/VVL-Balken + Liga-Calls-Linie je Tag
            window._rcDetCharts.filter(c => c.canvas && c.canvas.id === 'rcDetChRange').forEach(c => { try{ c.destroy(); }catch(e){} });
            window._rcDetCharts = window._rcDetCharts.filter(c => !(c.canvas && c.canvas.id === 'rcDetChRange'));
            const dBnt = days.map(k => { const e = eslOfDay(k, std); return e ? e.bnt : null; });
            const dVvl = days.map(k => { const e = eslOfDay(k, std); return e ? e.vvl : null; });
            const dCalls = days.map(k => { const l = ligaOfDay(k, std); return l ? (l.calls||0) : null; });
            rcDetChart('rcDetChRange', { type:'bar',
                data:{ labels: days.map(k => k.slice(8)+'.'+k.slice(5,7)+'.'), datasets:[
                    { label:'BNT', data:dBnt, backgroundColor:'rgba(230,0,0,0.85)', borderRadius:3 },
                    { label:'VVL', data:dVvl, backgroundColor:'rgba(255,255,255,0.55)', borderRadius:3 },
                    { label:'Liga-Calls', data:dCalls, type:'line', borderColor:'#FF6666', backgroundColor:'transparent', tension:0.3, pointRadius:3, spanGaps:true, yAxisID:'y1' } ] },
                options: RC_DET_CHART_OPTS({ scales:{ x:{ grid:{ display:false }, ticks:{ color:'#9C9C9C', font:{ size:9 } } },
                    y:{ grid:{ color:'rgba(255,255,255,0.07)' }, ticks:{ color:'#9C9C9C', font:{ size:9 } }, beginAtZero:true },
                    y1:{ position:'right', grid:{ display:false }, ticks:{ color:'#6E6E6E', font:{ size:8.5 } }, beginAtZero:true } } }) });
        }

        async function rcRangeLoad(){
            if (window.rcRangeBusy) { setStatus('Es laeuft bereits ein Bereichs-Abruf — bitte warten.', true); return; }
            const from = document.getElementById('rcRgFrom').value, to = document.getElementById('rcRgTo').value;
            if (!from || !to || from > to) { setStatus('Bitte gueltigen Bereich waehlen.', true); return; }
            window.rcRangeBusy = true;
            const btn = document.getElementById('rcRgLoad'); if (btn) btn.disabled = true;
            try {
                // 1) Ligaliste: Kommando an den Crawler (Fenster-Handle + BroadcastChannel)
                let ligaSent = false;
                const cmd = { type:'RC_HARVEST_RANGE', from, to };
                try { if (window.rcKpiWin && !window.rcKpiWin.closed) { window.rcKpiWin.postMessage(cmd, '*'); ligaSent = true; } } catch(e){}
                try { rcKpiChannel.postMessage(cmd); } catch(e){}
                window.rcRangeDone = d => {
                    setStatus('Ligaliste: ' + ((d.days||[]).length ? (d.days.length + ' Tag(e) erhalten [' + d.days.join(', ') + ']') : 'keine Tage') + (d.error ? ' — ' + d.error : '') + '. Tabelle aktualisiert.', !!d.error);
                    renderRangeTable();
                };
                setStatus(ligaSent
                    ? 'Ligaliste angefragt (' + from + ' bis ' + to + ')... ESL-Bereichs-Export laeuft — Portal-Tabelle blitzt kurz auf, danach automatisch zurueck auf heute.'
                    : 'HINWEIS: Ligaliste-Fenster nicht verbunden (KPI-Button oben nutzen). ESL-Bereichs-Export laeuft trotzdem...', !ligaSent);
                // 2) ESL: Bereichs-Export ueber den echten UI-Ablauf, danach zurueck auf heute
                if (typeof rcFetchRangeViaUI === 'function' && document.getElementById('filterForm') && window.XLSX) {
                    const ger = s => s.split('-').reverse().join('.');
                    const buf = await rcFetchRangeViaUI(ger(from), ger(to));
                    const perDay = buf ? rcAggregateMultiDayBuffer(buf) : {};
                    const tKey = rcTodayKey();
                    const histX = JSON.parse(localStorage.getItem('rcEslHistory') || '{}');
                    let added = 0;
                    Object.keys(perDay).forEach(k => {
                        if (k < from || k > to) return;
                        if (k === tKey && histX[k] && histX[k].live) return; // Heute-Livestand nicht ueberschreiben
                        if (!histX[k] || (histX[k].kontakte || 0) <= (perDay[k].kontakte || 0)) { histX[k] = perDay[k]; added++; }
                    });
                    Object.keys(histX).sort().slice(0, -40).forEach(k => delete histX[k]);
                    try { localStorage.setItem('rcEslHistory', JSON.stringify(histX)); } catch(e){}
                    window.rcEslHistory = histX;
                    setStatus('ESL: ' + added + ' Tag(e) uebernommen [' + Object.keys(perDay).sort().join(', ') + ']' + (ligaSent ? ' — warte auf Ligaliste...' : ' — Ligaliste nicht verbunden (KPI-Button).'), false);
                    if (window.renderTrendHist) window.renderTrendHist();
                } else {
                    setStatus('ESL-Formular nicht erreichbar (nicht auf der ESL-Portalseite injiziert?)' + (ligaSent ? ' — Liga-Anfrage laeuft.' : ''), true);
                }
            } catch(e){
                setStatus('Fehler beim Bereichs-Abruf: ' + e, true);
            } finally {
                window.rcRangeBusy = false;
                const btn2 = document.getElementById('rcRgLoad'); if (btn2) btn2.disabled = false;
                renderRangeTable();
            }
        }

        document.getElementById('rcRgLoad').addEventListener('click', rcRangeLoad);
        document.getElementById('rcRgStand').addEventListener('click', () => {
            const from = document.getElementById('rcRgFrom').value, to = document.getElementById('rcRgTo').value;
            const std = document.getElementById('rcRgStd').value;
            window.rcExportStandRange(from, to, std);
        });
        document.getElementById('rcRgExport').addEventListener('click', () => {
            const from = document.getElementById('rcRgFrom').value, to = document.getElementById('rcRgTo').value;
            const std = document.getElementById('rcRgStd').value;
            window.rcExportTrend({ std: std, from: from || undefined, to: to || undefined });
        });
        ['rcRgFrom','rcRgTo','rcRgStd'].forEach(id => document.getElementById(id).addEventListener('change', renderRangeTable));
        renderRangeTable(); // zeigt sofort, was bereits in den Historien liegt
    };

    // ---------- Zentrale Klick-Delegation: alles mit data-rc-* oeffnet Details ----------
    function rcHandleDataClick(e){
        if (e.target.closest('a, select, button, input')) return; // Mail-Links, Filter, Tabs etc. nicht abfangen
        const t = e.target.closest('[data-rc-vo],[data-rc-ccs],[data-rc-team],[data-rc-std]');
        if (!t) return false;
        if (t.dataset.rcVo || t.dataset.rcCcs) window.rcOpenAgentDetail({ vo:t.dataset.rcVo, ccs:t.dataset.rcCcs, name:t.dataset.rcName });
        else if (t.dataset.rcTeam) window.rcOpenTeamDetail(t.dataset.rcTeam);
        else if (t.dataset.rcStd) window.rcOpenStandortDetail(t.dataset.rcStd);
        return true;
    }
    overlay.addEventListener('click', rcHandleDataClick);
    detailModal.addEventListener('click', e => {
        if (e.target === detailModal) { rcCloseDetail(); return; }
        rcHandleDataClick(e); // Agenten/Teams IM Modal sind ebenfalls klickbar
    });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && detailModal.style.display === 'flex') rcCloseDetail(); });

    // ============================================================
    //  SESSION-KEEP-ALIVE — verhindert den PrimeFaces-idleMonitor-Logout
    //  ------------------------------------------------------------
    //  Das ESL-Portal hat <p:idleMonitor timeout=14400000> (= 4 h). Auf einem
    //  unbeaufsichtigten Wandmonitor (nie jemand an Maus/Tastatur) feuert er
    //  nach 4 h Inaktivitaet -> viewExpiredDialog ("Ihr Sitzung wurde wegen
    //  Inaktivitaet beendet") -> Anmeldeseite. WICHTIG: Hintergrund-fetch/XHR
    //  (der 20-s-Live-Poll) setzt den Monitor NICHT zurueck — er lauscht nur auf
    //  ECHTE DOM-User-Events (mousemove/keydown/...). Das Portal haelt per
    //  globalPoll (5 min) die SERVER-Session warm; es ist also rein der CLIENT-
    //  seitige Monitor, der abmeldet. Gegenmassnahme:
    //   1) rcKeepAliveTick: alle rcKeepAliveSec synthetische User-Aktivitaet auf
    //      document feuern + das PF-IdleMonitor-Widget resetten (belt & suspenders,
    //      versionsunabhaengig) -> die 4 h laufen nie voll.
    //   2) rcSessionWatchTick: erkennt einen sichtbaren viewExpiredDialog (echter
    //      Session-Tod) -> Banner + Poller stoppen; ajaxTimeoutDialog ("keine
    //      Antwort vom Server") nur wegklicken (KEIN Reload — der wuerde das per
    //      F12 injizierte Script wegwerfen).
    //  Debug:  window.rcSessionState  ·  rcKeepAliveTick()  ·  rcSessionWatchTick()
    // ============================================================
    window.rcKeepAliveSec = window.rcKeepAliveSec || 120;   // alle 2 min "Leben" simulieren (idle-timeout = 4 h -> massig Reserve)
    // Frischer Zustand bei jedem (Re-)Inject: ein Re-Inject erfolgt i.d.R. nach
    // erneutem Login, also gilt die Session wieder als lebendig.
    window.rcSessionState = { alive:true, lastAlive:null, lostAt:null, lostReason:null, lastReset:null };

    function rcNowStamp(){ const d = new Date(); return pad2(d.getHours())+':'+pad2(d.getMinutes())+':'+pad2(d.getSeconds()); }

    // Einmaliger, idempotenter "Session ist tot"-Handler: Banner + Poller stoppen.
    function rcSessionLost(reason){
        if (!window.rcSessionState.alive) return;          // schon gemeldet
        window.rcSessionState.alive = false;
        window.rcSessionState.lostAt = rcNowStamp();
        window.rcSessionState.lostReason = reason || 'unbekannt';
        rcLog.error('=== ESL-SESSION VERLOREN um ' + window.rcSessionState.lostAt + ' — Grund: ' + window.rcSessionState.lostReason + ' ===');
        try { showWarn('ESL-Sitzung abgelaufen (' + window.rcSessionState.lostReason + ', ' + window.rcSessionState.lostAt + ') — bitte im Portal neu anmelden und das Dashboard-Script (F12) neu einfuegen. Live-Abruf pausiert.'); } catch(e){}
        if (window.rcLiveInterval) { clearInterval(window.rcLiveInterval); window.rcLiveInterval = null; }  // kein Haemmern gegen die Login-Seite
    }
    window.rcSessionLost = rcSessionLost;

    // 1) idleMonitor bei Laune halten
    //    WICHTIG (Bugfix): der PF-IdleMonitor sitzt auf dem jQuery-"idleTimer"-Plugin,
    //    das an document gebunden ist. Der eigentliche Reset MUSS ueber dieses Plugin
    //    bzw. die pause()/resume()-Signatur des Widgets laufen. Die alte Version hat das
    //    Widget ueber /idlemonitor/i.test(cfg.id) gesucht -> cfg.id ist aber die JSF-
    //    Client-ID (z. B. "j_idt5"), NICHT der Widget-Typ -> traf nie zu -> der 4-h-Idle-
    //    Zaehler lief trotz "Aktivitaet" durch und das Portal sprang auf die Login-Seite.
    function rcJq(){
        return window.jQuery || window.$ || (window.PrimeFaces && PrimeFaces.$) || null;
    }
    function rcKeepAliveTick(){
        if (!window.rcSessionState.alive) return;
        var didReset = false;
        try {
            // a) DIREKTER Reset des jQuery-idleTimer (das nutzt PF IdleMonitor intern).
            //    Wird an document, document.body und window versucht (je nach PF-Version
            //    ist das Plugin an eines davon gebunden).
            var jq = rcJq();
            if (jq && typeof jq.fn === 'object' && jq.fn.idleTimer) {
                [document, document.body, window].forEach(function(el){
                    try { jq(el).idleTimer('reset'); didReset = true; } catch(e){}
                });
            }
            // b) PF-IdleMonitor-Widget ueber seine SIGNATUR erkennen (nicht ueber die id):
            //    ein IdleMonitor hat cfg.timeout UND pause()+resume(). pause()+resume()
            //    re-armt den idleTimer sauber (= Reset). Poll-Widgets haben start/stop
            //    statt pause/resume und werden so nicht faelschlich getriggert.
            if (window.PrimeFaces && PrimeFaces.widgets) {
                Object.keys(PrimeFaces.widgets).forEach(function(k){
                    var w = PrimeFaces.widgets[k];
                    if (!w || !w.cfg) return;
                    var isIdle = ('timeout' in w.cfg) && typeof w.pause === 'function' && typeof w.resume === 'function';
                    if (!isIdle) return;
                    try {
                        if (typeof w.reset === 'function') { w.reset(); }
                        else { w.pause(); w.resume(); }
                        didReset = true;
                    } catch(e){}
                });
            }
            // c) synthetische User-Aktivitaet als Zusatz (falls das Plugin doch an einem
            //    anderen Element haengt und auf echte Events lauscht). keydown ohne key ->
            //    loest keinen Escape-/Shortcut-Handler aus (no-op).
            ['mousemove','mousedown','keydown'].forEach(function(type){
                var ev;
                try { ev = new Event(type, { bubbles:true }); }
                catch(e){ ev = document.createEvent('Event'); ev.initEvent(type, true, true); }
                try { document.dispatchEvent(ev); } catch(e){}
            });
            window.rcSessionState.lastAlive = rcNowStamp();
            window.rcSessionState.lastReset = didReset;   // Diagnose: hat ein echter Timer-Reset gegriffen?
        } catch(e){}
    }
    window.rcKeepAliveTick = rcKeepAliveTick;

    // 2) Timeout-/ViewExpired-Dialoge beobachten
    function rcDlgVisible(widgetVar){
        try { var w = (window.PF && PF(widgetVar)); return !!(w && w.jq && w.jq.is(':visible')); }
        catch(e){ return false; }
    }
    function rcSessionWatchTick(){
        try {
            // "keine Antwort vom Server" -> nur wegklicken, KEIN Reload (haelt das Script am Leben)
            if (rcDlgVisible('ajaxTimeoutDialog')) {
                try { PF('ajaxTimeoutDialog').hide(); } catch(e){}
                rcLog.warn('ESL: ajaxTimeoutDialog ("keine Antwort vom Server") um ' + rcNowStamp() + ' weggeklickt.');
            }
            // echter Session-Tod
            if (rcDlgVisible('viewExpiredDialog')) rcSessionLost('viewExpiredDialog sichtbar (idleMonitor/Server)');
        } catch(e){}
    }
    window.rcSessionWatchTick = rcSessionWatchTick;

    // ============================================================
    //  BOOT
    // ============================================================
    rcLog.log('Lade externe Bibliotheken...');
    // Helden-Ruf: rotiert alle 11 s durch alle Mitarbeiter (nur auf der Radar-Seite aktiv)
    window.rcHeroInterval = setInterval(function(){ try { window.rcHeroCallTick(); } catch(e){} }, 11000);
    // Low-Performer-Modul: wechselt alle 30 s zwischen Agenten- und Teambasis
    window.rcLowPerfInterval = setInterval(function(){
        try {
            window.rcLowPerfMode = window.rcLowPerfMode ? 0 : 1;
            if (window.rcActivePage === 'radar' && window.renderLowPerformer) window.renderLowPerformer();
        } catch(e){}
    }, 30000);
    // Frontlage/Kriegsrat-HP alle 5 s aus RC_WAR.bases nachziehen — damit die
    // DOM-Panels nie im Widerspruch zum Live-Canvas stehen (leicht, nur Text).
    window.rcWarHudInterval = setInterval(function(){
        try {
            if (window.rcActivePage !== 'radar' || window.rcRadarMode === 'league') return;
            if (window.renderRadarMission) window.renderRadarMission();
            if (window.rcWarUpdateConquestGoal) window.rcWarUpdateConquestGoal();
        } catch(e){}
    }, 5000);
    // Session-Keep-Alive: idleMonitor wach halten (verhindert 4-h-Idle-Logout) +
    // Session-Tod erkennen. Laeuft unabhaengig vom Bibliotheks-Load sofort los.
    window.rcKeepAliveInterval = setInterval(rcKeepAliveTick, window.rcKeepAliveSec * 1000);
    rcKeepAliveTick();                                              // sofort einmal "Leben" zeigen
    window.rcSessionWatchInterval = setInterval(rcSessionWatchTick, 5000);
    Promise.all([
        ladeBibliothek('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', 'XLSX'),
        ladeBibliothek('https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js', 'confetti'),
        ladeBibliothek('https://cdn.jsdelivr.net/npm/chart.js', 'Chart')
    ]).then(() => {
        rcLog.log('Bibliotheken bereit. Starte Live-Crawl (20s)...');
        rcAutoMapping();          // Mitarbeiter-Excel ohne Datei-Dialog uebernehmen
        window.rcLiveInterval = setInterval(holeExcelVomServer, 20000);
        holeExcelVomServer();
        // Tageshistorie: 20 s nach Start fehlende Vortage nachladen, danach alle 4 h pruefen
        setTimeout(rcHarvestEslHistory, 20000);
        window.rcHistInterval = setInterval(rcHarvestEslHistory, 4*3600*1000);
        rcAutoKpiQuelle();        // Ligaliste selbst oeffnen (Crawler braucht unseren opener)
    }).catch(err => {
        rcLog.error('Fehler beim Start:', err);
        window.rcLiveInterval = setInterval(holeExcelVomServer, 20000);
        holeExcelVomServer();
    });

    // ============================================================
    //  CROCO — Auftrags-Backend (offene/stornierte Auftraege) + ESL-Abgleich
    //  ------------------------------------------------------------
    //  Datenquelle: Croco.xls (Drag&Drop auf den "Croco"-Button) ODER der
    //  Satellit croco_crawler.js (Ligaliste-Report "CrocoXLS"), der die
    //  Auftrags-Tabelle scrapt und via BroadcastChannel/postMessage
    //  { type:'CROCO_BATCH', rows:[[header...],[...]] | orders:[{...}] } sendet.
    //  Der Parser ist HEADER-GETRIEBEN und tolerant gegen verschiedene
    //  Spaltennamen (konfigurierbar). Offene Auftraege > 7 Tage = ueberfaellig.
    //  Storno wird gegen die heutigen ESL-Verkaeufe (rcAllSales) abgeglichen:
    //  "im ESL gebucht, in Croco storniert" ist der kritische Widerspruch.
    //  Konsole: rcCrocoStats · rcCrocoView() · rcCrocoOrders · rcCrocoDebug()
    //           rcCrocoOpenImport() · rcCrocoReset() · rcCrocoCfg
    // ============================================================
    (function rcCrocoModule(){
        var DATK = 'rcCrocoData_v1', CFGK = 'rcCrocoCfg_v1';
        function p2(n){ return (n<10?'0':'')+n; }
        function el(id){ return document.getElementById(id); }
        function esc(s){ return String(s==null?'':s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];}); }
        function num1(n){ n=Number(n)||0; return (Math.round(n*10)/10).toString().replace('.',','); }
        function normK(s){ return (s||'').toString().toLowerCase().replace(/[.,\-_/]/g,' ').replace(/\s+/g,' ').trim(); }

        // ---- Spalten-Kandidaten (fuzzy, deutsch) — per rcCrocoCfg.columns ueberschreibbar
        // ---- Spalten des ECHTEN CroCo Sales Operation Report (v3.15) ----
        // Kopfzeile laut Portal:
        //   Standort | Team | Main SF ID | CCS: User | MAV: User | VOID | NBA Tipp |
        //   Order Source | Order ID | Dat: Angebot | Dat: Auftrag | Dat: Brutto |
        //   Dat: Aktivierung | Dat: Storno | Produkt | OSF CS ID | OSF Order ID |
        //   VVL Bewertung | MSISDN | Workorder | Kundennummer | Weborder |
        //   OSF Status | Hardware | Stornotyp
        // WICHTIG: CroCo hat KEINE "offen/storniert"-Spalte — der Zustand steckt in
        // den DATUMS-Spalten (siehe classifyOrder). Aeltere/andere Exporte mit
        // klassischen Spaltennamen werden weiterhin unterstuetzt (Fallback-Namen).
        var COL_DEFS = {
            auftrag:  ['order id','osf order id','auftragsnummer','auftrags-nr','auftragsnr','auftrag','vorgangsnummer','ordernummer','bestellnummer','belegnummer'],
            vo:       ['void','vo_nummer','vo-nummer','vonummer','vo_id','vo'],
            agentId:  ['ccs: user','ccs user','ccs-id','ccsid','mav: user','mav user','user_id','personalnummer'],
            // ACHTUNG: Der echte CroCo-Report hat KEINE Namensspalte — nur IDs
            // (CCS: User, VOID, Main SF ID). Der Agentenname wird deshalb ueber das
            // Mitarbeiter-Mapping aufgeloest (siehe resolveGeo). "Main SF ID" hier
            // bewusst NICHT als Name fuehren, sonst stuenden IDs statt Namen im Bild.
            agent:    ['agentenname','agent','verkaeufer','mitarbeiter','berater','bearbeiter'],
            sfId:     ['main sf id','sf id'],
            standort: ['standort','location','niederlassung','filiale'],
            team:     ['team','teamname','gruppe'],
            produkt:  ['produkt','produktname','tarif','artikel','leistung','paket','hardware'],
            kunde:    ['kundennummer','kundenname','kunde','endkunde','customer'],
            // Datums-Spalten = der eigentliche Statusgeber
            datAngebot: ['dat: angebot','dat angebot','angebotsdatum'],
            datAuftrag: ['dat: auftrag','dat auftrag','auftragsdatum','bestelldatum','eingangsdatum','erstelldatum','anlagedatum','datum'],
            datBrutto:  ['dat: brutto','dat brutto','bruttodatum'],
            datAktiv:   ['dat: aktivierung','dat aktivierung','aktivierungsdatum','aktivierung'],
            datStorno:  ['dat: storno','dat storno','stornodatum'],
            stornotyp:  ['stornotyp','storno-typ','stornogrund','storno-grund','stornierungsgrund'],
            status:     ['osf status','auftragsstatus','vorgangsstatus','bearbeitungsstatus','status'],
            osfStatus:  ['osf status'],
            vvlBew:     ['vvl bewertung','vvl-bewertung']
        };
        var STORNO_RE = /storn|abgelehnt|abgebroch|widerruf|r[uü]ck|annull|cancel|zur[uü]ckgezogen|entfall|abbruch/i;
        var DONE_RE   = /aktiv|geschaltet|erledigt|abgeschloss|fertig|installiert|bereitgestellt|realisiert|provisioniert|freigeschaltet|versorgt|abgerechnet|complete|done|gebucht|geliefert/i;

        // ---- Konfiguration (persistent) ----
        function loadCfg(){ var c={}; try{ c=JSON.parse(localStorage.getItem(CFGK)||'{}')||{}; }catch(e){}
            c.columns = c.columns || {};           // { canonical: 'exakter Headername' } — Override
            if (c.overdueDays == null) c.overdueDays = 7;
            if (c.stornoRadar == null) c.stornoRadar = true;
            return c; }
        var CFG = window.rcCrocoCfg = loadCfg();
        function saveCfg(){ try{ localStorage.setItem(CFGK, JSON.stringify(CFG)); }catch(e){} }

        // ---- Datum robust nach ISO (DD.MM.YYYY / YYYY-MM-DD / Excel-Serial) ----
        function toIso(v){
            if (v==null || v==='') return '';
            if (typeof v === 'number' && isFinite(v)){ var ep=Date.UTC(1899,11,30); var d=new Date(ep+v*86400000); return d.getUTCFullYear()+'-'+p2(d.getUTCMonth()+1)+'-'+p2(d.getUTCDate()); }
            var t=String(v).trim(); var m;
            m=t.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/); if(m) return m[1]+'-'+p2(+m[2])+'-'+p2(+m[3]);
            m=t.match(/(\d{1,2})[.\/-](\d{1,2})[.\/-](\d{2,4})/); if(m){ var y=m[3].length===2?('20'+m[3]):m[3]; return y+'-'+p2(+m[2])+'-'+p2(+m[1]); }
            var d2=new Date(t); if(!isNaN(d2.getTime())) return d2.getFullYear()+'-'+p2(d2.getMonth()+1)+'-'+p2(d2.getDate());
            return '';
        }
        function ageDaysOf(iso){ if(!iso) return null; var d=new Date(iso+'T00:00:00'); if(isNaN(d.getTime())) return null; var t=new Date(); t.setHours(0,0,0,0); return Math.max(0, Math.round((t.getTime()-d.getTime())/86400000)); }
        // Reine Text-Klassifikation (Fallback fuer Exporte MIT Status-Spalte)
        function classifyStatus(s){ var t=(s||'').toString(); if(STORNO_RE.test(t)) return 'storno'; if(DONE_RE.test(t)) return 'erledigt'; return 'offen'; }
        // ECHTE CroCo-Logik: der Zustand steht in den Datums-Spalten, nicht im Text.
        //   Dat: Storno gesetzt      -> storno   (Stornotyp bestaetigt es zusaetzlich)
        //   Dat: Aktivierung gesetzt -> erledigt (Auftrag ist durch)
        //   sonst                    -> offen    (laeuft noch = Nachfass-Kandidat)
        function classifyOrder(o){
            if (o.datStorno || /storn|widerruf|annull|cancel/i.test(o.stornotyp||'')) return 'storno';
            if (o.datAktiv) return 'erledigt';
            if (o.status){                                   // Fallback, falls Daten fehlen
                if (STORNO_RE.test(o.status)) return 'storno';
                if (DONE_RE.test(o.status))   return 'erledigt';
            }
            return 'offen';
        }
        // "Offen seit": Auftragsdatum, sonst Brutto-, sonst Angebotsdatum
        function baseDate(o){ return o.datAuftrag || o.datBrutto || o.datAngebot || ''; }

        // ---- Header-Zeile finden + Spalten-Index-Map bauen ----
        function matchCol(headerCells, canonical){
            var override = CFG.columns[canonical];
            var lc = headerCells.map(function(x){ return (x==null?'':String(x)).toLowerCase().trim(); });
            if (override){ var oi = lc.indexOf(String(override).toLowerCase().trim()); if(oi>=0) return oi; }
            var cands = COL_DEFS[canonical] || [];
            for (var c=0;c<cands.length;c++){ var i=lc.indexOf(cands[c]); if(i>=0) return i; }
            // Teil-Treffer (enthaelt) — NUR fuer aussagekraeftige Namen (>=5 Zeichen).
            // Sonst wuerde z.B. "vo" in "Weborder"/"Vodafone" treffen und die Spalten
            // wild verschieben. Exakte Treffer laufen deshalb IMMER zuerst.
            for (var c2=0;c2<cands.length;c2++){
                if (cands[c2].length < 5) continue;
                for(var j=0;j<lc.length;j++){ if(lc[j] && lc[j].indexOf(cands[c2])>=0) return j; }
            }
            return -1;
        }
        function findHeaderRow(rows){
            var best=-1, bestScore=1;
            for (var r=0; r<Math.min(rows.length, 12); r++){
                var row=rows[r]; if(!row||!row.length) continue;
                var cells=row.map(function(x){ return (x==null?'':String(x)).toLowerCase().trim(); });
                var score=0;
                Object.keys(COL_DEFS).forEach(function(k){ var cands=COL_DEFS[k]; for(var c=0;c<cands.length;c++){ if(cells.indexOf(cands[c])>=0){ score++; break; } } });
                if(score>bestScore){ bestScore=score; best=r; }
            }
            return best;
        }

        // ---- Rohzeilen (2D) -> normalisierte Auftraege ----
        function parseRows(rows){
            if(!rows || !rows.length) return { orders:[], header:null, detected:{} };
            var hr = findHeaderRow(rows);
            if(hr<0) return { orders:[], header:null, detected:{} };
            var header = rows[hr];
            var mapIdx={}, detected={};
            Object.keys(COL_DEFS).forEach(function(k){ var i=matchCol(header, k); mapIdx[k]=i; if(i>=0) detected[k]=String(header[i]); });
            var orders=[];
            for (var r=hr+1; r<rows.length; r++){
                var row=rows[r]; if(!row) continue;
                var get=function(k){ var i=mapIdx[k]; return (i>=0 && row[i]!=null) ? String(row[i]).trim() : ''; };
                var auftrag=get('auftrag'), vo=get('vo'), kunde=get('kunde'), agent=get('agent'), agentId=get('agentId');
                if(!auftrag && !vo && !kunde && !agent && !agentId) continue;   // Leerzeile
                orders.push(makeOrder({ auftrag:auftrag, vo:vo, status:get('status'),
                    datAngebot:get('datAngebot'), datAuftrag:get('datAuftrag'), datBrutto:get('datBrutto'),
                    datAktiv:get('datAktiv'), datStorno:get('datStorno'), stornotyp:get('stornotyp'),
                    kunde:kunde, produkt:get('produkt'), agent:agent, agentId:agentId,
                    standort:get('standort'), team:get('team') }));
            }
            return { orders:orders, header:header, detected:detected };
        }

        // ---- Objekt (Crawler) -> normalisierter Auftrag (Keys bereits kanonisch ODER fuzzy) ----
        function orderFromObject(o){
            if(!o || typeof o!=='object') return null;
            var lk={}; Object.keys(o).forEach(function(k){ lk[k.toLowerCase().trim()]=o[k]; });
            var pick=function(canon){ if(o[canon]!=null && o[canon]!=='') return o[canon]; var cands=COL_DEFS[canon]||[]; for(var c=0;c<cands.length;c++){ if(lk[cands[c]]!=null && lk[cands[c]]!=='') return lk[cands[c]]; } return ''; };
            return makeOrder({ auftrag:pick('auftrag'), vo:pick('vo'), status:pick('status'),
                datAngebot:pick('datAngebot'), datAuftrag:pick('datAuftrag'), datBrutto:pick('datBrutto'),
                datAktiv:pick('datAktiv'), datStorno:pick('datStorno'), stornotyp:pick('stornotyp'),
                kunde:pick('kunde'), produkt:pick('produkt'), agent:pick('agent'), agentId:pick('agentId'),
                standort:pick('standort'), team:pick('team') });
        }

        function makeOrder(o){
            var s = function(x){ return (x==null?'':String(x)).trim(); };
            var ord={ auftrag:s(o.auftrag), vo:s(o.vo), status:s(o.status),
                datAngebot:toIso(o.datAngebot), datAuftrag:toIso(o.datAuftrag), datBrutto:toIso(o.datBrutto),
                datAktiv:toIso(o.datAktiv),     datStorno:toIso(o.datStorno),   stornotyp:s(o.stornotyp),
                kunde:s(o.kunde), produkt:s(o.produkt), agent:s(o.agent), agentId:s(o.agentId),
                standort:'', team:'', stack:'' };
            // Altdaten/andere Exporte: einzelnes "datum"-Feld weiterhin akzeptieren
            if(!ord.datAuftrag && o.datum) ord.datAuftrag = toIso(o.datum);
            ord.bucket   = classifyOrder(ord);
            ord.datum    = baseDate(ord);                 // "offen seit" (Anzeige + Alter)
            ord.ageDays  = ageDaysOf(ord.datum);
            ord.stornogrund = ord.stornotyp;              // Abwaertskompatibel fuer die Anzeige
            resolveGeo(ord, o.standort, o.team);
            return ord;
        }
        function resolveGeo(ord, stdRaw, teamRaw){
            var map=window.rcWcaMapping||{};
            var std = stdRaw ? normalizeStandort(stdRaw) : '';
            var team = (teamRaw||'').toString().trim();
            var mm = (ord.vo && map.voMap && map.voMap[ord.vo]) || (ord.agentId && map.ccsMap && map.ccsMap[ord.agentId]);
            if(mm){ if(!std && mm.standort) std=normalizeStandort(mm.standort); if(!team && mm.team) team=mm.team; if(!ord.agent && mm.name) ord.agent=mm.name; if(!ord.agentId && mm.ccsId) ord.agentId=mm.ccsId; }
            ord.standort = (std && STANDORT_METADATA[std]) ? std : (std||'ALL');
            ord.team = team;
            ord.stack = (team && map.stackMap) ? (map.stackMap[team]||'') : '';
        }

        // ---- Scope-Filter (Standort + Team + Stack) — wie rcLigaAgg ----
        function scopeFilter(orders){
            var fv=(el('rcStandortFilter')||{}).value||'ALL';
            var tSel=el('rcTeamFilter'); var ft=(fv!=='ALL'&&tSel)?(tSel.value||'ALL'):'ALL';
            var sSel=el('rcStackFilter'); var fs=sSel?(sSel.value||'ALL'):'ALL';
            if(fv==='ALL'&&ft==='ALL'&&fs==='ALL') return orders;
            return orders.filter(function(o){
                if(fv!=='ALL' && o.standort!==fv) return false;
                if(ft!=='ALL' && o.team!==ft) return false;
                if(fs!=='ALL' && (o.stack||'')!==fs) return false;
                return true;
            });
        }

        // ---- ESL-Abgleich: Storno trotz heutigem ESL-Verkauf ----
        function reconcile(orders){
            var sales=window.rcAllSales||[];
            var out={ stornoTrotzEsl:[] };
            if(!sales.length) return out;
            var byKunde={}, byAgent={};
            sales.forEach(function(s){
                if(s.kunde){ var kk=normK(s.kunde); (byKunde[kk]||(byKunde[kk]=[])).push(s); }
                var an=window.rcNormName?window.rcNormName(s.name):normK(s.name); (byAgent[an]||(byAgent[an]=[])).push(s);
            });
            var seen={};
            orders.forEach(function(o){
                if(o.bucket!=='storno') return;
                var hit=null;
                if(o.kunde){ var arr=byKunde[normK(o.kunde)]; if(arr && arr.length) hit=arr[0]; }
                if(!hit && o.agent){ var an=window.rcNormName?window.rcNormName(o.agent):normK(o.agent); var arr2=byAgent[an];
                    if(arr2 && arr2.length){ // nur werten, wenn Standort passt und (Produktfamilie grob passt ODER kein Produkt bekannt)
                        hit=arr2.find(function(s){ return (!o.standort||o.standort==='ALL'||s.standort===o.standort); }) || null; } }
                if(hit){ var key=(o.auftrag||o.vo||'')+'|'+normK(o.kunde||o.agent); if(seen[key]) return; seen[key]=1;
                    out.stornoTrotzEsl.push({ auftrag:o.auftrag, vo:hit.vo||o.vo, agent:o.agent||hit.name, standort:o.standort||hit.standort, produkt:o.produkt||hit.prod, kunde:o.kunde, datum:o.datum }); }
            });
            return out;
        }

        // ---- Kennzahlen berechnen ----
        function computeStats(orders){
            var st={ ready:true, total:orders.length, offen:0, storno:0, erledigt:0, ueberfaellig:0,
                stornoquote:0, byStd:{}, byTeam:{}, byAgent:[], overdue:[], stornoList:[], recon:null,
                lastUpdate: window.rcCrocoMeta && window.rcCrocoMeta.lastUpdate };
            var over=CFG.overdueDays||7, agentMap={};
            orders.forEach(function(o){
                var b=o.bucket; if(b==='offen') st.offen++; else if(b==='storno') st.storno++; else if(b==='erledigt') st.erledigt++;
                var isOver = b==='offen' && o.ageDays!=null && o.ageDays>over;
                if(isOver) st.ueberfaellig++;
                var sc=o.standort||'ALL'; var s=st.byStd[sc]||(st.byStd[sc]={offen:0,storno:0,erledigt:0,ueberfaellig:0,total:0}); s.total++; s[b]=(s[b]||0)+1; if(isOver) s.ueberfaellig++;
                if(o.team){ var t=st.byTeam[o.team]||(st.byTeam[o.team]={offen:0,storno:0,erledigt:0,ueberfaellig:0,total:0}); t.total++; t[b]=(t[b]||0)+1; if(isOver) t.ueberfaellig++; }
                var ak=o.agent||o.vo||o.agentId||'?'; var a=agentMap[ak]||(agentMap[ak]={agent:o.agent||ak,standort:o.standort,team:o.team,offen:0,storno:0,erledigt:0,ueberfaellig:0,total:0}); a.total++; a[b]=(a[b]||0)+1; if(isOver) a.ueberfaellig++;
                if(isOver) st.overdue.push(o);
                if(b==='storno') st.stornoList.push(o);
            });
            st.stornoquote = (st.storno+st.erledigt)>0 ? (st.storno/(st.storno+st.erledigt)*100) : (st.total>0 ? st.storno/st.total*100 : 0);
            st.overdue.sort(function(a,b){ return (b.ageDays||0)-(a.ageDays||0); });
            st.stornoList.sort(function(a,b){ return (b.datum||'').localeCompare(a.datum||''); });
            st.byAgent = Object.keys(agentMap).map(function(k){ return agentMap[k]; }).sort(function(a,b){ return b.ueberfaellig-a.ueberfaellig || b.offen-a.offen; });
            st.recon = reconcile(orders);
            return st;
        }

        // ---- State ----
        window.rcCrocoOrders = [];
        window.rcCrocoStats = { ready:false };
        window.rcCrocoMeta = null;
        window.rcCrocoTok = 0;        // Aenderungs-Token fuer die Modul-Selbstheilung
        window.rcCrocoView = function(){ try { return computeStats(scopeFilter(window.rcCrocoOrders)); } catch(e){ return { ready:false }; } };

        function persist(){ try { var slim=window.rcCrocoOrders.slice(0,4000); localStorage.setItem(DATK, JSON.stringify({ orders:slim, meta:window.rcCrocoMeta })); } catch(e){} }
        function restore(){ try { var raw=JSON.parse(localStorage.getItem(DATK)||'null'); if(raw && raw.orders){ // ageDays neu berechnen (Tag kann sich geaendert haben)
            window.rcCrocoOrders=raw.orders.map(function(o){ o.ageDays=ageDaysOf(o.datum); o.bucket=o.bucket||classifyStatus(o.status); return o; }); window.rcCrocoMeta=raw.meta||null; recompute(false); } }catch(e){} }

        function recompute(refreshUi){
            window.rcCrocoStats = computeStats(window.rcCrocoOrders);
            window.rcCrocoTok++;
            if(refreshUi!==false) renderCrocoPage();
        }

        // ---- Daten uebernehmen (aus Import ODER Crawler) ----
        function setOrders(orders, meta){
            var prevStorno = stornoKeySet(window.rcCrocoOrders);
            orders.forEach(function(o){ resolveGeo(o, o.standort, o.team); });   // Mapping ggf. spaeter geladen
            window.rcCrocoOrders = orders;
            window.rcCrocoMeta = Object.assign({ lastUpdate:new Date().toISOString(), count:orders.length }, meta||{});
            persist(); recompute();
            // neue Stornos gegen ESL abgleichen -> Radar/Toast
            try {
                var newStorno = orders.filter(function(o){ return o.bucket==='storno' && !prevStorno[stornoKey(o)]; });
                if(newStorno.length && window.rcCrocoStats.recon){
                    var hitKeys={}; window.rcCrocoStats.recon.stornoTrotzEsl.forEach(function(h){ hitKeys[(h.auftrag||h.vo||'')+'|'+normK(h.kunde||h.agent)]=h; });
                    newStorno.forEach(function(o){ var k=(o.auftrag||o.vo||'')+'|'+normK(o.kunde||o.agent); if(hitKeys[k]) onNewStornoConflict(hitKeys[k]); });
                }
            } catch(e){}
            if(window.renderMarquee) try { window.renderMarquee(); } catch(e){}
            rcLog.log('[Croco] '+orders.length+' Auftraege uebernommen · offen '+window.rcCrocoStats.offen+' · ueberfaellig '+window.rcCrocoStats.ueberfaellig+' · storno '+window.rcCrocoStats.storno+(window.rcCrocoMeta.source?' · Quelle '+window.rcCrocoMeta.source:''));
        }
        function stornoKey(o){ return (o.auftrag||o.vo||'')+'|'+normK(o.kunde||o.agent||''); }
        function stornoKeySet(list){ var s={}; (list||[]).forEach(function(o){ if(o.bucket==='storno') s[stornoKey(o)]=1; }); return s; }

        window.rcCrocoIngest = function(payload){
            try {
                if(!payload) return;
                var orders=null, meta={ source: payload.source||'nachricht' };
                if(Array.isArray(payload.rows)) { var pr=parseRows(payload.rows); orders=pr.orders; meta.detected=pr.detected; }
                else if(Array.isArray(payload.orders)) orders=payload.orders.map(orderFromObject).filter(Boolean);
                if(orders) setOrders(orders, meta);
                else rcLog.warn('[Croco] Nachricht ohne verwertbare rows/orders.');
            } catch(e){ rcLog.error('[Croco] Ingest-Fehler:', e); }
        };

        // ---- Empfaenger: BroadcastChannel (same-origin) + postMessage (cross-origin) ----
        try { var ch=new BroadcastChannel('regiocom_live_arena'); ch.onmessage=function(ev){ var d=ev.data; if(d && (d.type==='CROCO_BATCH'||d.type==='CROCO_UPDATE')) window.rcCrocoIngest(d); }; } catch(e){}
        window.addEventListener('message', function(ev){ var d=ev.data; if(d && (d.type==='CROCO_BATCH'||d.type==='CROCO_UPDATE')) window.rcCrocoIngest(d); });

        // ---- Storno-Konflikt: leichter Alarm (Toast) + Seam fuer RC_WAR ----
        function onNewStornoConflict(h){
            try { if(window.rcCfg && window.rcCrocoCfg && window.rcCrocoCfg.stornoRadar===false) return; } catch(e){}
            try { if(typeof window.rcWarStorno==='function'){ window.rcWarStorno(h); } } catch(e){}
            crocoToast('STORNO trotz ESL-Verkauf: '+(h.agent||'?')+' ('+(h.standort||'')+')'+(h.produkt?' — '+h.produkt:''));
        }
        function crocoToast(msg){
            var host=el('rcCrocoToasts'); if(!host){ host=document.createElement('div'); host.id='rcCrocoToasts'; host.style.cssText='position:fixed;right:16px;bottom:16px;z-index:2147483200;display:flex;flex-direction:column;gap:8px;pointer-events:none;'; document.body.appendChild(host); }
            var t=document.createElement('div'); t.style.cssText='background:#1D1D1D;color:#F5F5F5;border-left:4px solid #E60000;border-radius:8px;padding:10px 14px;font:700 12.5px/1.4 -apple-system,Segoe UI,Arial,sans-serif;box-shadow:0 8px 24px rgba(0,0,0,.5);max-width:340px;opacity:0;transform:translateY(8px);transition:.25s;';
            t.innerHTML='&#9650; '+esc(msg); host.appendChild(t); requestAnimationFrame(function(){ t.style.opacity='1'; t.style.transform='none'; });
            setTimeout(function(){ t.style.opacity='0'; t.style.transform='translateY(8px)'; setTimeout(function(){ t.remove(); }, 300); }, 8000);
        }

        // ============================================================
        //  UI — dedizierte "Croco"-Seite (Reiter) + Import-Button/Modal
        // ============================================================
        var STYLE_ID='rcCrocoStyle';
        if(!el(STYLE_ID)){ var st=document.createElement('style'); st.id=STYLE_ID; st.textContent=
            '#rcPageCrocoContent{padding:14px 16px;gap:12px;grid-template-columns:1fr;align-content:start;overflow:auto;}'+
            '.rc-cro-tiles{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;}'+
            '@media(max-width:1100px){.rc-cro-tiles{grid-template-columns:repeat(2,1fr);}}'+
            '.rc-cro-tile{background:#1D1D1D;border:1px solid #333;border-radius:12px;padding:14px 16px;border-top:3px solid #0090B0;}'+
            '.rc-cro-tile .k{font-size:11px;letter-spacing:.4px;color:#9C9C9C;text-transform:uppercase;font-weight:700;}'+
            '.rc-cro-tile .v{font-size:30px;font-weight:800;line-height:1.1;margin-top:4px;color:#F5F5F5;}'+
            '.rc-cro-tile .s{font-size:11px;color:#9C9C9C;margin-top:2px;}'+
            '.rc-cro-cols{display:grid;grid-template-columns:1fr 1fr;gap:12px;}'+
            '@media(max-width:1100px){.rc-cro-cols{grid-template-columns:1fr;}}'+
            '.rc-cro-card{background:#1D1D1D;border:1px solid #333;border-radius:12px;padding:12px 14px;min-height:120px;}'+
            '.rc-cro-card h3{margin:0 0 8px;font-size:13px;color:#F5F5F5;font-weight:800;letter-spacing:.3px;}'+
            '.rc-cro-list{list-style:none;margin:0;padding:0;font-size:12.5px;}'+
            '.rc-cro-list li{display:flex;gap:8px;align-items:baseline;padding:5px 0;border-bottom:1px solid #262626;}'+
            '.rc-cro-list li .nm{flex:1;color:#F5F5F5;font-weight:600;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;}'+
            '.rc-cro-list li .mt{color:#9C9C9C;font-size:11px;}'+
            '.rc-cro-list li .ag{font-weight:800;white-space:nowrap;}'+
            '.rc-cro-empty{color:#9C9C9C;text-align:center;padding:18px;font-size:13px;}'+
            '.rc-cro-tbl{width:100%;border-collapse:collapse;font-size:12px;}'+
            '.rc-cro-tbl th{color:#9C9C9C;text-align:left;font-weight:700;padding:4px 6px;border-bottom:1px solid #333;}'+
            '.rc-cro-tbl td{padding:4px 6px;border-bottom:1px solid #262626;color:#F5F5F5;}'+
            '.rc-cro-status{font-size:11px;color:#9C9C9C;}'+
            '#rcCrocoModal{position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:2147483210;display:none;align-items:center;justify-content:center;}'+
            '#rcCrocoModal .box{background:#1D1D1D;border:1px solid #333;border-top:4px solid #E60000;border-radius:12px;padding:22px 24px;max-width:460px;color:#F5F5F5;font-family:-apple-system,Segoe UI,Arial,sans-serif;}'+
            '#rcCrocoDrop{border:2px dashed #E60000;border-radius:10px;padding:22px;text-align:center;cursor:pointer;margin:14px 0;}'+
            '#rcCrocoDrop.drag{background:rgba(230,0,0,.08);}'+
            '.rc-flag-mini{display:inline-block;min-width:20px;text-align:center;font-size:10px;font-weight:800;color:#fff;background:#333;border-radius:3px;padding:1px 4px;margin-right:2px;}';
            document.head.appendChild(st); }

        function flagMini(code){ return '<span class="rc-flag-mini">'+esc(code||'?')+'</span>'; }
        function stdName(code){ return (STANDORT_METADATA[code] && STANDORT_METADATA[code].short) || code || ''; }

        // Reiter + Content-Div anlegen (wie ensureInfoPage) — idempotent
        function ensureCrocoPage(){
            var ov=window.__rcOverlayEl; if(!ov) return;
            if(!el('rcPageCrocoContent')){
                var c=document.createElement('div'); c.id='rcPageCrocoContent'; c.className='rc-grid'; c.style.display='none';
                var mq=ov.querySelector('.rc-marquee'); if(mq) ov.insertBefore(c,mq); else ov.appendChild(c);
            }
            var sw=ov.querySelector('.rc-pageswitch');
            if(sw && !el('rcPageCroco')){
                var b=document.createElement('button'); b.className='rc-page-btn'; b.id='rcPageCroco'; b.setAttribute('data-page','croco'); b.textContent='Croco';
                b.addEventListener('click', function(){ if(window.__rcSwitchPageFn) window.__rcSwitchPageFn('croco'); });
                // hinter "Cockpit" einsortieren (vor evtl. Info)
                var after=el('rcPageCockpit'); if(after && after.nextSibling) sw.insertBefore(b, after.nextSibling); else sw.appendChild(b);
            }
            if(window.__rcPagesRef) window.__rcPagesRef.croco=['rcPageCroco','rcPageCrocoContent','grid'];
        }

        function renderCrocoPage(){
            var host=el('rcPageCrocoContent'); if(!host) return;
            var cv=window.rcCrocoView();
            if(!cv.ready){
                host.innerHTML='<div class="rc-cro-empty" style="margin-top:40px;">'+
                    '<div style="font-size:34px;margin-bottom:8px;">&#128230;</div>'+
                    '<div style="font-size:16px;font-weight:800;color:#F5F5F5;">Noch keine Croco-Daten</div>'+
                    '<div style="margin-top:8px;max-width:520px;margin-left:auto;margin-right:auto;line-height:1.6;">'+
                    'Lade die <b>Croco.xls</b> per Klick auf den <b>Croco</b>-Knopf in der Kopfleiste (oder ziehe sie darauf), '+
                    'oder starte den <b>croco_crawler.js</b> auf der Ligaliste (Report &bdquo;CrocoXLS&ldquo;). '+
                    'Dann erscheinen hier offene Auftraege, Ueberfaellige (&gt;'+(CFG.overdueDays||7)+' Tage), Stornoquote und der ESL-Abgleich.</div>'+
                    '<button class="rc-btn" id="rcCrocoEmptyBtn" style="margin-top:16px;background:#E60000;color:#fff;border:none;padding:10px 20px;border-radius:8px;font-weight:700;cursor:pointer;">Croco.xls laden</button>'+
                    '</div>';
                var eb=el('rcCrocoEmptyBtn'); if(eb) eb.onclick=openImport;
                return;
            }
            var qCol = cv.stornoquote<=5?'#008A00':(cv.stornoquote<=12?'#EB9700':'#E60000');
            var reconN = cv.recon && cv.recon.stornoTrotzEsl ? cv.recon.stornoTrotzEsl.length : 0;
            var tiles='<div class="rc-cro-tiles">'+
                tile('Offene Auftraege', cv.offen, cv.total+' gesamt', '#0090B0')+
                tile('&gt;'+(CFG.overdueDays||7)+' Tage offen', cv.ueberfaellig, 'ueberfaellig', cv.ueberfaellig>0?'#E60000':'#008A00')+
                tile('Storniert', cv.storno, num1(cv.stornoquote)+'% Stornoquote', qCol)+
                tile('Erledigt', cv.erledigt, 'abgeschlossen', '#647500')+
                tile('ESL-Widerspruch', reconN, 'Storno trotz Verkauf', reconN>0?'#E60000':'#008A00')+
                '</div>';

            var overdue='<div class="rc-cro-card"><h3>Ueberfaellige Auftraege (&gt;'+(CFG.overdueDays||7)+' Tage offen)</h3>'+listOverdue(cv.overdue)+'</div>';
            var storno='<div class="rc-cro-card"><h3>Storno &times; ESL-Abgleich</h3>'+listRecon(cv)+'</div>';
            var byStd='<div class="rc-cro-card"><h3>Auftraege je Standort</h3>'+tableStd(cv.byStd)+'</div>';
            var byAgent='<div class="rc-cro-card"><h3>Offene/ueberfaellige je Agent</h3>'+tableAgent(cv.byAgent)+'</div>';

            var meta=window.rcCrocoMeta||{};
            var upd = meta.lastUpdate ? new Date(meta.lastUpdate).toLocaleString('de-DE') : '—';
            var status='<div class="rc-cro-status">Stand: '+esc(upd)+' &middot; '+cv.total+' Auftraege im Filter'+(meta.source?' &middot; Quelle: '+esc(meta.source):'')+' &middot; <a href="#" id="rcCrocoReimport" style="color:#57D0E0;">neu laden</a></div>';

            host.innerHTML=tiles+'<div class="rc-cro-cols">'+overdue+storno+'</div><div class="rc-cro-cols">'+byStd+byAgent+'</div>'+status;
            var ri=el('rcCrocoReimport'); if(ri) ri.onclick=function(e){ e.preventDefault(); openImport(); };
        }
        function tile(k,v,s,col){ return '<div class="rc-cro-tile" style="border-top-color:'+col+';"><div class="k">'+k+'</div><div class="v" style="color:'+col+';">'+v+'</div><div class="s">'+s+'</div></div>'; }
        function listOverdue(list){ if(!list||!list.length) return '<div class="rc-cro-empty">Kein Auftrag laenger als '+(CFG.overdueDays||7)+' Tage offen. Sauber!</div>';
            return '<ul class="rc-cro-list">'+list.slice(0,14).map(function(o){ var crit=o.ageDays>=14; return '<li><span class="nm">'+flagMini(o.standort)+' '+esc(o.auftrag||o.vo||'?')+(o.agent?' <span class="mt">&middot; '+esc(o.agent)+'</span>':'')+'</span><span class="mt">'+esc(o.produkt||o.kunde||'')+'</span><span class="ag" style="color:'+(crit?'#E60000':'#EB9700')+'">'+o.ageDays+' T</span></li>'; }).join('')+'</ul>'; }
        function listRecon(cv){ var r=cv.recon||{}; var list=r.stornoTrotzEsl||[];
            if(!(window.rcAllSales&&window.rcAllSales.length)) return '<div class="rc-cro-empty">ESL-Verkaufsdaten noch nicht geladen — Abgleich startet automatisch, sobald der ESL-Poll laeuft.</div>';
            if(!list.length) return '<div class="rc-cro-empty">Kein Widerspruch: keine heute im ESL gebuchte Bestellung wurde in Croco storniert.</div>';
            return '<ul class="rc-cro-list">'+list.slice(0,14).map(function(o){ return '<li><span class="nm">'+flagMini(o.standort)+' '+esc(o.agent||'?')+' <span class="mt">&middot; '+esc(o.kunde||('VO '+(o.vo||'')))+'</span></span><span class="mt">'+esc(o.produkt||'')+'</span><span class="ag" style="color:#E60000">STORNO</span></li>'; }).join('')+'</ul>'; }
        function tableStd(byStd){ var keys=Object.keys(byStd||{}).sort(function(a,b){ return (byStd[b].offen||0)-(byStd[a].offen||0); });
            if(!keys.length) return '<div class="rc-cro-empty">Keine Daten.</div>';
            return '<table class="rc-cro-tbl"><thead><tr><th>Standort</th><th>Offen</th><th>&gt;'+(CFG.overdueDays||7)+'T</th><th>Storno</th><th>Erledigt</th></tr></thead><tbody>'+keys.map(function(k){ var s=byStd[k]; return '<tr><td>'+flagMini(k)+' '+esc(stdName(k))+'</td><td>'+(s.offen||0)+'</td><td>'+(s.ueberfaellig?'<b style="color:#E60000">'+s.ueberfaellig+'</b>':'0')+'</td><td>'+(s.storno||0)+'</td><td>'+(s.erledigt||0)+'</td></tr>'; }).join('')+'</tbody></table>'; }
        function tableAgent(list){ var top=(list||[]).filter(function(a){ return a.offen>0||a.ueberfaellig>0; }).slice(0,12);
            if(!top.length) return '<div class="rc-cro-empty">Keine offenen Auftraege im Filter.</div>';
            return '<table class="rc-cro-tbl"><thead><tr><th>Agent</th><th>Offen</th><th>&gt;'+(CFG.overdueDays||7)+'T</th><th>Storno</th></tr></thead><tbody>'+top.map(function(a){ return '<tr><td>'+flagMini(a.standort)+' '+esc(a.agent)+'</td><td>'+(a.offen||0)+'</td><td>'+(a.ueberfaellig?'<b style="color:#E60000">'+a.ueberfaellig+'</b>':'0')+'</td><td>'+(a.storno||0)+'</td></tr>'; }).join('')+'</tbody></table>'; }

        // ---- Import (Croco.xls per Drag&Drop / Datei) ----
        function ensureModal(){
            if(el('rcCrocoModal')) return;
            var m=document.createElement('div'); m.id='rcCrocoModal';
            m.innerHTML='<div class="box">'+
                '<h3 style="margin:0 0 6px;font-size:17px;">Croco-Auftragsdaten laden</h3>'+
                '<p style="font-size:12.5px;color:#C9C9C9;margin:0 0 6px;line-height:1.55;">Ziehe die <b>Croco.xls</b> (oder .xlsx/.csv) hierher oder klicke zum Auswaehlen. Die Spalten werden automatisch erkannt (Auftragsnummer, Status, Datum, Kunde, Produkt, Agent, Standort, Team).</p>'+
                '<div id="rcCrocoDrop"><div style="font-size:26px;">&#128228;</div><div style="font-weight:700;margin-top:6px;">Croco-Datei hier ablegen oder klicken</div><input type="file" id="rcCrocoFile" accept=".xlsx,.xls,.csv" style="display:none;"></div>'+
                '<div id="rcCrocoDetect" style="font-size:11.5px;color:#9C9C9C;min-height:16px;"></div>'+
                '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;">'+
                '<button id="rcCrocoClose" style="background:transparent;color:#9C9C9C;border:1px solid #555;padding:8px 14px;border-radius:7px;cursor:pointer;">Schliessen</button>'+
                '</div></div>';
            document.body.appendChild(m);
            m.addEventListener('click', function(e){ if(e.target===m) m.style.display='none'; });
            el('rcCrocoClose').onclick=function(){ m.style.display='none'; };
            var drop=el('rcCrocoDrop'), inp=el('rcCrocoFile');
            drop.onclick=function(){ inp.click(); };
            inp.onchange=function(e){ var f=e.target.files[0]; if(f) readFile(f); };
            drop.addEventListener('dragover', function(e){ e.preventDefault(); drop.classList.add('drag'); });
            drop.addEventListener('dragleave', function(){ drop.classList.remove('drag'); });
            drop.addEventListener('drop', function(e){ e.preventDefault(); drop.classList.remove('drag'); var f=e.dataTransfer.files[0]; if(f) readFile(f); });
        }
        function readFile(f){
            var det=el('rcCrocoDetect'); if(det) det.textContent='Lese '+f.name+' ...';
            if(!window.XLSX){ if(det) det.innerHTML='<span style="color:#E60000;">SheetJS (XLSX) noch nicht geladen — kurz warten und erneut versuchen.</span>'; return; }
            var r=new FileReader();
            r.onload=function(ev){
                try {
                    var wb=XLSX.read(new Uint8Array(ev.target.result), { type:'array', cellDates:false });
                    // groesstes Blatt waehlen (meiste Zeilen)
                    var best=null, bestN=-1;
                    wb.SheetNames.forEach(function(sn){ var rows=XLSX.utils.sheet_to_json(wb.Sheets[sn], { header:1, raw:true, defval:'' }); if(rows.length>bestN){ bestN=rows.length; best=rows; } });
                    var pr=parseRows(best||[]);
                    if(!pr.orders.length){ if(det) det.innerHTML='<span style="color:#E60000;">Keine Auftragszeilen erkannt. Spaltenkopf mit Auftragsnummer/Status/Datum noetig.</span>'; return; }
                    setOrders(pr.orders, { source:'Import '+f.name });
                    if(det) det.innerHTML='<span style="color:#3DD68C;">'+pr.orders.length+' Auftraege geladen. Erkannt: '+esc(Object.keys(pr.detected).join(', ')||'—')+'</span>';
                    if(window.__rcSwitchPageFn) window.__rcSwitchPageFn('croco');
                    setTimeout(function(){ var mm=el('rcCrocoModal'); if(mm) mm.style.display='none'; }, 1400);
                } catch(err){ if(det) det.innerHTML='<span style="color:#E60000;">Fehler: '+esc(err.message)+'</span>'; rcLog.error('[Croco] Import-Fehler:', err); }
            };
            r.readAsArrayBuffer(f);
        }
        function openImport(){ ensureModal(); el('rcCrocoModal').style.display='flex'; }
        window.rcCrocoOpenImport = openImport;

        // Header-Button "Croco" (additiv, keine Template-Edits) — Klick=Import, Drop=Import
        function ensureHeaderButton(){
            var ov=window.__rcOverlayEl||document; var header=ov.querySelector('.rc-header'); if(!header || el('rcBtnCroco')) return;
            var ref=el('rcBtnMapping');
            var b=document.createElement('button'); b.className='rc-btn rc-btn-ghost'; b.id='rcBtnCroco'; b.title='Croco-Auftragsdaten laden (offene Auftraege, Stornos, ESL-Abgleich) — Datei hierher ziehen'; b.textContent='Croco';
            if(ref && ref.parentNode) ref.parentNode.insertBefore(b, ref); else header.appendChild(b);
            b.onclick=openImport;
            b.addEventListener('dragover', function(e){ e.preventDefault(); b.style.outline='2px dashed #E60000'; });
            b.addEventListener('dragleave', function(){ b.style.outline=''; });
            b.addEventListener('drop', function(e){ e.preventDefault(); b.style.outline=''; var f=e.dataTransfer.files[0]; if(f){ ensureModal(); readFile(f); openImport(); } });
        }

        // ---- Konsolen-API ----
        window.rcCrocoReset = function(){ window.rcCrocoOrders=[]; window.rcCrocoMeta=null; try{ localStorage.removeItem(DATK); }catch(e){} recompute(); rcLog.log('[Croco] Daten verworfen.'); };
        window.rcCrocoDebug = function(){ var cv=window.rcCrocoView(); rcLog.log('[Croco] '+JSON.stringify({ total:cv.total, offen:cv.offen, ueberfaellig:cv.ueberfaellig, storno:cv.storno, erledigt:cv.erledigt, stornoquote:Math.round(cv.stornoquote*10)/10, eslWiderspruch:(cv.recon&&cv.recon.stornoTrotzEsl?cv.recon.stornoTrotzEsl.length:0) }, null, 2)); return cv; };

        // ---- Boot ----
        ensureCrocoPage(); ensureHeaderButton(); restore(); renderCrocoPage();
        // Selbstheilung: Reiter/Button/Seite gegen Portal-Re-Renders idempotent halten
        window.rcCrocoInterval = setInterval(function(){ try { ensureCrocoPage(); ensureHeaderButton(); if(window.rcActivePage==='croco') renderCrocoPage(); } catch(e){} }, 3000);
        // ESL-Abgleich frisch halten (rcAllSales fuellt sich nach jedem 20-s-Poll)
        window.rcCrocoReconcileInterval = setInterval(function(){ try { if(window.rcCrocoOrders.length){ recompute(window.rcActivePage==='croco'); } } catch(e){} }, 20000);
        rcLog.log('[Croco] Modul bereit — Kopfleiste "Croco" (Import) · Reiter "Croco" · rcCrocoOpenImport() · croco_crawler.js sendet CROCO_BATCH.');
    })();

    return '+++ esl live-arena v22.0 (Vodafone Edition) gestartet +++';
})();