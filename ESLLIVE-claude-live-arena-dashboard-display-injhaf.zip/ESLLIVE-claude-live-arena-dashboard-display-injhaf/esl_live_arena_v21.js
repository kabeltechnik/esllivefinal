(function() {
    // ============================================================
    //  regiocom esl live-arena v21.0
    //  Live-Motivations-Cockpit fuer Sales-Agents (WCA/ESL-Portal)
    //  - laeuft 100% clientseitig in der Browser-Konsole
    //  - pollt alle 20s den Excel-Export des PrimeFaces-Portals
    //  - Aggregation korrigiert, alle Kategorien, bewegliche Diagramme
    //  - Nationen-Battle mit manueller Laenderauswahl
    // ============================================================

    // 1. ORIGINAL-CONSOLE WIEDERHERSTELLEN (Portal ueberschreibt console evtl.)
    let realConsole = window.console;
    try {
        const iframe = document.createElement('iframe');
        iframe.style.display = 'none';
        document.body.appendChild(iframe);
        if (iframe.contentWindow && iframe.contentWindow.console) realConsole = iframe.contentWindow.console;
    } catch (e) {}
    const rcLog = {
        log: (...a) => { try { realConsole.log(...a); } catch(e){} },
        error: (...a) => { try { realConsole.error(...a); } catch(e){} },
        warn: (...a) => { try { realConsole.warn(...a); } catch(e){} }
    };
    rcLog.log("regiocom esl live-arena v21.0 gestartet");

    // 2. CLEAN-STATE: alte Intervalle stoppen, alte DOM-Reste entfernen
    ['rcLiveInterval','rcFlashbackInterval','rcSprucheInterval','rcClockInterval','rcRotateInterval'].forEach(k=>{
        if (window[k]) { clearInterval(window[k]); window[k]=null; }
    });
    ['rcLiveDashboard','rcToastContainer','rcLiveBadge','rcMappingModal'].forEach(id => {
        const el = document.getElementById(id); if (el) el.remove();
    });
    // Chart-Instanzen zerstoeren, sonst zeichnen sie nach Re-Inject auf tote Canvases
    ['rcChartInstance','rcTnpsChartInstance','rcQualiStdChartInstance','rcRadarChartA_i','rcRadarChartB_i'].forEach(k => {
        if (window[k]) { try { window[k].destroy(); } catch(e){} window[k] = null; }
    });
    window.rcRadarBuilt = false;

    // ============================================================
    //  STAMMDATEN
    // ============================================================
    const STANDORT_METADATA = {
        'ADP': { name: 'Alexandroupolis', short: 'Alexandr.',   nation: 'GR', color: '#2C57D2', call: 'DELTA',    lat: 40.85, lon: 25.87 },
        'AL':  { name: 'Alanya',          short: 'Alanya',      nation: 'TR', color: '#FF4C02', call: 'ALPHA',    lat: 36.54, lon: 32.00 },
        'B':   { name: 'Berlin',          short: 'Berlin',      nation: 'DE', color: '#9BA7B2', call: 'BRAVO',    lat: 52.52, lon: 13.40 },
        'E':   { name: 'Essen',           short: 'Essen',       nation: 'DE', color: '#9BA7B2', call: 'ECHO',     lat: 51.45, lon: 7.01 },
        'P':   { name: 'Potsdam',         short: 'Potsdam',     nation: 'DE', color: '#9BA7B2', call: 'PAPA',     lat: 52.40, lon: 13.06 },
        'SER': { name: 'Serres',          short: 'Serres',      nation: 'GR', color: '#2C57D2', call: 'SIERRA',   lat: 41.08, lon: 23.55 },
        'ZWT': { name: 'Zeitwert',        short: 'Zeitwert',    nation: 'AT', color: '#FF679B', call: 'ZULU',     lat: 48.20, lon: 16.37 },
        'NBB': { name: 'Neubrandenburg',  short: 'Neubrdbg.',   nation: 'DE', color: '#FFB200', call: 'NOVEMBER', lat: 53.55, lon: 13.26 },
        'SKA': { name: 'Sakarya',         short: 'Sakarya',     nation: 'TR', color: '#FF4C02', call: 'KILO',     lat: 40.77, lon: 30.40 }
    };
    const shortName = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].short) || (STANDORT_METADATA[code] && STANDORT_METADATA[code].name) || code;

    // Qualitaets-Ziele (Mandanten-Vorgaben)
    const RC_ZIELE = {
        ff7:   { min: 80,  label: 'FF7 ≥ 80 %' },
        cs:    { min: 90,  label: 'CS ≥ 90 %' },
        ahtMin:{ max: 13,  opt: 10, label: 'AHT ≤ 13 Min' },
        tnps:  { min: 70,  label: 'TNPS ≥ 70 %' },
        dds:   { max: 5,   label: 'DDS ≤ 5,0 %' },
        fq:    { min: 30,  label: 'FQ ≥ 30 %' },
        aq:    { min: 85,  label: 'AQ ≥ 85 %' },
        calls: { min: 40,  label: '≥ 40 Calls/Tag' }
    };
    // Ampel-Farbe: erfuellt = gruen, bis 10 % daneben = gelb, sonst orange/rot
    function zielColor(val, ziel){
        if (val == null || !ziel) return '#9BA7B2';
        if (ziel.min != null) { if (val >= ziel.min) return '#48e6a0'; if (val >= ziel.min*0.9) return '#FFB200'; return '#FF6B6B'; }
        if (ziel.max != null) { if (val <= ziel.max) return '#48e6a0'; if (val <= ziel.max*1.15) return '#FFB200'; return '#FF6B6B'; }
        return '#9BA7B2';
    }
    const NATION_METADATA = {
        'TR': { name: 'Tuerkei',       color: '#FF4C02' },
        'GR': { name: 'Griechenland',  color: '#2C57D2' },
        'DE': { name: 'Deutschland',   color: '#FFB200' },
        'AT': { name: 'Oesterreich',   color: '#FF679B' }
    };
    const ORDER = ['AL','SER','ADP','B','P','E','ZWT','NBB','SKA'];

    function normalizeStandort(std) {
        if (!std) return 'ALL';
        let s = std.toString().toUpperCase().trim();
        const map = {ALANYA:'AL',SERRES:'SER',ALEXANDROUPOLIS:'ADP',BERLIN:'B',ESSEN:'E',POTSDAM:'P',ZEITWERT:'ZWT',NEUBRANDENBURG:'NBB',SAKARYA:'SKA'};
        if (map[s]) return map[s];
        return s;
    }

    function getFlagSvg(code, size = 'small', wave = false) {
        let nation = STANDORT_METADATA[code] ? STANDORT_METADATA[code].nation : code;
        const w = size === 'xl' ? 54 : (size === 'large' ? 34 : 20);
        const h = size === 'xl' ? 36 : (size === 'large' ? 22.6 : 13.3);
        const cls = wave ? 'rc-flag-wave' : '';
        const base = `border-radius:3px; display:inline-block; vertical-align:middle; box-shadow:0 1px 3px rgba(0,0,0,0.4);`;
        if (nation === 'TR') return `<svg class="${cls}" viewBox="0 0 120 80" width="${w}" height="${h}" style="${base}"><rect width="120" height="80" fill="#E30A17"/><circle cx="45" cy="40" r="20" fill="#fff"/><circle cx="50" cy="40" r="16" fill="#E30A17"/><polygon points="70,40 76,42 74,48 79,44 85,46 81,41 85,36 79,38 74,34 76,40" fill="#fff"/></svg>`;
        if (nation === 'GR') return `<svg class="${cls}" viewBox="0 0 27 18" width="${w}" height="${h}" style="${base}"><rect width="27" height="18" fill="#005BA6"/><rect y="2" width="27" height="2" fill="#fff"/><rect y="6" width="27" height="2" fill="#fff"/><rect y="10" width="27" height="2" fill="#fff"/><rect y="14" width="27" height="2" fill="#fff"/><rect width="10" height="10" fill="#005BA6"/><rect x="4" width="2" height="10" fill="#fff"/><rect y="4" width="10" height="2" fill="#fff"/></svg>`;
        if (nation === 'DE') return `<svg class="${cls}" viewBox="0 0 5 3" width="${w}" height="${h}" style="${base}"><rect y="0" width="5" height="1" fill="#000"/><rect y="1" width="5" height="1" fill="#D00"/><rect y="2" width="5" height="1" fill="#FFCE00"/></svg>`;
        if (nation === 'AT') return `<svg class="${cls}" viewBox="0 0 3 2" width="${w}" height="${h}" style="${base}"><rect y="0" width="3" height="0.67" fill="#C60C30"/><rect y="0.67" width="3" height="0.67" fill="#FFF"/><rect y="1.34" width="3" height="0.67" fill="#C60C30"/></svg>`;
        return `<svg class="${cls}" viewBox="0 0 24 24" width="${w}" height="${h}" fill="none" stroke="#9BA7B2" stroke-width="2" style="${base}"><circle cx="12" cy="12" r="10"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10zM2 12h20"/></svg>`;
    }

    function ladeBibliothek(url, checkVar) {
        return new Promise((resolve) => {
            if (window[checkVar]) return resolve();
            const s = document.createElement('script');
            s.src = url; s.type = 'text/javascript';
            s.onload = () => { rcLog.log(`Bibliothek ${checkVar} geladen.`); resolve(); };
            s.onerror = () => { rcLog.error(`Fehler beim Laden von ${checkVar}.`); resolve(); };
            document.head.appendChild(s);
        });
    }

    // Mapping (Mitarbeiter-IDs) aus localStorage
    window.rcWcaMapping = null;
    const savedMapping = localStorage.getItem('rcWcaMapping');
    if (savedMapping) { try { window.rcWcaMapping = JSON.parse(savedMapping); } catch(e){} }

    // Standort-Auswahl fuer den Battle — IMMER genau 2 (Duell-Format)
    (function(){
        let sel = [];
        try { sel = JSON.parse(localStorage.getItem('rcSelectedStandorte') || '[]'); } catch(e){}
        sel = (Array.isArray(sel) ? sel : []).filter(c => STANDORT_METADATA[c]).slice(0, 2);
        if (sel.length < 2) sel = ['AL','SER'];
        window.rcSelectedStandorte = new Set(sel);
    })();

    // ============================================================
    //  KPI-EMPFAENGER (externe Website via Satellite-Crawler)
    // ============================================================
    window.rcKpiData = {};    // { ccsId => kpiObjekt }
    window.rcKpiByName = {};  // { normalisierterName => kpiObjekt }  (Join-Fallback)
    window.rcKpiLastUpdate = null;

    // Name normalisieren, damit "Baltaci Derya" == "Derya Baltaci" == "baltaci derya"
    window.rcNormName = function(s){
        if (!s) return '';
        return s.toString().toLowerCase()
            .replace(/[.,]/g,' ')
            .replace(/[äàáâ]/g,'a').replace(/[öòóô]/g,'o').replace(/[üùúû]/g,'u').replace(/ß/g,'ss')
            .split(/\s+/).filter(Boolean).sort().join(' ');
    };

    function ingestKpi(kpi){
        if (!kpi || !kpi.ccsId) return;
        window.rcKpiData[kpi.ccsId] = kpi;
        if (kpi.agentName) window.rcKpiByName[window.rcNormName(kpi.agentName)] = kpi;
    }

    // KPI-Objekt zu einem ESL-Agenten finden (per CCS-ID, sonst per Name)
    window.rcKpiForAgent = function(ag){
        if (!ag) return null;
        if (ag.ccsId && window.rcKpiData[ag.ccsId]) return window.rcKpiData[ag.ccsId];
        const byName = window.rcKpiByName[window.rcNormName(ag.name)];
        return byName || null;
    };

    // Gemeinsamer Handler fuer alle Kanaele (BroadcastChannel same-origin + postMessage cross-origin)
    function handleKpiMessage(d){
        if (!d || typeof d !== 'object') return false;
        if (d.type === 'KPI_BATCH' && Array.isArray(d.payload)) {
            d.payload.forEach(ingestKpi);
        } else if (d.type === 'KPI_UPDATE' && d.payload) {
            ingestKpi(d.payload);
        } else { return false; }

        window.rcKpiLastUpdate = new Date();
        rcLog.log(`KPI-Daten empfangen: ${Object.keys(window.rcKpiData).length} Agenten (CCS-ID)`);
        if (window.rcCaptureTnpsSnapshot) window.rcCaptureTnpsSnapshot();
        if (window.renderTnpsChart) window.renderTnpsChart();
        if (window.rcLetzteStats) {
            const agentsArr = Object.values(window.rcLetzteStats.agentStats);
            if (window.renderAgents) window.renderAgents(agentsArr);
            if (window.renderAnspFokus) window.renderAnspFokus(agentsArr);
            if (window.renderQualitaet) window.renderQualitaet();
            if (window.renderMarquee) window.renderMarquee();
            if (window.rcActivePage === 'cockpit' && window.renderCockpit) window.renderCockpit();
        }
        return true;
    }

    // Kanal 1: BroadcastChannel (funktioniert nur wenn Crawler auf DERSELBEN Domain laeuft)
    const rcKpiChannel = new BroadcastChannel('regiocom_live_arena');
    rcKpiChannel.onmessage = (event) => handleKpiMessage(event.data);

    // Kanal 2: window.postMessage (CROSS-ORIGIN — Ligaliste ist ccs.vodafone.de, Dashboard esl.regiocom.net!)
    // Der Crawler funkt via window.opener.postMessage zurueck. Nur KPI-Zahlen, daher Origin-agnostisch.
    window.addEventListener('message', (event) => {
        const d = event.data;
        if (d && (d.type === 'KPI_BATCH' || d.type === 'KPI_UPDATE')) handleKpiMessage(d);
    });

    // KPI-Quelle (Ligaliste) aus dem Dashboard oeffnen -> setzt window.opener beim Crawler,
    // damit dieser cross-origin zurueckfunken kann.
    window.RC_LIGA_URL = 'https://ccs.vodafone.de/cgi-bin/AGENTEN_KENNZAHLEN_2/LIGA_LISTEN_NEW/dist/liga_listen.rb?script_id=11035';
    window.rcOpenKpiQuelle = function(){
        window.rcKpiWin = window.open(window.RC_LIGA_URL, 'rcKpiQuelle');
        if (!window.rcKpiWin) { alert('Popup wurde blockiert. Bitte Popups fuer diese Seite erlauben und erneut klicken.'); return; }
        rcLog.log('KPI-Quelle geoeffnet. Jetzt dort den kpi_crawler.js in die Konsole einfuegen.');
    };
    rcLog.log("KPI-Empfaenger aktiv (BroadcastChannel + postMessage). Warte auf Crawler-Daten...");

    // ============================================================
    //  STYLES
    // ============================================================
    const styleEl = document.createElement('style');
    styleEl.innerHTML = `
        @import url('https://fonts.googleapis.com/css2?family=Nunito:wght@700;800;900&family=Roboto:wght@300;400;700&family=Roboto+Mono:wght@500;700&display=swap');
        :root{
            --rc-blue:#2C57D2; --rc-orange:#FF4C02; --rc-green:#009864; --rc-cyan:#00D9FF;
            --rc-yellow:#FFB200; --rc-pink:#FF679B; --rc-dark-bg:#070b12; --rc-card-bg:rgba(19,26,38,0.92);
            --rc-matrix-green:#00FF63;
        }
        #rcLiveDashboard{position:fixed; inset:0; width:100vw; height:100vh; z-index:999999; color:#E9ECF0;
            font-family:'Roboto',sans-serif; display:flex; flex-direction:column; overflow:hidden; box-sizing:border-box;
            background:
              radial-gradient(1200px 600px at 15% -10%, rgba(44,87,210,0.25), transparent 60%),
              radial-gradient(1000px 500px at 100% 0%, rgba(255,76,2,0.14), transparent 55%),
              linear-gradient(rgba(10,15,26,0.97), rgba(5,8,15,0.99)),
              repeating-linear-gradient(0deg, rgba(255,255,255,0.015) 0px, rgba(255,255,255,0.015) 1px, transparent 1px, transparent 3px);
        }
        #rcLiveDashboard *{box-sizing:border-box;}
        .rc-header{height:58px; background:rgba(9,14,24,0.85); border-bottom:1px solid rgba(44,87,210,0.5);
            display:flex; justify-content:space-between; align-items:center; padding:0 20px; flex-shrink:0;
            box-shadow:0 4px 24px rgba(0,0,0,0.5); backdrop-filter:blur(6px);}
        .rc-header-brand{display:flex; align-items:center; gap:12px;}
        .rc-pageswitch{display:flex; background:rgba(255,255,255,0.06); border:1px solid rgba(255,255,255,0.12); border-radius:8px; overflow:hidden;}
        .rc-page-btn{background:transparent; border:none; color:#9BA7B2; font-family:'Nunito'; font-weight:800; font-size:12px; padding:6px 16px; cursor:pointer; transition:all 0.2s;}
        .rc-page-btn:hover{color:#fff;}
        .rc-page-btn.active{background:linear-gradient(135deg,var(--rc-blue),var(--rc-cyan)); color:#fff;}
        .rc-quali{flex:1; display:flex; flex-direction:column; min-height:0; overflow:hidden;}
        .rc-quali-strip{display:flex; gap:10px; padding:12px; flex-shrink:0;}
        .rc-quali-strip .rc-kpi{flex:1;}
        .rc-arena-tag{font-family:'Nunito'; font-weight:800; font-size:13px; text-transform:uppercase; color:var(--rc-cyan);
            letter-spacing:2px; border-left:1px solid rgba(255,255,255,0.2); padding-left:14px;}
        .rc-live-pill{display:inline-flex; align-items:center; gap:6px; background:rgba(0,255,99,0.1);
            border:1px solid rgba(0,255,99,0.4); border-radius:9999px; padding:3px 10px 3px 8px;
            font-family:'Nunito'; font-weight:900; font-size:10px; letter-spacing:1.5px; color:#8affc4;}
        .rc-live-dot{width:8px; height:8px; border-radius:50%; background:var(--rc-matrix-green); animation:rc-pulse 1.5s infinite;}
        @keyframes rc-pulse{0%{box-shadow:0 0 0 0 rgba(0,255,99,0.6);}70%{box-shadow:0 0 0 8px rgba(0,255,99,0);}100%{box-shadow:0 0 0 0 rgba(0,255,99,0);}}
        .rc-clock{font-family:'Roboto Mono'; font-weight:700; font-size:15px; color:#fff; text-align:right; line-height:1;}
        .rc-clock small{display:block; font-size:9px; color:#9BA7B2; letter-spacing:0.5px; margin-top:2px;}
        .rc-select{background:#101828; border:1px solid rgba(255,255,255,0.15); color:#fff; padding:6px 12px;
            border-radius:8px; font-family:'Roboto'; font-size:13px; outline:none; cursor:pointer;}
        .rc-btn{padding:6px 14px; border:none; border-radius:8px; font-family:'Nunito'; font-weight:800; font-size:12px;
            cursor:pointer; color:#fff; transition:all 0.2s;}
        .rc-btn-blue{background:linear-gradient(90deg,var(--rc-blue),var(--rc-cyan));}
        .rc-btn-orange{background:linear-gradient(90deg,var(--rc-orange),var(--rc-yellow));}
        .rc-btn-gray{background:rgba(255,255,255,0.08);}
        .rc-btn:hover{transform:translateY(-1px); box-shadow:0 4px 14px rgba(255,255,255,0.15);}
        .rc-btn-tab{background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.1); color:#9BA7B2;
            cursor:pointer; transition:all 0.2s; outline:none; padding:2px 9px; font-size:10px; border-radius:5px;
            font-family:'Nunito'; font-weight:800;}
        .rc-btn-tab.active{background:var(--rc-blue); border-color:var(--rc-cyan); color:#fff; box-shadow:0 0 10px rgba(44,87,210,0.5);}

        /* KPI STRIP */
        .rc-kpi-strip{display:flex; align-items:stretch; gap:10px; padding:10px 18px; flex-shrink:0;
            background:rgba(9,14,24,0.55); border-bottom:1px solid rgba(44,87,210,0.25);}
        .rc-kpi{flex:1; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); border-radius:10px;
            padding:8px 12px; position:relative; overflow:hidden;}
        .rc-kpi.hot{border-color:rgba(255,178,0,0.45); background:linear-gradient(180deg,rgba(255,178,0,0.08),rgba(255,255,255,0.02));}
        .rc-kpi-l{font-family:'Nunito'; font-weight:800; font-size:9px; letter-spacing:0.6px; text-transform:uppercase; color:#9BA7B2; display:flex; align-items:center; gap:5px;}
        .rc-kpi-v{font-family:'Nunito'; font-weight:900; font-size:24px; line-height:1.05; color:#fff; margin-top:3px; font-variant-numeric:tabular-nums;}
        .rc-kpi-v small{font-size:11px; color:#9BA7B2; font-weight:700; margin-left:5px;}
        .rc-kpi.blue .rc-kpi-v{color:var(--rc-cyan);} .rc-kpi.green .rc-kpi-v{color:#48e6a0;}
        .rc-kpi.orange .rc-kpi-v{color:#ff8a4c;} .rc-kpi.pink .rc-kpi-v{color:var(--rc-pink);}
        .rc-kpi.gold .rc-kpi-v{color:var(--rc-yellow);}
        @keyframes rc-kpi-flash{0%{text-shadow:0 0 16px currentColor; transform:scale(1.12);}100%{text-shadow:none; transform:scale(1);}}

        /* GRID */
        .rc-grid{display:grid; grid-template-columns:320px 1fr 320px; gap:10px; padding:10px; flex:1; overflow:hidden;}
        .rc-col{display:flex; flex-direction:column; gap:10px; overflow:hidden; height:100%;}
        .rc-card{background:var(--rc-card-bg); border:1px solid rgba(44,87,210,0.22); border-radius:10px; padding:11px 12px;
            box-shadow:0 8px 26px rgba(0,0,0,0.4); display:flex; flex-direction:column; overflow:hidden; position:relative;}
        .rc-card::before{content:''; position:absolute; top:0; left:0; width:100%; height:3px;
            background:linear-gradient(90deg,var(--rc-blue),var(--rc-cyan),transparent);}
        .rc-card.accent-orange::before{background:linear-gradient(90deg,var(--rc-orange),var(--rc-yellow),transparent);}
        .rc-card.accent-blue::before{background:linear-gradient(90deg,var(--rc-blue),var(--rc-cyan),transparent);}
        .rc-card.accent-pink::before{background:linear-gradient(90deg,var(--rc-pink),var(--rc-yellow),transparent);}
        .rc-card.accent-dark::before{background:linear-gradient(90deg,#5a6b7d,transparent);}
        .rc-card-header{display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;
            border-bottom:1px solid rgba(44,87,210,0.2); padding-bottom:6px;}
        .rc-card-title{font-family:'Nunito'; font-size:12.5px; font-weight:900; text-transform:uppercase; color:#fff; margin:0; letter-spacing:0.5px;}
        .rc-scroll{overflow-y:auto;} .rc-scroll::-webkit-scrollbar{width:5px;}
        .rc-scroll::-webkit-scrollbar-thumb{background:rgba(44,87,210,0.35); border-radius:4px;}

        .rc-list-item{background:rgba(13,20,37,0.5); border:1px solid rgba(44,87,210,0.15); border-radius:7px;
            padding:6px 10px; margin-bottom:5px; display:flex; align-items:center; gap:9px; font-size:12px; transition:border-color 0.2s, background 0.2s;}
        .rc-list-item:hover{border-color:rgba(0,217,255,0.4); background:rgba(0,217,255,0.06);}
        .rc-rank-badge{width:22px; height:22px; border-radius:50%; background:rgba(255,255,255,0.05);
            border:1px solid rgba(255,255,255,0.15); display:flex; align-items:center; justify-content:center;
            font-family:'Roboto Mono'; font-weight:bold; font-size:11px; flex-shrink:0;}
        .r1{border-color:var(--rc-yellow); color:var(--rc-yellow); text-shadow:0 0 8px rgba(255,178,0,0.6);}
        .r2{border-color:var(--rc-cyan); color:var(--rc-cyan); text-shadow:0 0 8px rgba(0,217,255,0.6);}
        .r3{border-color:var(--rc-orange); color:var(--rc-orange); text-shadow:0 0 8px rgba(255,76,2,0.6);}

        .rc-table{width:100%; border-collapse:collapse; font-size:12px; text-align:left;}
        .rc-table th{padding:9px 8px; font-family:'Nunito'; font-size:10px; color:#9BA7B2;
            border-bottom:2px solid rgba(44,87,210,0.3); text-transform:uppercase; position:sticky; top:0; background:#0e1626; z-index:1;}
        .rc-table td{padding:8px; border-bottom:1px solid rgba(44,87,210,0.1); vertical-align:middle;}
        .rc-table tr:hover{background:rgba(44,87,210,0.06);}
        .rc-table-row-1{border-left:4px solid var(--rc-yellow); background:rgba(255,178,0,0.05);}
        .rc-table-row-2{border-left:4px solid var(--rc-cyan); background:rgba(0,217,255,0.05);}
        .rc-table-row-3{border-left:4px solid var(--rc-orange); background:rgba(255,76,2,0.05);}
        .rc-mono{font-family:'Roboto Mono'; font-weight:bold;}

        .rc-bar-track{height:7px; background:rgba(255,255,255,0.05); border-radius:4px; overflow:hidden; border:1px solid rgba(44,87,210,0.2);}
        .rc-bar-fill{height:100%; border-radius:4px; box-shadow:0 0 8px rgba(0,217,255,0.4);
            transition:width 0.9s cubic-bezier(0.4,0,0.2,1); width:0;}

        /* Standort-Battle Auswahl + Duell */
        .rc-battle-picker{display:flex; flex-wrap:wrap; gap:5px; margin-bottom:10px;}
        .rc-battle-chip{cursor:pointer; border:1px solid rgba(255,255,255,0.15); border-radius:6px; padding:3px 7px 3px 5px;
            background:rgba(255,255,255,0.03); opacity:0.4; transition:all 0.2s; display:flex; align-items:center; gap:4px;
            font-family:'Nunito'; font-weight:800; font-size:10px; color:#cfd8e3;}
        .rc-battle-chip.on{opacity:1; border-color:var(--rc-cyan); box-shadow:0 0 8px rgba(0,217,255,0.3);}
        .rc-duel{display:flex; align-items:stretch; gap:8px; margin-top:4px;}
        .rc-duel-side{flex:1; text-align:center; padding:12px 8px; border-radius:10px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.08);}
        .rc-duel-vs{display:flex; align-items:center; justify-content:center; font-family:'Nunito'; font-weight:900; font-size:16px; color:var(--rc-orange); text-shadow:0 0 10px rgba(255,76,2,0.5);}
        .rc-tug{height:12px; border-radius:6px; overflow:hidden; display:flex; margin-top:10px; border:1px solid rgba(255,255,255,0.1);}

        /* Flaggen-Wehen */
        @keyframes rc-wave{0%,100%{transform:rotate(-1.6deg) skewX(-2deg);}50%{transform:rotate(1.6deg) skewX(2deg);}}
        .rc-flag-wave{animation:rc-wave 2.4s ease-in-out infinite; transform-origin:left center;}

        /* Motivations-Banner */
        .rc-moti{flex-shrink:0; background:linear-gradient(100deg,rgba(44,87,210,0.28),rgba(255,76,2,0.18));
            border:1px solid rgba(255,255,255,0.12); border-radius:12px; padding:11px 16px; display:flex; align-items:center; gap:12px;
            box-shadow:0 8px 24px rgba(0,0,0,0.35); overflow:hidden;}
        .rc-moti .spk{font-size:22px;}
        .rc-moti-txt{font-family:'Nunito'; font-weight:800; font-size:14px; color:#fff; transition:opacity 0.5s; line-height:1.3;}
        .rc-moti-txt b{color:var(--rc-yellow);}

        /* Marquee */
        .rc-marquee{height:34px; background:rgba(9,14,24,0.9); border-top:1px solid var(--rc-blue); color:#fff;
            display:flex; align-items:center; overflow:hidden; white-space:nowrap; position:relative;
            font-family:'Roboto Mono'; font-size:13px; font-weight:700; flex-shrink:0; box-shadow:0 -5px 15px rgba(0,0,0,0.5);}
        .rc-marquee-content{display:inline-block; padding-left:100%; animation:rc-marquee 90s linear infinite;}
        @keyframes rc-marquee{0%{transform:translateX(0);}100%{transform:translateX(-100%);}}

        /* ===== Feier-Fenster: grosses TOR (neuer Verkauf) + kleiner Rueckblick ===== */
        #rcToastContainer{position:fixed; top:66px; right:20px; z-index:10000001; display:flex; flex-direction:column; gap:10px; max-height:80vh;}
        .rc-toast-recap{background:rgba(13,20,37,0.92); border:1px solid rgba(0,217,255,0.28); border-left:4px solid var(--rc-cyan);
            border-radius:10px; padding:10px 16px; color:#e3ecf5; min-width:240px; font-family:'Nunito'; font-weight:700; font-size:13px;
            display:flex; align-items:center; gap:8px; box-shadow:0 10px 24px rgba(0,0,0,0.5); backdrop-filter:blur(6px);
            animation:rc-recap-in 0.4s cubic-bezier(0.25,1,0.5,1) forwards;}
        .rc-toast-recap b{color:#fff;}
        @keyframes rc-recap-in{from{transform:translateX(120%); opacity:0;} to{transform:translateX(0); opacity:1;}}
        @keyframes rc-toast-out{to{transform:translateX(120%); opacity:0;}}
        /* Grosses TOR-Fenster (zentriert, dramatisch, SEHR gross) */
        .rc-toast-goal{position:fixed; top:50%; left:50%; transform:translate(-50%,-50%); z-index:10000002; pointer-events:none; text-align:center;
            padding:44px 88px; border-radius:26px; min-width:560px; background:linear-gradient(135deg,rgba(9,16,28,0.98),rgba(6,10,18,0.98));
            border:3px solid var(--rc-green); box-shadow:0 0 70px rgba(0,255,120,0.55), 0 40px 100px rgba(0,0,0,0.8);
            animation:rc-goal-in 0.6s cubic-bezier(0.18,1.5,0.5,1) forwards;}
        .rc-toast-goal.special{border-color:var(--rc-yellow); box-shadow:0 0 80px rgba(255,178,0,0.65), 0 40px 100px rgba(0,0,0,0.8);}
        .rc-goal-emoji{font-size:64px; line-height:1;}
        .rc-goal-head{font-family:'Nunito'; font-weight:900; font-size:82px; letter-spacing:10px; color:var(--rc-green); text-shadow:0 0 40px rgba(0,255,120,0.7); margin-top:6px; line-height:1;}
        .rc-toast-goal.special .rc-goal-head{color:var(--rc-yellow); text-shadow:0 0 40px rgba(255,178,0,0.8);}
        .rc-goal-time{display:inline-flex; align-items:center; gap:8px; margin-top:14px; padding:6px 18px; border-radius:9999px;
            background:rgba(0,217,255,0.12); border:1px solid rgba(0,217,255,0.5); font-family:'Roboto Mono'; font-weight:700; font-size:22px; color:var(--rc-cyan); letter-spacing:1px;}
        .rc-goal-city{font-family:'Nunito'; font-weight:900; font-size:34px; color:#fff; margin-top:16px; display:flex; align-items:center; gap:14px; justify-content:center;}
        .rc-goal-name{font-family:'Nunito'; font-weight:900; font-size:30px; color:#fff; margin-top:14px;}
        .rc-goal-name b{color:var(--rc-cyan);}
        .rc-goal-prod{font-size:22px; color:#cfd8e3; margin-top:6px; font-weight:400;}
        .rc-goal-prod b{font-weight:800; color:var(--rc-yellow);}
        @keyframes rc-goal-in{0%{opacity:0; transform:translate(-50%,-50%) scale(0.4);}60%{opacity:1; transform:translate(-50%,-50%) scale(1.06);}100%{opacity:1; transform:translate(-50%,-50%) scale(1);}}
        @keyframes rc-goal-out{to{opacity:0; transform:translate(-50%,-50%) scale(0.85);}}
        /* Screen-Flash beim Tor */
        .rc-goal-flash{position:fixed; inset:0; z-index:10000000; pointer-events:none;
            background:radial-gradient(circle at 50% 38%, rgba(0,255,120,0.32), transparent 55%); animation:rc-flash-anim 0.9s ease-out forwards;}
        .rc-goal-flash.special{background:radial-gradient(circle at 50% 38%, rgba(255,178,0,0.4), transparent 55%);}
        @keyframes rc-flash-anim{0%{opacity:0;}18%{opacity:1;}100%{opacity:0;}}

        #rcMappingModal{display:none; position:fixed; inset:0; background:rgba(5,10,24,0.9); z-index:10000000;
            justify-content:center; align-items:center; backdrop-filter:blur(8px);}
        #rcDropZone{border:2px dashed rgba(44,87,210,0.4); padding:30px 20px; border-radius:12px;
            background:rgba(44,87,210,0.03); cursor:pointer; transition:all 0.2s; margin-bottom:20px; text-align:center;}

        /* ===== Professionelle Kompakt-Overrides (regiocom CD) ===== */
        .rc-duel-side{padding:9px 6px;}
        .rc-duel-vs{font-size:13px;}
        .rc-battle-chip{padding:2px 6px 2px 4px; font-size:9px;}
        .rc-kpi-v{font-size:21px;}
        .rc-kpi{padding:7px 11px;}
        .rc-kpi-strip{padding:8px 14px;}
        .rc-moti{padding:8px 14px;}
        .rc-moti-txt{font-size:13px;}
        .rc-marquee{font-size:12px;}
        .rc-mq-alarm{color:#FF6B6B; font-weight:800;}
        .rc-mq-alarm b{color:#fff; background:rgba(220,20,60,0.35); padding:1px 6px; border-radius:4px;}
        .rc-mq-sep{color:#4a5768;}

        /* ===== Qualitaet-Seite: 3-Spalten-Grid ===== */
        .rc-quali-grid{display:grid; grid-template-columns:300px 1fr 300px; gap:10px; padding:0 10px 10px; flex:1; overflow:hidden;}
        .rc-ziel-chip{display:flex; justify-content:space-between; align-items:center; font-size:11px; padding:5px 9px;
            border-radius:6px; background:rgba(255,255,255,0.03); border:1px solid rgba(255,255,255,0.07); margin-bottom:4px;}
        .rc-det-item{border-left:3px solid #DC143C; background:rgba(220,20,60,0.08); border-radius:6px; padding:7px 10px; margin-bottom:5px;}
        @keyframes rc-det-pulse{0%,100%{box-shadow:0 0 0 0 rgba(220,20,60,0.35);}50%{box-shadow:0 0 10px 2px rgba(220,20,60,0.45);}}
        .rc-det-critical{animation:rc-det-pulse 2.2s ease-in-out infinite;}

        /* ===== Radar-Seite ===== */
        .rc-radar{flex:1; display:none; grid-template-columns:1fr 300px; gap:10px; padding:10px; min-height:0; overflow:hidden;}
        .rc-radar-svgwrap{position:relative; flex:1; min-height:0; display:flex; align-items:center; justify-content:center; overflow:hidden;}
        .rc-radar-svgwrap svg{width:100%; height:100%;}
        @keyframes rc-sweep{from{transform:rotate(0deg);}to{transform:rotate(360deg);}}
        .rc-sweep{animation:rc-sweep 7s linear infinite;}
        @keyframes rc-blip-pulse{0%{transform:scale(1); opacity:0.55;}70%{transform:scale(2.6); opacity:0;}100%{transform:scale(2.6); opacity:0;}}
        .rc-blip-pulse{animation:rc-blip-pulse 2.8s ease-out infinite;}
        @keyframes rc-ping{0%{transform:scale(0.4); opacity:0.9;}100%{transform:scale(5); opacity:0;}}
        .rc-ping-g{animation:rc-ping 2.6s ease-out forwards;}
        .rc-radar-log-item{font-family:'Roboto Mono'; font-size:10.5px; color:#BEE7FF; padding:4px 8px; border-left:2px solid var(--rc-cyan);
            background:rgba(0,217,255,0.05); border-radius:0 5px 5px 0; margin-bottom:4px;}
        .rc-radar-log-item b{color:#fff;}

        /* ===== Ruhige, professionelle Farbwelt (Ueberschreibt Neon-Werte) ===== */
        #rcLiveDashboard{background:
            radial-gradient(1100px 520px at 20% -12%, rgba(44,87,210,0.12), transparent 60%),
            linear-gradient(rgba(13,17,23,0.98), rgba(9,12,17,0.99)) !important;}
        .rc-card{background:rgba(19,24,32,0.94) !important; border:1px solid rgba(255,255,255,0.07) !important; box-shadow:0 6px 20px rgba(0,0,0,0.35) !important;}
        .rc-card::before{height:2px !important; opacity:0.75;}
        .rc-kpi{background:rgba(255,255,255,0.025) !important; border-color:rgba(255,255,255,0.06) !important;}
        .rc-kpi.hot{border-color:rgba(255,178,0,0.28) !important; background:rgba(255,178,0,0.04) !important;}
        .rc-kpi.blue .rc-kpi-v{color:#6fc3e8;} .rc-kpi.green .rc-kpi-v{color:#3fbf8f;}
        .rc-kpi.orange .rc-kpi-v{color:#e8875c;} .rc-kpi.pink .rc-kpi-v{color:#d97ba0;} .rc-kpi.gold .rc-kpi-v{color:#d9a13c;}
        .rc-live-pill{background:rgba(0,152,100,0.12) !important; border-color:rgba(0,152,100,0.45) !important; color:#7fd4b4 !important;}
        .rc-live-dot{background:#00C878 !important;}
        .rc-rank-badge{text-shadow:none !important;}
        .r1{color:#d9a13c !important; border-color:#d9a13c !important;} .r2{color:#6fc3e8 !important; border-color:#6fc3e8 !important;} .r3{color:#e8875c !important; border-color:#e8875c !important;}
        .rc-bar-fill{box-shadow:none !important;}
        .rc-btn:hover{box-shadow:0 3px 10px rgba(0,0,0,0.3) !important;}
        .rc-table th{background:#12161d !important;}
        .rc-marquee{background:rgba(12,16,22,0.95) !important; border-top:1px solid rgba(44,87,210,0.5) !important;}

        /* Dezente Verwaltungs-Buttons (nicht fuer Mitarbeiter-Augen) */
        .rc-btn-ghost{background:rgba(255,255,255,0.04) !important; border:1px solid rgba(255,255,255,0.09); color:#8b98a5 !important;
            font-size:10px !important; padding:4px 9px !important; font-weight:700 !important;}
        .rc-btn-ghost:hover{color:#cfd8e3 !important; transform:none !important;}

        /* Ansprache-Fokus (Warnliste) */
        .rc-warn-item{display:flex; align-items:center; gap:8px; padding:6px 9px; border-radius:6px; margin-bottom:5px;
            background:rgba(255,178,0,0.05); border-left:3px solid #FFB200;}
        .rc-warn-item.hart{background:rgba(220,20,60,0.08); border-left-color:#DC143C;}
        .rc-warn-item .nm{flex:1; font-family:'Nunito'; font-weight:800; font-size:11.5px; color:#fff;}
        .rc-warn-item .wv{font-family:'Roboto Mono'; font-size:10px; color:#9BA7B2;}

        /* EKG-Scanline fuer Monitor-Charts */
        .rc-chartwrap{position:relative; flex:1; padding:4px; min-height:0;}
        .rc-ekg-scan{position:absolute; top:8%; bottom:12%; width:2px; pointer-events:none; opacity:0.5;
            background:linear-gradient(180deg, transparent, rgba(0,217,255,0.7), transparent);
            animation:rc-ekg 7s linear infinite;}
        @keyframes rc-ekg{0%{left:4%;}100%{left:97%;}}

        /* Cockpit (Manager) */
        .rc-cockpit{flex:1; display:none; flex-direction:column; min-height:0; overflow:hidden;}
        .rc-cockpit-grid{display:grid; grid-template-columns:1.1fr 1.3fr 0.9fr; gap:10px; padding:0 10px 10px; flex:1; overflow:hidden;}
        .rc-chip{display:inline-block; font-family:'Nunito'; font-weight:800; font-size:8.5px; padding:2px 6px; border-radius:4px; margin:1px 2px 1px 0; letter-spacing:0.3px;}
        .rc-chip.rot{background:rgba(220,20,60,0.18); color:#ff8f8f; border:1px solid rgba(220,20,60,0.4);}
        .rc-chip.gelb{background:rgba(255,178,0,0.12); color:#e8c377; border:1px solid rgba(255,178,0,0.35);}
        .rc-mailbtn{background:rgba(44,87,210,0.15); border:1px solid rgba(44,87,210,0.4); color:#8fb3ff; border-radius:5px;
            font-family:'Nunito'; font-weight:800; font-size:9.5px; padding:3px 8px; cursor:pointer; text-decoration:none; display:inline-block;}
        .rc-mailbtn:hover{background:rgba(44,87,210,0.3); color:#fff;}
    `;
    document.head.appendChild(styleEl);

    // ============================================================
    //  OVERLAY-STRUKTUR
    // ============================================================
    const overlay = document.createElement('div');
    overlay.id = 'rcLiveDashboard';
    document.body.appendChild(overlay);

    const regiocomLogoSvg = `<svg viewBox="0 0 160 40" width="128" height="30" style="vertical-align:middle;"><g transform="translate(5,2)"><path d="M 5,35 C 5,15 15,5 25,5 C 20,15 18,25 20,35 Z" fill="#009864"/><path d="M 13,35 C 13,18 23,9 33,11 C 29,18 27,26 28,35 Z" fill="#FF4C02"/><path d="M 21,35 C 21,21 31,13 39,17 C 35,23 32,29 32,35 Z" fill="#2C57D2"/></g><text x="48" y="27" font-family="'Nunito',sans-serif" font-weight="900" font-size="20" fill="#FFF" letter-spacing="-0.5">regiocom</text></svg>`;

    const standortOptions = ['<option value="ALL">Alle Standorte</option>']
        .concat(ORDER.map(c => `<option value="${c}">${STANDORT_METADATA[c].name}</option>`)).join('');

    overlay.innerHTML = `
        <div class="rc-header">
            <div class="rc-header-brand">
                ${regiocomLogoSvg}
                <span class="rc-arena-tag">esl live-arena</span>
                <span class="rc-live-pill"><span class="rc-live-dot"></span>LIVE</span>
                <span id="rcFetchStatus" style="font-size:11px; color:#6b7785; font-family:'Roboto Mono';">— warte auf Abruf</span>
            </div>
            <div style="display:flex; align-items:center; gap:14px;">
                <div class="rc-clock"><div id="rcClock">--:--:--</div><small id="rcClockDate">—</small></div>
                <div class="rc-pageswitch">
                    <button class="rc-page-btn active" id="rcPageArena" data-page="arena">Arena</button>
                    <button class="rc-page-btn" id="rcPageQuali" data-page="quali">Qualität</button>
                    <button class="rc-page-btn" id="rcPageRadar" data-page="radar">Radar</button>
                    <button class="rc-page-btn" id="rcPageCockpit" data-page="cockpit">Cockpit</button>
                </div>
                <select id="rcStackFilter" class="rc-select" title="Stack (Abteilung)"><option value="ALL">Alle Stacks</option></select>
                <select id="rcStandortFilter" class="rc-select">${standortOptions}</select>
                <select id="rcTeamFilter" class="rc-select" style="display:none;"><option value="ALL">Alle Teams</option></select>
                <button class="rc-btn rc-btn-ghost" id="rcBtnTest">Test</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnKpiQuelle" title="Ligaliste als KPI-Quelle oeffnen">KPI</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnMapping">Map</button>
                <button class="rc-btn rc-btn-ghost" id="rcBtnToggle">&#10005;</button>
            </div>
        </div>

        <div class="rc-kpi-strip">
            <div class="rc-kpi"><div class="rc-kpi-l">Kontakte</div><div class="rc-kpi-v" id="kpiCalls">0</div></div>
            <div class="rc-kpi blue"><div class="rc-kpi-l">Ansprachen</div><div class="rc-kpi-v" id="kpiPitches">0<small id="kpiPitchRate">0%</small></div></div>
            <div class="rc-kpi green hot"><div class="rc-kpi-l">&#9733; BNT gesamt</div><div class="rc-kpi-v" id="kpiBnt">0<small id="kpiBntRate">0%</small></div></div>
            <div class="rc-kpi gold hot"><div class="rc-kpi-l">&#9733; KIP-BNT</div><div class="rc-kpi-v" id="kpiKip">0</div></div>
            <div class="rc-kpi blue hot"><div class="rc-kpi-l">&#9733; Mobilfunk-BNT</div><div class="rc-kpi-v" id="kpiMob">0</div></div>
            <div class="rc-kpi pink"><div class="rc-kpi-l">VVL</div><div class="rc-kpi-v" id="kpiVvl">0</div></div>
            <div class="rc-kpi"><div class="rc-kpi-l">Angebote offen</div><div class="rc-kpi-v" id="kpiOffers">0</div></div>
            <div class="rc-kpi orange"><div class="rc-kpi-l">Ablehnungen</div><div class="rc-kpi-v" id="kpiRej">0<small id="kpiRejRate">0%</small></div></div>
        </div>

        <div id="rcWarnBar" style="display:none; padding:7px 18px; background:linear-gradient(90deg,rgba(255,76,2,0.28),rgba(255,76,2,0.05)); border-bottom:1px solid rgba(255,76,2,0.45); color:#ffb89a; font-family:'Nunito'; font-weight:800; font-size:12px; flex-shrink:0;"></div>

        <div class="rc-grid" id="rcPageArenaContent">
            <!-- LINKS -->
            <div class="rc-col">
                <div class="rc-card accent-blue" style="flex:1.1;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcBattleTitle">Standort-Battle</h2>
                        <span id="rcBattleHint" style="font-size:9px; color:#9BA7B2; font-family:'Nunito'; font-weight:700;">Flaggen antippen</span>
                    </div>
                    <div class="rc-battle-picker" id="rcNationPicker"></div>
                    <div id="rcNationBattleList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
                <div class="rc-card accent-blue" style="flex:1.3;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcStandorteTitle">Standorte</h2>
                        <div style="display:flex; gap:5px;">
                            <button id="rcTabStdSales" class="rc-btn-tab active">Abschluesse</button>
                            <button id="rcTabStdRates" class="rc-btn-tab">Quoten</button>
                        </div>
                    </div>
                    <div id="rcStandortBattleList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
                <div class="rc-card accent-dark" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Meistverkaufte Produkte</h2></div>
                    <div id="rcTopProductsList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                </div>
            </div>

            <!-- MITTE -->
            <div class="rc-col">
                <div class="rc-moti"><span class="spk"><svg viewBox="0 0 44 44" width="26" height="26" style="display:block;"><path d="M 6,38 C 6,18 16,8 26,8 C 21,18 19,28 21,38 Z" fill="#009864"/><path d="M 14,38 C 14,21 24,12 34,14 C 30,21 28,29 29,38 Z" fill="#FF4C02"/><path d="M 22,38 C 22,24 32,16 40,20 C 36,26 33,32 33,38 Z" fill="#2C57D2"/></svg></span><div class="rc-moti-txt" id="rcMotiText">Live-Arena bereit — der Tag gehoert euch</div></div>
                <div style="display:flex; gap:10px; flex:2.1; min-height:0;">
                    <div class="rc-card" style="flex:1.5; min-width:0;">
                        <div class="rc-card-header">
                            <h2 class="rc-card-title">Agenten-Arena</h2>
                            <div style="display:flex; align-items:center; gap:8px;">
                                <div style="display:flex; gap:5px;">
                                    <button id="rcTabAgTotal" class="rc-btn-tab active">Gesamt</button>
                                    <button id="rcTabAgBnt" class="rc-btn-tab">BNT</button>
                                    <button id="rcTabAgAnsp" class="rc-btn-tab">Ansprachen</button>
                                </div>
                                <span id="rcValidRows" style="font-size:10px; color:#6fc3e8;" class="rc-mono">0 Zeilen</span>
                            </div>
                        </div>
                        <div class="rc-scroll" style="flex:1; background:rgba(0,0,0,0.12); border-radius:8px;">
                            <table class="rc-table">
                                <thead><tr>
                                    <th style="width:34px; text-align:center;">#</th>
                                    <th>Verkaeufer</th>
                                    <th style="width:40px; text-align:center; color:var(--rc-yellow);">KIP</th>
                                    <th style="width:40px; text-align:center; color:var(--rc-cyan);">MOB</th>
                                    <th style="width:40px; text-align:center; color:#3fbf8f;">BNT</th>
                                    <th style="width:40px; text-align:center; color:var(--rc-pink);">VVL</th>
                                    <th style="width:46px; text-align:center; color:#fff;">Ges.</th>
                                </tr></thead>
                                <tbody id="rcAgentLeaderboard"><tr><td colspan="7" style="text-align:center; padding:20px; color:#888;">Lade Daten aus Portal</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                    <div class="rc-card accent-orange" style="flex:1; min-width:0;">
                        <div class="rc-card-header">
                            <h2 class="rc-card-title"><svg viewBox="0 0 24 24" width="13" height="13" style="vertical-align:-2px;"><path d="M12 3 L22 20 H2 Z" fill="none" stroke="#FFB200" stroke-width="2" stroke-linejoin="round"/><line x1="12" y1="10" x2="12" y2="14.5" stroke="#FFB200" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17.2" r="1.1" fill="#FFB200"/></svg> Ansprache-Fokus</h2>
                            <span style="font-size:9px; color:#9BA7B2;">Calls ohne ESL-Ansprache</span>
                        </div>
                        <div id="rcAnspFokus" class="rc-scroll" style="flex:1;">Warte auf KPI-Quelle</div>
                    </div>
                </div>
                <div style="display:flex; gap:10px; flex:1.6; min-height:170px;">
                    <div class="rc-card accent-blue" style="flex:1; min-width:0;">
                        <div class="rc-card-header"><h2 class="rc-card-title">Abschluesse je Standort — kumuliert</h2></div>
                        <div class="rc-chartwrap"><canvas id="rcTrendChart"></canvas><div class="rc-ekg-scan"></div></div>
                    </div>
                    <div class="rc-card accent-blue" style="flex:1; min-width:0;">
                        <div class="rc-card-header"><h2 class="rc-card-title">TNPS-Monitor je Standort</h2><span style="font-size:9px; color:#9BA7B2;">Verlauf, alle 5 Min</span></div>
                        <div class="rc-chartwrap"><canvas id="rcTnpsChart"></canvas><div class="rc-ekg-scan" style="animation-delay:3.5s;"></div></div>
                    </div>
                </div>
            </div>

            <!-- RECHTS -->
            <div class="rc-col">
                <div class="rc-card accent-orange" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">KIP-BNT Liga</h2></div>
                    <div id="rcKipLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-blue" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Mobilfunk-BNT Liga</h2></div>
                    <div id="rcMobLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-pink" style="flex:1;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title" id="rcSideTitle">VVL Liga</h2>
                        <div style="display:flex; gap:5px;">
                            <button id="rcTabSideVvl" class="rc-btn-tab active">VVL</button>
                            <button id="rcTabSideAnsp" class="rc-btn-tab">Ansprachen</button>
                        </div>
                    </div>
                    <div id="rcSideLeaderboard" class="rc-scroll" style="flex:1;">Lade</div>
                </div>
                <div class="rc-card accent-dark" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Live-Abschluss-Ticker</h2></div>
                    <div id="rcTickerList" class="rc-scroll" style="flex:1; font-size:11px;">Lade</div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 2: QUALITÄT ===================== -->
        <div class="rc-quali" id="rcPageQualiContent" style="display:none;">
            <div class="rc-quali-strip">
                <div class="rc-kpi"><div class="rc-kpi-l">Ø CS · Ziel ≥ 90 %</div><div class="rc-kpi-v" id="qKpiCs">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø TNPS · Ziel ≥ 70 %</div><div class="rc-kpi-v" id="qKpiTnps">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø AQ · Ziel ≥ 85 %</div><div class="rc-kpi-v" id="qKpiAufleger">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø FQ · Ziel ≥ 30 %</div><div class="rc-kpi-v" id="qKpiFq">—</div></div>
                <div class="rc-kpi"><div class="rc-kpi-l">Ø AHT · Ziel ≤ 13 Min</div><div class="rc-kpi-v" id="qKpiAht">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Detraktoren heute</div><div class="rc-kpi-v" id="qKpiDet">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Kurz-Calls unter 6 Min</div><div class="rc-kpi-v" id="qKpiKurz">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Nicht-Tracker</div><div class="rc-kpi-v" id="qKpiNonTrack">—</div></div>
            </div>
            <div class="rc-quali-grid">
                <!-- LINKS: Standort-Chart + rotierende Rangliste -->
                <div class="rc-col">
                    <div class="rc-card accent-blue" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title">CS &amp; TNPS je Standort</h2></div>
                        <div class="rc-chartwrap"><canvas id="rcQualiStdChart"></canvas></div>
                    </div>
                    <div class="rc-card accent-blue" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" id="rcQualiRankTitle">Feedbackquote — Top 10</h2><span style="font-size:9px; color:#9BA7B2;">wechselt automatisch</span></div>
                        <div id="rcQualiRank" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                </div>
                <!-- MITTE: Haupttabelle -->
                <div class="rc-card accent-blue" style="min-height:0;">
                    <div class="rc-card-header">
                        <h2 class="rc-card-title">Qualitäts-KPIs je Agent</h2>
                        <div style="display:flex; gap:5px;">
                            <button class="rc-btn-tab active" id="qSortCalls">Calls</button>
                            <button class="rc-btn-tab" id="qSortCs">CS</button>
                            <button class="rc-btn-tab" id="qSortTnps">TNPS</button>
                            <button class="rc-btn-tab" id="qSortFq">FQ</button>
                            <button class="rc-btn-tab" id="qSortAufleger">AQ</button>
                        </div>
                    </div>
                    <div class="rc-scroll" style="flex:1;">
                        <table class="rc-table">
                            <thead><tr>
                                <th style="width:34px; text-align:center;">#</th>
                                <th>Agent</th>
                                <th style="width:56px; text-align:center; color:#6fc3e8;">Calls</th>
                                <th style="width:52px; text-align:center; color:#BEE7FF;">AHT</th>
                                <th style="width:48px; text-align:center;">AQ %</th>
                                <th style="width:48px; text-align:center;">CS %</th>
                                <th style="width:52px; text-align:center;">TNPS %</th>
                                <th style="width:46px; text-align:center;">FQ %</th>
                                <th style="width:48px; text-align:center;">DDS %</th>
                                <th style="width:40px; text-align:center; color:#FF6B6B;">Det</th>
                                <th style="width:52px; text-align:center; color:#fff;">Anspr.</th>
                            </tr></thead>
                            <tbody id="rcQualiBody"><tr><td colspan="11" style="text-align:center; padding:24px; color:#888;">Warte auf KPI-Quelle — Button oben rechts nutzen</td></tr></tbody>
                        </table>
                    </div>
                </div>
                <!-- RECHTS: Detraktoren-Alarm + Kurz-Telefonierer -->
                <div class="rc-col">
                    <div class="rc-card accent-orange" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" style="color:#FF6B6B;">Detraktoren — Handlung erforderlich</h2></div>
                        <div id="rcDetraktorList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                    <div class="rc-card accent-orange" style="flex:1;">
                        <div class="rc-card-header"><h2 class="rc-card-title" style="color:#FFB200;">Kurz-Telefonierer — unter 6 Min</h2><span style="font-size:9px; color:#9BA7B2;">Risiko fuer Loesungsquote</span></div>
                        <div id="rcKurzTelList" class="rc-scroll" style="flex:1;">Warte auf Daten</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 3: RADAR ===================== -->
        <div class="rc-radar" id="rcPageRadarContent">
            <div class="rc-card accent-blue" style="min-height:0;">
                <div class="rc-card-header">
                    <h2 class="rc-card-title">Operation Live-Arena — Luftraum Europa</h2>
                    <span class="rc-mono" style="font-size:10px; color:var(--rc-cyan);" id="rcRadarStatusLine">SYSTEM AKTIV</span>
                </div>
                <div class="rc-radar-svgwrap" id="rcRadarSvgWrap"></div>
            </div>
            <div class="rc-col">
                <div class="rc-card accent-blue" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title" id="rcRadarChartATitle">Abschluesse je Standort</h2><span style="font-size:9px; color:#9BA7B2;">wechselt automatisch</span></div>
                    <div class="rc-chartwrap"><canvas id="rcRadarChartA"></canvas></div>
                </div>
                <div class="rc-card accent-blue" style="flex:1;">
                    <div class="rc-card-header"><h2 class="rc-card-title" id="rcRadarChartBTitle">CR-BNT je Standort</h2><span style="font-size:9px; color:#9BA7B2;">wechselt automatisch</span></div>
                    <div class="rc-chartwrap"><canvas id="rcRadarChartB"></canvas></div>
                </div>
                <div class="rc-card accent-dark" style="flex:0.9;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Einsatz-Log</h2></div>
                    <div id="rcRadarLog" class="rc-scroll" style="flex:1;"><div style="color:#5a6b7d; font-size:11px; font-family:'Roboto Mono';">— Warte auf Abschluesse —</div></div>
                </div>
            </div>
        </div>

        <!-- ===================== SEITE 4: COCKPIT (Manager / Teamleiter) ===================== -->
        <div class="rc-cockpit" id="rcPageCockpitContent">
            <div class="rc-quali-strip">
                <div class="rc-kpi"><div class="rc-kpi-l">Kontakte</div><div class="rc-kpi-v" id="ckKontakte">—</div></div>
                <div class="rc-kpi blue"><div class="rc-kpi-l">Ansprachen · Quote</div><div class="rc-kpi-v" id="ckAnspr">—</div></div>
                <div class="rc-kpi green"><div class="rc-kpi-l">BNT · CR-BNT</div><div class="rc-kpi-v" id="ckBnt">—</div></div>
                <div class="rc-kpi pink"><div class="rc-kpi-l">VVL · CR-VVL</div><div class="rc-kpi-v" id="ckVvl">—</div></div>
                <div class="rc-kpi orange"><div class="rc-kpi-l">Kritische Agenten</div><div class="rc-kpi-v" id="ckKrit">—</div></div>
                <div class="rc-kpi" style="display:flex; align-items:center; justify-content:center; gap:8px; flex-wrap:wrap;">
                    <button class="rc-btn rc-btn-blue" id="ckBtnExport" style="font-size:11px;">Excel-Export</button>
                    <a class="rc-mailbtn" id="ckBtnMailAll" href="#" style="font-size:10.5px; padding:6px 12px;">Mail an Teamleitung</a>
                </div>
            </div>
            <div class="rc-cockpit-grid">
                <div class="rc-card accent-blue" style="min-height:0;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Team-Leistung</h2><span style="font-size:9px; color:#9BA7B2;">schwaechste zuerst</span></div>
                    <div class="rc-scroll" style="flex:1;">
                        <table class="rc-table"><thead><tr>
                            <th>Team</th><th style="width:44px; text-align:center;">Kont.</th>
                            <th style="width:52px; text-align:center;">Anspr %</th>
                            <th style="width:40px; text-align:center;">BNT</th><th style="width:56px; text-align:center;">CR-BNT</th>
                            <th style="width:40px; text-align:center;">VVL</th><th style="width:56px; text-align:center;">CR-VVL</th>
                        </tr></thead><tbody id="rcCkTeams"><tr><td colspan="7" style="text-align:center; padding:18px; color:#888;">Lade Daten</td></tr></tbody></table>
                    </div>
                </div>
                <div class="rc-card accent-orange" style="min-height:0;">
                    <div class="rc-card-header"><h2 class="rc-card-title" style="color:#FF6B6B;">Kritische Agenten — Handlungsbedarf</h2><span style="font-size:9px; color:#9BA7B2;">Sales + Qualitaet kombiniert</span></div>
                    <div id="rcCkKrit" class="rc-scroll" style="flex:1;">Lade Daten</div>
                </div>
                <div class="rc-card accent-blue" style="min-height:0;">
                    <div class="rc-card-header"><h2 class="rc-card-title">Standort-Leistung</h2></div>
                    <div class="rc-scroll" style="flex:1;">
                        <table class="rc-table"><thead><tr>
                            <th>Standort</th><th style="width:44px; text-align:center;">Kont.</th>
                            <th style="width:40px; text-align:center;">BNT</th><th style="width:56px; text-align:center;">CR-BNT</th>
                            <th style="width:40px; text-align:center;">VVL</th><th style="width:56px; text-align:center;">CR-VVL</th>
                        </tr></thead><tbody id="rcCkStd"><tr><td colspan="6" style="text-align:center; padding:18px; color:#888;">Lade Daten</td></tr></tbody></table>
                    </div>
                </div>
            </div>
        </div>

        <div class="rc-marquee"><div class="rc-marquee-content" id="rcNewsMarquee">+++ LIVE-ARENA BEREIT +++ DATEN WERDEN GELADEN +++</div></div>
    `;

    const toastContainer = document.createElement('div');
    toastContainer.id = 'rcToastContainer';
    document.body.appendChild(toastContainer);

    const badge = document.createElement('div');
    badge.id = 'rcLiveBadge';
    Object.assign(badge.style, {display:'none', position:'fixed', bottom:'20px', right:'20px',
        background:'linear-gradient(135deg,var(--rc-blue),var(--rc-orange))', color:'#fff', padding:'12px 20px',
        borderRadius:'30px', cursor:'pointer', zIndex:'9999999', fontWeight:'bold', fontFamily:"'Nunito'"});
    badge.innerHTML = 'Live-Arena oeffnen';
    document.body.appendChild(badge);

    const modal = document.createElement('div');
    modal.id = 'rcMappingModal';
    modal.innerHTML = `
        <div class="rc-card" style="width:400px; text-align:center; border-color:rgba(44,87,210,0.4);">
            <h3 style="font-family:'Nunito'; font-weight:900; margin:0 0 10px;">Mitarbeiter-Mapping</h3>
            <p style="font-size:12px; color:#9BA7B2; margin-bottom:20px;">Lade die Mitarbeiter_ID_Und_Namen.xlsx hoch.</p>
            <div id="rcDropZone">
                <div style="font-size:32px; margin-bottom:10px; color:var(--rc-blue);">&#128193;</div>
                <div style="font-size:13px; font-weight:bold;">Datei hier ablegen oder klicken</div>
                <input type="file" id="rcFileInput" accept=".xlsx" style="display:none;"/>
            </div>
            <button class="rc-btn rc-btn-gray" id="rcBtnCancelMapping">Abbrechen</button>
        </div>`;
    document.body.appendChild(modal);

    // Standort-Picker aufbauen (Flagge + Kuerzel; ein Land kann mehrere Standorte haben)
    (function buildBattlePicker(){
        const p = document.getElementById('rcNationPicker');
        p.innerHTML = ORDER.map(code =>
            `<div class="rc-battle-chip ${window.rcSelectedStandorte.has(code)?'on':''}" data-std="${code}" title="${STANDORT_METADATA[code].name}">${getFlagSvg(code,'small')}<span>${code}</span></div>`
        ).join('');
        p.querySelectorAll('.rc-battle-chip').forEach(chip => {
            chip.addEventListener('click', () => {
                const c = chip.dataset.std;
                const sel = window.rcSelectedStandorte;
                if (sel.has(c)) { if (sel.size > 1) sel.delete(c); }
                else {
                    // Duell-Format: max. 2 — beim dritten Klick faellt der zuerst gewaehlte raus
                    if (sel.size >= 2) sel.delete(sel.values().next().value);
                    sel.add(c);
                }
                localStorage.setItem('rcSelectedStandorte', JSON.stringify([...sel]));
                p.querySelectorAll('.rc-battle-chip').forEach(ch => ch.classList.toggle('on', sel.has(ch.dataset.std)));
                if (window.rcLetzteStats) renderStandortBattle(window.rcLetzteStats.standortStats);
            });
        });
    })();

    // ============================================================
    //  STATE & EVENTS
    // ============================================================
    window.rcActiveStandortTab = 'sales';
    window.rcActiveAgentTab = 'total';
    window.rcActiveSideTab = 'vvl';

    function bindTab(id, group, val, cb){
        document.getElementById(id).addEventListener('click', () => {
            group.forEach(g => document.getElementById(g).classList.remove('active'));
            document.getElementById(id).classList.add('active');
            cb(val);
            if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        });
    }
    bindTab('rcTabStdSales', ['rcTabStdSales','rcTabStdRates'], 'sales', v => window.rcActiveStandortTab=v);
    bindTab('rcTabStdRates', ['rcTabStdSales','rcTabStdRates'], 'rates', v => window.rcActiveStandortTab=v);
    bindTab('rcTabAgTotal', ['rcTabAgTotal','rcTabAgBnt','rcTabAgAnsp'], 'total', v => window.rcActiveAgentTab=v);
    bindTab('rcTabAgBnt',   ['rcTabAgTotal','rcTabAgBnt','rcTabAgAnsp'], 'bnt',   v => window.rcActiveAgentTab=v);
    bindTab('rcTabAgAnsp',  ['rcTabAgTotal','rcTabAgBnt','rcTabAgAnsp'], 'ansp',  v => window.rcActiveAgentTab=v);
    bindTab('rcTabSideVvl',  ['rcTabSideVvl','rcTabSideAnsp'], 'vvl',  v => { window.rcActiveSideTab=v; document.getElementById('rcSideTitle').textContent='VVL Liga'; });
    bindTab('rcTabSideAnsp', ['rcTabSideVvl','rcTabSideAnsp'], 'ansp', v => { window.rcActiveSideTab=v; document.getElementById('rcSideTitle').textContent='Top-Ansprachen'; });

    window.toggleDashboard = v => { document.getElementById('rcLiveDashboard').style.display = v?'flex':'none'; document.getElementById('rcLiveBadge').style.display = v?'none':'flex'; };
    window.openMappingModal = () => document.getElementById('rcMappingModal').style.display='flex';
    window.closeMappingModal = () => document.getElementById('rcMappingModal').style.display='none';
    document.getElementById('rcBtnToggle').addEventListener('click', () => window.toggleDashboard(false));
    badge.addEventListener('click', () => window.toggleDashboard(true));
    document.getElementById('rcBtnMapping').addEventListener('click', window.openMappingModal);
    document.getElementById('rcBtnCancelMapping').addEventListener('click', window.closeMappingModal);
    document.getElementById('rcBtnTest').addEventListener('click', () => window.simulateFakeSale());
    document.getElementById('rcBtnKpiQuelle').addEventListener('click', () => window.rcOpenKpiQuelle());
    document.getElementById('rcStandortFilter').addEventListener('change', () => {
        // Standort gewechselt -> Team-Auswahl zuruecksetzen (altes Team gilt im neuen Standort nicht)
        const ts = document.getElementById('rcTeamFilter'); if (ts) { ts.value = 'ALL'; ts.dataset.sig = ''; }
        if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
    });
    document.getElementById('rcTeamFilter').addEventListener('change', () => { if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom); });

    // ---- Seitenumschaltung Arena / Qualität / Radar ----
    window.rcActivePage = 'arena';
    window.rcQualiSort = 'calls';
    const RC_PAGES = { arena:['rcPageArena','rcPageArenaContent','grid'], quali:['rcPageQuali','rcPageQualiContent','flex'], radar:['rcPageRadar','rcPageRadarContent','grid'], cockpit:['rcPageCockpit','rcPageCockpitContent','flex'] };
    function switchPage(page){
        window.rcActivePage = page;
        Object.entries(RC_PAGES).forEach(([p,[btnId,contentId,disp]]) => {
            document.getElementById(btnId).classList.toggle('active', p===page);
            document.getElementById(contentId).style.display = p===page ? disp : 'none';
        });
        if (page==='quali' && window.renderQualitaet) window.renderQualitaet();
        if (page==='radar') { if (window.renderRadar) window.renderRadar(); if (window.renderRadarCharts) window.renderRadarCharts(window.rcRotState||0); }
        if (page==='cockpit' && window.renderCockpit) window.renderCockpit();
    }
    Object.keys(RC_PAGES).forEach(p => document.getElementById(RC_PAGES[p][0]).addEventListener('click', () => switchPage(p)));

    // ---- Qualität Sortier-Tabs ----
    const Q_SORT_TABS = [['qSortCalls','calls'],['qSortCs','cs'],['qSortTnps','tnps'],['qSortFq','fq'],['qSortAufleger','auflegerquote']];
    Q_SORT_TABS.forEach(([id,key]) => {
        const btn = document.getElementById(id); if (!btn) return;
        btn.addEventListener('click', () => {
            window.rcQualiSort = key;
            Q_SORT_TABS.forEach(([x]) => { const b = document.getElementById(x); if (b) b.classList.remove('active'); });
            btn.classList.add('active');
            if (window.renderQualitaet) window.renderQualitaet();
        });
    });

    // ---- Auto-Rotation: alle 30 s wechseln die Modul-Ansichten (mehr Bewegung auf dem Monitor) ----
    window.rcRotState = 0;
    window.rcQualiRankMode = 'fq';
    window.rcRotateInterval = setInterval(() => {
        window.rcRotState++;
        const lr = window.rcLastRender;
        try {
            if (window.rcActivePage === 'arena' && lr) {
                // Standorte/Teams: Abschluesse <-> Quoten
                window.rcActiveStandortTab = (window.rcRotState % 2) ? 'rates' : 'sales';
                document.getElementById('rcTabStdSales').classList.toggle('active', window.rcActiveStandortTab==='sales');
                document.getElementById('rcTabStdRates').classList.toggle('active', window.rcActiveStandortTab==='rates');
                // Agenten-Arena: Gesamt -> BNT -> Ansprachen
                const agTabs = ['total','bnt','ansp'];
                window.rcActiveAgentTab = agTabs[window.rcRotState % 3];
                [['rcTabAgTotal','total'],['rcTabAgBnt','bnt'],['rcTabAgAnsp','ansp']].forEach(([id,v]) => document.getElementById(id).classList.toggle('active', v===window.rcActiveAgentTab));
                // Seitenkarte: VVL <-> Ansprachen
                window.rcActiveSideTab = (window.rcRotState % 2) ? 'ansp' : 'vvl';
                document.getElementById('rcTabSideVvl').classList.toggle('active', window.rcActiveSideTab==='vvl');
                document.getElementById('rcTabSideAnsp').classList.toggle('active', window.rcActiveSideTab==='ansp');
                document.getElementById('rcSideTitle').textContent = window.rcActiveSideTab==='ansp' ? 'Top-Ansprachen' : 'VVL Liga';
                window.renderAgents(lr.agentsArr);
                renderSide(lr.agentsArr, lr.filterVal);
                if (lr.filterVal !== 'ALL') renderStandorte(lr.teamStats, true); else renderStandorte(lr.standortStats, false);
            }
            if (window.rcActivePage === 'quali' && window.renderQualitaet) {
                window.rcQualiRankMode = (window.rcRotState % 2) ? 'tnps' : 'fq';
                window.renderQualitaet();
            }
            if (window.rcActivePage === 'radar' && window.renderRadarCharts) window.renderRadarCharts(window.rcRotState);
        } catch(e) { rcLog.warn('Rotation:', e); }
    }, 30000);

    // Drag & Drop Mapping
    (function(){
        const dz = document.getElementById('rcDropZone'), fi = document.getElementById('rcFileInput');
        const read = f => { const r = new FileReader(); r.onload = e => verarbeiteMappingExcel(e.target.result); r.readAsArrayBuffer(f); };
        dz.addEventListener('click', () => fi.click());
        fi.addEventListener('change', e => { if (e.target.files[0]) read(e.target.files[0]); });
        dz.addEventListener('dragover', e => { e.preventDefault(); dz.style.borderColor='var(--rc-orange)'; });
        dz.addEventListener('dragleave', () => dz.style.borderColor='rgba(44,87,210,0.4)');
        dz.addEventListener('drop', e => { e.preventDefault(); dz.style.borderColor='rgba(44,87,210,0.4)';
            const f = e.dataTransfer.files[0]; if (f && f.name.endsWith('.xlsx')) read(f); else alert('Bitte eine .xlsx Datei nutzen.'); });
    })();

    function verarbeiteMappingExcel(arrayBuffer) {
        if (!window.XLSX) return;
        try {
            const wb = XLSX.read(new Uint8Array(arrayBuffer), { type:'array' });
            const s1 = wb.SheetNames.find(n => /name|id|mitarbeiter/i.test(n)) || wb.SheetNames[0];
            const s2 = wb.SheetNames.find(n => /ort|standort/i.test(n)) || wb.SheetNames[1];
            const data = XLSX.utils.sheet_to_json(wb.Sheets[s1], { header:1 });
            let voMap={}, ccsMap={}, standortMap={};
            if (data.length) {
                const h = data[0].map(x => (x||'').toString().toLowerCase().trim());
                const si=h.indexOf('standort'), ti=h.indexOf('team'), ci=h.indexOf('ccs_user'), ni=h.indexOf('namen'), vi=h.indexOf('vo_nummer');
                for (let i=1;i<data.length;i++){ const r=data[i]; if(!r||!r.length) continue;
                    const vo=(r[vi]||'').toString().trim(), ccs=(r[ci]||'').toString().trim();
                    const info = { name:(r[ni]||'').toString().trim(), team:(r[ti]||'').toString().trim(), standort:(r[si]||'').toString().trim(), ccsId:ccs };
                    if (!info.name) continue;
                    if (vo) voMap[vo]=info; if (ccs) ccsMap[ccs]=info;
                }
            }
            if (s2) {
                const sd = XLSX.utils.sheet_to_json(wb.Sheets[s2], { header:1 });
                if (sd.length) {
                    const h = sd[0].map(x => (x||'').toString().toLowerCase().trim());
                    const ci = h.findIndex(x => x.includes('abk')||x.includes('code')); const ni = h.findIndex(x => !x.includes('abk')&&x.includes('ort'));
                    const cIdx = ci!==-1?ci:1, nIdx = ni!==-1?ni:0;
                    for (let i=1;i<sd.length;i++){ const r=sd[i]; if(!r) continue;
                        const abk=(r[cIdx]||'').toString().toUpperCase().trim(), full=(r[nIdx]||'').toString().trim();
                        if (abk&&full) standortMap[abk]=full;
                    }
                }
            }
            // Blatt "Stacks_Und_Die_Teams": Standort | Stack | Team -> Team-zu-Stack-Zuordnung
            let stackMap = {};
            const s3 = wb.SheetNames.find(n => /stack/i.test(n));
            if (s3) {
                const sd = XLSX.utils.sheet_to_json(wb.Sheets[s3], { header:1 });
                if (sd.length) {
                    const h = sd[0].map(x => (x||'').toString().toLowerCase().trim());
                    const si = h.findIndex(x => x.includes('stack')), ti = h.findIndex(x => x.includes('team'));
                    const sIdx = si!==-1?si:1, tIdx = ti!==-1?ti:2;
                    for (let i=1;i<sd.length;i++){ const r=sd[i]; if(!r) continue;
                        const stack=(r[sIdx]||'').toString().trim(), teamId=(r[tIdx]||'').toString().trim();
                        if (stack && teamId) stackMap[teamId]=stack;
                    }
                }
            }
            window.rcWcaMapping = { voMap, ccsMap, standortMap, stackMap };
            localStorage.setItem('rcWcaMapping', JSON.stringify(window.rcWcaMapping));
            updateStackFilterOptions();
            window.closeMappingModal();
            if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
        } catch(e){ rcLog.error('Mapping-Fehler:', e); }
    }

    // Stack-Dropdown aus dem Mapping befuellen (Stacks = getrennte Abteilungen)
    function updateStackFilterOptions(){
        const sel = document.getElementById('rcStackFilter');
        if (!sel) return;
        const stacks = [...new Set(Object.values((window.rcWcaMapping && window.rcWcaMapping.stackMap) || {}))].sort();
        const cur = sel.value;
        sel.innerHTML = '<option value="ALL">Alle Stacks</option>' + stacks.map(s => `<option value="${s}">${s}</option>`).join('');
        sel.value = stacks.includes(cur) ? cur : 'ALL';
        sel.style.display = stacks.length ? '' : 'none';
    }
    updateStackFilterOptions();
    document.getElementById('rcStackFilter').addEventListener('change', () => {
        const ts = document.getElementById('rcTeamFilter'); if (ts) { ts.value = 'ALL'; ts.dataset.sig = ''; }
        if (window.rcLetzterDatenstrom) window.processDataStream(window.rcLetzterDatenstrom);
    });
    document.getElementById('ckBtnExport').addEventListener('click', () => { if (window.rcExportReport) window.rcExportReport(); });

    // ============================================================
    //  UHR + MOTIVATIONS-SPRUECHE
    // ============================================================
    function tickClock(){
        const n = new Date();
        const c=document.getElementById('rcClock'), d=document.getElementById('rcClockDate');
        if (c) c.textContent = n.toLocaleTimeString('de-DE');
        if (d) d.textContent = n.toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit',year:'numeric'});
    }
    window.rcClockInterval = setInterval(tickClock, 1000); tickClock();

    window.rcMotiSprueche = [
        'Jeder Anruf ist eine neue Chance — pack ihn',
        'KIP und Mobilfunk zaehlen doppelt fuers Team',
        'Wer heute dranbleibt, steht morgen ganz oben',
        'Ein Laecheln hoert man auch am Telefon',
        'Der naechste Abschluss wartet nur auf dich',
        'Teamgeist schlaegt Einzelkaempfer — gemeinsam nach vorn'
    ];
    let motiIdx = 0;
    window.rcSprucheInterval = setInterval(() => {
        const el = document.getElementById('rcMotiText'); if (!el) return;
        // abwechselnd echter Datenspruch (falls vorhanden) und Standardspruch
        let line;
        if (window.rcDynamicMoti && window.rcDynamicMoti.length && motiIdx % 2 === 0) {
            line = window.rcDynamicMoti[Math.floor(Math.random()*window.rcDynamicMoti.length)];
        } else {
            line = window.rcMotiSprueche[motiIdx % window.rcMotiSprueche.length];
        }
        el.style.opacity = 0;
        setTimeout(() => { el.innerHTML = line; el.style.opacity = 1; }, 300);
        motiIdx++;
    }, 6500);

    // ============================================================
    //  ZAHLEN-ANIMATION (Count-up)
    // ============================================================
    function setNum(el, n){ const v = n.toLocaleString('de-DE');
        if (el.firstChild && el.firstChild.nodeType === 3) el.firstChild.nodeValue = v; else el.textContent = v; }
    function animateCount(el, to) {
        if (!el) return;
        to = Math.round(to || 0);
        const from = parseInt(el.dataset.v || '0') || 0;
        el.dataset.v = to;
        el.style.animation = 'none'; void el.offsetHeight; el.style.animation = 'rc-kpi-flash 0.5s ease-out';
        if (from === to) { setNum(el, to); return; }
        const dur = 650, st = performance.now();
        // Backstop: garantiert den Endwert, auch wenn requestAnimationFrame pausiert (Tab im Hintergrund)
        setTimeout(() => { if (parseInt(el.dataset.v) === to) setNum(el, to); }, dur + 140);
        (function step(now){
            const p = Math.min((now-st)/dur, 1), e = 1-Math.pow(1-p,3);
            if (parseInt(el.dataset.v) !== to) return; // neuere Animation hat uebernommen
            setNum(el, Math.round(from + (to-from)*e));
            if (p < 1) requestAnimationFrame(step);
        })(performance.now());
    }

    // ============================================================
    //  TOASTS + KONFETTI
    // ============================================================
    // Grosses TOR-Fenster fuer NEUE Verkaeufe (zentriert, Screen-Flash, Konfetti)
    function showGoal(name, produkt, code, timeStr){
        const meta = STANDORT_METADATA[code];
        const city = meta ? meta.name.toUpperCase() : code;
        const special = /KIP BNT|MOBILFUNK/i.test(produkt);
        const flash = document.createElement('div');
        flash.className = 'rc-goal-flash' + (special ? ' special' : '');
        document.body.appendChild(flash);
        setTimeout(() => flash.remove(), 900);
        const g = document.createElement('div');
        g.className = 'rc-toast-goal' + (special ? ' special' : '');
        const head = special ? 'TOP-ABSCHLUSS' : 'ABSCHLUSS';
        const zeit = timeStr || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'});
        const iconCol = special ? '#FFB200' : '#00FF63';
        // Flat-Line-Badge im regiocom-Stil: Ring + Haken + Strahlen (kein Emoji)
        const badgeSvg = `<svg viewBox="0 0 96 96" width="76" height="76" style="display:block; margin:0 auto;">
            <circle cx="48" cy="48" r="30" fill="none" stroke="${iconCol}" stroke-width="4" opacity="0.9"/>
            <circle cx="48" cy="48" r="38" fill="none" stroke="${iconCol}" stroke-width="1.5" opacity="0.35"/>
            <path d="M34 48 L44 58 L63 38" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>
            <g stroke="${iconCol}" stroke-width="3" stroke-linecap="round" opacity="0.8">
                <line x1="48" y1="2"  x2="48" y2="12"/><line x1="48" y1="84" x2="48" y2="94"/>
                <line x1="2"  y1="48" x2="12" y2="48"/><line x1="84" y1="48" x2="94" y2="48"/>
                <line x1="15" y1="15" x2="22" y2="22"/><line x1="74" y1="74" x2="81" y2="81"/>
                <line x1="81" y1="15" x2="74" y2="22"/><line x1="22" y1="74" x2="15" y2="81"/>
            </g></svg>`;
        g.innerHTML = `${badgeSvg}
            <div class="rc-goal-head" style="font-size:56px; letter-spacing:6px;">${head}</div>
            <div class="rc-goal-time">${zeit} Uhr</div>
            <div class="rc-goal-city">${getFlagSvg(code,'xl',true)} ${city}</div>
            <div class="rc-goal-name"><b>${name}</b> <span style="color:#9BA7B2; font-size:18px;">(${code})</span></div>
            <div class="rc-goal-prod">erzielt <b>${produkt}</b></div>`;
        document.body.appendChild(g);
        if (window.confetti) {
            if (special) { confetti({particleCount:160,spread:100,origin:{y:0.6}}); setTimeout(()=>confetti({particleCount:110,spread:120,origin:{y:0.5}}),350); setTimeout(()=>confetti({particleCount:110,spread:80,origin:{y:0.7}}),800); }
            else confetti({ particleCount:110, spread:85, origin:{y:0.6} });
        }
        const dur = special ? 6500 : 4800;
        setTimeout(() => { g.style.animation = 'rc-goal-out 0.4s forwards'; setTimeout(() => g.remove(), 400); }, dur);
    }

    // Feier-Queue: NUR echte Abschluesse (Rueckblick-Toasts wurden entfernt — wirkten unklar/unprofessionell)
    window.rcCelebrationQueue = []; window.rcIsCelebrating = false;
    function queueCelebration(name, prod, standort, timeStr){
        window.rcCelebrationQueue.push({name,prod,standort,timeStr});
        processCelebrationQueue();
    }
    function processCelebrationQueue(){
        if (window.rcIsCelebrating || !window.rcCelebrationQueue.length) return;
        window.rcIsCelebrating = true;
        const it = window.rcCelebrationQueue.shift();
        showGoal(it.name, it.prod, it.standort, it.timeStr);
        const special = /KIP BNT|MOBILFUNK/i.test(it.prod);
        setTimeout(() => { window.rcIsCelebrating = false; processCelebrationQueue(); }, special ? 7000 : 5200);
    }
    window.simulateFakeSale = function(){
        const names=["Deniz T.","Ahmet A.","Ebru D.","Oezlem T.","Saray S.","Yeliz A.","Uemit D.","Lara D.","Cihan G."];
        const st=["AL","SER","ADP","B","P","E","ZWT"]; const pr=["Kip BNT","Mobilfunk BNT","Env BNT","VVL (Up-Selling)"];
        queueCelebration(names[Math.random()*names.length|0], pr[Math.random()*pr.length|0], st[Math.random()*st.length|0], new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}));
    };

    // ============================================================
    //  DATUM / ZEIT
    // ============================================================
    function parseDateTime(rawVal){
        if (rawVal === '' || rawVal == null) return null;
        if (typeof rawVal === 'number') { const d = new Date(Math.round((rawVal-25569)*86400*1000)); return isNaN(d)?null:{date:d, hasTime:(rawVal%1!==0)}; }
        const str = rawVal.toString().trim();
        const tm = str.match(/^(\d{1,2}):(\d{2})(?::(\d{2}))?$/);
        if (tm) { const t=new Date(); return {date:new Date(t.getFullYear(),t.getMonth(),t.getDate(),+tm[1],+tm[2],tm[3]?+tm[3]:0), hasTime:true}; }
        const dtm = str.match(/(\d{1,2})[.\/](\d{1,2})[.\/](\d{2,4})[ T]+(\d{1,2}):(\d{2})/);
        if (dtm) { let y=+dtm[3]; if(y<100)y+=2000; return {date:new Date(y,dtm[2]-1,+dtm[1],+dtm[4],+dtm[5]), hasTime:true}; }
        const d = new Date(str);
        if (!isNaN(d)) return {date:d, hasTime:str.includes(':')};
        return null;
    }
    const pad2 = n => n.toString().padStart(2,'0');
    const getTimeString = d => d ? `${pad2(d.getHours())}:${pad2(d.getMinutes())}` : '';

    // ============================================================
    //  KATEGORISIERUNG
    // ============================================================
    // Gibt zurueck: {cat, isBnt, isVvl}  cat in kip|mob|env|fibDsl|ptv|sonstBnt|kipVvl|mobVvl|fibVvl|null
    function classify(pgRaw){
        const pg = (pgRaw||'').toString().toUpperCase();
        if (pg.includes('VVL')) {
            if (pg.includes('MOBILFUNK')) return {cat:'mobVvl', isBnt:false, isVvl:true};
            if (pg.includes('KIP')) return {cat:'kipVvl', isBnt:false, isVvl:true};
            return {cat:'fibVvl', isBnt:false, isVvl:true};
        }
        if (pg.includes('KIP') && pg.includes('BNT')) return {cat:'kip', isBnt:true, isVvl:false};
        if (pg.includes('MOBILFUNK') && pg.includes('BNT')) return {cat:'mob', isBnt:true, isVvl:false};
        if (pg.includes('ENV') && pg.includes('BNT')) return {cat:'env', isBnt:true, isVvl:false};
        if (pg.includes('DSL')||pg.includes('FIB')||pg.includes('KABEL')||pg.includes('GLASFASER')) return {cat:'fibDsl', isBnt:true, isVvl:false};
        if (pg.includes('PTV')||pg.includes('PREMIUM')) return {cat:'ptv', isBnt:true, isVvl:false};
        if (pg.includes('BNT')) return {cat:'sonstBnt', isBnt:true, isVvl:false};
        return {cat:null, isBnt:false, isVvl:false};
    }
    const bntOf = o => (o.kip||0)+(o.mob||0)+(o.env||0)+(o.fibDsl||0)+(o.ptv||0)+(o.sonstBnt||0);
    const vvlOf = o => (o.kipVvl||0)+(o.mobVvl||0)+(o.fibVvl||0);

    // ============================================================
    //  HAUPT-VERARBEITUNG
    // ============================================================
    if (!window.rcCelebratedSales) window.rcCelebratedSales = new Set(); // schon gefeierte Verkaufszeilen (id|kategorie|menge)
    window.rcIsInitialized = false;
    window.rcNewsHistorie = [];
    window.rcMarqueeBuffer = [];
    window.rcRowHourMap = window.rcRowHourMap || new Map();

    window.processDataStream = function(sheetData) {
      try {
        if (!sheetData || !Array.isArray(sheetData) || !sheetData.length) return;
        window.rcLetzterDatenstrom = sheetData;
        window.rcAllSales = [];
        const filterVal = document.getElementById('rcStandortFilter').value;
        const teamSel = document.getElementById('rcTeamFilter');
        const filterTeam = (filterVal !== 'ALL' && teamSel) ? teamSel.value : 'ALL';
        const stackSel = document.getElementById('rcStackFilter');
        const filterStack = stackSel ? stackSel.value : 'ALL';
        const mapping = window.rcWcaMapping;
        const stackMap = (mapping && mapping.stackMap) || {};
        const stackOf = t => stackMap[(t||'').toString().trim()] || '';
        window.rcStackOf = stackOf; // fuer Qualitaet/Cockpit
        const teamsByStd = {}; // { code: Set(team) }  fuer das Team-Dropdown

        // Spalten-Indizes (Defaults + Header-Erkennung)
        let idx = { datum:0, standort:1, team:2, vo:3, prod:5, erg:8, anz:9, grund:-1, ansp:-1, id:-1 };
        const h = sheetData[0].map(x => (x||'').toString().toLowerCase().trim());
        const set = (key, ...names) => { for (const nm of names){ const i = h.indexOf(nm); if (i!==-1){ idx[key]=i; return; } } };
        set('datum','datum'); set('standort','standort'); set('team','team'); set('vo','vo_nummer','vo-nummer','vo');
        set('prod','produktgruppe','produktgrupe','produktgruppen'); set('erg','ergebnis','status'); set('anz','anzahl','anz');
        set('ansp','sis_angesprochen','angesprochen'); set('id','id');
        const gi = h.findIndex(x => x.includes('nicht_moeglich')||x.includes('nicht moeglich')||x.includes('grund')); if (gi!==-1) idx.grund=gi;

        const agentStats = {}, standortStats = {}, teamStats = {};
        const nationStats = { TR:blankNation(), GR:blankNation(), DE:blankNation(), AT:blankNation() };
        let gBnt=0, gRej=0, gVvl=0, gKip=0, gMob=0, gOffers=0;
        // Kontakte/Ansprachen/Ablehnungen = EINDEUTIGE Kontakte (eine id kann mehrere Produktzeilen haben)
        const gCallIds = new Set(), gAnspIds = new Set(), gRejIds = new Set();

        const isFirstRun = (window.rcIsInitialized !== true);
        const now = new Date(), oneHourAgo = new Date(now.getTime()-3600000);
        const startHour = 8, currentHour = now.getHours();
        const loHour = Math.min(startHour, currentHour);
        const hourLabels = []; for (let hh=loHour; hh<=currentHour; hh++) hourLabels.push(pad2(hh)+':00');
        const trend = { total:new Array(hourLabels.length).fill(0), bnt:new Array(hourLabels.length).fill(0),
                        kip:new Array(hourLabels.length).fill(0), mob:new Array(hourLabels.length).fill(0), vvl:new Array(hourLabels.length).fill(0) };
        const anspTrend = new Array(hourLabels.length).fill(0); // Ansprachen je Stunde (fuer das dynamische Diagramm)
        const trendByStd = {}; // { code: [Abschluesse je Stunde] } — Linien je Standort

        // Stunden-Zuordnung eines Kontakts (echte Zeit > gemerkte Stunde > aktuelle Stunde)
        function hourOf(rowId, dObj){
            if (dObj && dObj.hasTime) return dObj.date.getHours();
            if (window.rcRowHourMap.has(rowId)) return window.rcRowHourMap.get(rowId);
            let hv;
            if (isFirstRun) { let s=0; for(let k=0;k<rowId.length;k++) s+=rowId.charCodeAt(k); hv = loHour + (s % hourLabels.length); }
            else hv = currentHour;
            window.rcRowHourMap.set(rowId, hv);
            return hv;
        }

        function blankNation(){ return { anzahl:0, kip:0, mob:0, bnt:0, vvl:0 }; }
        function ensureStd(code, meta){ if (!standortStats[code]) standortStats[code] = { code, name:meta?meta.name:code,
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, calls:0,pitches:0,rejections:0,accepted:0 }; return standortStats[code]; }
        function ensureTeam(teamId, code){ if (!teamStats[teamId]) teamStats[teamId] = { code:teamId, name:teamId, standort:code,
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, calls:0,pitches:0,rejections:0,accepted:0 }; return teamStats[teamId]; }
        function ensureAgent(vo, name, team, code, ccsId){ if (!agentStats[vo]) agentStats[vo] = { vo, name, team, standort:code, ccsId:ccsId||'',
            kip:0,mob:0,env:0,fibDsl:0,ptv:0,sonstBnt:0,kipVvl:0,mobVvl:0,fibVvl:0, ansprachen:0 };
            else if (ccsId && !agentStats[vo].ccsId) agentStats[vo].ccsId = ccsId;
            return agentStats[vo]; }

        for (let i=1;i<sheetData.length;i++){
            const row = sheetData[i];
            if (!row || row.length <= Math.max(idx.standort, idx.vo, idx.prod, idx.erg, idx.anz)) continue;

            const datumRaw = (row[idx.datum]||'').toString().trim();
            let standortRaw = (row[idx.standort]||'').toString().toUpperCase().trim();
            let teamRaw = (row[idx.team]||'').toString().trim();
            const voRaw = (row[idx.vo]||'').toString().trim();
            const prodRaw = (row[idx.prod]||'').toString().trim();
            const ergRaw = (row[idx.erg]||'').toString().trim();
            const ergL = ergRaw.toLowerCase();
            const anzahl = parseInt(row[idx.anz]) || 0;
            const angesprochen = idx.ansp!==-1 ? (row[idx.ansp]||'').toString().toLowerCase().trim() : '';

            let code = normalizeStandort(standortRaw);
            let realName = voRaw, team = teamRaw, realCcs = '';
            if (mapping && (mapping.voMap || mapping.ccsMap)) {
                const m = (mapping.voMap && mapping.voMap[voRaw]) || (mapping.ccsMap && mapping.ccsMap[voRaw]);
                if (m) { realName = m.name || voRaw; team = m.team || teamRaw; if (m.standort) code = normalizeStandort(m.standort); realCcs = m.ccsId || ''; }
            }
            const meta = STANDORT_METADATA[code];
            const nationCode = meta ? meta.nation : null;

            // Teams je Standort sammeln (fuer das Dropdown) — aus ALLEN Zeilen
            if (code && team) { (teamsByStd[code] || (teamsByStd[code] = new Set())).add(team); }

            // Scope: Stack, Standort UND Team muessen passen -> bei Filter NUR diese Daten
            // (Stacks sind getrennte Abteilungen, z.B. MF_CARE vs. onecoax_tech — kein Vergleich untereinander)
            const inScope = (filterVal === 'ALL' || code === filterVal)
                         && (filterTeam === 'ALL' || team === filterTeam)
                         && (filterStack === 'ALL' || stackOf(team) === filterStack);

            // Zeit / Stunde bestimmen
            const dObj = parseDateTime(datumRaw);
            const timeStr = (dObj && dObj.hasTime) ? getTimeString(dObj.date) : '';
            const withinHour = dObj ? (dObj.date >= oneHourAgo && dObj.date <= now) : false;

            let rowId = (idx.id!==-1 && row[idx.id]) ? row[idx.id].toString().trim() : `${code}_${voRaw}_${prodRaw}_${anzahl}_${i}`;

            // --- Kontakt-/Quoten-Zaehlung: ALLE Zeilen im Scope (Bugfix ggue. v20) ---
            const isReject = ergL.includes('abgelehnt') || ergL.includes('nicht'); // "nicht moeglich" (Encoding-sicher)
            const isOffer  = ergL.includes('angebot') && !ergL.includes('angenommen'); // offenes Angebot, KEIN Abschluss
            const std = ensureStd(code, meta);
            const tm = (inScope && team) ? ensureTeam(team, code) : null;
            // Ansprache = "Angebot gemacht" (ob angenommen, offen ODER abgelehnt) — NUR "nicht moeglich" zaehlt nicht.
            const istAnsprache = (angesprochen === 'ja') ||
                (angesprochen === '' && (ergL.includes('angenommen') || ergL.includes('angebot') || ergL.includes('abgelehnt')));
            if (inScope) {
                gCallIds.add(rowId);
                (std._c || (std._c = new Set())).add(rowId);
                if (tm) (tm._c || (tm._c = new Set())).add(rowId);
                if (istAnsprache) {
                    const neu = !gAnspIds.has(rowId);
                    gAnspIds.add(rowId);
                    (std._a || (std._a = new Set())).add(rowId);
                    if (tm) (tm._a || (tm._a = new Set())).add(rowId);
                    if (neu) { const hi = hourOf(rowId, dObj) - loHour; if (hi>=0 && hi<anspTrend.length) anspTrend[hi]++; }
                }
                if (isReject) {
                    gRejIds.add(rowId);
                    (std._r || (std._r = new Set())).add(rowId);
                    if (tm) (tm._r || (tm._r = new Set())).add(rowId);
                }
                if (isOffer) { gOffers += anzahl; std.offers = (std.offers||0) + anzahl; }
                // NUR Zeilen im Scope anlegen -> bei Filter erscheinen ausschliesslich diese Agenten
                if (voRaw) {
                    const ag = ensureAgent(voRaw, realName, team, code, realCcs);
                    if (!ag.stack) ag.stack = stackOf(team);
                    (ag._cIds || (ag._cIds = new Set())).add(rowId); // Kontakte je Agent (fuer CR-Berechnung)
                    if (istAnsprache) {
                        if (!ag._anspIds) ag._anspIds = new Set();
                        if (!ag._anspIds.has(rowId)) { ag._anspIds.add(rowId); ag.ansprachen++; }
                    }
                }
                if (tm && !tm.stack) tm.stack = stackOf(team);
            }

            // Ablehnungsgruende -> Marquee
            if (anzahl === 0 && idx.grund !== -1 && (ergL.includes('nicht') || ergL.includes('abgelehnt'))) {
                const grund = (row[idx.grund]||'').toString().trim();
                if (grund) { const hash = `${voRaw}_${grund}`;
                    if (!window.rcNewsHistorie.includes(hash)) { window.rcNewsHistorie.push(hash);
                        if (window.rcNewsHistorie.length>50) window.rcNewsHistorie.shift();
                        window.rcMarqueeBuffer.push(`${getFlagSvg(code,'small')} ${realName} (${code}) — abgelehnt: "${grund}"`);
                        if (window.rcMarqueeBuffer.length>25) window.rcMarqueeBuffer.shift();
                    }
                }
            }

            // --- Abschluss-Zaehlung: NUR "angenommen" ist ein echter Abschluss ---
            // "Angebot" = offenes/unterbreitetes Angebot, KEIN Verkauf -> zaehlt nicht als BNT/VVL
            const accepted = anzahl > 0 && ergL.includes('angenommen');
            if (accepted) {
                const { cat, isBnt, isVvl } = classify(prodRaw);
                if (cat) {
                    // Eindeutiger Schluessel je Verkaufszeile: Kontakt-id + Kategorie + Menge.
                    // Nur "angenommen" landet hier -> ein Angebot, das spaeter angenommen wird, gilt korrekt als NEU.
                    const saleKey = rowId + '|' + cat + '|' + anzahl;
                    const isNew = !window.rcCelebratedSales.has(saleKey);
                    window.rcCelebratedSales.add(saleKey); // auch ausserhalb des Filters merken -> kein Toast-Sturm bei Filterwechsel

                    if (inScope) {
                        std.accepted++;
                        ensureAgent(voRaw, realName, team, code, realCcs)[cat] += anzahl;
                        std[cat] += anzahl;
                        if (tm) tm[cat] += anzahl;
                        if (isBnt) gBnt += anzahl;
                        if (isVvl) gVvl += anzahl;
                        if (cat==='kip') gKip += anzahl;
                        if (cat==='mob') gMob += anzahl;
                        if (nationCode && nationStats[nationCode]) {
                            nationStats[nationCode].anzahl += anzahl;
                            if (isBnt) nationStats[nationCode].bnt += anzahl;
                            if (isVvl) nationStats[nationCode].vvl += anzahl;
                            if (cat==='kip') nationStats[nationCode].kip += anzahl;
                            if (cat==='mob') nationStats[nationCode].mob += anzahl;
                        }
                        // Tagesverlauf-Bucket (gesamt + je Standort)
                        if (isBnt || isVvl) {
                            const hi = hourOf(rowId, dObj) - loHour;
                            if (hi>=0 && hi<hourLabels.length) {
                                trend.total[hi]+=anzahl; if(isBnt) trend.bnt[hi]+=anzahl; if(cat==='kip') trend.kip[hi]+=anzahl; if(cat==='mob') trend.mob[hi]+=anzahl; if(isVvl) trend.vvl[hi]+=anzahl;
                                (trendByStd[code] || (trendByStd[code] = new Array(hourLabels.length).fill(0)))[hi] += anzahl;
                            }
                        }
                        window.rcAllSales.push({ name:realName, prod:prodRaw, standort:code, timeStr });

                        // NEUER Verkauf -> Abschluss-Fenster + Ticker + Radar-Ping (beim ersten Lauf nur letzte Stunde)
                        if (isNew) {
                            const dt = timeStr || (isFirstRun ? '' : new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}));
                            if (!isFirstRun || withinHour) queueCelebration(realName, prodRaw, code, dt);
                            addTicker(code, realName, prodRaw, dt || getTimeString(now));
                            if (window.rcRadarPing && (!isFirstRun || withinHour)) window.rcRadarPing(code, realName, prodRaw, dt || getTimeString(now));
                        }
                    }
                }
            }
        }

        if (isFirstRun && sheetData.length>1) window.rcIsInitialized = true;

        // Zaehler aus den Eindeutig-Sets ableiten (konsistente Basis fuer ALLE Ansichten)
        const gCalls = gCallIds.size, gPitches = gAnspIds.size;
        gRej = gRejIds.size;
        const fromSets = o => { o.calls = o._c ? o._c.size : 0; o.pitches = o._a ? o._a.size : 0; o.rejections = o._r ? o._r.size : 0; };

        // Ableitungen je Standort/Team/Agent
        Object.values(standortStats).forEach(s => { fromSets(s); s.bnt = bntOf(s); s.vvl = vvlOf(s); s.total = s.bnt + s.vvl; });
        Object.values(teamStats).forEach(t => { fromSets(t); t.bnt = bntOf(t); t.vvl = vvlOf(t); t.total = t.bnt + t.vvl; });
        Object.values(agentStats).forEach(a => { a.kontakte = a._cIds ? a._cIds.size : 0; a.bnt = bntOf(a); a.vvl = vvlOf(a); a.total = a.bnt + a.vvl; });

        // Team-Dropdown fuer den aktuell gewaehlten Standort befuellen
        updateTeamFilter(filterVal, teamsByStd[filterVal]);

        window.rcLetzteStats = { agentStats, standortStats, teamStats, nationStats };

        // KPI-Strip
        animateCount(document.getElementById('kpiCalls'), gCalls);
        animateCount(document.getElementById('kpiPitches'), gPitches);
        document.getElementById('kpiPitchRate').textContent = ` ${gCalls>0?Math.round(gPitches/gCalls*100):0}%`;
        animateCount(document.getElementById('kpiBnt'), gBnt);
        document.getElementById('kpiBntRate').textContent = ` ${gCalls>0?Math.round(gBnt/gCalls*100):0}%`;
        animateCount(document.getElementById('kpiKip'), gKip);
        animateCount(document.getElementById('kpiMob'), gMob);
        animateCount(document.getElementById('kpiVvl'), gVvl);
        animateCount(document.getElementById('kpiOffers'), gOffers);
        animateCount(document.getElementById('kpiRej'), gRej);
        document.getElementById('kpiRejRate').textContent = ` ${gCalls>0?Math.round(gRej/gCalls*100):0}%`;

        document.getElementById('rcValidRows').textContent = (sheetData.length-1) + ' Zeilen';
        updateFetchStatus(gCalls);
        detectDataIssues(sheetData.length-1);

        // Renders
        const agentsArr = Object.values(agentStats).sort((a,b) => b.total-a.total);
        // Letzten Render-Kontext merken (fuer 30s-Auto-Rotation ohne Neu-Parsing)
        window.rcLastRender = { agentsArr, standortStats, teamStats, filterVal, filterTeam };
        renderAgents(agentsArr);
        if (window.renderAnspFokus) window.renderAnspFokus(agentsArr);
        renderLiga('rcKipLeaderboard', agentsArr, 'kip', 'var(--rc-yellow)', filterVal);
        renderLiga('rcMobLeaderboard', agentsArr, 'mob', 'var(--rc-cyan)', filterVal);
        renderSide(agentsArr, filterVal);
        // Bei Standort-Filter: Standorte-Karte + Battle zeigen die TEAMS dieses Standorts
        if (filterVal !== 'ALL') { renderStandorte(teamStats, true); renderTeamBattle(teamStats, filterVal, filterTeam); }
        else { renderStandorte(standortStats, false); renderStandortBattle(standortStats); }
        renderProducts(sheetData, idx);
        renderTrend(hourLabels, trendByStd, anspTrend);
        if (window.renderTnpsChart) window.renderTnpsChart();
        renderMarquee();
        buildDynamicMoti(agentsArr, standortStats);
        if (window.renderRadar) window.renderRadar();
        if (window.rcActivePage === 'quali' && window.renderQualitaet) window.renderQualitaet();
        if (window.rcActivePage === 'cockpit' && window.renderCockpit) window.renderCockpit();

        rcLog.log(`v21: ${sheetData.length-1} Zeilen verarbeitet | BNT ${gBnt} · KIP ${gKip} · MOB ${gMob} · VVL ${gVvl}`);
      } catch(err) { rcLog.error('Fehler in processDataStream:', err); }
    };

    // ============================================================
    //  DATEN-TRANSPARENZ (Status, Warnungen)
    // ============================================================
    function getPortalDateRange(){
        try {
            const inps = [...document.querySelectorAll('#filterForm input.hasDatepicker, #filterForm .ui-calendar input')]
                .filter(i => i.value && i.value.trim());
            const vals = [...new Set(inps.map(i => i.value.trim()))];
            if (vals.length === 1) return vals[0];
            if (vals.length >= 2) return vals[0] + '–' + vals[vals.length-1];
        } catch(e){}
        return '';
    }
    function updateFetchStatus(kontakte){
        const el = document.getElementById('rcFetchStatus'); if (!el) return;
        const dr = getPortalDateRange();
        el.textContent = 'aktualisiert ' + new Date().toLocaleTimeString('de-DE')
            + (dr ? ' · Zeitraum ' + dr : '') + ' · ' + (kontakte||0).toLocaleString('de-DE') + ' Kontakte';
    }
    function showWarn(msg){ const b = document.getElementById('rcWarnBar'); if (b){ b.textContent = '⚠  ' + msg; b.style.display = msg ? 'block' : 'none'; } }
    function detectDataIssues(rows){
        let warn = '';
        // aktiver Spaltenfilter im Portal-Datatable?
        try {
            const active = [];
            document.querySelectorAll('#filterForm input.ui-column-filter, #filterForm .ui-datatable thead input').forEach(f => {
                if (!f || f.classList.contains('hasDatepicker')) return;
                if (f.value && f.value.trim()) active.push(f.value.trim());
            });
            if (active.length) warn = 'Spaltenfilter im Portal aktiv (' + active.slice(0,3).join(', ') + ') — es werden nur gefilterte Daten angezeigt. Zum Leeren die Filterfelder unter den Spalten loeschen.';
        } catch(e){}
        // starker Einbruch der Zeilenzahl (z.B. ploetzlich gesetzter Filter)
        if (!warn && window.rcMaxRows && window.rcMaxRows > 80 && rows < window.rcMaxRows * 0.55)
            warn = 'Nur ' + rows + ' Zeilen geladen (zuvor bis ' + window.rcMaxRows + ') — Spaltenfilter oder Zeitraum pruefen.';
        window.rcMaxRows = Math.max(window.rcMaxRows || 0, rows);
        showWarn(warn);
    }

    // ============================================================
    //  RENDER-FUNKTIONEN
    // ============================================================
    function rankClass(i){ return i===0?'r1':(i===1?'r2':(i===2?'r3':'')); }

    window.renderAgents = function(agentsArr){
        const tab = window.rcActiveAgentTab;
        const sortKey = tab==='bnt' ? (a=>a.bnt) : (tab==='ansp' ? (a=>a.ansprachen) : (a=>a.total));
        const arr = agentsArr.slice().sort((a,b) => sortKey(b)-sortKey(a)).slice(0,50);

        let html = '';
        arr.forEach((ag, i) => {
            const rc = rankClass(i), hl = i===0?'rc-table-row-1':(i===1?'rc-table-row-2':(i===2?'rc-table-row-3':''));
            html += `<tr class="${hl}">
                <td style="text-align:center;"><div class="rc-rank-badge ${rc}">${i+1}</div></td>
                <td><b style="font-family:'Nunito'; font-size:12px;">${getFlagSvg(ag.standort,'small')} ${ag.name}</b><span class="rc-mono" style="color:#5a6b7d; font-size:9px; margin-left:5px;">${ag.team||''}</span></td>
                <td style="text-align:center; color:var(--rc-yellow);" class="rc-mono">${ag.kip}</td>
                <td style="text-align:center; color:var(--rc-cyan);" class="rc-mono">${ag.mob}</td>
                <td style="text-align:center; color:#3fbf8f;" class="rc-mono">${ag.bnt}</td>
                <td style="text-align:center; color:var(--rc-pink);" class="rc-mono">${ag.vvl}</td>
                <td style="text-align:center; color:#fff; font-size:13px;" class="rc-mono">${tab==='ansp'?ag.ansprachen:ag.total}</td>
            </tr>`;
        });
        const leaderboard = document.getElementById('rcAgentLeaderboard');
        leaderboard.innerHTML = html || `<tr><td colspan="7" style="text-align:center; padding:20px; color:#888;">Keine Abschluesse vorhanden</td></tr>`;
    };

    // Ansprache-Fokus: wer telefoniert (Ligaliste), aber macht keine/wenige Ansprachen auf ESL
    window.renderAnspFokus = function(agentsArr){
        const el = document.getElementById('rcAnspFokus');
        if (!el) return;
        const warnSvg = h => `<svg viewBox="0 0 24 24" width="14" height="14" style="flex-shrink:0;"><path d="M12 3 L22 20 H2 Z" fill="none" stroke="${h?'#FF6B6B':'#FFB200'}" stroke-width="2" stroke-linejoin="round"/><line x1="12" y1="10" x2="12" y2="14.5" stroke="${h?'#FF6B6B':'#FFB200'}" stroke-width="2" stroke-linecap="round"/><circle cx="12" cy="17.2" r="1.1" fill="${h?'#FF6B6B':'#FFB200'}"/></svg>`;
        const list = [];
        (agentsArr || []).forEach(ag => {
            const kpi = window.rcKpiForAgent(ag);
            if (!kpi || !kpi.callCount || kpi.callCount < 5) return;
            const anspr = ag.ansprachen || 0;
            const q = anspr / kpi.callCount;
            if (anspr === 0) list.push({ ag, calls: kpi.callCount, anspr, q, hart: true });
            else if (q < 0.25) list.push({ ag, calls: kpi.callCount, anspr, q, hart: false });
        });
        if (!list.length) {
            const hasKpi = Object.keys(window.rcKpiData || {}).length > 0;
            el.innerHTML = `<div style="padding:10px; font-size:11px; color:${hasKpi?'#3fbf8f':'#888'}; font-weight:700;">${hasKpi?'Stark — alle Agenten mit Calls machen Ansprachen':'Warte auf KPI-Quelle (Button oben)'}</div>`;
            return;
        }
        list.sort((a,b) => (a.q - b.q) || (b.calls - a.calls));
        el.innerHTML = list.slice(0, 20).map(x => `<div class="rc-warn-item${x.hart?' hart':''}">
            ${warnSvg(x.hart)}
            <span class="nm">${getFlagSvg(x.ag.standort,'small')} ${x.ag.name}</span>
            <span class="wv">${x.calls} Calls · ${x.anspr} Anspr · <b style="color:${x.hart?'#FF6B6B':'#FFB200'};">${Math.round(x.q*100)} %</b></span>
        </div>`).join('');
    };

    // ============================================================
    //  SEITE 2: QUALITÄT — alle Service-KPIs aus der Ligaliste
    // ============================================================
    const fmtAht = sec => sec == null ? '—' : `${Math.floor(sec/60)}:${(''+Math.round(sec%60)).padStart(2,'0')}`;

    window.renderQualitaet = function(){
        const body = document.getElementById('rcQualiBody');
        if (!body) return;

        // ESL-Ansprachen: Join primaer per CCS-ID (verlaesslich), Name nur als Fallback
        const anspByCcs = {}, anspByName = {};
        if (window.rcLetzteStats) {
            Object.values(window.rcLetzteStats.agentStats).forEach(a => {
                if (a.ccsId) anspByCcs[a.ccsId] = a.ansprachen || 0;
                anspByName[window.rcNormName(a.name)] = a.ansprachen || 0;
            });
        }
        const eslAnsp = k => (k.ccsId && anspByCcs[k.ccsId] != null) ? anspByCcs[k.ccsId]
                            : (anspByName[window.rcNormName(k.agentName)] != null ? anspByName[window.rcNormName(k.agentName)] : null);

        const filterVal = document.getElementById('rcStandortFilter').value;
        const teamSel = document.getElementById('rcTeamFilter');
        const filterTeam = (filterVal !== 'ALL' && teamSel) ? teamSel.value : 'ALL';
        let list = Object.values(window.rcKpiData);
        if (filterVal && filterVal !== 'ALL') list = list.filter(k => normalizeStandort(k.standort) === filterVal);
        if (filterTeam !== 'ALL') list = list.filter(k => k.team === filterTeam);

        const setV = (id, txt, col) => { const e = document.getElementById(id); if (e) { e.textContent = txt; if (col) e.style.color = col; } };
        if (!list.length) {
            body.innerHTML = `<tr><td colspan="11" style="text-align:center; padding:24px; color:#888;">Warte auf KPI-Quelle — Button oben rechts nutzen</td></tr>`;
            ['qKpiCs','qKpiTnps','qKpiAufleger','qKpiFq','qKpiAht','qKpiDet','qKpiKurz','qKpiNonTrack'].forEach(id => setV(id,'—','#9BA7B2'));
            return;
        }

        // Kopf-Leiste: Durchschnitte mit Ziel-Ampel (FF7 kommt erst nach 7 Tagen -> bewusst nicht angezeigt)
        const avg = key => { const v = list.filter(k => k[key] != null); return v.length ? (v.reduce((s,k)=>s+k[key],0)/v.length) : null; };
        const avgCs = avg('cs'), avgTnps = avg('tnps'), avgAq = avg('auflegerquote'), avgFq = avg('fq');
        const ahtVals = list.filter(k => k.ahtSec != null && k.ahtSec > 0);
        const avgAhtMin = ahtVals.length ? (ahtVals.reduce((s,k)=>s+k.ahtSec,0)/ahtVals.length/60) : null;
        const detSum = list.reduce((s,k)=>s+(k.det||0),0);
        const kurzArr = list.filter(k => k.ahtSec != null && k.ahtSec > 0 && k.ahtSec < 360 && k.callCount >= 5)
                            .sort((a,b) => a.ahtSec - b.ahtSec);
        let nonTrack = 0;
        list.forEach(k => { const a = eslAnsp(k) || 0; if ((k.callCount>=10 && (a/k.callCount)<0.2) || (k.callCount>=5 && a===0)) nonTrack++; });

        const pct = v => v!=null ? v.toFixed(1).replace('.',',')+' %' : '—';
        setV('qKpiCs',   pct(avgCs),   zielColor(avgCs,  RC_ZIELE.cs));
        setV('qKpiTnps', pct(avgTnps), zielColor(avgTnps,RC_ZIELE.tnps));
        setV('qKpiAufleger', pct(avgAq), zielColor(avgAq, RC_ZIELE.aq));
        setV('qKpiFq',   pct(avgFq),   zielColor(avgFq,  RC_ZIELE.fq));
        setV('qKpiAht',  avgAhtMin!=null ? avgAhtMin.toFixed(1).replace('.',',')+' Min' : '—', zielColor(avgAhtMin, RC_ZIELE.ahtMin));
        setV('qKpiDet',  detSum, detSum>0 ? '#FF6B6B' : '#3fbf8f');
        setV('qKpiKurz', kurzArr.length, kurzArr.length>0 ? '#FFB200' : '#3fbf8f');
        setV('qKpiNonTrack', nonTrack, nonTrack>0 ? '#FF6B6B' : '#3fbf8f');

        // Chart links: CS & TNPS je Standort (horizontale Balken)
        (function(){
            const ctx = document.getElementById('rcQualiStdChart');
            if (!ctx || !window.Chart) return;
            const per = {};
            list.forEach(k => { const c = normalizeStandort(k.standort);
                (per[c] || (per[c] = { cs:[], tnps:[] }));
                if (k.cs != null) per[c].cs.push(k.cs);
                if (k.tnps != null) per[c].tnps.push(k.tnps);
            });
            const codes = ORDER.filter(c => per[c] && (per[c].cs.length || per[c].tnps.length));
            const mean = a => a.length ? +(a.reduce((s,x)=>s+x,0)/a.length).toFixed(1) : null;
            const dCs = codes.map(c => mean(per[c].cs)), dTn = codes.map(c => mean(per[c].tnps));
            const labels = codes.map(c => shortName(c));
            if (window.rcQualiStdChartInstance && (window.rcQualiStdChartInstance.canvas !== ctx || window.rcQualiStdChartInstance.data.labels.length !== labels.length)) {
                try { window.rcQualiStdChartInstance.destroy(); } catch(e){}
                window.rcQualiStdChartInstance = null;
            }
            if (window.rcQualiStdChartInstance) {
                const ch = window.rcQualiStdChartInstance;
                ch.data.labels = labels; ch.data.datasets[0].data = dCs; ch.data.datasets[1].data = dTn; ch.update();
            } else {
                window.rcQualiStdChartInstance = new Chart(ctx, { type:'bar',
                    data:{ labels, datasets:[
                        { label:'CS %',   data:dCs, backgroundColor:'rgba(0,152,100,0.65)', borderRadius:3 },
                        { label:'TNPS %', data:dTn, backgroundColor:'rgba(44,87,210,0.65)', borderRadius:3 } ] },
                    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false,
                        animation:{ duration:800 },
                        plugins:{ legend:{ labels:{ color:'#cfd8e3', boxWidth:9, font:{size:9.5} } } },
                        scales:{ x:{ grid:{color:'rgba(255,255,255,0.05)'}, ticks:{color:'#8b98a5', font:{size:8.5}}, suggestedMax:100 },
                                 y:{ grid:{display:false}, ticks:{color:'#cfd8e3', font:{size:10}} } } } });
            }
        })();

        // Rotierende Rangliste links unten: Feedbackquote <-> TNPS (Auto-Wechsel alle 30 s)
        const rankMode = window.rcQualiRankMode || 'fq';
        const rankTitle = document.getElementById('rcQualiRankTitle');
        if (rankTitle) rankTitle.textContent = rankMode === 'fq' ? 'Feedbackquote — Top 10' : 'TNPS — Top 10';
        const rankKey = rankMode, rankZiel = rankMode === 'fq' ? RC_ZIELE.fq : RC_ZIELE.tnps;
        const rankArr = list.filter(k => k[rankKey] != null && k.callCount >= 5).sort((a,b) => b[rankKey] - a[rankKey]).slice(0,10);
        const rankEl = document.getElementById('rcQualiRank');
        if (rankEl) rankEl.innerHTML = rankArr.length ? rankArr.map((k,i) => `<div class="rc-list-item">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;"><b style="font-size:11.5px;">${getFlagSvg(normalizeStandort(k.standort),'small')} ${k.agentName}</b></div>
                <div class="rc-mono" style="color:${zielColor(k[rankKey], rankZiel)}; font-size:13px;">${k[rankKey].toFixed(1).replace('.',',')} %</div>
            </div>`).join('') : `<div style="padding:8px; color:#888; font-size:11px;">Noch keine belastbaren Werte</div>`;

        // Kurz-Telefonierer: unter 6 Min wird es schwer, den Kunden wirklich zu loesen (FF7-Schutz)
        const kurzEl = document.getElementById('rcKurzTelList');
        if (kurzEl) {
            kurzEl.innerHTML = kurzArr.length ? kurzArr.slice(0,12).map(k => `<div class="rc-warn-item${k.ahtSec < 240 ? ' hart' : ''}">
                <span class="nm">${getFlagSvg(normalizeStandort(k.standort),'small')} ${k.agentName}</span>
                <span class="wv">Ø <b style="color:${k.ahtSec<240?'#FF6B6B':'#FFB200'};">${fmtAht(k.ahtSec)} Min</b> · ${k.callCount} Calls</span>
            </div>`).join('') : `<div style="padding:10px; color:#3fbf8f; font-size:11px; font-weight:700;">Alle Gespraechszeiten im gruenen Bereich</div>`;
        }

        // Detraktoren-Modul rechts: sofortiger Handlungsbedarf
        const detEl = document.getElementById('rcDetraktorList');
        if (detEl) {
            const detArr = list.filter(k => (k.det||0) > 0).sort((a,b) => (b.det||0)-(a.det||0) || (b.dds||0)-(a.dds||0));
            detEl.innerHTML = detArr.length ? detArr.slice(0,12).map(k => {
                const kritisch = k.dds != null && k.dds > RC_ZIELE.dds.max;
                return `<div class="rc-det-item${kritisch?' rc-det-critical':''}">
                    <div style="display:flex; justify-content:space-between; align-items:center;">
                        <b style="font-size:12px; color:#fff;">${getFlagSvg(normalizeStandort(k.standort),'small')} ${k.agentName}</b>
                        <span class="rc-mono" style="color:#FF6B6B; font-size:14px;">${k.det}</span>
                    </div>
                    <div style="font-size:10px; color:#FFB3B3; margin-top:2px;">
                        ${kritisch ? `DDS ${k.dds.toFixed(1).replace('.',',')} % — ueber Limit, sofort gegensteuern` : `Detraktoren heute — Gespraech nachhalten`}
                    </div>
                </div>`; }).join('')
                : `<div style="padding:10px; color:#48e6a0; font-size:11px; font-weight:700;">Keine Detraktoren — Qualitaet stabil</div>`;
        }

        // Haupttabelle
        const sk = window.rcQualiSort || 'calls';
        list.sort((a,b) => {
            const va = (sk==='calls') ? (a.callCount||0) : (a[sk]!=null?a[sk]:-1);
            const vb = (sk==='calls') ? (b.callCount||0) : (b[sk]!=null?b[sk]:-1);
            return vb - va;
        });
        const cell = (v, ziel) => `<td style="text-align:center; color:${zielColor(v, ziel)};" class="rc-mono">${v!=null?v.toFixed(1).replace('.',','):'—'}</td>`;
        let html = '';
        list.slice(0,80).forEach((k, i) => {
            const hl = i===0?'rc-table-row-1':(i===1?'rc-table-row-2':(i===2?'rc-table-row-3':''));
            const ansp = eslAnsp(k);
            const isNonTrack = (k.callCount>=10 && ansp!=null && (ansp/k.callCount)<0.2) || (k.callCount>=5 && ansp===0);
            const rowStyle = isNonTrack ? ' style="background:rgba(255,76,2,0.10); box-shadow:inset 3px 0 0 var(--rc-orange);"' : '';
            const callCol = zielColor(k.callCount, RC_ZIELE.calls);
            html += `<tr class="${hl}"${rowStyle}>
                <td style="text-align:center;"><div class="rc-rank-badge ${rankClass(i)}">${i+1}</div></td>
                <td><b style="font-family:'Nunito'; font-size:12px;">${getFlagSvg(normalizeStandort(k.standort),'small')} ${k.agentName}</b>${isNonTrack?' <span style="color:var(--rc-orange); font-size:8.5px; font-weight:800;">KEINE ANSPRACHE</span>':''}<div class="rc-mono" style="color:#5a6b7d; font-size:9px;">${k.team||''}</div></td>
                <td style="text-align:center; color:${callCol}; font-size:13px;" class="rc-mono">${k.callCount!=null?k.callCount:'—'}</td>
                <td style="text-align:center; color:${zielColor(k.ahtSec!=null?k.ahtSec/60:null, RC_ZIELE.ahtMin)};" class="rc-mono">${fmtAht(k.ahtSec)}</td>
                ${cell(k.auflegerquote, RC_ZIELE.aq)}
                ${cell(k.cs, RC_ZIELE.cs)}
                ${cell(k.tnps, RC_ZIELE.tnps)}
                ${cell(k.fq, RC_ZIELE.fq)}
                ${cell(k.dds, RC_ZIELE.dds)}
                <td style="text-align:center; color:${(k.det||0)>0?'#FF6B6B':'#48e6a0'};" class="rc-mono">${k.det!=null?k.det:'—'}</td>
                <td style="text-align:center; color:#fff; font-size:12px;" class="rc-mono">${ansp!=null?ansp:'—'}</td>
            </tr>`;
        });
        body.innerHTML = html;
    };

    // ============================================================
    //  SEITE 3: RADAR — Luftraum Europa (Standorte + Abschluss-Pings)
    // ============================================================
    const rcProj = (lon, lat) => [ +(((lon+12)*20).toFixed(1)), +(((60-lat)*24.615).toFixed(1)) ];
    window.rcRadarEvents = window.rcRadarEvents || [];

    function buildRadar(){
        const wrap = document.getElementById('rcRadarSvgWrap');
        if (!wrap || window.rcRadarBuilt) return;
        const pt = (lon,lat) => { const [x,y] = rcProj(lon,lat); return x + ',' + y; };
        const poly = pts => 'M' + pts.map(p => pt(p[0],p[1])).join(' L') + ' Z';
        // Grob stilisierte Kuestenlinien (bewusst reduziert, Low-Poly)
        const MAINLAND = [[-8.7,43.8],[-9.4,38.7],[-8.9,37.0],[-7.4,37.2],[-5.6,36.0],[-2.1,36.7],[-0.5,39.5],[0.2,40.6],[3.2,42.4],[4.8,43.3],[7.5,43.7],[8.9,44.4],[10.2,44.0],[12.4,41.9],[14.9,40.2],[16.2,38.9],[17.2,40.4],[15.9,41.9],[14.0,44.8],[13.6,45.6],[15.2,44.2],[16.9,43.3],[18.5,42.4],[19.4,41.3],[20.0,39.7],[21.1,38.4],[21.8,36.8],[23.0,36.4],[23.6,37.9],[24.0,40.0],[24.5,40.9],[26.1,40.1],[28.0,41.2],[27.5,42.5],[28.6,43.4],[29.7,45.2],[31.0,46.3],[33.5,46.1],[38.0,46.5],[38.0,60.0],[30.5,60.0],[28.0,59.4],[24.1,59.4],[21.0,56.9],[21.0,55.7],[19.5,54.4],[14.2,53.9],[12.1,54.2],[10.9,53.9],[9.5,54.8],[8.6,53.5],[7.1,53.3],[4.7,52.9],[3.4,51.3],[1.6,50.9],[-1.6,49.6],[-4.7,48.4],[-2.5,47.3],[-1.2,46.2],[-1.3,44.5],[-1.8,43.4],[-4.8,43.4]];
        const ANATOLIA = [[26.7,40.4],[29.1,41.0],[31.3,41.4],[35.0,42.0],[38.0,41.5],[38.0,36.3],[36.0,36.2],[32.8,36.0],[30.4,36.3],[29.1,36.6],[27.2,36.9],[27.0,38.4],[26.3,39.3]];
        const UK = [[-5.7,50.1],[1.4,51.2],[0.4,53.0],[-2.0,55.8],[-5.0,55.5],[-3.2,53.6],[-4.8,51.7]];
        const SCAND = [[5.5,59.0],[7.0,58.0],[9.0,58.7],[11.2,58.9],[12.7,55.4],[14.3,55.4],[16.6,56.4],[18.9,59.3],[17.8,60.0],[10.6,60.0],[9.6,59.1]];
        const landStyle = 'fill="rgba(44,87,210,0.10)" stroke="rgba(0,217,255,0.22)" stroke-width="1"';

        const rings = [90,180,270,360].map(r => `<circle cx="500" cy="320" r="${r}" fill="none" stroke="rgba(0,217,255,0.09)" stroke-width="1"/>`).join('');
        const cross = `<line x1="500" y1="0" x2="500" y2="640" stroke="rgba(0,217,255,0.06)"/><line x1="60" y1="320" x2="940" y2="320" stroke="rgba(0,217,255,0.06)"/>`;

        // Blips: Position + Label-Ausrichtung (Berlin/Potsdam liegen eng beieinander)
        const labelOfs = { P:{dx:-10,anchor:'end'}, E:{dx:-10,anchor:'end'}, B:{dx:12,anchor:'start'}, NBB:{dx:12,dy:-8,anchor:'start'} };
        let blips = '';
        ORDER.forEach(code => {
            const m = STANDORT_METADATA[code]; if (!m || m.lat == null) return;
            const [x,y] = rcProj(m.lon, m.lat);
            const o = labelOfs[code] || { dx:12, anchor:'start' };
            const lx = x + (o.dx||12), ly = y + (o.dy||-4);
            blips += `<g>
                <circle class="rc-blip-pulse" cx="${x}" cy="${y}" r="7" fill="${m.color}" style="transform-origin:${x}px ${y}px;"/>
                <circle cx="${x}" cy="${y}" r="4.5" fill="${m.color}" stroke="#0a0f1a" stroke-width="1.5"/>
                <text x="${lx}" y="${ly}" text-anchor="${o.anchor}" font-family="Nunito" font-size="11" font-weight="800" fill="#E9ECF0" letter-spacing="0.4">${m.short}</text>
                <text id="rcBlipCnt_${code}" x="${lx}" y="${ly+12}" text-anchor="${o.anchor}" font-family="Roboto Mono" font-size="10" fill="#6fc3e8">0</text>
            </g>`;
        });

        wrap.innerHTML = `<svg viewBox="0 0 1000 640" preserveAspectRatio="xMidYMid meet">
            <defs>
                <linearGradient id="rcSweepGrad" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0" stop-color="rgba(0,217,255,0.28)"/><stop offset="1" stop-color="rgba(0,217,255,0)"/>
                </linearGradient>
                <clipPath id="rcRadarClip"><rect x="0" y="0" width="1000" height="640"/></clipPath>
            </defs>
            <rect x="0" y="0" width="1000" height="640" fill="rgba(5,9,17,0.6)"/>
            <g clip-path="url(#rcRadarClip)">
                <path d="${poly(MAINLAND)}" ${landStyle}/>
                <path d="${poly(ANATOLIA)}" ${landStyle}/>
                <path d="${poly(UK)}" ${landStyle}/>
                <path d="${poly(SCAND)}" ${landStyle}/>
                ${rings}${cross}
                <path class="rc-sweep" d="M500,320 L500,-130 A450,450 0 0 1 711,-77 Z" fill="url(#rcSweepGrad)" style="transform-origin:500px 320px;"/>
                <g id="rcRadarPings"></g>
                ${blips}
            </g>
        </svg>`;
        window.rcRadarBuilt = true;
    }

    window.renderRadar = function(){
        buildRadar();
        const stats = (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        let totalSales = 0;
        ORDER.forEach(code => {
            const s = stats[code], m = STANDORT_METADATA[code];
            const cnt = s ? (s.total||0) : 0; totalSales += cnt;
            const el = document.getElementById('rcBlipCnt_' + code);
            if (el) el.textContent = cnt + ' ABS';
        });
        const line = document.getElementById('rcRadarStatusLine');
        if (line) line.textContent = 'SYSTEM AKTIV · ' + totalSales + ' ABSCHLUESSE · ' + new Date().toLocaleTimeString('de-DE');
        // Einsatz-Log
        const log = document.getElementById('rcRadarLog');
        if (log && window.rcRadarEvents.length) {
            log.innerHTML = window.rcRadarEvents.map(e =>
                `<div class="rc-radar-log-item">[${e.time}] <b>${e.call}</b> — Abschluss: ${e.prod} <span style="color:#9BA7B2;">(${e.name})</span></div>`).join('');
        }
    };

    // Rotierende Radar-Charts rechts: 4 Sichten, alle 30 s einen weiter
    window.renderRadarCharts = function(state){
        if (!window.Chart) return;
        const stats = (window.rcLetzteStats && window.rcLetzteStats.standortStats) || {};
        const codes = ORDER.filter(c => stats[c] && stats[c].calls > 0);
        if (!codes.length) return;
        // TNPS je Standort aus den KPI-Daten
        const tnpsPer = {};
        Object.values(window.rcKpiData || {}).forEach(k => {
            if (k.tnps == null) return;
            const c = normalizeStandort(k.standort);
            (tnpsPer[c] || (tnpsPer[c] = [])).push(k.tnps);
        });
        const mean = a => a && a.length ? +(a.reduce((s,x)=>s+x,0)/a.length).toFixed(1) : null;
        const views = [
            { t:'Abschluesse je Standort',    col:'rgba(44,87,210,0.7)',  fn:c => stats[c].total || 0 },
            { t:'CR-BNT je Standort in %',    col:'rgba(0,152,100,0.7)',  fn:c => stats[c].calls ? +((stats[c].bnt||0)/stats[c].calls*100).toFixed(1) : 0 },
            { t:'Ansprachequote je Standort', col:'rgba(255,178,0,0.6)',  fn:c => stats[c].calls ? +((stats[c].pitches||0)/stats[c].calls*100).toFixed(1) : 0 },
            { t:'Ø TNPS je Standort in %',    col:'rgba(0,217,255,0.55)', fn:c => mean(tnpsPer[c]) }
        ];
        const labels = codes.map(c => shortName(c));
        const drawInto = (canvasId, instKey, titleId, view) => {
            const ctx = document.getElementById(canvasId); if (!ctx) return;
            const tEl = document.getElementById(titleId); if (tEl) tEl.textContent = view.t;
            const data = codes.map(view.fn);
            if (window[instKey] && window[instKey].canvas !== ctx) { try { window[instKey].destroy(); } catch(e){} window[instKey] = null; }
            if (window[instKey]) {
                const ch = window[instKey];
                ch.data.labels = labels;
                ch.data.datasets[0].data = data;
                ch.data.datasets[0].label = view.t;
                ch.data.datasets[0].backgroundColor = view.col;
                ch.update();
            } else {
                window[instKey] = new Chart(ctx, { type:'bar',
                    data:{ labels, datasets:[{ label:view.t, data, backgroundColor:view.col, borderRadius:3 }] },
                    options:{ indexAxis:'y', responsive:true, maintainAspectRatio:false, animation:{ duration:700 },
                        plugins:{ legend:{ display:false } },
                        scales:{ x:{ grid:{color:'rgba(255,255,255,0.05)'}, ticks:{color:'#8b98a5', font:{size:8.5}} },
                                 y:{ grid:{display:false}, ticks:{color:'#cfd8e3', font:{size:9.5}} } } } });
            }
        };
        const i = ((state || 0) % views.length + views.length) % views.length;
        drawInto('rcRadarChartA', 'rcRadarChartA_i', 'rcRadarChartATitle', views[i]);
        drawInto('rcRadarChartB', 'rcRadarChartB_i', 'rcRadarChartBTitle', views[(i+1) % views.length]);
    };

    window.rcRadarPing = function(code, name, prod, time){
        const m = STANDORT_METADATA[code]; if (!m || m.lat == null) return;
        window.rcRadarEvents.unshift({ time: time || new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}), call: m.short, name, prod, code });
        if (window.rcRadarEvents.length > 14) window.rcRadarEvents.pop();
        buildRadar();
        const g = document.getElementById('rcRadarPings');
        if (g) {
            const [x,y] = rcProj(m.lon, m.lat);
            const ping = document.createElementNS('http://www.w3.org/2000/svg','g');
            ping.setAttribute('class','rc-ping-g');
            ping.setAttribute('style',`transform-origin:${x}px ${y}px;`);
            ping.innerHTML = `<circle cx="${x}" cy="${y}" r="10" fill="none" stroke="${m.color}" stroke-width="2.5"/>`;
            g.appendChild(ping);
            setTimeout(() => ping.remove(), 2700);
        }
        if (window.rcActivePage === 'radar') window.renderRadar();
    };

    // ============================================================
    //  SEITE 4: COCKPIT — Steuerung fuer Manager und Teamleiter
    // ============================================================
    const stdFullName = code => (STANDORT_METADATA[code] && STANDORT_METADATA[code].name) || code;
    const crPct = (z, n) => n > 0 ? +(z / n * 100).toFixed(1) : 0;
    const crTxt = (z, n) => n > 0 ? (z / n * 100).toFixed(1).replace('.', ',') + ' %' : '—';

    // Kritische Agenten: Sales-Blocker + Qualitaets-Risiken kombiniert
    function collectCritical(){
        const out = [];
        if (!window.rcLetzteStats) return out;
        Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
            const kpi = window.rcKpiForAgent(ag) || {};
            const probs = [];
            const calls = kpi.callCount || 0, anspr = ag.ansprachen || 0;
            if (calls >= 5 && anspr === 0) probs.push(['KEINE ANSPRACHE', 'rot']);
            else if (calls >= 10 && anspr / calls < 0.2) probs.push(['WENIG ANSPRACHEN', 'gelb']);
            if (kpi.ahtSec != null && kpi.ahtSec > 0 && kpi.ahtSec < 360 && calls >= 5) probs.push(['AHT < 6 MIN', kpi.ahtSec < 240 ? 'rot' : 'gelb']);
            if (kpi.tnps != null && kpi.tnps < 0 && calls >= 5) probs.push(['TNPS NEGATIV', 'rot']);
            if (kpi.cs != null && kpi.cs < 50 && calls >= 5) probs.push(['CS KRITISCH', 'rot']);
            if ((kpi.det || 0) >= 2) probs.push([kpi.det + ' DETRAKTOREN', 'rot']);
            else if ((kpi.det || 0) === 1) probs.push(['1 DETRAKTOR', 'gelb']);
            if (probs.length) out.push({ ag, kpi, probs, score: probs.filter(p => p[1] === 'rot').length * 2 + probs.length });
        });
        out.sort((a, b) => b.score - a.score);
        return out;
    }

    // Outlook-Vorlage je Agent (mailto oeffnet den Standard-Mail-Client mit fertigem Text)
    function agentMailHref(x){
        const ag = x.ag, kpi = x.kpi;
        const subject = `ESL Live-Arena — Handlungsbedarf: ${ag.name} (${stdFullName(ag.standort)}, Team ${ag.team || '-'})`;
        const lines = [
            'Hallo,', '',
            `im ESL Live-Dashboard sind heute kritische Werte fuer ${ag.name} aufgefallen:`, '',
            `Standort: ${stdFullName(ag.standort)} | Team: ${ag.team || '-'}` + (ag.stack ? ` | Stack: ${ag.stack}` : ''),
            `ESL: ${ag.kontakte || 0} Kontakte | ${ag.ansprachen || 0} Ansprachen | ${ag.bnt || 0} BNT | ${ag.vvl || 0} VVL`,
        ];
        if (kpi.callCount != null) {
            let l = `Ligaliste: ${kpi.callCount} Calls`;
            if (kpi.ahtSec != null) l += ` | AHT ${fmtAht(kpi.ahtSec)} Min`;
            if (kpi.cs != null) l += ` | CS ${kpi.cs.toFixed(1).replace('.', ',')} %`;
            if (kpi.tnps != null) l += ` | TNPS ${kpi.tnps.toFixed(1).replace('.', ',')} %`;
            lines.push(l);
        }
        lines.push('', 'Auffaelligkeiten:');
        x.probs.forEach(p => lines.push('- ' + p[0]));
        lines.push('', 'Bitte zeitnah mit dem Agenten sprechen und kurz Rueckmeldung geben.', '', 'Viele Gruesse');
        return 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\r\n'));
    }

    function summaryMailHref(crit, teams){
        const subject = 'ESL Live-Arena — Tagesueberblick kritische Werte (' + new Date().toLocaleDateString('de-DE') + ')';
        const lines = ['Hallo zusammen,', '', 'Ueberblick der kritischen Punkte aus dem Live-Dashboard:', ''];
        crit.slice(0, 12).forEach(x => lines.push(`- ${x.ag.name} (${stdFullName(x.ag.standort)}, Team ${x.ag.team || '-'}): ${x.probs.map(p => p[0]).join(', ')}`));
        if (!crit.length) lines.push('- Keine kritischen Agenten — starker Tag.');
        lines.push('', 'Schwaechste Teams nach CR-BNT:');
        teams.slice(0, 5).forEach(t => lines.push(`- Team ${t.name} (${stdFullName(t.standort)}): CR-BNT ${crTxt(t.bnt, t.calls)} | CR-VVL ${crTxt(t.vvl, t.calls)} | ${t.pitches} Ansprachen bei ${t.calls} Kontakten`));
        lines.push('', 'Details im Dashboard (Seite Cockpit) oder im Excel-Export.', '', 'Viele Gruesse');
        return 'mailto:?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(lines.join('\r\n'));
    }

    window.renderCockpit = function(){
        if (!window.rcLetzteStats) return;
        const { agentStats, standortStats, teamStats } = window.rcLetzteStats;
        const stds = Object.values(standortStats).filter(s => s.calls > 0);
        const sum = k => stds.reduce((s, x) => s + (x[k] || 0), 0);
        const kont = sum('calls'), ansp = sum('pitches'), bnt = sum('bnt'), vvl = sum('vvl');
        const setV = (id, html) => { const e = document.getElementById(id); if (e) e.innerHTML = html; };
        setV('ckKontakte', kont.toLocaleString('de-DE'));
        setV('ckAnspr', `${ansp}<small>${crTxt(ansp, kont)}</small>`);
        setV('ckBnt', `${bnt}<small style="color:${zielColor(crPct(bnt,kont), {min:10})}">${crTxt(bnt, kont)}</small>`);
        setV('ckVvl', `${vvl}<small>${crTxt(vvl, kont)}</small>`);

        const crit = collectCritical();
        setV('ckKrit', crit.length);
        const kritEl = document.getElementById('rcCkKrit');
        if (kritEl) kritEl.innerHTML = crit.length ? crit.slice(0, 25).map(x => `<div class="rc-warn-item${x.probs.some(p => p[1] === 'rot') ? ' hart' : ''}" style="flex-wrap:wrap;">
                <span class="nm">${getFlagSvg(x.ag.standort, 'small')} ${x.ag.name} <span class="rc-mono" style="color:#5a6b7d; font-size:9px;">${x.ag.team || ''}</span></span>
                <a class="rc-mailbtn" href="${agentMailHref(x)}">Mail</a>
                <div style="width:100%; margin-top:3px;">${x.probs.map(p => `<span class="rc-chip ${p[1]}">${p[0]}</span>`).join('')}</div>
            </div>`).join('') : `<div style="padding:10px; color:#3fbf8f; font-weight:700; font-size:11px;">Keine kritischen Agenten — starker Tag</div>`;

        // Teams: schwaechste CR-BNT zuerst (dort ist Coaching am wirksamsten)
        const teams = Object.values(teamStats).filter(t => t.calls > 0).sort((a, b) => crPct(a.bnt, a.calls) - crPct(b.bnt, b.calls));
        const tmEl = document.getElementById('rcCkTeams');
        if (tmEl) tmEl.innerHTML = teams.map(t => `<tr>
                <td><b style="font-size:11px;">Team ${t.name}</b><div class="rc-mono" style="color:#5a6b7d; font-size:8.5px;">${shortName(t.standort)}${t.stack ? ' · ' + t.stack : ''}</div></td>
                <td style="text-align:center;" class="rc-mono">${t.calls}</td>
                <td style="text-align:center; color:${zielColor(crPct(t.pitches, t.calls), {min:40})};" class="rc-mono">${crTxt(t.pitches, t.calls)}</td>
                <td style="text-align:center; color:#3fbf8f;" class="rc-mono">${t.bnt}</td>
                <td style="text-align:center; color:${zielColor(crPct(t.bnt, t.calls), {min:10})};" class="rc-mono">${crTxt(t.bnt, t.calls)}</td>
                <td style="text-align:center; color:var(--rc-pink);" class="rc-mono">${t.vvl}</td>
                <td style="text-align:center;" class="rc-mono">${crTxt(t.vvl, t.calls)}</td>
            </tr>`).join('') || `<tr><td colspan="7" style="text-align:center; padding:18px; color:#888;">Keine Team-Daten</td></tr>`;

        const stdEl = document.getElementById('rcCkStd');
        if (stdEl) stdEl.innerHTML = stds.slice().sort((a, b) => b.total - a.total).map(s => `<tr>
                <td><b style="font-size:11px;">${getFlagSvg(s.code, 'small')} ${shortName(s.code)}</b></td>
                <td style="text-align:center;" class="rc-mono">${s.calls}</td>
                <td style="text-align:center; color:#3fbf8f;" class="rc-mono">${s.bnt}</td>
                <td style="text-align:center; color:${zielColor(crPct(s.bnt, s.calls), {min:10})};" class="rc-mono">${crTxt(s.bnt, s.calls)}</td>
                <td style="text-align:center; color:var(--rc-pink);" class="rc-mono">${s.vvl}</td>
                <td style="text-align:center;" class="rc-mono">${crTxt(s.vvl, s.calls)}</td>
            </tr>`).join('') || `<tr><td colspan="6" style="text-align:center; padding:18px; color:#888;">Keine Daten</td></tr>`;

        const mailAll = document.getElementById('ckBtnMailAll');
        if (mailAll) mailAll.href = summaryMailHref(crit, teams);
    };

    // ============================================================
    //  EXCEL-EXPORT — regiocom CD, 6 Blaetter, berechnete CR%
    //  Styling via xlsx-js-style (Drop-in-Fork); Fallback: normale SheetJS ohne Farben
    // ============================================================
    function rcLoadStyledXlsx(cb){
        if (window.rcXLSXS) return cb(window.rcXLSXS);
        const prev = window.XLSX;
        const s = document.createElement('script');
        s.src = 'https://cdn.jsdelivr.net/npm/xlsx-js-style@1.2.0/dist/xlsx.bundle.js';
        s.onload = function(){
            const x = window.XLSX || prev;
            x.__styled = (x !== prev);          // Fork geladen -> Styling verfuegbar
            window.XLSX = prev;                  // Original-Instanz fuer den Import unangetastet lassen
            window.rcXLSXS = x; cb(x);
        };
        s.onerror = function(){
            const fb = prev || window.XLSX;
            if (!fb) { alert('XLSX-Bibliothek nicht verfuegbar.'); return; }
            fb.__styled = false; window.rcXLSXS = fb;
            rcLog.log('Styling-CDN blockiert -> Export ohne Farben (Daten korrekt)');
            cb(fb);
        };
        document.head.appendChild(s);
    }

    window.rcExportReport = function(){
        if (!window.rcLetzteStats) { alert('Noch keine Daten geladen.'); return; }
        rcLoadStyledXlsx(function(XL){
            const styled = !!XL.__styled;
            const { agentStats, standortStats, teamStats } = window.rcLetzteStats;
            const wb = XL.utils.book_new();

            const nd = new Date();
            const dstr = pad2(nd.getDate()) + '.' + pad2(nd.getMonth()+1) + '.' + String(nd.getFullYear()).slice(-2);
            const titel = 'Vodafone      ESL PERFORMANCE TRACKING  |  Zeitraum: ' + dstr + ' - ' + dstr;
            const PCT = '0.0%';
            const crF = (z,n) => n > 0 ? +(z/n).toFixed(4) : 0;   // Bruch fuer echtes Excel-%-Format

            // --- Style-Bausteine (nur wirksam, wenn der Styling-Fork geladen wurde) ---
            const bd = { style:'thin', color:{ rgb:'FFD9D9D9' } };
            const BORDER = { top:bd, bottom:bd, left:bd, right:bd };
            const FILL = c => ({ patternType:'solid', fgColor:{ rgb:c } });
            const S_TITLE = { fill:FILL('FFE60000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:13 }, alignment:{ horizontal:'left', vertical:'center' } };
            const S_HDR   = bg => ({ fill:FILL(bg), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ horizontal:'center', vertical:'center', wrapText:true }, border:BORDER });
            const S_CELL  = al => ({ font:{ sz:10 }, alignment:{ horizontal:al||'center', vertical:'center' }, border:BORDER });
            const S_GROUP = { fill:FILL('FFE60000'), font:{ bold:true, color:{rgb:'FFFFFFFF'}, sz:10 }, alignment:{ vertical:'center' }, border:BORDER };

            const M = (r1,c1,r2,c2) => ({ s:{r:r1,c:c1}, e:{r:r2,c:c2} });

            // Generischer Styler: legt fehlende Zellen an, faerbt Titel/Header/Daten, setzt %-Format
            function decorate(ws, o){
                const rng = XL.utils.decode_range(ws['!ref']);
                for (let R=rng.s.r; R<=rng.e.r; R++){
                    for (let C=rng.s.c; C<=rng.e.c; C++){
                        const addr = XL.utils.encode_cell({ r:R, c:C });
                        if (!ws[addr]) ws[addr] = { t:'s', v:'' };
                        let st;
                        if (o.titleRows && o.titleRows.indexOf(R)!==-1) st = S_TITLE;
                        else if (o.headerRows && o.headerRows.indexOf(R)!==-1) st = S_HDR(o.hdrBg);
                        else if (o.groupRows && o.groupRows.has(R)) st = S_GROUP;
                        else {
                            st = S_CELL(C===0 ? 'left' : 'center');
                            if (o.pctCols && o.pctCols.has(C) && ws[addr].t==='n') ws[addr].z = PCT;
                        }
                        if (styled) ws[addr].s = st;
                    }
                }
                if (o.cols)   ws['!cols']   = o.cols;
                if (o.merges) ws['!merges'] = (ws['!merges']||[]).concat(o.merges);
            }

            // ---------- Flache Blaetter (Standorte/Stacks/Teams/Agenten) ----------
            function flatSheet(name, hdrBg, header, dataRows, pctCols, widths){
                const aoa = [ [titel], header ].concat(dataRows);
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1], hdrBg:hdrBg,
                    pctCols:new Set(pctCols), merges:[ M(0,0,0,header.length-1) ], cols:widths });
                XL.utils.book_append_sheet(wb, ws, name);
            }

            const stds  = Object.values(standortStats).filter(s => s.calls > 0).sort((a,b) => b.total - a.total);
            const teams = Object.values(teamStats).filter(t => t.calls > 0).sort((a,b) => b.total - a.total);
            const w = (...a) => a.map(x => ({ wch:x }));

            // Blatt 1: Liga Standorte (rohe Produktzahlen je Standort, IST + CR%)
            (function(){
                const grp = ['Standort','Calls','ENV BNT','','DSL / FIB BNT','','KIP BNT','','MOB BNT','','BNT GES.','','Mobilfunk VVL','','KIP VVL','','VVL','','Kumuliert',''];
                const sub = ['','IST','IST','CR%','IST','CR%','IST','CR%','IST','CR%','GES. IST','CR%','IST','CR%','IST','CR%','GES. IST','CR%','GES. IST','CR%'];
                const aoa = [ [titel], grp, sub ];
                stds.forEach(s => aoa.push([ stdFullName(s.code), s.calls,
                    s.env, crF(s.env,s.calls), s.fibDsl, crF(s.fibDsl,s.calls), s.kip, crF(s.kip,s.calls), s.mob, crF(s.mob,s.calls),
                    s.bnt, crF(s.bnt,s.calls), s.mobVvl, crF(s.mobVvl,s.calls), s.kipVvl, crF(s.kipVvl,s.calls),
                    s.vvl, crF(s.vvl,s.calls), s.total, crF(s.total,s.calls) ]));
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1,2], hdrBg:'FFC00000', pctCols:new Set([3,5,7,9,11,13,15,17,19]),
                    merges:[ M(0,0,0,19), M(1,0,2,0), M(1,1,2,1), M(1,2,1,3), M(1,4,1,5), M(1,6,1,7), M(1,8,1,9), M(1,10,1,11), M(1,12,1,13), M(1,14,1,15), M(1,16,1,17), M(1,18,1,19) ],
                    cols:w(18,7,7,7,10,7,7,7,7,7,9,7,10,7,8,7,7,7,9,7) });
                XL.utils.book_append_sheet(wb, ws, 'Liga Standorte');
            })();

            // Blatt 2: Liga Teams (je Standort gruppiert; ENV/PTV/KIP/Mobilfunk BNT + VVL + Ziel-Spalten leer)
            (function(){
                const grp = ['Standort / Team','Calls','ENV BNT','','PTV BNT','','KIP BNT','','Mobilfunk BNT','','BNT','','','Mobilfunk VVL','','KIP VVL','','VVL','','','Kumuliert','',''];
                const sub = ['','IST','Stück','CR%','Stück','CR%','Stück','CR%','Stück','CR%','IST Stück','CR%','Ziel','Stück','CR%','Stück','CR%','IST Stück','CR%','Ziel','IST Stück','CR%','Ziel'];
                const aoa = [ [titel], grp, sub ];
                const groupRows = new Set();
                const rowOf = (o) => [ '', o.calls, o.env, crF(o.env,o.calls), o.ptv, crF(o.ptv,o.calls), o.kip, crF(o.kip,o.calls),
                    o.mob, crF(o.mob,o.calls), o.bnt, crF(o.bnt,o.calls), '', o.mobVvl, crF(o.mobVvl,o.calls), o.kipVvl, crF(o.kipVvl,o.calls),
                    o.vvl, crF(o.vvl,o.calls), '', o.total, crF(o.total,o.calls), '' ];
                stds.forEach(s => {
                    const gr = rowOf(s); gr[0] = stdFullName(s.code);
                    groupRows.add(aoa.length); aoa.push(gr);
                    teams.filter(t => t.standort === s.code).sort((a,b) => b.total - a.total).forEach(t => {
                        const r = rowOf(t); r[0] = t.name; aoa.push(r);
                    });
                });
                const ws = XL.utils.aoa_to_sheet(aoa);
                decorate(ws, { titleRows:[0], headerRows:[1,2], hdrBg:'FFC00000', groupRows:groupRows,
                    pctCols:new Set([3,5,7,9,11,14,16,18,21]),
                    merges:[ M(0,0,0,22), M(1,0,2,0), M(1,1,2,1), M(1,2,1,3), M(1,4,1,5), M(1,6,1,7), M(1,8,1,9), M(1,10,1,12), M(1,13,1,14), M(1,15,1,16), M(1,17,1,19), M(1,20,1,22) ],
                    cols:w(18,7,7,7,7,7,7,7,9,7,8,7,6,10,7,7,7,7,7,6,9,7,6) });
                XL.utils.book_append_sheet(wb, ws, 'Liga Teams');
            })();

            // Blatt 3: Standorte (aggregiert)
            flatSheet('Standorte', 'FFC00000',
                ['Standort','KIP BNT','MOB BNT','FIB/DSL BNT','ENV BNT','BNT GES.','VVL GES.','Ansprachen','Calls','CR-BNT','CR-VVL','CR-Ansp','Gesamt'],
                stds.map(s => [ stdFullName(s.code), s.kip, s.mob, s.fibDsl, s.env, s.bnt, s.vvl, s.pitches, s.calls,
                    crF(s.bnt,s.calls), crF(s.vvl,s.calls), crF(s.bnt,s.pitches), s.total ]),
                [9,10,11], w(18,9,9,11,9,9,9,10,8,8,8,8,8));

            // Blatt 4: Stacks (nach Standort + Stack aggregiert)
            (function(){
                const agg = {};
                Object.values(teamStats).forEach(t => {
                    const key = t.standort + '|' + (t.stack || '');
                    const o = agg[key] || (agg[key] = { standort:t.standort, stack:t.stack||'', kip:0,mob:0,fibDsl:0,env:0,bnt:0,vvl:0,pitches:0,calls:0,total:0 });
                    ['kip','mob','fibDsl','env','bnt','vvl','pitches','calls','total'].forEach(k => o[k] += (t[k]||0));
                });
                flatSheet('Stacks', 'FF2C57D2',
                    ['Standort','Stack','KIP','MOB','FIB/DSL','ENV','BNT gesamt','VVL','Ansprachen','Calls','CR-BNT','CR-VVL','CR-Ansp','Gesamt'],
                    Object.values(agg).filter(o => o.calls > 0).sort((a,b) => b.total - a.total).map(o =>
                        [ stdFullName(o.standort), o.stack, o.kip, o.mob, o.fibDsl, o.env, o.bnt, o.vvl, o.pitches, o.calls,
                          crF(o.bnt,o.calls), crF(o.vvl,o.calls), crF(o.bnt,o.pitches), o.total ]),
                    [10,11,12], w(16,14,8,8,9,8,10,8,10,8,8,8,8,8));
            })();

            // Blatt 5: Teams
            flatSheet('Teams', 'FFFF4C02',
                ['Standort','Team','KIP','MOB','FIB/DSL','ENV','BNT gesamt','VVL','Calls','CR-BNT','CR-VVL','Ansprachen'],
                teams.map(t => [ stdFullName(t.standort), t.name, t.kip, t.mob, t.fibDsl, t.env, t.bnt, t.vvl, t.calls,
                    crF(t.bnt,t.calls), crF(t.vvl,t.calls), t.pitches ]),
                [9,10], w(16,10,8,8,9,8,10,8,8,8,8,10));

            // Blatt 6: Agenten (ohne CR — wie Vorlage)
            flatSheet('Agenten', 'FF009864',
                ['Standort','Agent','Team','KIP','MOB','FIB/DSL','ENV','BNT','VVL','Ansprachen','Gesamt'],
                Object.values(agentStats).sort((a,b) => b.total - a.total).map(a =>
                    [ stdFullName(a.standort), a.name, a.team || '', a.kip, a.mob, a.fibDsl, a.env, a.bnt, a.vvl, a.ansprachen, a.total ]),
                [], w(16,18,10,7,7,9,7,7,7,10,8));

            const fn = `regiocom_ESL_Report_${nd.getFullYear()}-${pad2(nd.getMonth()+1)}-${pad2(nd.getDate())}_${pad2(nd.getHours())}${pad2(nd.getMinutes())}.xlsx`;
            XL.writeFile(wb, fn);
            rcLog.log('Report exportiert (' + (styled ? 'mit' : 'ohne') + ' Styling): ' + fn);
        });
    };

    // KIP / MOB Liga — zeigt nur die (bereits gefilterten) Agenten
    function renderLiga(elId, agentsArr, key, color, filterVal){
        const list = agentsArr.filter(a => a[key] > 0).sort((a,b) => b[key]-a[key]).slice(0,10);
        if (!list.length) { document.getElementById(elId).innerHTML = `<div style="padding:10px; color:#888;">Noch keine Abschluesse</div>`; return; }
        let html = '';
        list.forEach((ag, i) => {
            html += `<div class="rc-list-item">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;"><b>${getFlagSvg(ag.standort,'small')} ${ag.name} <span class="rc-mono" style="color:#9BA7B2; font-size:10px; font-weight:normal;">(${ag.standort})</span></b></div>
                <div class="rc-mono" style="color:${color}; font-size:15px;">${ag[key]}</div>
            </div>`;
        });
        document.getElementById(elId).innerHTML = html;
    }

    function renderSide(agentsArr, filterVal){
        const tab = window.rcActiveSideTab;
        const key = tab==='ansp' ? 'ansprachen' : 'vvl';
        const color = tab==='ansp' ? 'var(--rc-cyan)' : 'var(--rc-pink)';
        let arr = agentsArr.filter(a => a[key] > 0).sort((a,b) => b[key]-a[key]).slice(0,10);
        let html = '';
        arr.forEach((ag, i) => {
            html += `<div class="rc-list-item">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;"><b>${getFlagSvg(ag.standort,'small')} ${ag.name} <span class="rc-mono" style="color:#9BA7B2; font-size:10px; font-weight:normal;">(${ag.standort})</span></b></div>
                <div class="rc-mono" style="color:${color}; font-size:15px;">${ag[key]}</div>
            </div>`;
        });
        document.getElementById('rcSideLeaderboard').innerHTML = html || `<div style="padding:10px; color:#888;">Noch keine Daten</div>`;
    }

    function renderStandorte(statsObj, isTeam){
        const el = document.getElementById('rcStandortBattleList');
        const arr = Object.values(statsObj);
        // Team-Modus: kein Flaggen-SVG (Team-ID hat keine Flagge), neutrale Farbe
        const flag = (s) => isTeam ? '' : (getFlagSvg(s.code,'small') + ' ');
        const label = (s) => isTeam ? ('Team ' + s.name) : shortName(s.code);
        const emptyTxt = isTeam ? 'Keine Team-Daten' : 'Keine Standort-Daten';
        if (window.rcActiveStandortTab === 'rates') {
            const rows = arr.filter(s => s.calls > 0).map(s => ({...s,
                pitchRate: s.calls>0?Math.round(s.pitches/s.calls*100):0,
                bntRate:   s.calls>0?Math.round(s.bnt/s.calls*100):0,
                rejRate:   s.calls>0?Math.round(s.rejections/s.calls*100):0
            })).sort((a,b) => b.bntRate-a.bntRate);
            let html = '';
            rows.forEach(s => {
                const col = s.bntRate>=15?'var(--rc-green)':(s.bntRate>=8?'var(--rc-yellow)':'var(--rc-orange)');
                html += `<div style="margin-bottom:9px;">
                    <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px;">
                        <span>${flag(s)}<b>${label(s)}</b></span>
                        <span class="rc-mono" style="font-size:10px; color:#9BA7B2;">Abschl <b style="color:${col};">${s.bntRate}%</b> · Ansp ${s.pitchRate}% · Abl ${s.rejRate}%</span>
                    </div>
                    <div class="rc-bar-track"><div class="rc-bar-fill" style="background:linear-gradient(90deg,${col},#fff); width:${Math.min(s.bntRate*3,100)}%;"></div></div>
                </div>`;
            });
            el.innerHTML = html || `<div style="padding:10px; color:#888;">${emptyTxt}</div>`;
        } else {
            const rows = arr.filter(s => s.total > 0).sort((a,b) => b.total-a.total);
            const max = rows.length ? rows[0].total : 1;
            let html = '';
            rows.forEach(s => {
                const meta = STANDORT_METADATA[s.code], col = isTeam ? 'var(--rc-cyan)' : (meta?meta.color:'#9BA7B2');
                html += `<div style="margin-bottom:9px;">
                    <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:3px;">
                        <span>${flag(s)}<b>${label(s)}</b> <span class="rc-mono" style="font-size:9px; color:#9BA7B2;">KIP ${s.kip} · MOB ${s.mob}</span></span>
                        <span class="rc-mono" style="color:var(--rc-cyan);"><b>${s.bnt}</b> BNT · ${s.vvl} VVL</span>
                    </div>
                    <div class="rc-bar-track"><div class="rc-bar-fill" style="background:linear-gradient(90deg,${col},#fff); width:${Math.max(3,s.total/max*100)}%;"></div></div>
                </div>`;
            });
            el.innerHTML = html || `<div style="padding:10px; color:#888;">${emptyTxt}</div>`;
        }
    }

    // Team-Dropdown fuer den gewaehlten Standort befuellen (nur sichtbar wenn ein Standort gewaehlt ist)
    function updateTeamFilter(std, teamsSet){
        const sel = document.getElementById('rcTeamFilter');
        if (!sel) return;
        if (std === 'ALL' || !teamsSet || !teamsSet.size) {
            sel.style.display = 'none';
            if (sel.dataset.sig !== 'none') { sel.innerHTML = '<option value="ALL">Alle Teams</option>'; sel.dataset.sig = 'none'; }
            return;
        }
        const cur = sel.value;
        const teams = [...teamsSet].sort();
        const sig = std + '|' + teams.join(',');
        if (sel.dataset.sig !== sig) {
            sel.innerHTML = '<option value="ALL">Alle Teams</option>' + teams.map(t => `<option value="${t}">Team ${t}</option>`).join('');
            sel.dataset.sig = sig;
            sel.value = (cur && teams.includes(cur)) ? cur : 'ALL';
        }
        sel.style.display = '';
    }

    // Team-Battle: Teams des gewaehlten Standorts als Wettbewerber (bei Standort-Filter)
    function renderTeamBattle(teamStats, filterStd, filterTeam){
        const el = document.getElementById('rcNationBattleList');
        document.getElementById('rcBattleTitle').textContent = 'Team-Battle';
        document.getElementById('rcStandorteTitle').textContent = 'Teams';
        document.getElementById('rcBattleHint').textContent = STANDORT_METADATA[filterStd] ? STANDORT_METADATA[filterStd].name : filterStd;
        document.getElementById('rcNationPicker').style.display = 'none';
        const stdCol = (STANDORT_METADATA[filterStd] || {}).color || 'var(--rc-cyan)';

        let arr = Object.values(teamStats).filter(t => t.total > 0).sort((a,b) => b.total-a.total);
        if (!arr.length) { el.innerHTML = `<div style="padding:10px; color:#888;">Noch keine Team-Abschluesse in ${filterStd}</div>`; return; }

        // Genau 2 Teams -> Duell
        if (arr.length === 2) {
            const [A,B] = arr, tot = Math.max(A.total+B.total,1);
            const aPct = Math.round(A.total/tot*100), bPct = 100-aPct;
            const win = A.total===B.total ? null : (A.total>B.total?A.code:B.code);
            const side = (s, isWin) => `<div class="rc-duel-side" style="${isWin?'border-color:'+stdCol+'; box-shadow:0 0 14px '+stdCol+'55;':''}">
                <div style="font-family:'Nunito'; font-weight:900; font-size:12.5px; color:#fff;">Team ${s.name}</div>
                <div class="rc-mono" style="font-size:24px; font-weight:900; color:${stdCol};">${s.total}</div>
                <div class="rc-mono" style="font-size:9px; color:#9BA7B2;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
            </div>`;
            el.innerHTML = `<div class="rc-duel">${side(A,win===A.code)}<div class="rc-duel-vs">VS</div>${side(B,win===B.code)}</div>
                <div class="rc-tug"><div style="width:${aPct}%; background:${stdCol};"></div><div style="width:${bPct}%; background:#5a6b7d;"></div></div>
                <div style="display:flex; justify-content:space-between; font-size:10px; color:#9BA7B2; margin-top:5px;" class="rc-mono"><span>${aPct}%</span><span>Vorsprung: ${Math.abs(A.total-B.total)}</span><span>${bPct}%</span></div>`;
            return;
        }
        // Ranking
        let html = '';
        arr.forEach((t, i) => {
            const hi = (filterTeam !== 'ALL' && t.code === filterTeam);
            html += `<div class="rc-list-item" style="padding:7px 10px; border-left:3px solid ${hi?stdCol:'rgba(44,87,210,0.4)'};${hi?'box-shadow:0 0 8px '+stdCol+'55;':''} ${i===0?'background:rgba(255,178,0,0.06);':''}">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="flex:1;">
                    <div style="font-family:'Nunito'; font-weight:900; font-size:12.5px; color:#fff;">Team ${t.name}</div>
                    <div class="rc-mono" style="font-size:9px; color:#9BA7B2;">KIP ${t.kip} · MOB ${t.mob} · VVL ${t.vvl}</div>
                </div>
                <div class="rc-mono" style="font-size:17px; font-weight:900; color:${stdCol};">${t.total}</div>
            </div>`;
        });
        el.innerHTML = html;
    }

    // Standort-Battle: jeder Standort ist ein Wettbewerber (Flagge + Standortname).
    // Ein Land kann mehrere Standorte haben (GR = Serres + Alexandroupolis), daher NICHT nach Nation gruppieren.
    function renderStandortBattle(standortStats){
        const el = document.getElementById('rcNationBattleList');
        // Titel/Picker aus evtl. Team-Modus zuruecksetzen
        document.getElementById('rcBattleTitle').textContent = 'Standort-Battle';
        document.getElementById('rcStandorteTitle').textContent = 'Standorte';
        document.getElementById('rcBattleHint').textContent = 'Flaggen antippen';
        document.getElementById('rcNationPicker').style.display = '';
        const sel = window.rcSelectedStandorte;
        const arr = ORDER.filter(c => sel.has(c) && standortStats[c] && standortStats[c].total > 0)
                         .map(c => standortStats[c]).sort((a,b) => b.total-a.total);
        if (!arr.length) { el.innerHTML = `<div style="padding:10px; color:#888;">Keine Daten fuer die gewaehlten Standorte</div>`; return; }
        const colOf = c => (STANDORT_METADATA[c] || {}).color || '#9BA7B2';

        // Duell-Ansicht bei genau 2 aktiven Standorten
        if (arr.length === 2) {
            const [A,B] = arr, tot = Math.max(A.total+B.total,1);
            const aPct = Math.round(A.total/tot*100), bPct = 100-aPct;
            const colA = colOf(A.code), colB = colOf(B.code);
            const win = A.total===B.total ? null : (A.total>B.total?A.code:B.code);
            const side = (s, col, isWin) => `<div class="rc-duel-side" style="${isWin?'border-color:'+col+'; box-shadow:0 0 14px '+col+'55;':''}">
                <div>${getFlagSvg(s.code,'large',isWin)}</div>
                <div style="font-family:'Nunito'; font-weight:900; font-size:13px; color:#fff; margin-top:4px; letter-spacing:0.3px;">${shortName(s.code)}</div>
                <div class="rc-mono" style="font-size:24px; font-weight:900; color:${col}; text-shadow:0 0 12px ${col}55;">${s.total}</div>
                <div class="rc-mono" style="font-size:9px; color:#9BA7B2;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
            </div>`;
            el.innerHTML = `<div class="rc-duel">${side(A,colA,win===A.code)}<div class="rc-duel-vs">VS</div>${side(B,colB,win===B.code)}</div>
                <div class="rc-tug"><div style="width:${aPct}%; background:${colA}; transition:width 0.9s;"></div><div style="width:${bPct}%; background:${colB}; transition:width 0.9s;"></div></div>
                <div style="display:flex; justify-content:space-between; font-size:10px; color:#9BA7B2; margin-top:5px;" class="rc-mono"><span>${aPct}%</span><span>Vorsprung: ${Math.abs(A.total-B.total)}</span><span>${bPct}%</span></div>`;
            return;
        }
        // Ranking-Ansicht
        let html = '';
        arr.forEach((s, i) => {
            const col = colOf(s.code);
            html += `<div class="rc-list-item" style="padding:7px 10px; border-left:3px solid ${col}; ${i===0?'background:rgba(255,178,0,0.06);':''}">
                <div class="rc-rank-badge ${rankClass(i)}">${i+1}</div>
                <div style="display:flex; align-items:center;">${getFlagSvg(s.code,'small',i===0)}</div>
                <div style="flex:1; margin-left:4px;">
                    <div style="font-family:'Nunito'; font-weight:900; font-size:12.5px; color:#fff;">${shortName(s.code)}</div>
                    <div class="rc-mono" style="font-size:9px; color:#9BA7B2;">KIP ${s.kip} · MOB ${s.mob} · VVL ${s.vvl}</div>
                </div>
                <div class="rc-mono" style="font-size:17px; font-weight:900; color:${col};">${s.total}</div>
            </div>`;
        });
        el.innerHTML = html;
    }

    function renderProducts(sheetData, idx){
        const counts = {};
        for (let i=1;i<sheetData.length;i++){ const r=sheetData[i]; if(!r) continue;
            const pg=(r[idx.prod]||'').toString().trim(), anz=parseInt(r[idx.anz])||0, erg=(r[idx.erg]||'').toString().toLowerCase();
            if (anz>0 && erg.includes('angenommen') && pg) counts[pg]=(counts[pg]||0)+anz; // nur echte Abschluesse
        }
        const top = Object.entries(counts).sort((a,b) => b[1]-a[1]).slice(0,6);
        const max = top.length ? top[0][1] : 1;
        let html = '';
        top.forEach(([name,cnt], i) => {
            html += `<div style="margin-bottom:7px;">
                <div style="display:flex; justify-content:space-between; font-size:11px; margin-bottom:2px;">
                    <span style="font-weight:bold; color:#E9ECF0; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:78%;" title="${name}">${i+1}. ${name}</span>
                    <span class="rc-mono" style="color:var(--rc-cyan);">${cnt}x</span>
                </div>
                <div class="rc-bar-track"><div class="rc-bar-fill" style="background:linear-gradient(90deg,var(--rc-blue),var(--rc-cyan)); width:${Math.max(4,cnt/max*100)}%;"></div></div>
            </div>`;
        });
        const el = document.getElementById('rcTopProductsList');
        el.innerHTML = html || `<div style="color:#888; font-size:11px;">Keine Daten</div>`;
    }

    // Gemeinsame EKG-Monitor-Optik fuer die beiden Verlaufscharts
    const RC_EKG_OPTS = (yTitle) => ({ responsive:true, maintainAspectRatio:false, interaction:{mode:'index',intersect:false},
        animation:{ duration:800, easing:'linear' },
        plugins:{ legend:{ position:'top', labels:{ color:'#cfd8e3', boxWidth:9, usePointStyle:true, font:{size:9.5} } },
            tooltip:{ backgroundColor:'#12161d', borderColor:'rgba(44,87,210,0.4)', borderWidth:1 } },
        scales:{
            x:{ grid:{color:'rgba(0,217,255,0.04)'}, ticks:{color:'#8b98a5', font:{size:8.5}} },
            y:{ position:'left', grid:{color:'rgba(0,217,255,0.07)'}, ticks:{color:'#8b98a5', font:{size:8.5}, precision:0},
                title:{display:!!yTitle, text:yTitle||'', color:'#5a6b7d', font:{size:8.5}} }
        } });

    function renderTrend(hourLabels, trendByStd, anspTrend){
        // Abschluesse je STANDORT (kumulierte Linien) + Ansprachen/h als Balken.
        // Bei aktivem Filter enthaelt trendByStd nur die gefilterten Standorte.
        const cum = a => a.reduce((acc,v,i) => { acc.push((acc[i-1]||0)+v); return acc; }, []);
        const ctx = document.getElementById('rcTrendChart');
        if (!ctx || !window.Chart) return;
        const codes = ORDER.filter(c => trendByStd[c] && trendByStd[c].some(v => v > 0));
        const ds = [{ type:'bar', label:'Ansprachen/h', data:(anspTrend||[]), backgroundColor:'rgba(44,87,210,0.30)',
                      borderRadius:2, yAxisID:'y1', order:5 }];
        codes.forEach(c => {
            const m = STANDORT_METADATA[c];
            ds.push({ type:'line', label:shortName(c), data:cum(trendByStd[c]), borderColor:m.color,
                backgroundColor:'transparent', borderWidth:2, tension:0, pointRadius:0, pointHoverRadius:4, yAxisID:'y', order:1 });
        });
        if (window.rcChartInstance && (window.rcChartInstance.canvas !== ctx || window.rcChartInstance.data.datasets.length !== ds.length)) {
            try { window.rcChartInstance.destroy(); } catch(e){}
            window.rcChartInstance = null;
        }
        if (window.rcChartInstance) {
            window.rcChartInstance.data.labels = hourLabels;
            window.rcChartInstance.data.datasets.forEach((d,i) => { d.data = ds[i].data; d.label = ds[i].label; if (ds[i].borderColor) d.borderColor = ds[i].borderColor; });
            window.rcChartInstance.update();
        } else {
            const opts = RC_EKG_OPTS('Abschluesse (kum.)');
            opts.scales.y.beginAtZero = true;
            opts.scales.y1 = { position:'right', grid:{display:false}, ticks:{color:'rgba(44,87,210,0.8)', font:{size:8.5}, precision:0}, beginAtZero:true };
            window.rcChartInstance = new Chart(ctx, { data:{ labels:hourLabels, datasets:ds }, options:opts });
        }
    }

    // TNPS-Historie: bei jedem KPI-Batch ein Snapshot je Standort (max 72 Punkte = 6 Std)
    window.rcTnpsHistory = window.rcTnpsHistory || [];
    window.rcCaptureTnpsSnapshot = function(){
        const list = Object.values(window.rcKpiData || {});
        if (!list.length) return;
        const per = {};
        list.forEach(k => {
            if (k.tnps == null) return;
            const c = normalizeStandort(k.standort);
            (per[c] || (per[c] = [])).push(k.tnps);
        });
        const snap = { t: new Date().toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}), v: {} };
        Object.entries(per).forEach(([c, arr]) => snap.v[c] = +(arr.reduce((s,x)=>s+x,0)/arr.length).toFixed(1));
        const last = window.rcTnpsHistory[window.rcTnpsHistory.length-1];
        if (last && last.t === snap.t) window.rcTnpsHistory[window.rcTnpsHistory.length-1] = snap;
        else window.rcTnpsHistory.push(snap);
        if (window.rcTnpsHistory.length > 72) window.rcTnpsHistory.shift();
    };

    window.renderTnpsChart = function(){
        const ctx = document.getElementById('rcTnpsChart');
        if (!ctx || !window.Chart) return;
        const hist = window.rcTnpsHistory;
        const filterVal = document.getElementById('rcStandortFilter').value;
        const labels = hist.map(h => h.t);
        let codes = ORDER.filter(c => hist.some(h => h.v[c] != null));
        if (filterVal !== 'ALL') codes = codes.filter(c => c === filterVal); // Filter -> nur dieser Standort
        const pr = hist.length < 3 ? 3 : 0; // bei wenigen Snapshots Punkte zeigen, sonst waere nichts sichtbar
        const ds = codes.map(c => ({ type:'line', label:shortName(c), data:hist.map(h => h.v[c] != null ? h.v[c] : null),
            borderColor:STANDORT_METADATA[c].color, backgroundColor:'transparent', borderWidth:2, tension:0,
            pointRadius:pr, pointHoverRadius:4, spanGaps:true }));
        if (window.rcTnpsChartInstance && (window.rcTnpsChartInstance.canvas !== ctx || window.rcTnpsChartInstance.data.datasets.length !== ds.length)) {
            try { window.rcTnpsChartInstance.destroy(); } catch(e){}
            window.rcTnpsChartInstance = null;
        }
        if (!ds.length) return;
        if (window.rcTnpsChartInstance) {
            window.rcTnpsChartInstance.data.labels = labels;
            window.rcTnpsChartInstance.data.datasets.forEach((d,i) => { d.data = ds[i].data; d.label = ds[i].label; d.borderColor = ds[i].borderColor; });
            window.rcTnpsChartInstance.update();
        } else {
            const opts = RC_EKG_OPTS('TNPS %');
            opts.scales.y.suggestedMin = -20; opts.scales.y.suggestedMax = 100;
            window.rcTnpsChartInstance = new Chart(ctx, { data:{ labels, datasets:ds }, options:opts });
        }
    };

    function addTicker(code, name, prod, time){
        const t = document.getElementById('rcTickerList'); if (!t) return;
        if (t.innerText.includes('Lade') || t.innerText.includes('Warte')) t.innerHTML = '';
        const item = document.createElement('div');
        item.className = 'rc-list-item';
        item.style.borderLeft = /KIP BNT|MOBILFUNK/i.test(prod) ? '3px solid var(--rc-yellow)' : '3px solid var(--rc-green)';
        item.innerHTML = `<span style="color:#6b7785; font-family:monospace;">[${time}]</span>
            <span><b>${getFlagSvg(code,'small')} ${name} <span class="rc-mono" style="color:#9BA7B2; font-size:10px; font-weight:normal;">(${code})</span></b> · <span style="color:#ddd;">${prod}</span></span>`;
        t.insertBefore(item, t.firstChild);
        while (t.children.length > 25) t.removeChild(t.lastElementChild);
    }

    // Laufband: ZUERST die Ansprachen-Alarme (wer telefoniert, aber nicht anspricht), dann Ablehnungsgruende
    function renderMarquee(){
        const el = document.getElementById('rcNewsMarquee');
        if (!el) return;
        const items = [];

        // 1) Ansprachen-Alarme (Calls aus Ligaliste vs. ESL-Ansprachen)
        if (window.rcLetzteStats) {
            const alarme = [];
            Object.values(window.rcLetzteStats.agentStats).forEach(ag => {
                const kpi = window.rcKpiForAgent(ag);
                if (!kpi || !kpi.callCount || kpi.callCount < 5) return;
                const anspr = ag.ansprachen || 0;
                const q = anspr / kpi.callCount;
                if (anspr === 0) alarme.push({ ag, kpi, anspr, q, hart: true });
                else if (kpi.callCount >= 10 && q < 0.2) alarme.push({ ag, kpi, anspr, q, hart: false });
            });
            alarme.sort((a,b) => a.q - b.q);
            alarme.slice(0, 8).forEach(x => {
                const txt = x.hart
                    ? `<span class="rc-mq-alarm">&#9650; <b>${x.ag.name}</b> (${x.ag.standort}) — ${x.kpi.callCount} Calls, noch keine Ansprache — jetzt proaktiv ansprechen</span>`
                    : `<span class="rc-mq-alarm">&#9650; <b>${x.ag.name}</b> (${x.ag.standort}) — nur ${Math.round(x.q*100)} % Ansprachequote bei ${x.kpi.callCount} Calls</span>`;
                items.push(txt);
            });
        }

        // 2) Ablehnungsgruende (bestehender Buffer)
        window.rcMarqueeBuffer.forEach(b => items.push(b));

        if (!items.length) return;
        const txt = items.join(' <span class="rc-mq-sep">+++</span> ');
        el.innerHTML = '<span class="rc-mq-sep">+++</span> ' + txt + ' <span class="rc-mq-sep">+++</span>';
        el.style.animationDuration = Math.max(70, Math.round(txt.replace(/<[^>]+>/g,'').length*0.14)) + 's';
    }
    window.renderMarquee = renderMarquee;

    function buildDynamicMoti(agentsArr, standortStats){
        const m = [];
        const top = agentsArr[0];
        if (top && top.total>0) m.push(`<b>${top.name}</b> fuehrt die Arena mit <b>${top.total}</b> Sales an`);
        const kipL = agentsArr.slice().sort((a,b)=>b.kip-a.kip)[0];
        if (kipL && kipL.kip>0) m.push(`KIP-Koenig: <b>${kipL.name}</b> mit <b>${kipL.kip}</b> KIP-BNT`);
        const mobL = agentsArr.slice().sort((a,b)=>b.mob-a.mob)[0];
        if (mobL && mobL.mob>0) m.push(`Mobilfunk-Held: <b>${mobL.name}</b> mit <b>${mobL.mob}</b> Abschluessen`);
        const stds = Object.values(standortStats).sort((a,b)=>b.bnt-a.bnt);
        if (stds[0] && stds[0].bnt>0) m.push(`Standort-Spitze: <b>${stds[0].name}</b> mit <b>${stds[0].bnt}</b> BNT`);

        // Qualitaets-Stars mit wenig Abschluessen: gute CS/TNPS = Vertrauen ist da -> zur Ansprache ermutigen
        const qualiTemplates = [
            (n, kv) => `<b>${n}</b>, ${kv} — deine Kunden vertrauen dir. Genau jetzt ist der Moment fuer den Abschluss!`,
            (n, kv) => `<b>${n}</b>, ${kv} — so eine Beratung verdient einen Abschluss. Trau dich, mach die Ansprache!`,
            (n, kv) => `Respekt, <b>${n}</b>: ${kv}. Wer so ueberzeugt, verkauft auch — der naechste Call gehoert dir!`,
            (n, kv) => `<b>${n}</b>, deine Gespraechsqualitaet ist top (${kv}). Der Abschluss ist nur noch einen Satz entfernt!`
        ];
        let qi = 0;
        agentsArr.forEach(ag => {
            if (qi >= 3 || (ag.total || 0) > 1) return;
            const kpi = window.rcKpiForAgent(ag);
            if (!kpi || !kpi.callCount || kpi.callCount < 8) return;
            const parts = [];
            if (kpi.cs != null && kpi.cs >= 85) parts.push(`CS <b>${kpi.cs.toFixed(0)} %</b>`);
            if (kpi.tnps != null && kpi.tnps >= 60) parts.push(`TNPS <b>${kpi.tnps.toFixed(0)} %</b>`);
            if (!parts.length) return;
            m.push(qualiTemplates[qi % qualiTemplates.length](ag.name, parts.join(' und ')));
            qi++;
        });
        window.rcDynamicMoti = m;
    }

    // ============================================================
    //  DATEN-PIPELINE (unveraendert bewaehrt aus v20)
    // ============================================================
    function verarbeiteExcelBuffer(arrayBuffer){
        if (!window.XLSX) { rcLog.error('XLSX nicht geladen.'); return; }
        try {
            const wb = XLSX.read(new Uint8Array(arrayBuffer), { type:'array' });
            const sn = wb.SheetNames[0]; if (!sn) return;
            const ws = wb.Sheets[sn]; if (!ws) return;
            const data = XLSX.utils.sheet_to_json(ws, { header:1 });
            if (!data || !data.length) return;
            window.processDataStream(data);
        } catch(e){ rcLog.error('Excel-Verarbeitung fehlgeschlagen:', e); }
    }

    async function holeExcelVomServer(){
        rcLog.log('--- Aktualisierungszyklus (20s) ---');
        try {
            const form = document.getElementById('filterForm');
            if (!form) {
                rcLog.error("Formular 'filterForm' nicht gefunden.");
                const s = document.getElementById('rcFetchStatus'); if (s) s.textContent = 'kein Datenformular gefunden';
                showWarn('Kein "filterForm" auf dieser Seite — bitte das Script auf der ESL-Seite "Projektergebnisse" (mit von/bis und Excel-Export) einfuegen.');
                return;
            }
            const buttons = Array.from(form.querySelectorAll('button[type="submit"], input[type="submit"]'));

            // 1. Suche/Filter ausloesen, um Backend-DataModel zu erneuern
            const searchBtn = buttons.find(b => /suchen|aktualisieren|filtern|anzeigen/.test((b.innerText||b.value||'').toLowerCase()));
            if (searchBtn) {
                const sid = searchBtn.id || searchBtn.name;
                if (sid) {
                    const sd = new FormData(form);
                    sd.append(sid, sid);
                    sd.append('javax.faces.partial.ajax','true');
                    sd.append('javax.faces.source', sid);
                    sd.append('javax.faces.partial.execute','filterForm data');
                    sd.append('javax.faces.partial.render','filterForm data');
                    try {
                        const resp = await fetch(form.action || window.location.href, { method:'POST', body:sd,
                            headers:{ 'Faces-Request':'partial/ajax', 'X-Requested-With':'XMLHttpRequest' } });
                        const txt = await resp.text();
                        const vs = txt.match(/<update id="[^"]*javax\.faces\.ViewState[^"]*"><!\[CDATA\[(.*?)\]\]><\/update>/) ||
                                   txt.match(/name="javax\.faces\.ViewState".*?value="([^"]+)"/);
                        if (vs && vs[1]) { const old = form.querySelector('input[name="javax.faces.ViewState"]'); if (old) old.value = vs[1]; }
                    } catch(e){ rcLog.error('Fehler bei Such-Aktualisierung:', e); }
                }
            }

            // 2. Excel-Export ausloesen (mit aktualisiertem ViewState)
            const formData = new FormData(form);
            const exportBtn = buttons.find(b => { const t=(b.innerText||b.value||'').toLowerCase(); return t.includes('excel')||t.includes('export')||(b.innerHTML||'').toLowerCase().includes('excel'); });
            const btnId = exportBtn ? (exportBtn.id || exportBtn.name) : 'filterForm:j_idt517';
            if (btnId) formData.append(btnId, btnId);

            const response = await fetch(form.action || window.location.href, { method:'POST', body:formData });
            if (response.ok) { verarbeiteExcelBuffer(await response.arrayBuffer()); }
            else rcLog.error('Server-Fehler beim Excel-Abruf. HTTP', response.status);
        } catch(e){ rcLog.error('Kritischer Fehler beim Datenabruf:', e); }
    }

    // ============================================================
    //  BOOT
    // ============================================================
    rcLog.log('Lade externe Bibliotheken...');
    Promise.all([
        ladeBibliothek('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', 'XLSX'),
        ladeBibliothek('https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js', 'confetti'),
        ladeBibliothek('https://cdn.jsdelivr.net/npm/chart.js', 'Chart')
    ]).then(() => {
        rcLog.log('Bibliotheken bereit. Starte Live-Crawl (20s)...');
        window.rcLiveInterval = setInterval(holeExcelVomServer, 20000);
        holeExcelVomServer();
    }).catch(err => {
        rcLog.error('Fehler beim Start:', err);
        window.rcLiveInterval = setInterval(holeExcelVomServer, 20000);
        holeExcelVomServer();
    });

    return '+++ regiocom esl live-arena v21.0 gestartet +++';
})();
